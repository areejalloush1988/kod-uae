-- The requested owner may sign in through confirmed email or verified Google.
-- auth.users confirmation is server-owned; user_metadata never grants roles.
begin;
create or replace function kod_private.kod_verified_owner_identity() returns trigger language plpgsql security definer set search_path=''
as $$begin
 if lower(coalesce(new.identity_data->>'email',''))='areejalloush1988@gmail.com'
 and (new.provider='email' or (new.provider='google' and new.identity_data->>'email_verified'='true'))
 and exists(select 1 from auth.users u where u.id=new.user_id and lower(u.email)='areejalloush1988@gmail.com' and u.email_confirmed_at is not null)
 then
  insert into kod_private.kod_account_roles(user_id,role) values(new.user_id,'developer') on conflict(user_id) do update set role='developer';
  update public.kod_profiles set account_role='developer' where id=new.user_id;
 end if;
 return new;
end$$;
create or replace function kod_private.kod_verified_owner_confirmation() returns trigger language plpgsql security definer set search_path=''
as $$begin
 if lower(coalesce(new.email,''))='areejalloush1988@gmail.com' and new.email_confirmed_at is not null
 and exists(select 1 from auth.identities i where i.user_id=new.id
 and lower(coalesce(i.identity_data->>'email',''))='areejalloush1988@gmail.com'
 and (i.provider='email' or (i.provider='google' and i.identity_data->>'email_verified'='true'))) then
  insert into kod_private.kod_account_roles(user_id,role) values(new.id,'developer') on conflict(user_id) do update set role='developer';
  update public.kod_profiles set account_role='developer' where id=new.id;
 end if;
 return new;
end$$;
-- Supabase's automatic RLS event trigger does not need public RPC access.
do $$begin
 if to_regprocedure('public.rls_auto_enable()') is not null then
  revoke execute on function public.rls_auto_enable() from public,anon,authenticated;
 end if;
end$$;
commit;

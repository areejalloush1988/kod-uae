begin;

alter table public.kod_memberships add column activation_requested_at timestamptz;
alter table public.kod_restaurants add column instore_percent smallint not null default 0 check (instore_percent between 0 and 70);

create table kod_private.kod_member_cards (
 user_id uuid primary key references auth.users(id) on delete cascade,
 card_number text not null unique check (card_number ~ '^[0-9]{16}$' and card_number <> '0000000000000000')
);
alter table kod_private.kod_member_cards enable row level security;
revoke all on kod_private.kod_member_cards from public, anon, authenticated;

create table public.kod_instore_receipts (
 id uuid primary key default gen_random_uuid(), request_id uuid not null unique,
 customer_id uuid not null references auth.users(id) on delete cascade,
 restaurant_id uuid not null references public.kod_restaurants(id), restaurant_name text not null,
 business_day date not null, invoice_ref text not null check (char_length(invoice_ref) between 1 and 48),
 bill_cents integer not null check (bill_cents between 1 and 99999999),
 percent smallint not null check (percent between 1 and 70),
 discount_cents integer not null check (discount_cents = round(bill_cents::numeric * percent / 100)),
 net_cents integer generated always as (bill_cents-discount_cents) stored,
 created_at timestamptz not null default now(), unique(restaurant_id,business_day,invoice_ref)
);
create index kod_instore_member_history on public.kod_instore_receipts(customer_id,created_at desc);
create index kod_instore_branch_history on public.kod_instore_receipts(restaurant_id,created_at desc);
alter table public.kod_instore_receipts enable row level security;
revoke all on public.kod_instore_receipts from public, anon, authenticated;
grant select (id,customer_id,restaurant_id,restaurant_name,business_day,invoice_ref,bill_cents,percent,discount_cents,net_cents,created_at) on public.kod_instore_receipts to authenticated;
create policy kod_instore_receipt_read on public.kod_instore_receipts for select to authenticated
 using (customer_id=(select auth.uid()) or kod_private.kod_owns_restaurant(restaurant_id) or (select kod_private.kod_is_developer()));

create function kod_private.kod_member_card(p_request boolean) returns jsonb
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); serial text; holder text; m public.kod_memberships%rowtype;
begin
 if actor is null or kod_private.kod_role() is distinct from 'customer' then raise exception 'member_required'; end if;
 select * into m from public.kod_memberships where user_id=actor for update;
 if not found then raise exception 'membership_missing'; end if;
 if p_request and (m.status<>'active' or m.expires_at is null or m.expires_at<=now()) and m.activation_requested_at is null then
  update public.kod_memberships set activation_requested_at=now() where user_id=actor returning * into m;
 end if;
 select card_number into serial from kod_private.kod_member_cards where user_id=actor;
 while serial is null loop
  insert into kod_private.kod_member_cards(user_id,card_number)
  select actor,lpad((('x'||right(replace(gen_random_uuid()::text,'-',''),15))::bit(60)::bigint % 9999999999999999 + 1)::text,16,'0')
  on conflict do nothing returning card_number into serial;
  if serial is null then select card_number into serial from kod_private.kod_member_cards where user_id=actor; end if;
 end loop;
 select nullif(trim(full_name),'') into holder from public.kod_profiles where id=actor;
 return jsonb_build_object('number',serial,'name',coalesce(holder,'عضو كود'),'status',m.status,'expires_at',m.expires_at,'requested_at',m.activation_requested_at);
end $$;

create function kod_private.kod_set_member_access(p_member uuid,p_active boolean,p_ends_on date) returns void
language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not kod_private.kod_is_developer() then raise exception 'operator_required'; end if;
 if p_active is null or (p_active and (p_ends_on is null or p_ends_on<(now() at time zone 'Asia/Dubai')::date or not isfinite(p_ends_on))) then raise exception 'invalid_end_date'; end if;
 if not exists(select 1 from kod_private.kod_account_roles where user_id=p_member and role='customer') then raise exception 'member_required';end if;
 update public.kod_memberships set status=case when p_active then 'active' else 'cancelled' end,
  expires_at=case when p_active then ((p_ends_on+1)::timestamp at time zone 'Asia/Dubai') else now() end,
  activation_requested_at=null where user_id=p_member;
 if not found then raise exception 'membership_missing'; end if;
end $$;

create function kod_private.kod_set_instore_rate(p_restaurant_id uuid,p_percent integer) returns void
language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not (kod_private.kod_is_developer() or (coalesce(kod_private.kod_role(),'')='merchant' and kod_private.kod_owns_restaurant(p_restaurant_id))) then raise exception 'branch_required'; end if;
 if p_percent is null or p_percent not between 0 and 70 then raise exception 'invalid_rate'; end if;
 update public.kod_restaurants set instore_percent=p_percent where id=p_restaurant_id and approved and not is_demo;
 if not found then raise exception 'branch_required'; end if;
end $$;

create function kod_private.kod_instore_bill(p_restaurant_id uuid,p_card_number text,p_bill_cents integer,p_invoice text,p_request_id uuid,p_expected_percent integer) returns jsonb
language plpgsql security definer set search_path='' as $$
declare
 branch public.kod_restaurants%rowtype; member_id uuid; membership public.kod_memberships%rowtype; receipt public.kod_instore_receipts%rowtype;
 reference text:=upper(trim(p_invoice)); business_date date:=(now() at time zone 'Asia/Dubai')::date; saving integer; result jsonb;
begin
 if auth.uid() is null or not (kod_private.kod_is_developer() or (coalesce(kod_private.kod_role(),'')='merchant' and kod_private.kod_owns_restaurant(p_restaurant_id))) then raise exception 'branch_required'; end if;
 if p_bill_cents is null or p_bill_cents not between 1 and 99999999 or reference is null or char_length(reference) not between 1 and 48 or reference ~ '[[:cntrl:]]' then raise exception 'invalid_invoice'; end if;
 if p_card_number is null or p_card_number !~ '^[0-9]{16}$' then raise exception 'card_unavailable'; end if;
 select user_id into member_id from kod_private.kod_member_cards where card_number=p_card_number;
 if not found then raise exception 'card_unavailable'; end if;
 if p_request_id is not null then
  perform pg_advisory_xact_lock(hashtextextended(p_request_id::text,0));
  select * into receipt from public.kod_instore_receipts where request_id=p_request_id;
  if found then
   if receipt.restaurant_id<>p_restaurant_id or receipt.customer_id<>member_id or receipt.bill_cents<>p_bill_cents or receipt.invoice_ref<>reference then raise exception 'request_mismatch'; end if;
   return jsonb_build_object('id',receipt.id,'restaurant_name',receipt.restaurant_name,'invoice_ref',receipt.invoice_ref,'bill_cents',receipt.bill_cents,'percent',receipt.percent,'discount_cents',receipt.discount_cents,'net_cents',receipt.net_cents);
  end if;
 end if;
 select * into branch from public.kod_restaurants where id=p_restaurant_id for share;
 if not found or not branch.approved or branch.is_demo or branch.instore_percent=0 then raise exception 'branch_unavailable'; end if;
 select * into membership from public.kod_memberships where user_id=member_id for share;
 if not found or membership.status<>'active' or membership.expires_at is null or membership.expires_at<=clock_timestamp() then raise exception 'card_unavailable'; end if;
 if exists(select 1 from public.kod_instore_receipts where restaurant_id=p_restaurant_id and business_day=business_date and invoice_ref=reference) then raise exception 'invoice_already_used'; end if;
 saving:=round(p_bill_cents::numeric*branch.instore_percent/100);
 result:=jsonb_build_object('restaurant_name',branch.name,'invoice_ref',reference,'bill_cents',p_bill_cents,'percent',branch.instore_percent,'discount_cents',saving,'net_cents',p_bill_cents-saving);
 if p_request_id is null then return result; end if;
 if p_expected_percent is distinct from branch.instore_percent then raise exception 'quote_changed'; end if;
 insert into public.kod_instore_receipts(request_id,customer_id,restaurant_id,restaurant_name,business_day,invoice_ref,bill_cents,percent,discount_cents)
 values(p_request_id,member_id,branch.id,branch.name,business_date,reference,p_bill_cents,branch.instore_percent,saving)
 on conflict (restaurant_id,business_day,invoice_ref) do nothing returning * into receipt;
 if not found then raise exception 'invoice_already_used'; end if;
 return result||jsonb_build_object('id',receipt.id);
end $$;

create function public.kod_member_card(p_request boolean default false) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_member_card(p_request)$$;
create function public.kod_set_member_access(p_member uuid,p_active boolean,p_ends_on date default null) returns void language sql security invoker set search_path='' as $$select kod_private.kod_set_member_access(p_member,p_active,p_ends_on)$$;
create function public.kod_set_instore_rate(p_restaurant_id uuid,p_percent integer) returns void language sql security invoker set search_path='' as $$select kod_private.kod_set_instore_rate(p_restaurant_id,p_percent)$$;
create function public.kod_instore_bill(p_restaurant_id uuid,p_card_number text,p_bill_cents integer,p_invoice text,p_request_id uuid default null,p_expected_percent integer default null) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_instore_bill(p_restaurant_id,p_card_number,p_bill_cents,p_invoice,p_request_id,p_expected_percent)$$;
revoke all on function kod_private.kod_member_card(boolean),kod_private.kod_set_member_access(uuid,boolean,date),kod_private.kod_set_instore_rate(uuid,integer),kod_private.kod_instore_bill(uuid,text,integer,text,uuid,integer),public.kod_member_card(boolean),public.kod_set_member_access(uuid,boolean,date),public.kod_set_instore_rate(uuid,integer),public.kod_instore_bill(uuid,text,integer,text,uuid,integer) from public,anon,authenticated;
grant execute on function kod_private.kod_member_card(boolean),kod_private.kod_set_member_access(uuid,boolean,date),kod_private.kod_set_instore_rate(uuid,integer),kod_private.kod_instore_bill(uuid,text,integer,text,uuid,integer),public.kod_member_card(boolean),public.kod_set_member_access(uuid,boolean,date),public.kod_set_instore_rate(uuid,integer),public.kod_instore_bill(uuid,text,integer,text,uuid,integer) to authenticated;
notify pgrst,'reload schema';
commit;

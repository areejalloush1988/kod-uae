begin;

create or replace function kod_private.kod_member_card(p_request boolean) returns jsonb
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); serial text; holder text; m public.kod_memberships%rowtype;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('customer','developer') then raise exception 'member_required'; end if;
 select * into m from public.kod_memberships where user_id=actor for update;
 if not found then
  insert into public.kod_memberships(user_id) values(actor) on conflict(user_id) do nothing;
  select * into strict m from public.kod_memberships where user_id=actor for update;
 end if;
 if p_request and (m.status<>'active' or m.expires_at is null or m.expires_at<=now()) and m.activation_requested_at is null then
  update public.kod_memberships set activation_requested_at=now() where user_id=actor returning * into m;
 end if;
 select card_number into serial from kod_private.kod_member_cards where user_id=actor;
 while serial is null loop
  insert into kod_private.kod_member_cards(user_id,card_number)
  select actor,lpad((('x'||right(replace(gen_random_uuid()::text,'-',''),15))::bit(60)::bigint % 9999999999999999 + 1)::text,16,'0')
  on conflict do nothing returning card_number into serial;
  if serial is null then select card_number into serial from kod_private.kod_member_cards where user_id=actor; end if;
 end loop;
 select nullif(trim(full_name),'') into holder from public.kod_profiles where id=actor;
 return jsonb_build_object('number',serial,'name',coalesce(holder,'عضو كود'),'status',m.status,'expires_at',m.expires_at,'requested_at',m.activation_requested_at);
end $$;

create or replace function kod_private.kod_set_member_access(p_member uuid,p_active boolean,p_ends_on date) returns void
language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not kod_private.kod_is_developer() then raise exception 'operator_required'; end if;
 if p_active is null or (p_active and (p_ends_on is null or p_ends_on<(now() at time zone 'Asia/Dubai')::date or not isfinite(p_ends_on))) then raise exception 'invalid_end_date'; end if;
 if p_member is null or (p_member<>auth.uid() and not exists(select 1 from kod_private.kod_account_roles where user_id=p_member and role='customer')) then raise exception 'member_required';end if;
 update public.kod_memberships set status=case when p_active then 'active' else 'cancelled' end,
  expires_at=case when p_active then ((p_ends_on+1)::timestamp at time zone 'Asia/Dubai') else now() end,
  activation_requested_at=null where user_id=p_member;
 if not found then raise exception 'membership_missing'; end if;
end $$;

notify pgrst, 'reload schema';
commit;

begin;
-- The four original prices are also the fixed carrier products used by older clients.
create table public.kod_membership_prices (
 tier text not null check(tier in ('bronze','silver','gold')),
 months smallint not null check(months in (1,3,6,12)),
 amount_fils integer check(amount_fils between 1 and 9999999),
 legacy_fils integer check(legacy_fils>0),
 primary key(tier,months)
);
insert into public.kod_membership_prices(tier,months,amount_fils,legacy_fils)
select tier,months,amount,amount from (
 select tier,months,case
   when tier='bronze' and months=1 then 6900 when tier='silver' and months=3 then 18900
   when tier='gold' and months=6 then 35900 when tier='gold' and months=12 then 59900 end as amount
 from unnest(array['bronze','silver','gold']) tier cross join unnest(array[1,3,6,12]) months
) pairs;
create unique index kod_legacy_membership_term on public.kod_membership_prices(months) where legacy_fils is not null;
alter table public.kod_membership_prices enable row level security;
revoke all on public.kod_membership_prices from public,anon,authenticated,service_role;
grant select on public.kod_membership_prices to anon,authenticated,service_role;
create policy kod_published_membership_prices on public.kod_membership_prices for select to anon,authenticated using(true);
create function public.kod_membership_catalog() returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_agg(jsonb_build_object('tier',tier,'months',months,'amount_fils',amount_fils,
    'carrier_allowed',coalesce(amount_fils=legacy_fils,false)) order by tier,months) from public.kod_membership_prices
$$;
revoke all on function public.kod_membership_catalog() from public,anon,authenticated;
grant execute on function public.kod_membership_catalog() to anon,authenticated,service_role;

create function kod_private.kod_set_membership_prices(p_changes jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
declare change jsonb; current_price integer; new_price integer; before_price integer; term integer; entry_tier text; seen text[]:='{}'; pair text;
begin
 if auth.uid() is null or not coalesce(kod_private.kod_is_developer(),false) then raise exception 'operator_required';end if;
 if jsonb_typeof(p_changes) is distinct from 'array' then raise exception 'invalid_prices';end if;
 if jsonb_array_length(p_changes) not between 1 and 12 then raise exception 'invalid_prices';end if;
 -- Serialize administrative patches. Each field must still hold the price originally displayed.
 perform pg_advisory_xact_lock(74123,18018);
 for change in select value from jsonb_array_elements(p_changes) order by value->>'tier',value->>'months' loop
  if jsonb_typeof(change) is distinct from 'object' or not (change ?& array['tier','months','previous_fils','amount_fils']) or (change - array['tier','months','previous_fils','amount_fils']) <> '{}'::jsonb then raise exception 'invalid_prices';end if;
  entry_tier:=change->>'tier';
  if coalesce(entry_tier,'') not in ('bronze','silver','gold') or coalesce(change->>'months','') not in ('1','3','6','12')
   or jsonb_typeof(change->'months')<>'number' then raise exception 'invalid_prices';end if;
  if exists(select from jsonb_each(change) kv where kv.key in('amount_fils','previous_fils') and kv.value<>'null'::jsonb
    and (jsonb_typeof(kv.value)<>'number' or kv.value::text !~ '^[1-9][0-9]{0,6}$')) then raise exception 'invalid_prices';end if;
  term:=(change->>'months')::integer;pair:=entry_tier||'/'||term;
  if pair=any(seen) then raise exception 'invalid_prices';end if;seen:=array_append(seen,pair);
  select amount_fils into strict current_price from public.kod_membership_prices where tier=entry_tier and months=term for update;
  before_price:=(change->>'previous_fils')::integer;new_price:=(change->>'amount_fils')::integer;
  if before_price is distinct from current_price then raise exception 'price_conflict';end if;
  update public.kod_membership_prices set amount_fils=new_price where tier=entry_tier and months=term;
 end loop;
 return public.kod_membership_catalog();
end $$;
create function public.kod_set_membership_prices(p_changes jsonb) returns jsonb language sql security invoker set search_path='' as $$
 select kod_private.kod_set_membership_prices(p_changes) $$;

-- Retain existing generated values, then allow independent tiers for future paid orders.
alter table public.kod_subscription_orders alter column club_tier drop expression, alter column club_tier set not null;
alter table public.kod_subscription_orders add constraint kod_order_membership_plan foreign key(club_tier,months)
 references public.kod_membership_prices(tier,months);
alter table kod_private.kod_member_invoices add column club_tier text;
update kod_private.kod_member_invoices b set club_tier=c.tier from public.kod_membership_prices c
 where c.months=b.months and c.legacy_fils is not null and b.club_tier is null;
alter table kod_private.kod_member_invoices alter column club_tier set not null,
 add constraint kod_invoice_membership_plan foreign key(club_tier,months) references public.kod_membership_prices(tier,months);
drop index kod_private.kod_open_member_invoice;
create unique index kod_open_member_invoice on kod_private.kod_member_invoices(member_id,club_tier,months) where status in('requested','invoiced');

create function kod_private.kod_request_plan_invoice(p_tier text,p_months integer,p_request uuid,p_expected_fils integer)
returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); quoted integer; bill kod_private.kod_member_invoices%rowtype;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('customer','developer') then raise exception 'member_required';end if;
 if p_request is null or p_expected_fils is null or p_expected_fils<=0 then raise exception 'invalid_amount';end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,35123));
 select * into bill from kod_private.kod_member_invoices where member_id=actor and request_id=p_request;
 if found then
  if bill.club_tier is distinct from p_tier or bill.months is distinct from p_months or bill.amount_fils is distinct from p_expected_fils then raise exception 'request_mismatch';end if;
  return bill.id;
 end if;
 select amount_fils into quoted from public.kod_membership_prices where tier=p_tier and months=p_months for share;
 if quoted is null then raise exception 'price_unset';end if;
 if quoted<>p_expected_fils then raise exception 'price_changed';end if;
 select * into bill from kod_private.kod_member_invoices where member_id=actor and club_tier=p_tier and months=p_months and status in('requested','invoiced');
 if found then
  if bill.amount_fils<>p_expected_fils then raise exception 'invoice_open';end if;
  return bill.id;
 end if;
 insert into kod_private.kod_member_invoices(member_id,request_id,club_tier,months,amount_fils)
 values(actor,p_request,p_tier,p_months,quoted) returning * into bill;
 return bill.id;
end $$;
create function public.kod_request_plan_invoice(p_tier text,p_months integer,p_request uuid,p_expected_fils integer)
returns uuid language sql security invoker set search_path='' as $$
 select kod_private.kod_request_plan_invoice(p_tier,p_months,p_request,p_expected_fils) $$;
-- Older clients are bound to the tier and amount they actually displayed.
create or replace function kod_private.kod_member_invoice_request(p_months integer,p_request uuid,p_expected_fils integer)
returns uuid language plpgsql security definer set search_path='' as $$
declare old_plan public.kod_membership_prices%rowtype;
begin
 select * into old_plan from public.kod_membership_prices where months=p_months and legacy_fils is not null;
 if not found or old_plan.legacy_fils is distinct from p_expected_fils then raise exception 'invalid_amount';end if;
 return kod_private.kod_request_plan_invoice(old_plan.tier,p_months,p_request,p_expected_fils);
end $$;
create or replace function kod_private.kod_member_invoice_desk() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare actor uuid:=auth.uid(); admin boolean:=kod_private.kod_is_developer();
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('customer','developer') then raise exception 'member_required';end if;
 return jsonb_build_object('invoices',coalesce((select jsonb_agg(jsonb_build_object('id',b.id,'name',coalesce(nullif(p.full_name,''),'عضو كود'),
   'mine',b.member_id=actor,'club_tier',b.club_tier,'months',b.months,'amount_fils',b.amount_fils,'state',b.status,'asked',b.requested_at,'invoiced',b.invoiced_at,
   'note',b.payment_note,'url',b.payment_url,'review_note',b.review_note,'starts',o.valid_from,'ends',o.valid_until)
   order by b.requested_at desc,b.id) from kod_private.kod_member_invoices b join public.kod_profiles p on p.id=b.member_id
   left join public.kod_subscription_orders o on o.id=b.paid_order where b.member_id=actor or admin),'[]'::jsonb));
end $$;
create or replace function kod_private.kod_member_invoice_update(p_id uuid,p_action text,p_note text,p_url text,p_fils integer,p_reference text) returns void
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); admin boolean:=kod_private.kod_is_developer(); b kod_private.kod_member_invoices%rowtype;
 note text:=trim(coalesce(p_note,''));url text:=trim(coalesce(p_url,''));ref text:=trim(coalesce(p_reference,''));o uuid; target text;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('customer','developer') then raise exception 'member_required';end if;
 if not admin and p_action is distinct from 'close' then raise exception 'operator_required';end if;
 select * into b from kod_private.kod_member_invoices where id=p_id and (admin or member_id=actor) for update;
 if not found then raise exception 'booking_changed';end if;
 if p_action='invoice' then
  if b.status not in('requested','invoiced') then raise exception 'booking_changed';end if;
  if not kod_private.kod_invoice_details_ok(note,url) then raise exception 'invalid_invoice';end if;
  update kod_private.kod_member_invoices set status='invoiced',payment_note=nullif(note,''),payment_url=nullif(url,''),invoiced_at=coalesce(invoiced_at,clock_timestamp()) where id=p_id;
 elsif p_action='settle' then
  if p_fils is distinct from b.amount_fils then raise exception 'amount_mismatch';end if;
  if length(ref) not between 3 and 100 or ref ~ '[[:cntrl:]]' then raise exception 'invalid_reference';end if;
  if b.status='paid' and upper(b.payment_reference)=upper(ref) then return;end if;
  if b.status<>'invoiced' then raise exception 'booking_changed';end if;
  insert into kod_private.kod_manual_payments values(upper(ref),p_id,'member');
  insert into public.kod_subscription_orders(user_id,request_id,club_tier,months,amount_fils,rail,checkout_ref)
   values(b.member_id,b.id,b.club_tier,b.months,b.amount_fils,'invoice','KOD-INV-'||b.id) returning id into o;
  perform public.kod_settle_subscription(o,'invoice','KOD-INV-'||b.id,'KOD-INV-'||b.id,'','AED',b.amount_fils);
  update kod_private.kod_member_invoices set status='paid',paid_at=clock_timestamp(),paid_order=o,payment_reference=ref where id=p_id;
 elsif p_action='close' then
  target:=case when admin then 'declined' else 'cancelled' end;
  if b.status=target then return;end if;
  if b.status not in('requested','invoiced') or (not admin and b.status='invoiced') then raise exception 'booking_changed';end if;
  if admin and length(note) not between 2 and 220 then raise exception 'reason_required';end if;
  update kod_private.kod_member_invoices set status=target,review_note=case when admin then note end where id=p_id;
 else raise exception 'invalid_request';end if;
exception when unique_violation then raise exception 'duplicate_reference';
end $$;

-- Reserve the exact choice before opening the existing hosted payment service.
-- The same request ID carries the DB snapshot into its service-role preparation step.
create function kod_private.kod_reserve_membership_checkout(p_tier text,p_months integer,p_rail text,p_expected_fils integer,p_request uuid)
returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); item public.kod_subscription_orders%rowtype; plan public.kod_membership_prices%rowtype; moment timestamptz:=clock_timestamp();
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('customer','developer') then raise exception 'member_required';end if;
 if p_request is null or coalesce(p_rail,'') not in('stripe','etisalat','du') or p_expected_fils is null or p_expected_fils<=0 then raise exception 'invalid_plan';end if;
 if not coalesce((public.kod_subscription_methods()->p_rail) @> jsonb_build_array(p_months),false) then raise exception 'method_unavailable';end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,74123));
 select * into item from public.kod_subscription_orders where user_id=actor and request_id=p_request for update;
 if found then
  if item.club_tier is distinct from p_tier or item.months is distinct from p_months or item.rail<>p_rail or item.amount_fils<>p_expected_fils then raise exception 'request_mismatch';end if;
  return item.request_id;
 end if;
 select * into plan from public.kod_membership_prices where tier=p_tier and months=p_months for share;
 if plan.amount_fils is null then raise exception 'price_unset';end if;
 if plan.amount_fils<>p_expected_fils then raise exception 'price_changed';end if;
 if p_rail<>'stripe' and plan.legacy_fils is distinct from p_expected_fils then raise exception 'method_unavailable';end if;
 select * into item from public.kod_subscription_orders where user_id=actor and club_tier=p_tier and months=p_months
  and amount_fils=p_expected_fils and rail=p_rail and status='pending'
  and (checkout_until>moment+interval '1 minute' or (checkout_ref is null and created_at>moment-interval '15 minutes'))
  order by created_at desc limit 1 for update;
 if found then return item.request_id;end if;
 insert into public.kod_subscription_orders(user_id,request_id,club_tier,months,amount_fils,rail)
  values(actor,p_request,p_tier,p_months,p_expected_fils,p_rail);
 return p_request;
end $$;
create function public.kod_reserve_membership_checkout(p_tier text,p_months integer,p_rail text,p_expected_fils integer,p_request uuid)
returns uuid language sql security invoker set search_path='' as $$
 select kod_private.kod_reserve_membership_checkout(p_tier,p_months,p_rail,p_expected_fils,p_request) $$;

create or replace function public.kod_prepare_subscription(p_user uuid,p_request uuid,p_months integer,p_rail text,p_product text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare item public.kod_subscription_orders%rowtype; plan public.kod_membership_prices%rowtype; moment timestamptz:=clock_timestamp();
begin
 if p_user is null or p_request is null or coalesce(p_months,0) not in(1,3,6,12) or coalesce(p_rail,'') not in('stripe','etisalat','du')
   or p_product is null or (p_rail<>'stripe' and p_product !~ '^[0-9]+$') or (p_rail='stripe' and p_product<>'') then raise exception 'invalid_plan';end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user::text,74123));
 select * into item from public.kod_subscription_orders where user_id=p_user and request_id=p_request for update;
 if found then
  if item.months<>p_months or item.rail<>p_rail or (item.product_ref<>'' and item.product_ref<>p_product) then raise exception 'request_mismatch';end if;
 else
  -- A client without an explicit reservation can purchase only its original offer.
  select * into strict plan from public.kod_membership_prices where months=p_months and legacy_fils is not null;
  if plan.amount_fils is distinct from plan.legacy_fils then raise exception 'price_changed';end if;
  select * into item from public.kod_subscription_orders where user_id=p_user and club_tier=plan.tier and months=p_months
   and amount_fils=plan.legacy_fils and rail=p_rail and product_ref in('',p_product) and status='pending'
   and (checkout_until>moment+interval '1 minute' or (checkout_ref is null and created_at>moment-interval '15 minutes'))
   order by created_at desc limit 1 for update;
  if not found then
   insert into public.kod_subscription_orders(user_id,request_id,club_tier,months,amount_fils,rail,product_ref)
    values(p_user,p_request,plan.tier,p_months,plan.legacy_fils,p_rail,p_product) returning * into item;
  end if;
 end if;
 if p_rail<>'stripe' and item.product_ref='' then
  if not exists(select from public.kod_membership_prices where tier=item.club_tier and months=item.months and legacy_fils=item.amount_fils) then raise exception 'method_unavailable';end if;
  update public.kod_subscription_orders set product_ref=p_product where id=item.id returning * into item;
 end if;
 if item.status='paid' then return jsonb_build_object('id',item.id,'state','paid');end if;
 if item.checkout_url is not null and item.checkout_until>moment+interval '1 minute' then return jsonb_build_object('id',item.id,'state','ready','url',item.checkout_url);end if;
 if item.checkout_ref is not null or item.created_at<moment-interval '30 minutes' then return jsonb_build_object('id',item.id,'state','expired');end if;
 if item.lease_until>moment then return jsonb_build_object('id',item.id,'state','starting');end if;
 update public.kod_subscription_orders set lease_id=gen_random_uuid(),lease_until=moment+interval '40 seconds' where id=item.id returning * into item;
 return jsonb_build_object('id',item.id,'state','new','lease',item.lease_id,'amount',item.amount_fils);
end $$;
do $privileges$
declare ns text;sig text;
begin
 foreach ns in array array['public','kod_private'] loop
  foreach sig in array array['kod_set_membership_prices(jsonb)','kod_request_plan_invoice(text,integer,uuid,integer)','kod_reserve_membership_checkout(text,integer,text,integer,uuid)'] loop
   execute format('revoke all on function %I.%s from public,anon,authenticated',ns,sig);
   execute format('grant execute on function %I.%s to authenticated',ns,sig);
  end loop;
 end loop;
end $privileges$;
notify pgrst,'reload schema';
commit;

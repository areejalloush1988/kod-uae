// Hosted checkout for fixed-term KOD memberships. The browser never receives merchant credentials.
const SITE = 'https://areejalloush1988.github.io/kod-uae/';
const TERMS = [1, 3, 6, 12];
const RAILS = ['stripe', 'etisalat', 'du'];
const PROVIDERS = {etisalat: 5, du: 4} as const;
const UUID = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
const env = (name: string) => Deno.env.get(name) || '';
type Rail = 'stripe' | 'etisalat' | 'du';
type Data = Record<string, any>;

function json(value: Data, status = 200) {
  return Response.json(value, {status, headers: {
    'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization,apikey,content-type,x-client-info',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff'
  }});
}
class PaymentError extends Error {
  readonly status: number;
  constructor(code: string, status: number) { super(code); this.status=status; }
}
function carrierEndpoint() {
  try {
    const url = new URL(env('KOD_APAYA_TOKEN_URL'));
    if (url.protocol === 'https:' && url.host === 'api.apaya.io' && !url.username && !url.password &&
        !url.search && !url.hash && !/sand|test/i.test(url.pathname) && url.pathname.endsWith('/tokens/request')) return url.href;
  } catch { /* The merchant's live endpoint is supplied during onboarding. */ }
  return '';
}
function product(rail: Rail, months: number): string {
  if (rail === 'stripe') return '';
  try {
    const id = String(JSON.parse(env('KOD_APAYA_PRODUCTS') || '{}')[rail]?.[months] ?? '');
    if (/^[1-9]\d{0,9}$/.test(id)) return id;
  } catch { /* An unconfigured plan is unavailable for carrier billing. */ }
  return '';
}
function ready(rail: Rail, months: number) {
  if (rail === 'stripe') return /^(sk|rk)_live_/.test(env('KOD_STRIPE_SECRET_KEY'));
  return Boolean(carrierEndpoint() && product(rail,months) && env('KOD_APAYA_API_KEY') && env('KOD_APAYA_USER') &&
    env('KOD_APAYA_PASSWORD') && env('KOD_APAYA_MERCHANT_ID'));
}
function safeCheckout(url: unknown, rail: Rail): url is string {
  try {
    if (typeof url !== 'string') return false;
    const target = new URL(url);
    const host = rail === 'stripe' ? 'checkout.stripe.com' : 'checkout.apaya.io';
    return target.protocol === 'https:' && target.host === host && !target.username && !target.password && target.pathname.length>1;
  } catch { return false; }
}
async function postRpc(name: string, payload: Data) {
  const key = env('SUPABASE_SERVICE_ROLE_KEY');
  const res = await fetch(env('SUPABASE_URL')+'/rest/v1/rpc/'+name,{
    method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},
    body:JSON.stringify(payload),signal:AbortSignal.timeout(10000)
  });
  if (!res.ok) throw new PaymentError('payment_record_unavailable',503);
  const text=await res.text();
  return text ? JSON.parse(text) : null;
}
async function customer(req: Request) {
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) throw new PaymentError('login_required',401);
  const base=env('SUPABASE_URL'),headers={apikey:env('SUPABASE_ANON_KEY'),Authorization:auth,'Content-Type':'application/json'};
  const [userRes,roleRes]=await Promise.all([
    fetch(base+'/auth/v1/user',{headers,signal:AbortSignal.timeout(8000)}),
    fetch(base+'/rest/v1/rpc/kod_my_role',{method:'POST',headers,body:'{}',signal:AbortSignal.timeout(8000)})
  ]);
  if (!userRes.ok) throw new PaymentError('login_required',401);
  if (!roleRes.ok) throw new PaymentError('account_unavailable',503);
  const user=await userRes.json(),role=await roleRes.json();
  if (!UUID.test(user.id) || !['customer','developer'].includes(role)) throw new PaymentError('member_required',403);
  return user;
}
function returnUrl(id: string) {
  return SITE+'?subscription='+encodeURIComponent(id)+'#subscriptions';
}
function checkoutTitle(months: number, language: string) {
  if(language==='en')return 'Tawfeer membership · '+months+(months===1?' month':' months');
  if(language==='ur')return 'توفیر کی رکنیت · '+months+' ماہ';
  if(language==='fa')return 'عضویت توفیر · '+months+' ماه';
  return 'عضوية توفير · '+months+' شهر';
}
async function stripeStart(id: string, months: number, fils: number, language='ar') {
  const body = new URLSearchParams({
    mode:'payment',success_url:returnUrl(id),cancel_url:returnUrl(id),client_reference_id:id,
    'metadata[kod_subscription]':id, 'allowed_payment_method_types[]':'card','adaptive_pricing[enabled]':'false',
    'line_items[0][quantity]':'1','line_items[0][price_data][currency]':'aed',
    'line_items[0][price_data][unit_amount]':String(fils),
    'line_items[0][price_data][product_data][name]':checkoutTitle(months,language)
  });
  if(language==='en')body.set('locale','en');
  const res=await fetch('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{
    Authorization:'Bearer '+env('KOD_STRIPE_SECRET_KEY'),'Stripe-Version':'2026-10-28.endive','Idempotency-Key':'kod-membership-'+id
  },body,signal:AbortSignal.timeout(15000)});
  if (!res.ok) throw new PaymentError('provider_unavailable',503);
  const session=await res.json();
  if (session.livemode!==true || !/^cs_live_/.test(session.id) || !safeCheckout(session.url,'stripe') ||
      session.currency!=='aed' || session.amount_total!==fils || !Number.isFinite(session.expires_at))
    throw new PaymentError('provider_mismatch',502);
  return {ref:session.id,url:session.url,until:new Date(session.expires_at*1000).toISOString()};
}
async function carrierStart(id: string, rail: 'du'|'etisalat', productId: string, fils: number, email: string) {
  const fields: Record<string,string|number>={
    productId:Number(productId),chargeAmount:fils/100,isTaxIncluded:'True',currency:'AED',pt:id,
    'lang-country':'ar-ae',email,defaultProviderId:String(PROVIDERS[rail]),
    successRedirectUrl:returnUrl(id),failureRedirectUrl:returnUrl(id),suppressRedirectParams:'True'
  };
  const res=await fetch(carrierEndpoint(),{method:'POST',headers:{'Content-Type':'application/json','X-Apaya-Api-Key':env('KOD_APAYA_API_KEY')},
    body:JSON.stringify({tokenTypeId:4,u:env('KOD_APAYA_USER'),p:env('KOD_APAYA_PASSWORD'),expiresMinutes:30,
      parameters:Object.entries(fields).map(([key,value])=>({key,value:String(value)}))}),signal:AbortSignal.timeout(15000)});
  if (!res.ok) throw new PaymentError('provider_unavailable',503);
  const reply=await res.json();
  if (reply.errorMessage || typeof reply.token!=='string' || !reply.token || reply.token.length>512) throw new PaymentError('provider_unavailable',503);
  const url=reply.checkoutUrl || 'https://checkout.apaya.io/'+encodeURIComponent(reply.token);
  if (!safeCheckout(url,rail)) throw new PaymentError('provider_mismatch',502);
  return {ref:reply.token,url,until:new Date(Date.now()+30*60000).toISOString()};
}
async function checkout(req: Request, body: Data) {
  const {months,rail,request_id}=body;
  if (!TERMS.includes(months)||!RAILS.includes(rail)||!UUID.test(request_id)) throw new PaymentError('invalid_plan',400);
  if (!ready(rail,months)) throw new PaymentError('method_unavailable',409);
  const live=await postRpc('kod_subscription_methods',{});
  if (!live?.[rail]?.includes(months)) throw new PaymentError('method_unavailable',409);
  const user=await customer(req);
  const email=String(user.email||body.receipt_email||'').trim();
  if (rail!=='stripe' && (email.length>254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) throw new PaymentError('email_required',400);
  const sku=product(rail,months);
  const order=await postRpc('kod_prepare_subscription',{p_user:user.id,p_request:request_id,p_months:months,p_rail:rail,p_product:sku});
  if (order.state==='paid') return json({paid:true,id:order.id});
  if (order.state==='ready' && safeCheckout(order.url,rail)) return json({id:order.id,url:order.url});
  if (order.state!=='new') throw new PaymentError(order.state==='expired'?'checkout_expired':'checkout_starting',409);
  const session=rail==='stripe'?await stripeStart(order.id,months,order.amount,['ar','en','ur','fa'].includes(body.language)?body.language:'ar'):await carrierStart(order.id,rail,sku,order.amount,email);
  const attached=await postRpc('kod_attach_checkout',{p_id:order.id,p_lease:order.lease,p_ref:session.ref,p_url:session.url,p_until:session.until});
  if (attached!==true) throw new PaymentError('checkout_starting',409);
  return json({id:order.id,url:session.url});
}
async function checkOrder(order: Data) {
  let payment='';
  if (order.rail==='stripe') {
    if (!ready('stripe',1) || !/^cs_live_/.test(order.checkout_ref)) return;
    const res=await fetch('https://api.stripe.com/v1/checkout/sessions/'+encodeURIComponent(order.checkout_ref),
      {headers:{Authorization:'Bearer '+env('KOD_STRIPE_SECRET_KEY'),'Stripe-Version':'2026-10-28.endive'},signal:AbortSignal.timeout(8000)});
    if(!res.ok)throw new PaymentError('provider_unavailable',503);
    const s=await res.json();
    if(s.payment_status!=='paid')return;
    if(s.object!=='checkout.session'||s.status!=='complete'||s.mode!=='payment'||s.livemode!==true||s.id!==order.checkout_ref||
      s.client_reference_id!==order.id||s.metadata?.kod_subscription!==order.id||s.currency!=='aed'||
      s.amount_total!==order.amount_fils||typeof s.payment_intent!=='string'||!/^pi_/.test(s.payment_intent))throw new PaymentError('provider_mismatch',502);
    payment=s.payment_intent;
  } else {
    const endpoint=carrierEndpoint();
    if(!endpoint||!env('KOD_APAYA_MERCHANT_ID'))return;
    const res=await fetch(endpoint.replace(/request$/, 'checkstatus'),{method:'POST',
      headers:{'Content-Type':'application/json','X-Apaya-Api-Key':env('KOD_APAYA_API_KEY')},signal:AbortSignal.timeout(8000),
      body:JSON.stringify({token:order.checkout_ref,includeTxs:true,includeTxDetail:true,u:env('KOD_APAYA_USER'),p:env('KOD_APAYA_PASSWORD')})});
    if(!res.ok)throw new PaymentError('provider_unavailable',503);
    const status=await res.json();if(status.errorMessage||Number(status.tokenTypeId)!==4)throw new PaymentError('provider_mismatch',502);
    for(const row of status.transactions||[]){
      const tx=row.detail?.data;
      if(row.status!=='Success'||tx?.transactionStatus!=='Success'||tx.transactionType!=='SinglePayment')continue;
      const actual=String(tx.actionedAmount),[units,fraction='']=actual.split('.');
      if(!/^\d{1,7}(\.\d{1,2})?$/.test(actual)||Number(units)*100+Number(fraction.padEnd(2,'0'))!==order.amount_fils||
        tx.passThrough!==order.id||tx.checkoutToken!==order.checkout_ref||tx.currency!=='AED'||
        Number(tx.paymentType)!==1||Number(tx.providerId)!==PROVIDERS[order.rail as 'du'|'etisalat']||
        String(tx.productId)!==order.product_ref||String(tx.merchantId)!==env('KOD_APAYA_MERCHANT_ID')||typeof tx.txId!=='string'||!tx.txId)
        throw new PaymentError('provider_mismatch',502);
      payment=tx.txId;break;
    }
  }
  if(payment)await postRpc('kod_settle_subscription',{p_id:order.id,p_rail:order.rail,p_checkout:order.checkout_ref,
    p_payment:payment,p_product:order.product_ref,p_currency:'AED',p_fils:order.amount_fils});
}
async function reconcile(req: Request, orderId?: string) {
  let user=null;
  if(orderId){if(!UUID.test(orderId))throw new PaymentError('invalid_request',400);user=await customer(req);}
  else{
    const key=env('SUPABASE_SERVICE_ROLE_KEY');
    if(!key||req.headers.get('Authorization')!=='Bearer '+key)throw new PaymentError('operator_required',403);
    const methods=Object.fromEntries(RAILS.map(rail=>[rail,TERMS.filter(n=>ready(rail as Rail,n))]));
    const res=await fetch(env('SUPABASE_URL')+'/rest/v1/kod_billing_availability?id=eq.1',{method:'PATCH',
      headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({methods,checked_at:new Date().toISOString()}),
      signal:AbortSignal.timeout(8000)});
    if(!res.ok)throw new PaymentError('status_unavailable',503);
  }
  const due=await postRpc('kod_claim_payment_checks',{p_user:user?.id||null,p_order:orderId||null});
  const results=await Promise.allSettled(due.map(checkOrder));
  if(results.some(r=>r.status==='rejected'))throw new PaymentError('verification_pending',503);
  return json({checked:true});
}
function parseObject(raw: Uint8Array): Data {
  try {
    const o=JSON.parse(new TextDecoder().decode(raw));
    if (o && typeof o==='object' && !Array.isArray(o)) return o;
  } catch { /* Invalid HTTP body. */ }
  throw new PaymentError('invalid_request',400);
}
export async function handle(req: Request): Promise<Response> {
  const url=new URL(req.url),route=url.pathname.split('/').filter(Boolean).at(-1);
  try {
    if (req.method==='OPTIONS') return json({});
    if(req.method!=='POST'||!['checkout','reconcile','check-order'].includes(route||'')) return json({error:'not_found'},404);
    if(Number(req.headers.get('Content-Length'))>8192) return json({error:'too_large'},413);
    const raw=new Uint8Array(await req.arrayBuffer());
    if(raw.length>8192) return json({error:'too_large'},413);
    const body=parseObject(raw);
    if(route==='reconcile')return await reconcile(req);
    if(route==='check-order'){if(!UUID.test(body.order_id||''))throw new PaymentError('invalid_request',400);return await reconcile(req,body.order_id);}
    return await checkout(req,body);
  } catch(error) {
    return error instanceof PaymentError?json({error:error.message},error.status):json({error:'provider_unavailable'},503);
  }
}
Deno.serve(handle);

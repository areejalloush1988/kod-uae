import { Buffer } from "node:buffer";
import { cardMetals, cardEntitlement, cardPrintedName, cardEndDate } from "./member-appearance.js";

const app = "https://areejalloush1988.github.io/kod-uae/";
const headers = {
  "Access-Control-Allow-Origin": new URL(app).origin,
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Cache-Control": "private, no-store",
  "X-Content-Type-Options": "nosniff",
};
const configKeys = {
  apple: ["PASS_TYPE_ID", "TEAM_ID", "SIGNER_CERT_B64", "SIGNER_KEY_B64", "WWDR_B64"],
  samsung: ["CARD_ID", "PARTNER_ID", "CERTIFICATE_ID", "PUBLIC_CERT_B64", "SIGNER_KEY_B64"],
};
const icons = {
  "icon.png": "iVBORw0KGgoAAAANSUhEUgAAAB0AAAAdCAIAAADZ8fBYAAAEjUlEQVR42s1WW2xUVRRde587c9uZltJSK7SlBYUPJAjWiiaSfqiJ/BlATIyGQIQP9cNXhBKEEAiamNBIQngkBpEoD6OERiwEtQoiYKQREBSwfBhKaC2F2ufM3HP29uPePoAWxITEk/Nx5j7WWXeftdcaUlXchcG4O8O79W11TlWJmEzEQJyDKjET34oT3aoOqiDqWyr1raMrosR0h3wVgILowv7Dl0+eHjfj0dLHHwqBztV+23quccJTVaMrJg3e+GZOQwxxTlXrl9ZUY0w1SpahrGHTTlX9cuHyJbi3GiUrzH1ndtapqlg3JAIPuRMxdza1HKnZ6nNujl+ooGPrtjX/8nvDh7uyOT/HL7TOHn53s4oQEzQsi4i1KjJ8HVRBJNaqc0QGUGZWJ2ItACIGlJjFOijABFWVG09yCL7ErCJ540qmzZ/d7Vq70m2B9FQsnFv8yJTJs2d2upaudJuTzPTX55FhcU4BYr507OSPazdfbjgTch+or4iIc+JEXLhwLghOfLS77q1VZ3d/rarO2qA3dXzD9ro3V13Y94OqusC6TKCqB954bwXufw2J+mUfqKrLBBh8UP9tHFq1YTGKVsenLPVKD63ZGOJ6/d+eauvobW8n5khkIEDFSVhuNhyKXZ0DACJidpnMr5/u/W7NuqQ3CqpiHRsPAAieOiHD52vrdy9aLF0WigH9EwGKgb4hDPoBggS2J+iIU0It1CiDs3KT4b2I788bd1xtvZhDhaJW4ATyb0yAQB58aPSBAGcX5vfrTAH4OYkY+WxYHOXmF8aTiYjvdV1+Pd8+sXe1XLFBQKoGXuKegvA9T1UJGDm+VGDJ47TtrJzz3Mx1y1xg2TMRkPbB9lc+9Aeintarm6bOskFGRXwvOaKkKCTkhU+NeXgyqxErHrIuHDhChv3s5G2sTpWILu458XfH5ezYyEzQU1A2dkR5cXSoYZOUVVXm5hQ5l4l7ieY/z/5U8zEAl86oiKpi0Ix0aS0A25s+uHo9wyMii9T4Jx7z/Lg6ByImJnWSW1z0wLNPp7STCD7nfLNybePe740fJ2ZELRNNiABgz4OidkH1pXOnfZN0zsaRXbFobp+Kwj4mQLVq+SsjkkWBSxvyXNptn/XywZXru1uuEDMbw140yRgiajp6YtuT8xp2fZ5lRhBzj7tW8cKc4ulT1ElYgMjXQxWf2rpnx4JXs0wewzgXpNFVMGps6fQHR5YXcywGVRAynd1/nW5sOn4yg1SWySXmnuBa8cRJLx39LCs/D0Bo9gN5Ic6xMUff3/LVkpUEz48lQRRkUhYpgRusWYYX5yR7nljbI1dLJkx+sW5L/sQyFem3tOtyKIQ+v6d+39trmhvPMjwPvjExZgMakIFYZzVtkYrBn/r8MzNr3kmOHjUYdIh8CwuS6eg+9Untb1/sbzn1R++V9gDpQcbKsXgir3x0+YzKafNnl1VVhsZ4Q4wOkZshdLjubWvvaGpOd3ZDIydiYxJFBXnlxSYWi6yWiG5KuWHyWFWckGGiYRNXnCNQP4M7yXmgrylu8hsiDL/l7XH/d/+j/gEpL/1fz4kLmQAAAABJRU5ErkJggg==",
  "icon@2x.png": "iVBORw0KGgoAAAANSUhEUgAAADoAAAA6CAIAAABu2d1/AAAJ6klEQVR42u1aaZBU1RU+59zX3a+nl9k3trBDGJQoWFpgaWIkcSlRSY1gSUpTRkujaJYqU4laYmkkW5USy5hy1yKxMJZKEAFrQEBxGcGITMRxwJkRwiLMPtPT3e/dc/Lj9fJ6mWFmIFhWze3+0f3m9LvfO/e731nuoIjAN2cQfKPGKNxRuKNwT8swTubHwiLMgM4XQEWImGPDwoIIMrDN0AeOWHdFMyrKBYdEw7I5Hd4VZlTUc+DInjWvH971KRmqel7NmdcuKqgoSaFxbDqaWhtefuPox58bfu+EBXNrai/zFQVHjHgk3nUm++S519b/4v7uzqMIJIACurR6wtVP/nHq5RcIMwAgUf3DL7x5zx/6Ih0ISkAAuHLy9MXP/HnChfNGhnjYcJ313bdh+3OX/ZjA6zFMEHHAxawer1lw8wevVJwxHREb/v766mU3mxBShjdpg/1WdzBccsuutcVTxovIcBEPf0UQhfmte/8iCB7DZNtmrVlrbVk+TygS7Xzrt48gotXXv+XuRzxoKuVx2dh+T2FX95F3Vj4BOJKFpeHTADub//vVniav+Flr91/Ztr0Y+PLdj3TcOvbp/uOtLR4ws2207cGC1m0f6rhFSsEwEY+E79HObh2PAWDWZAKAglYkakdj0c5ujXGgHM0SQKF4X78di5+GMIEAEBpT4Q0GBBkyFRQRmHSgvMQbCoTHV/mwQDjHeYRMdqi6zBvwgwhgnucRrdnWopm1zvLI8OAioTAHq8unLFwQlW7l8WTcy/BEuafmmksRsXT6xIkXnJdtg0iGEee+miWXIRFrziUbIKBSZChUREple2TYysAMiF3NB58+f+mxw80FWARJle2TtilnnnfDttXecBAJv/qk8ckFtX29HSaFnVlF6z5om7Vg4XVvPmWYJiK40SRiikDThq3Nm9/vOXDUVxS88L7lobEVqXUYme4KErY3tqxfvmJ/3XuWRADQqwpmLV546ar7gtVlIgICSHi4vuGNXz7w5Y5dNsQAwO8vOmPJ5T98+G6zKJTFBNEalTpUv2f9HStaP9ipwSZQFvTftm3Dty6Yl4qOIwzCDmIAOPLx3uN79yNRxezp5TVTAUBEnKwgFQgOfvBx++ctyuetPnt2ydQJbpukXGhSat+6rf+45mfRaK+pwoiAiLbEbty2Zvz8s04WbooV7lnzXskKBMKMiG6/sq3JUIfqG566sFZHbcMw2bYBEnBv2vGyG+4AOcMQngERBSC1eREJyPGqZNiICHPKxlkT56sAiK3JY0SOdby0ZLkVjXlVgYM1Qx0HSXGcu5NSQ1Q1PJHlIDYIgB4j8lX7i1ffeqxlv6nC7pgiAAhEhhoYrggiolLCrOMWAAIIpHLV9CySVlrJ8UDiumQCy/y5gIjEe/ua697bsmLV0abGLKyAACIKPYbfl5T7TLgO/fuOHN+y4pGDO/6tI1bGvhEAEcAEBzATVuqKJBYdJYNUiAjJTZKECxLr7u1sP0xgmBTOitUAKMDKMDymL593RUDAjsXWXHnb3vrNJhSelsKLfCoIAsw6lycMrEyfNxRI+MUNl5lJqea69/bV7yj0jGVtJ12WdtwAK5uPDBk2g4gLSE5gS91AhP3hoDcccHEh7V0AgM6WQ4Aoop38OjmluNiDAOwCygMjhkGvn+h5ARm0WRjy+M0Bt5rh84DknyLJPMnEkUKf5dfB3Z9etOQncXkw6V1gTziARO74lwHXLCkEQMknsYTk6Ia4BBVEACm9pRIUQEBMfExcpzS1xP0Y6dSJmTPRogAHy0sSEVRlwnXUu3BCtRdMcRMfUUR7fP6lax8LjalIleBExCzpB3DDxcTLUauEFGawI+1LYSZDbbrzob1btvhUME1lBAEOja1MqFMOGRAAwmOrzGC4v7eb0EggECEyItFOVKp89rT/k0R0HThCoHJJWDpjUv703PFuoKq0ePI4DZY77iOhBmvP6nUAoC1bmE/VW1s2a926tf5oU6MHTXHxQTR7wKycMzOLOORONZBozDmzNcaR3OkSe6Hgs7V1kWPtZCgARKJT9EZSavdzr1kQc3dPEFGLFS6trJwzAwDIlSRlVxNTfrCARGVEUBFD+To6DtavWo2IwnxKCCCaiajtsy92r/mXD0PuqIZEFkbHz/+Ov6TQyfLywCVFADDp4vnFZeNsHYPMPNBHoXcefuJYwz4yVE7AHAFYERFA3HTnyv5otyLDTVxn786qvcSRhQFqNUTW2l9SOKv2Egsi5FodESFQ/ZHeV6+/y45ESSk5GcQiTo779oN/a3hzY1Zyg4Q2x8oqJ0274rspJ+Yng7PDzr1jWYGnkFm7OS7Mpgq1fPThSz+6XUfjqBRb9ghSe9ZaAMhj7PzrixvvXelToawnR1Jx6Zt7yxKzKMy2ziotM+ESiebSmZPn3bi0n7tIGVkdDb8qbNi46dnvXXd87xfkMRCRbc1aC3MiauR7i4hoZluLCCkllq779Z9eu+03XirIiolIaHF/eeWkc5Yvy9uSyi5+HK70t3U8PmdR15EjBvqy9hYpFdXdwXDZ+XfddPZN1wQqSofl3ab1W9+6b1XLrg99FEZOR7lk6a8idsfSZx+bc8NVTgF34paeUxg1vlr3wuKf+IywaMnuTZCy2YpDT2nlpJlXfH/ywvkVs6cFx5QbppmsbdL5L2uOdfV0fHHgy7d3Nq7d3Px+vYD4VDB3vyrD6LXb5l5dW/vKKqcwHmoH0nmyrfc+uvHB3wU85WzZuVkEElk6ZkGEwPAbIbO40AwFSKmMwCtix6xoV0+kuzMOEQKPjwKJIjQrXBlGv901dtbsn767xhsKJvOOITZMBZg1KbXuxnveeeapoFEmmnMtEREViQhrzaAFODedQ0AERWiQosThQG6ebniidmf5xMk3bF5dNHncIK3fgQt3EYfsG25/YPtjj/sgrJQxoOI6rsCcVCuRhMNAszilYZ/dPm7mGcvWPVk0dXze84GhNZ2SiOtXvbDxrpXReJ9fhROF+EkPB6htR+PQN2fRoiuf/r2/rGhwrENoi4gICyo6vPM/G3/1UNP2bQSGlwJIKCwiDDJ8lEQAYOmYBX3F5eMvuv/n8269dohHLEPq4qQ0Zffzr77/6PMHd+22IW6AzwBf+uBJTlzhCLMtlg1RACmpmnDW9YvPveP64JjyVP18ys4mnL45AALL/rodn/5zU8v2+o59B2Lcy6AFgADzETeBU4AJyABfYVVV9dyab1958YyrFhaUF7t9ceqPUty31nGr7fPmtsaW9n2tXa2Hou3dVjSW261CRb5gIFBVVjZjYsmMSRU108zicOpuSMM7FRx+S09AmAVk6C7Jf445ouPLkXcgE8mAJOIo5lexlJIl5Y7w6zlk/VrG6D8IjMIdhTsKN3f8D4w547gFnUgQAAAAAElFTkSuQmCC",
  "icon@3x.png": "iVBORw0KGgoAAAANSUhEUgAAAFcAAABXCAIAAAD+qk47AAAPE0lEQVR42u1ceZBV5ZU/53z3vrX3brqx2W2kWUTUQVHcDSgaI8ZAooglo6kyE9FJzDpTcdTEjEvNVDJJNCiDijqDILIIQWkLRSU4gBSbLA1iN8hOb/Tytnu/c+aP+97rbnhbY3fTk3m3urte3Xrfvd/3u2f5nd93bqOIwP/7g7IQZFHIopBFIYtCFoUsClkUsihkUcjwMHrhHsICIACICICY2RiJUXtERMCenSH2XB0hIqKZDNXxJGuNiEiUAjIRJtV5lK1RESL+H0NBmONLbT50LNTQ7Mrz55aXKpcJAKIZVQIg4ueFuenAEas14M7PzR/U37GgZKP6qEc40w03Nm+as2DX4vfqqw9YgZDyuHIH9Ku4aeIVj8wqrhzWEaZ24BQ1Hzy64fnX9/3lo8b9hzhsK6+7qGJA5Z2TJ/zDTF9ZUQ8B0f22wMxEVPP+p8se/OXxmn0GuA1wIZAAa7AtCObkFE955p/GPzSj45Kcz9tfW77qx79pajhigkeBiYACYkPEhnDxeUPu+PO/XjD1hp4AoptRcJ7wgbUbX735XisScZu5orVIe3REUtqOhKB52h//ffzsKBDO322vLF14/8MmeA3DI8wdRiERRewAoNyzZG7lHd/odiC6EwURQYBAfdOLF3+7/vBBt+Fn205wSyJBDQQPbljS/5LRbNukVN2eL+dcOtWKWAaYzDpBSlfK0iF/YeEPd6zMLS8VkRQh9lzyBdEMiFtfWXr8cLUnCQSOvRCYIat17b/8ESD6vNc9M7ct1GiQKyEETnJxGd7GxsMb//AGIAp3pwl3q10pAoDq5WsUulk4ZezQbvTXfrix9cgJMo1g46n9765zoU+SQBCPOCZ6qld8yLYmQ4H0QRREEDHU1FK/t1aJCamflQiBCrQ11e2pAYCG6tqWkycJjNRPWESUmE21h1sOHQcASQn0uUHBmb7VFrCCoYy4HqFGOxIIAIAVDDHamZEiZMuOBIJ9tI5wVuDOy3Hn+CUDYxUWU9y+kiIA8BTkGeDKxNUF2PR5vEX5He7ZpzwCUZhduf5+Yyo0hlMHcCRksHL7lZZUDgOA4hFDC4YMsDGSdpTGcMmoipyyYhFByrgkYRFmYYYkCbFbcwQLAIydcZsWG1JOkUiFpHXUdyZ7CvN0OGL6vWPv+ZYlAUqJApGyxRp7z22AKJozmA+z1oCIhEiERMlquW5lTQIioi3r1atn7v9svd8s0paVYDGGEbED+WVlD25emlNe6hCtUOOpOePuqD90wGPk6EQpVplmwGocNPri729cZPg8CKnKUxGBGKFgrVuOnIicaiW3WTBkgFPI9AZ3bPzyq1dvnHn8wD6/KgLsWFkjIIbsFpfbM+vd+UNumOB8P8o4P9o0f8p94VCbx8iLVdaxUQAB3VRUNnDWmjf6jRl+Zg2SsJA7snH71teW1nyw4dTBYxyKaLKHXnHZzPfnKbcLRDqC2P11hLAgYVPN4RU/+FV11YcabAUmAgkIgyXAA8eOu/35pwZdc6lojbEK2pn6ob9uXTH7sYNbtyCgAhMABURDRIFx/tVXTJ37dPHIYakhYK1JqcDxhtU/f3rb68vD0maAW4GJSLaEC0rLH6l53/R5exyFjk9jf9W6Hf+14vj2vVZLQHnMwgsGV37rxotm3K48rjNrAecMW/bORat2vb26bk8NBy0jx9PvwuHj7p16wa3Xn1awJyKvGpU6vmXPm9MfOrp/lxcLSZGwOKHU5kjRwIEP7V5l+nsFhWikRIhTAB2OkKFOe/KpVQm2bW3ZhtsVP5MOAkZFxzbvenXyzNbGBo+R2zG+tKNQ/e6ZttBTipuTxkSzgJBSyu1yliEspCjZYpAIRJgZEckwyDA6XiRNLFDUfOjYf099sLWx0d0ZgvbojZiQZfSs7ojKASP6i0SYNjUjRuW2mJFGL5JGoxS27LfvfrTucK3XKEhSyGF8JudCg3ZE166qhs6QdKOi6qZSVT96unrd2uQQfE3Frc/2eYgIMxkGGuqjx//0yQsv+YyiFBAICJkGkuoaCnG9GPsmCohIFGkNVP3kmfUvvexReWLrVHoSiOlxK9PoAgrC4vinHQxZgVC8UojGsCi44JwBjDKiTkQdEaOUqbOdO4zI4XaIznVONzvngiKsGSlKnIQ5NgcU5rbjdftXr9s8d9HRL3Z7VL7otCbL5HFF03NnRzNSJPzdb1dtnrewfndtpCXopFzRDAhEJFGPBJAOKEDnBISIp/mTOLeXKJtEQoqCEhsunSEUZkZCBAQ8HYVIc2sQmg3weFU+a502NgmI6fVElcG0KDgQfPzEC6uefEqBocCVUi/ADvJCAtEBuyG0SufPGAvsymcUCkt6CAAQUIC9hfkAACygUqLAmklR7Ycbqp581mcUIJAwQ58MjwLCtu7SCG9hnjMQ08UFAYDNLy7UqBHUWWSdPnogMLCnMC+h4dKZgjeI1O3+UokZjXx/Owf6+hVloLJI9A/rv7H1O0vFnJLCDFgTxtKwqSCTYIB9hkmkY3YiAIBuR7DEtHxBBBBdfq+ApI7vDlv4GgH/LJJOfHiCxJFG+BZWYPhKChOKtmfkCGZSKq+8P4NGwBRTVsogRTH76ZAY4zRBBKDD3CRW1UmHNIpnhmaJkavOl3UynLNY6ZiCBQBFWFt2CptlFhd6/aVFCU3YSJQiIGdAqQAnAxeJItw2ZNzfTVv0exAWiZZ9UZ5HBIiitbAAIKrYsiWqdkS5okiMccYeqMS1uWiJHZ1uzNqj+oLDR2M8lW2tTGPPsjUrf/aEW+UkVGURgEGbufm+foWZoQAAAEUVg1IZmAiB2fzVsZz+Jabf2xfCQqCugcFCTGK8iCx2bv8SX3FmHuF8pWRUhQHuZJlCRAxyNZ48fOCjjRU3X8PMMdeQRI6dNhZ08pmzIU8gX65er1Ls6yBqsIpHDCPTSChY0ZkaBwAUVw71+QtZ7KQCPqEGq3rZB6gopvZHNX8k7PCZOn9O+INnDMn0x/Gdup37j36+y0RvMoKDCAK6bFxlfNMkHQqEIJJbXlZSOVRDJNneIWt2gW/3kqpgwykiAj43HNtRNz9fsDJonzqtIey0rylwDZp4ScI0mVhrcoLcoKsu0Wgl3QUTMZS7vv7g5wv+Aoh8Llim08gRbm7d9vo7JviSMl1EzVZeful548fEjT0DxQ0BACpuulqJmWIHVUQM9Hz6by9bbUEk7H1FSjQj4eYX3jxxeJ+pPMmmSoQWBgdeebG/tFiYEz7XRMAQAcDga8cXlQ22OZzMKYTZRd6jtbvXPzsPiaR3SXdcdP7kuRdd5E9Z8iCIjLxzcrKgkMwWkLV25+VU3nGjBcEUfVTM2qPy1j77p6Of7SRDida9GREQ8b3ZTzU1HjXQldQSEW0dyc8/r/L2GyHWbZOpBu2QhUvu/44Lfal8XgCFrEh46axfRFqDqFTvlKHasslQ65+bt3X5Mq8qSKGykKIItI247QZ/WbFoTmbXSVBQJMzll48dMen6MLemDL/sVv5DO7e9Ne1hHbGQqGctQoQtW5nG9vnLV/3iN26Vl7YVyk2+Cf94b7pyM2WRduXP7yeg1L0prLXXKNixetVb0x/RYQuV6qIE1IVYICJkGrsWvrvkgZ8Z5EZORbVIqTC3jLx1cvllY5040mUUSJEwnz/pyjG3Tgnp5hTmAABs236jaPs7K1++9q66nV+QoUCEte4uqc4RFx2mtPbxPyy46yFgJDFSJSYEBu1S3uuenJ2Wl1JqcgoAk577qcedq8FOrSawrb1Gfu3GTXOv+u7mlxaKACkFCGxr0Xw2eVSii3cyIil1bMuu1ybdV/Xr5wzyEKjUPW5ERlCfuvz795x36ei0vbJp8rzTDrDuty+u/NWTfqM4rQxJStk6YkFw2IQJE3/09yPvvKm9d0REmDNEAxE7zrt+b+3//Mf8zfMWhcItXpWXVnRGIktCxQMH/2DbMnd+LgCmboJKx3ZirVGvXDVj/6ZPvaqAtZ1+AUQh3YrA5aPHjvr25GGTrux/8ShPQV5XvaCp9tChv26pXvnB3pVrWwIn3ZCrlJGR7m5gxG6btfL14d+8NpOm6fSczynCGvYd+M+J01vrGgxyZ5IOnVLH4qANYRM8Bf0H5A8tLxo2yFdW5M7PNb1uYWnflXYqYhERsQKhSEtb65ETdXtrG/YdaA3VA4gL/EqZnLxJrZM9mkabVX/LY/983a9nO7acfraZeKxzrdo1G165eSYKERgZ8gKnZBTNtkQ0WAKagaFdY0pQfUs0XBGBaYCLlIkAGa4/BsHJ8dPumvbW71lrIpXJvlCm/N9pPd7x2juL7ntEOcGpKwQJESG20ZZpaIxtZ2Z+F2WarVbd2MlTvvfOn5XLjO8bdhsKcSC2z1++eNajCMpQLu5FypwWZlKqza67cPIt31v2gunzOE1mGYv0mev5hmJbX3Tf1BmL55h+V1i3OR035x4BIkRos+svu+vuu1fM6SoEcBbdXY5FHNu8a/HMHx/as8NHhU4EPYcmELHbAGTS4z+57onZEGs17NplzoLPOECEGluqfvr0ppffFBC3kRNtNO7N9RNpbYegecDIC2/93WMVU65xtvbP4oXDs1RH4kn4i1UfV/3y2a92bDXA41JeAenpPW5HodS2HYYWn6dgwg/vvf7xh115/gyTYneiEC3vWEiRHQx/NmfBxuffOLa/GoFc4CNDiQAwd5sAhYiISCgsNocsCPl9xRdOv2Xiow+UXjQCvvarll9XKYvf3moN7Fz83tb5Sw5+siWomxCUAW6FphO6HL28MydIp83HTFtYmG0bwhosA1zFQ4eN+e6USx+YXjxiWJTLJG927yUUYkbR/k7wyc/37Xvv45o1nx7dsrvl+AkLQgwagQgIgRAog/4WYWABFtAAoMD0eQr6ja4YcMW4C7557ZBrL3fl+CD6shp0y5t03aeaRnuQ2t+GDjWeqq+ura+uafjiYFPNV81HTgYbT9nBMDsbiu3blnK6xOM2Tb/XV1JYMKS8eOT5RcMHl44ZXnD+oI5cNvXL2ucOhY5aCEt0wzJRfomLURLfu5VO3kCGShjnWGt0KpTu7hjo2XfugWP/QAABnY62LqJ5dmP7EAqplLwMkkJvTqrXKTD2xUba7H8kyaKQRSGLQhaFLApZFLIoZFHIopDp8b92FlOUwLKJhgAAAABJRU5ErkJggg=="
};
function json(value, status = 200) {
  return Response.json(value, { status, headers });
}
function settings(provider) {
  const prefix = "KOD_" + provider.toUpperCase() + "_";
  const config = Object.fromEntries(configKeys[provider].map(key => [key, Deno.env.get(prefix + key)]));
  return Object.values(config).every(Boolean) ? config : null;
}
function pem(value) {
  return Buffer.from(value, "base64").toString("utf8");
}
function printNumber(number) {
  return number.match(/.{4}/g).join(" ");
}
function walletRgb(hex) {
  return "rgb(" + hex.slice(1).match(/../g).map(pair => parseInt(pair, 16)).join(", ") + ")";
}
// Tawfeer wallet language data
const walletLanguageData = {
  "en": {
    "توفير": "Tawfeer",
    "بطاقة عضوية توفير للخصومات": "Tawfeer discount membership card",
    "الفئة": "Tier",
    "حامل البطاقة": "Cardholder",
    "رقم العضوية": "Membership number",
    "صالحة حتى": "Valid until",
    "عند الكاشير": "At the till",
    "أبرز رمز الخصم في الفرع المشارك قبل الدفع. يتحقق الكاشير من صلاحية العضوية وقت استخدام البطاقة.": "Show your discount code at a participating branch before you pay. The cashier checks that your membership is valid when you use the card.",
    "برونزي": "Bronze",
    "فضي": "Silver",
    "ذهبي": "Gold",
    "بطاقة عضوية": "Membership card",
    "عضو توفير": "Tawfeer member"
  },
  "ur": {
    "توفير": "توفیر",
    "بطاقة عضوية توفير للخصومات": "توفیر کا رعایتی ممبرشپ کارڈ",
    "الفئة": "درجہ",
    "حامل البطاقة": "کارڈ ہولڈر",
    "رقم العضوية": "رکنیت نمبر",
    "صالحة حتى": "کارآمد رہنے کی آخری تاریخ",
    "عند الكاشير": "کاؤنٹر پر",
    "أبرز رمز الخصم في الفرع المشارك قبل الدفع. يتحقق الكاشير من صلاحية العضوية وقت استخدام البطاقة.": "ادائیگی سے پہلے شریک برانچ پر اپنا رعایتی کوڈ دکھائیں۔ کارڈ استعمال کرتے وقت کیشیئر آپ کی رکنیت کی میعاد چیک کرے گا۔",
    "برونزي": "کانسی",
    "فضي": "چاندی",
    "ذهبي": "سونا",
    "بطاقة عضوية": "ممبرشپ کارڈ",
    "عضو توفير": "توفیر کا رکن"
  },
  "fa": {
    "توفير": "توفیر",
    "بطاقة عضوية توفير للخصومات": "کارت عضویت تخفیف توفیر",
    "الفئة": "رده عضویت",
    "حامل البطاقة": "دارنده کارت",
    "رقم العضوية": "شمارهٔ عضویت",
    "صالحة حتى": "معتبر تا",
    "عند الكاشير": "پای صندوق",
    "أبرز رمز الخصم في الفرع المشارك قبل الدفع. يتحقق الكاشير من صلاحية العضوية وقت استخدام البطاقة.": "پیش از پرداخت، کد تخفیف خود را در شعبه طرف قرارداد نشان دهید. صندوقدار هنگام استفاده از کارت، اعتبار عضویت شما را بررسی می‌کند.",
    "برونزي": "برنزی",
    "فضي": "نقره‌ای",
    "ذهبي": "طلایی",
    "بطاقة عضوية": "کارت عضویت",
    "عضو توفير": "عضو توفیر"
  }
};
// End Tawfeer wallet language data
function walletCopy(language, source) {
  return walletLanguageData[language]?.[source] ?? source;
}
function holderName(card, language) {
  const name = cardPrintedName(card.name);
  return name === "عضو توفير" ? walletCopy(language,name) : name;
}
async function applePass(card, config, language = "ar") {
  const t = source => walletCopy(language,source);
  const { tier, until } = cardEntitlement(card), metal = cardMetals[tier || "inactive"];
  const { PKPass } = await import("npm:passkit-generator@3.7.0");
  const assets = Object.fromEntries(Object.entries(icons).map(([name, data]) => [name, Buffer.from(data, "base64")]));
  const pass = new PKPass(assets, {
    wwdr: pem(config.WWDR_B64), signerCert: pem(config.SIGNER_CERT_B64), signerKey: pem(config.SIGNER_KEY_B64),
    signerKeyPassphrase: Deno.env.get("KOD_APPLE_KEY_PASSPHRASE") || undefined,
  }, {
    formatVersion: 1, passTypeIdentifier: config.PASS_TYPE_ID, teamIdentifier: config.TEAM_ID,
    serialNumber: card.number, organizationName: t("توفير"), description: t("بطاقة عضوية توفير للخصومات"), logoText: t("توفير"),
    backgroundColor: walletRgb(metal.base), foregroundColor: walletRgb(metal.ink), labelColor: walletRgb(metal.sub),
  });
  pass.type = "storeCard";
  pass.headerFields.push({ key: "tier", label: t("الفئة"), value: t(metal.mark) });
  pass.primaryFields.push({ key: "holder", label: t("حامل البطاقة"), value: holderName(card,language) });
  pass.secondaryFields.push({ key: "number", label: t("رقم العضوية"), value: printNumber(card.number) });
  if (until) {
    pass.auxiliaryFields.push({ key: "validUntil", label: t("صالحة حتى"), value: cardEndDate(until) });
    pass.setExpirationDate(new Date(until));
  }
  pass.backFields.push({ key: "usage", label: t("عند الكاشير"), value: t("أبرز رمز الخصم في الفرع المشارك قبل الدفع. يتحقق الكاشير من صلاحية العضوية وقت استخدام البطاقة.") });
  pass.setBarcodes({ format: "PKBarcodeFormatQR", message: app + "#cashier/" + card.number, messageEncoding: "iso-8859-1", altText: printNumber(card.number) });
  return pass.getAsBuffer();
}
async function samsungUrl(card, config, now = Date.now(), language = "ar") {
  const t = source => walletCopy(language,source);
  const { default: jose } = await import("npm:node-jose@2.2.0");
  const [recipient, signer] = await Promise.all([
    jose.JWK.asKey(pem(config.PUBLIC_CERT_B64), "pem"),
    jose.JWK.asKey(pem(config.SIGNER_KEY_B64), "pem"),
  ]);
  const { tier, until } = cardEntitlement(card, now), metal = cardMetals[tier || "inactive"];
  const holder = holderName(card,language);
  const attributes = {
    title: tier ? t("توفير") + " · " + t(metal.mark) : t("توفير"), user: Array.from(holder).slice(0,64).join(""),
    bgColor: metal.base, fontColor: "dark", ...(until ? { endDate:until } : {}), providerName: t("توفير"), appLinkName: t("توفير"),
    appLinkLogo: app + "k.png", appLinkData: app + "#membership",
    "barcode.value": app + "#cashier/" + card.number, "barcode.serialType": "QRCODE", "barcode.ptFormat": "QRCODE",
  };
  const payload = { card: { type: "loyalty", subType: "others", data: [{ refId: card.number, createdAt: now, updatedAt: now, language, attributes }] } };
  const fields = { alg: "RS256", cty: "CARD", ver: "3", certificateId: config.CERTIFICATE_ID, partnerId: config.PARTNER_ID, utc: now };
  async function token() {
    const encrypted = await jose.JWE.createEncrypt({ format: "compact", fields: { alg: "RSA1_5", enc: "A128GCM" } }, { key: recipient, reference: false })
      .update(Buffer.from(JSON.stringify(payload))).final();
    return jose.JWS.createSign({ format: "compact", fields }, { key: signer, reference: false }).update(Buffer.from(encrypted)).final();
  }
  let signed = await token();
  if (signed.length > 2048) {
    // The cashier accepts the raw 16-digit serial as well as the full cashier URL.
    // Keep the loyalty template's required links and encode the styling in compact fields.
    const compact = { ...attributes, title: t(metal.mark), "barcode.value": card.number };
    delete compact.user;
    delete compact["barcode.serialType"];
    payload.card.data[0].attributes = compact;
    signed = await token();
    // The nested base64url envelopes grow by about 16/9 bytes per UTF-8 byte.
    const bytesAvailable = Math.max(0, Math.floor((2048 - signed.length - 5) * 9 / 16));
    let title = compact.title;
    for (const ch of Array.from(" · " + holder)) {
      const next = title + ch;
      if (Array.from(next).length > 32 || Buffer.byteLength(next) - Buffer.byteLength(compact.title) > bytesAvailable) break;
      title = next;
    }
    title = title.replace(/[ ·]+$/, "");
    if (title !== compact.title) { compact.title = title; signed = await token(); }
  }
  if (signed.length > 2048) throw Error("wallet_link_too_long");
  return "https://a.swallet.link/atw/v3/" + encodeURIComponent(config.CARD_ID) + "#Clip?cdata=" + signed;
}
async function walletRequest(request) {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (request.method !== "POST") return json({ error: "method" }, 405);
  const authorization = request.headers.get("Authorization") || "";
  if (!/^Bearer [^\s]+$/i.test(authorization)) return json({ error: "login" }, 401);
  const body = await request.json().catch(() => null);
  if (!body || !["apple", "samsung"].includes(body.provider) || Object.keys(body).some(k => !["provider","language"].includes(k)) || (body.language !== undefined && !["ar","en","ur","fa"].includes(body.language))) return json({ error: "provider" }, 400);
  try {
    // Private membership authority derives the member only from the authenticated session.
    const response = await fetch(Deno.env.get("SUPABASE_URL") + "/rest/v1/rpc/kod_member_card", {
      method: "POST", headers: { authorization, apikey: Deno.env.get("SUPABASE_ANON_KEY"), "Content-Type": "application/json" },
      body: JSON.stringify({ p_request: false }), signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) {
      if (response.status === 401) return json({ error: "login" }, 401);
      const detail = await response.json().catch(() => ({}));
      if (response.status === 403 || detail.message === "member_required") return json({ error: "member_required" }, 403);
      return json({ error: "membership_unavailable" }, 503);
    }
    const card = await response.json();
    if (!/^\d{16}$/.test(card?.number) || card.number === "0000000000000000") return json({ error: "member_required" }, 403);
    const language = body.language || "ar";
    const config = settings(body.provider);
    if (!config) return json({ error: "issuer_pending" }, 503);
    if (body.provider === "samsung") return json({ url: await samsungUrl(card, config, Date.now(), language) });
    const pass = await applePass(card, config, language);
    return new Response(pass, { headers: { ...headers, "Content-Type": "application/vnd.apple.pkpass", "Content-Disposition": 'attachment; filename="Tawfeer-Membership.pkpass"' } });
  } catch {
    return json({ error: "issuance_unavailable" }, 503);
  }
}
Deno.serve(walletRequest);

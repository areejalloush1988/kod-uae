import { Buffer } from "node:buffer";
import { cardMetals, cardEntitlement, cardPrintedName, cardEndDate } from "./member-appearance.js";

const app = "https://areejalloush1988.github.io/kod-uae/";
const headers = {
  "Access-Control-Allow-Origin": new URL(app).origin,
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Cache-Control": "private, no-store",
  "X-Content-Type-Options": "nosniff",
};
const configKeys = {
  apple: ["PASS_TYPE_ID", "TEAM_ID", "SIGNER_CERT_B64", "SIGNER_KEY_B64", "WWDR_B64"],
  samsung: ["CARD_ID", "PARTNER_ID", "CERTIFICATE_ID", "PUBLIC_CERT_B64", "SIGNER_KEY_B64"],
};
const icons = {
  "icon.png": "iVBORw0KGgoAAAANSUhEUgAAAB0AAAAdCAIAAADZ8fBYAAAEZElEQVR42r1WXYhVVRT+1tr7nPszM84YMtPgy9SAjjpOKlI6ClH5EkKDMAX2D1kQBBmJUqhNhhEiSOJbBGL0kmCCEj3ZQ9pof2AaNOo4+pKNgz/Xqbn3zD17fT1c73gdp9TAFovDYrPPx17f/tZaW/rQgXtgintj/kYoUOdoBHnXMCKiYiGAk3EF5Fh6xSFWuLuFNYZg41lMAwRgFVeECAQffeP12T0r4nwWELkzRAIAy8XSwIFv+nfuBiFwIH0libIlvZ9sX7Cm9z8T2vb4ktYFc794eW2sORIqThP784GHH1mwpteK41YaZ1JmqVz9pgis+KS4Zk/ZSuOhmHS91NO+bFlif6lTL6IBaXPXLJIA1N1EbgihcOkqQBVtaGgYvVwwGiCN06a5mp0CWBpItnTNGjhyCKI6wZPcTKmZIXJDQ0Nzuzo7OuctXd59ZnBw6fLujs55c7s6h4aGEDkzmySKqXQ2lSVJMjw8DGBkZKRUKv126tTEegjBQiDpnPtX/d6cPkmkoaWlZfPGTSTr8vnW1taPtn44NjYGkZkzZzrnXN4BQGq3Sv46Ls1Yk5TLxpVgxv0t73+wpUoNNrz7TiU8/uPPr7z2qojkctldO3c1Tm9iOa0F8QAIRrmcqJIgKU6/PviVWZg/v6uluVlUK7Q550IIIQSXjc+dP79v/5cViO3btjeqgCaqUT5HEIDSLJbc+WM/DB8fkNjRDKrrNqxf2fPU7Hlzduz8OMpmAHjvRcRXLY5j75x3bnpTk4jAIHE0cvL00JFjseRopjSLNX/2p/69vW+KqkbR6JWrly5fcs4Vi8WW5mZMVXkk0xDSEEIIICFQ7/c+89aZ77+NtY5mCsCY1uXv61i1AiBUCoVCoVAIIYhIW1tbCOE2VS0CAuScVSvq62YYUwCq3hdt9KHeVSu2rQtJGYJMJuO9rxzq4vBF55yK8Bab1G5Dkjy2de2i1U8X7Zp6X6kL+jgiKQDH0xktze0Ptquqc27zlr5j/f2pBYm8xF5i7zMZEYmi6NYORNLHUU0/A0iKCCFmwcV+/dvrnn3xeVUdGBhY0t3d3t7e1NTkVAGQEJXC1auqSrKWIhGZyGNyXTjnLSmvfuG5wXNn3+vrqywODg7+E7flcvl282KCK1UbL2/ctGnlkyv3fLbnu6P9F36/UCoVyWq/BchK3qyvr5epbtXXjIsbV6GioTS+cPGihYsXARgrjCZJQtzArXYxCqSxqQnlIFKhpYpLmoMfOXlGRAxkVVUqEsYSoznn8vm6fH19DdzErBCATFOaEVSRiydOO0SgKYNltP7s0aO/7N7vchnJxpKJKu7ymagup9kYkcJJ1VH1SiySiSQbu1zm188PDh4+ktE6C3Zdp17ifWs2/HFioKPniSiXFQjueMARLJeSUwcOHd7xqUNUoVOq7xIBWMI1j4zerilPMY+RpkiyaBAoa/ULEIK8m04zGu/0sNVfnfpY8xZsKv0Sloba8X0XyEZa+D/eUX8Dza1SBBzzfUMAAAAASUVORK5CYII=",
  "icon@2x.png": "iVBORw0KGgoAAAANSUhEUgAAADoAAAA6CAIAAABu2d1/AAAHqElEQVR42u1afXBUVxU/59z73u7bTdiFBCqRoSaQgBYMmf5B0Q7jUD8YIS0dHYv1C7Va2lHstDPO+Flm7EwLta3oVKAt7dTR6mjR1naUyh9KCaYOMiUJtoUkyoej0oYkuEk2++679/jHTcLL203YJclWZjiTP5Kbm83vnfs7H79zH26FpXD5GMFlZVfgXoF7ucKVk/wOiZCwzIDYMBtTGlxERCTfDCkzDAAI5QDNAAAsIeZSApiZuSi4iKRZKc7WLF22+MPXVzfUCteBGUfMWgXnuk5172/557E2B+KC3Hw3y3ysAedilcmbHrqv8bMbRMwtMxmMCjqeeeF3d9831NvnoMc8DjGGqxoiagxis5Kb9v2kZuVy8LXRutyxLwhc+Wbb8ac+9JnBnl6JLhuewLuIgclt3PWjmpXL9eCwcB2SovzhrweH5zUu+fiT33+q+XMRDl5IZCgoZwYWv+/6d9/yETPsC9d5u7KVcB2T9RetX730gzcMmwwJKgQXUYO65hNrgRkKReWEMZJnk68X/7HLbllrwABiATKwYQmxedcsBsTwjosYIjoCOJQ5GCDQAICOHLeIAIEp0hGIiIhz37PIAY+1KcRdZgSScbekRKt8P3MuE/lP6XQaAPrf6ol4tLKy0nGK4xhaVrgEFP4QWTBZFxUQWou423rw4IaP3UxExhhEZOa45x17tQ0AljU1DmezdtFueG7vb1av+YAe9oW4xAiWUwwLpVRff394xRkctP7o6elRSkU2z2DPUFSaHLUx77ruSGVxXVdrHfYuEb3NcM2o5btQKTW2br8xE/cuZYLrSDmrshKJOMRdRASAdDo9xl27wXEcY0wQBJEQlFLOOFwhBCh93apVXW+ciCQhmxmOHW2PpK1UKkVEsYpEXtgyFOf4qXrXdd25Ne/IC0ANAHPnXxXNOQyHW/9y/MRxQjJsEJCBpZA33Xijl0ywYZx2uDrQDIyIRISIwMx+kJ/kASCyrpRyk95jTzz+xJN7IvvP/P3kglkVrAO8WHnKz7s8SVVEIYQnIl6c6H9E1m1aSCaTUkopZKADS2sv7k2YMfLAROGSlGyipdJWhN+/8OI3v/2tpqamFY2Nje9tXNLQML/mnaU2GDbUACAIRuDqgj0qMxtDeSEY/Tnbfx6JQI5rA2wgtxw61Nbe3tbebhcrKirq6uqee/bXtYvrjB9MPaeGWY5CAFG2/3ykzFL4eSS5v/jklr233uMPZZkunIU91o5jHUQUi8WklEKIgYGBrq6udCplG5Lpw8qMEPj+85u+8dObbyeSEwt3A8F//UM/33Pw/sdQCjPaCgkpjdLd3d3GGKWUPU1EXNG4Yva8albBNMI12qAjWh9++sDTO4PzOTCTzhmE4yTdOadbjgCAVe3MDIL6e3v/c/bsGDEs7epqay2zp7E3t09+quWvCTedLxGicAPlD/q9tWuusx3wCD6E/v7+TCYT2bxgwYLpF8TMAFC3ZtWQfz7wc5OGGkF8TsW1G776/q/fxkqHVUfOz1kOhOtnwvNmQlqy0iu3fLr/9L86nv3tcM9AmA/jxE9g/I3P/LD58e85rosMYU3hujFb2cM07e3tLVXSFMkGIcVHH/3Op/buNiaYjAxOwmNtWOuxLIaIwFBdVZVKpcLpEwD+9PIBRARErTXDdOJmbVgbJ+FFxjGUt0+joLBfEdH4QapqzpL6Blt7LVwiOtrWtuPhR2TcFXEXkYwxWutgUiu2h0REQZwXxJS/r1Ap0oDQ3NzMzGNksE33XffcfefmO9qPtqlAUcwRcVd6sYJf8cqklNIrie55YIpqcYQQbPjzmzY9sH1bJpOx0sBqcUTcuXvXzt276uvrr164sLqq2vPiBZ+ZDZMUr7S2TqVPl0WejPbVVTXzH9r24G2bv+w4ztjcgJmFEFrrzs7Ozs7O4juHmVUTQgid8794+5e6urseeHC7lQBaa9ujYMiKEUvlmJ4LFDqn7t++beejP06n0lbDEJGU0safhT65Wf5EbGaG/QiCSOfU5jvvePXIkbu2fK2mpsY2hFpr6zYuxez+ktR8yWpCEOlh/12L6h7Z8YOt37235c+HWlpaOjo6Tp8509fXlx3OGm2KHK6MtOdeovjmUxac9lyUxyan2HBq9ux1zevXNa+38jA7NJjL5Yw2pVaxVCoFSlMRrJDhv2M2QU4BAMNFVB4RAQEHgT1QRBRCeImkV1FR8q3A6AiwgC70FYNBlGOl/gJcJAxM7q3Xu69es7L4OWF42sVawyX1kvnRxoaBuef4P3zIOiLOo88zTk0QyNd+9QcsaWCaN+W8BJvo0/72y30EFA4ECncVcao88fKBzuf/SHFX+1Mdv136sN9X5Lkn97/y+kv741QZvh8Zf5VCGLBKVKe/sP9n8xobOBfwlKdaJR8RIcac3jdO7rnh1sy/35QYC2PAyPsMiKQ4m6yas27Hvcs3rgNR9ltYhtf27nvxK1szZ8+6lIiUQMx//QKJtPEDyC1surZ+7eqqhlpZlmsVrdS5rlOdLx08dfiwAEdSLP9sseDbIjbafDMYgI9lvOZmMBJcl5IlXLKOCDJml5IxqijpBmBqtB1JYSVfYY8mP8MG/q/syusXV+BegVsW+x+nq23bsuaLgAAAAABJRU5ErkJggg==",
  "icon@3x.png": "iVBORw0KGgoAAAANSUhEUgAAAFcAAABXCAIAAAD+qk47AAAK00lEQVR42u2be3BU9RXHzzm/3927m5hk8+YRkISE4AMUEpS2Tmd41KkVVMCq43tGbWt9/NPaMloQja1O66PjYzq11dLpOLWlICodrc44ndYWpdIAkWAA8YFBIW82ZPfuvb/z6x83iUz23s1jN2RD90z+yGR/9yb3c8/j+zsnP9wAc+H/3iiLIEshSyFLIUshSyFLIUshS2EEJke1GokQETCzn0mD1lozp58CCaGZbY46ENfAmQwBgSQEJAaJiFmBTgcFJNKs+1S3hEDp7Oqyc2ryppaSEJmJgJl7v2hvaz54bP+BmIoGIR+JhvULOawLxFUfAtVfd3X9bVdXLJovcoKZH+dsxY/s3Lvz+U2NGzfbKmaKXFYq2ZtOsqckIWIqUlJZueq3j8xauhgAwGHtKK11RkcEAkoJkgDgs+27tt669kjz3pAoSALClwKRiHFk+vx5N722MXdaCUctREKiTE+NXyZI1swUMq3O439Ycduh7dtDlM+sRlEpkdDWsYIp02549bncaSXcZ5GUKCYJAgBAQCKSkqNxsyj/+leeLausjus+JBqNXkBUOn750w15M8u5zyJDwuQ0koKjVrCkYNVvHgbQ4FMwPCigIEtFar729do1yzlmT14EAyAkx+JnLrvwnEu+GePjntXNiwIig1pwyxoAgMxOhKPSUQtuXQOA2ssdyCMWHDvXLJ719UWuWDgNIKAgBJz51YUFBVOVshFxGAqIqMAuqJiSN70MFCdeMJY34W+jWpNC7URwVKi0sLCywoE4JDyUR8wzcLAgn4IBiDuQOgUiFOjnqKAYtAZElMK3ACkNnKpm18xoiGBhvgZGRJ3KbmoMZkWjJ06c8Ps0HA4TESvV3dHhtyY3N9c0zQzaU47KHMeRIXPzi1vuuPsuKaXjOCe7qNbaDJj/2f7OjKpZrYcOL/rKYituuT//8o+T0nGcZ5586tobrneilpRy8lFwLRaLdXd3e34khFBKAYBSqr2jXfko3Fgslln9hTGlBUJET18wDMPNvohoGAYze/oCjX+dOhWKyDPbe9YI9xu/NdmO2+SPCCnlkMTmer6UcjAipJRKqcSIcO8w6SlEo1HHcU5OCicXkcHs6FlN3aui0egkpkBEwLpuYd2PfngPEXGC8pFChMNhYB0Oh+/98VonoUa4V9UtrAPWQ9zEQx1mLgXF9YsvqF98ge8ipUFxYXHxTx95ONm9bCWCgaTihFPZ+I17RLBls7/+FUIgolZKxVUSmkTU/sVRx3EQUHu0VKCkpESk0BA+Fdlx2PTmZsfkK761csW+Dz4YEllumAQMo/G9/86smsWWPbZUmgYKboZz1dH40YxEIr29vX4OlaKsSAOF/ojVoO3+nI+IaYfillVPX0h9f5Hi9ag1b920ecqUKbW1tUVlJfKkG+q4o7VOV7X36zikRV9Kv9/JjoPM6J9ytNZoiM6j7VdecxUzFxcXV8+unj9/3oLzF5w3f35NdU3p1HIEAFtlRM+NWTuOHy9PCpqkJClBgo7ZKLxfJjMLhOZ9+9zI7Ojo6OjoeHfHu+6nRUVFVVVVl61YsW7deu2ocU0ZwyNQTCETAIRhePYdZeIblmh2ffrZ3xuemnvJ0in152jLQUJPXwCA3Xt2M/Ng0LpPq5Tq7Ozs7OycNfNMIFRKjV9rYERdpqDRtudA87Y321oOGhhMHFtS4sORlpGjba+v/9kzF65859GNaMok0849TU2DUJRSrlh2d81CiGVLl054IKBpND77l6cvuPS1+xq6Pz0itZEYF+QdESjPMEqFNrbds+HIO3swYGjFHtIQoGV/y5Dt8GD5VEqdNfes1OVtSggCsn3vhy/ffi9Y+gyjlFCOrBM/8GaVbUsZcDDe9MdtgJCYmUlKO2odPnw4kQIiMrNpmlWVlRNKQQNi86bXYxwxjJCybT+VTcmLEyLFeiI+OgE7Ozra2ts9KQBAeVl5WVkZKD2xqTHWfRyJtOaxdFmQkIRQbJ95UZ1fauzq6urfEXtRKCsrM3NztJq4AoEAADMvqmdmJEoyYSL/4mJ3Wa21i5ece+0Kbash4z03unpPnNBaJ7b3XcvPz0sMpVNpJIS2ndrLl8z/xqXd8VaHrVFMawGADBmunL7kjjuv2/ZraZrAeujIRH+5g/D9IzAD2nkaEOmqzU9e/IN7imbPoIDhOftJmNAR2RArO7v67n1vXPr0hmBhASiVqBdcJ3eHJX5vu7unGzRMbFJARGA2ckIXP7r2rn1vVlx4Xlz3JY6tyQufFtIQZoCjlnaSDenC4XAgEEisAu6G58NDh3o6OkGKCf4PIERQSvXFhCGlj3Ykv+oAWpMQfm8SEYF1eXl5aWmp5+VCiK6urtff+BsSejYdTzEIEgL8912UDGFST2PbCeXluroocePoZs1196+PdPcYOUHbtpl54p1itJVy+FYaMwAsX7bMUxe5g6YDBw+uWLny8KeHjZwgmQYSDars0dq4Ehw7BSICDVeuXm0YhvISBcxMRP94+591dQs3rL///d1NSjkiGJAhc9RfwcC47sdkKhSUFZ9dO2f1Fav+tOnPQyaRJ4Noa29/oOHBhocaaubMmVNTM2PGjNKS0ry8vIBhjNyZ29raktSjiew1IaJm/dCDDS+/+opt254jAzc0hBCO47S0tLS0tKTYccqsiHDdgeN29dw5T/ziMbeJ4FlTtNaO47gNCCGEHJONq+5INdiEEE4s/r07v3/gw4OP//IJtx3sOYA4ZQPoU+0L/SCIlGU/9sTj6+/7iVJqsPUEk8fSQAERBaKy7Aceati6ZUtVZaVb2IQQwl93nW4UXBKCSMXil69atfO9nQ9ueKCiosJtN7nNeDe2hRDuqArTbZlBYSBHqFg8HC5cd//6pl27f/+7jZetXFlSUsLMrvJx48UVkWkx91a2beuJzY6JILTjsFLhwqIbb77pxptv6jjatqdpT+OuXc3NzR9/8vGxY8d6eo5HY9G0yMH+OWUgIFKb/aRfkCGikNJlgUTFZaVLli9bsnzZQFtWW9GoZVmOciB9FSMcDoOtxjwHGy9Z6rIAAG07g/soNymYoZCZmzPYEUtLK6X/f2jT6AsEZB3v1ZaNQnh0mcaAY0i3TilQ6Yc+/AKtrZ4IAiVGosdsSoDR0/pF7+dtebOm6biT9uOTE1A7tQZDxNp7uj5qlWDA8FMZrYUweqPtn/xrJ2idOIyZjMbMGuCzHbt7uo4IERjhbAoQsPH5lwARJpUETNqDxcbntjB4n3XwoMBKBSm/5a23Dr32NgUNnvB+WYqO4CgKBVr/vbvplb8GKZ8dNQrVhCi23n5f9FgXhUzPKycNAtOwI30v3bqWlfLLcT7dV+YAhto/+eiFK75rdUUoFGDb0TyZcoRmZtuhUMCJxV9cc0frviZT5Po9wjBna6OqZ/q581Y///Opi84FAIirgROqGXuqDAGABEFAAkDb+wdeumXtRzvezRHhsZytHQRhqV7DCNV/55q6W7495byzgCZDvtRwbO/+XRu37PjVC9G+40GRN/Zz1v0riDSrKESCeMbU888un1ebP608U8/ca2aOfN529P39nzc2R1V3EPIEGX4Hi0dBwU2V7ukmG6IK7IHxjs7McABAAUYAgiQlj0xZj2wfoTUrBQgBzB2YWWLmBgOAZq01j7y0yVHdX2vWp4OYHM8uS5ZClkKWQpZClkKWQpZClsLpa/8Dn04+aYOd3K8AAAAASUVORK5CYII="
};
function json(value, status = 200) {
  return Response.json(value, { status, headers });
}
function settings(provider) {
  const prefix = "KOD_" + provider.toUpperCase() + "_";
  const config = Object.fromEntries(configKeys[provider].map(key => [key, Deno.env.get(prefix + key)]));
  return Object.values(config).every(Boolean) ? config : null;
}
function pem(value) {
  return Buffer.from(value, "base64").toString("utf8");
}
function printNumber(number) {
  return number.match(/.{4}/g).join(" ");
}
function walletRgb(hex) {
  return "rgb(" + hex.slice(1).match(/../g).map(pair => parseInt(pair, 16)).join(", ") + ")";
}
async function applePass(card, config) {
  const { tier, until } = cardEntitlement(card), metal = cardMetals[tier || "inactive"];
  const { PKPass } = await import("npm:passkit-generator@3.7.0");
  const assets = Object.fromEntries(Object.entries(icons).map(([name, data]) => [name, Buffer.from(data, "base64")]));
  const pass = new PKPass(assets, {
    wwdr: pem(config.WWDR_B64), signerCert: pem(config.SIGNER_CERT_B64), signerKey: pem(config.SIGNER_KEY_B64),
    signerKeyPassphrase: Deno.env.get("KOD_APPLE_KEY_PASSPHRASE") || undefined,
  }, {
    formatVersion: 1, passTypeIdentifier: config.PASS_TYPE_ID, teamIdentifier: config.TEAM_ID,
    serialNumber: card.number, organizationName: "توفير", description: "بطاقة عضوية توفير للخصومات", logoText: "توفير",
    backgroundColor: walletRgb(metal.base), foregroundColor: walletRgb(metal.ink), labelColor: walletRgb(metal.sub),
  });
  pass.type = "storeCard";
  pass.headerFields.push({ key: "tier", label: "الفئة", value: metal.mark });
  pass.primaryFields.push({ key: "holder", label: "حامل البطاقة", value: cardPrintedName(card.name) });
  pass.secondaryFields.push({ key: "number", label: "رقم العضوية", value: printNumber(card.number) });
  if (until) {
    pass.auxiliaryFields.push({ key: "validUntil", label: "صالحة حتى", value: cardEndDate(until) });
    pass.setExpirationDate(new Date(until));
  }
  pass.backFields.push({ key: "usage", label: "عند الكاشير", value: "أبرز رمز الخصم في الفرع المشارك قبل الدفع. يتحقق الكاشير من صلاحية العضوية وقت استخدام البطاقة." });
  pass.setBarcodes({ format: "PKBarcodeFormatQR", message: app + "#cashier/" + card.number, messageEncoding: "iso-8859-1", altText: printNumber(card.number) });
  return pass.getAsBuffer();
}
async function samsungUrl(card, config, now = Date.now()) {
  const { default: jose } = await import("npm:node-jose@2.2.0");
  const [recipient, signer] = await Promise.all([
    jose.JWK.asKey(pem(config.PUBLIC_CERT_B64), "pem"),
    jose.JWK.asKey(pem(config.SIGNER_KEY_B64), "pem"),
  ]);
  const { tier, until } = cardEntitlement(card, now), metal = cardMetals[tier || "inactive"];
  const holder = cardPrintedName(card.name);
  const attributes = {
    title: tier ? "توفير · " + metal.mark : "توفير", user: Array.from(holder).slice(0,64).join(""),
    bgColor: metal.base, fontColor: "dark", ...(until ? { endDate:until } : {}), providerName: "توفير", appLinkName: "توفير",
    appLinkLogo: app + "k.png", appLinkData: app + "#membership",
    "barcode.value": app + "#cashier/" + card.number, "barcode.serialType": "QRCODE", "barcode.ptFormat": "QRCODE",
  };
  const payload = { card: { type: "loyalty", subType: "others", data: [{ refId: card.number, createdAt: now, updatedAt: now, language: "ar", attributes }] } };
  const fields = { alg: "RS256", cty: "CARD", ver: "3", certificateId: config.CERTIFICATE_ID, partnerId: config.PARTNER_ID, utc: now };
  async function token() {
    const encrypted = await jose.JWE.createEncrypt({ format: "compact", fields: { alg: "RSA1_5", enc: "A128GCM" } }, { key: recipient, reference: false })
      .update(Buffer.from(JSON.stringify(payload))).final();
    return jose.JWS.createSign({ format: "compact", fields }, { key: signer, reference: false }).update(Buffer.from(encrypted)).final();
  }
  let signed = await token();
  if (signed.length > 2048) {
    // The cashier accepts the raw 16-digit serial as well as the full cashier URL.
    // Keep the loyalty template's required links and encode the styling in compact fields.
    const compact = { ...attributes, title: metal.mark, "barcode.value": card.number };
    delete compact.user;
    delete compact["barcode.serialType"];
    payload.card.data[0].attributes = compact;
    signed = await token();
    // The nested base64url envelopes grow by about 16/9 bytes per UTF-8 byte.
    const bytesAvailable = Math.max(0, Math.floor((2048 - signed.length - 5) * 9 / 16));
    let title = compact.title;
    for (const ch of Array.from(" · " + holder)) {
      const next = title + ch;
      if (Array.from(next).length > 32 || Buffer.byteLength(next) - Buffer.byteLength(compact.title) > bytesAvailable) break;
      title = next;
    }
    title = title.replace(/[ ·]+$/, "");
    if (title !== compact.title) { compact.title = title; signed = await token(); }
  }
  if (signed.length > 2048) throw Error("wallet_link_too_long");
  return "https://a.swallet.link/atw/v3/" + encodeURIComponent(config.CARD_ID) + "#Clip?cdata=" + signed;
}
async function walletRequest(request) {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (request.method !== "POST") return json({ error: "method" }, 405);
  const authorization = request.headers.get("Authorization") || "";
  if (!/^Bearer [^\s]+$/i.test(authorization)) return json({ error: "login" }, 401);
  const body = await request.json().catch(() => null);
  if (!body || !["apple", "samsung"].includes(body.provider) || Object.keys(body).length !== 1) return json({ error: "provider" }, 400);
  try {
    // Private membership authority derives the member only from the authenticated session.
    const response = await fetch(Deno.env.get("SUPABASE_URL") + "/rest/v1/rpc/kod_member_card", {
      method: "POST", headers: { authorization, apikey: Deno.env.get("SUPABASE_ANON_KEY"), "Content-Type": "application/json" },
      body: JSON.stringify({ p_request: false }), signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) {
      if (response.status === 401) return json({ error: "login" }, 401);
      const detail = await response.json().catch(() => ({}));
      if (response.status === 403 || detail.message === "member_required") return json({ error: "member_required" }, 403);
      return json({ error: "membership_unavailable" }, 503);
    }
    const card = await response.json();
    if (!/^\d{16}$/.test(card?.number) || card.number === "0000000000000000") return json({ error: "member_required" }, 403);
    const config = settings(body.provider);
    if (!config) return json({ error: "issuer_pending" }, 503);
    if (body.provider === "samsung") return json({ url: await samsungUrl(card, config) });
    const pass = await applePass(card, config);
    return new Response(pass, { headers: { ...headers, "Content-Type": "application/vnd.apple.pkpass", "Content-Disposition": 'attachment; filename="Tawfeer-Membership.pkpass"' } });
  } catch {
    return json({ error: "issuance_unavailable" }, 503);
  }
}
Deno.serve(walletRequest);

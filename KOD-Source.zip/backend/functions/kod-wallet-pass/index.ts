import { Buffer } from "node:buffer";

const app = "https://areejalloush1988.github.io/kod-uae/";
const headers = {
  "Access-Control-Allow-Origin": new URL(app).origin,
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Cache-Control": "private, no-store",
  "X-Content-Type-Options": "nosniff",
};
const configKeys = {
  apple: ["PASS_TYPE_ID", "TEAM_ID", "SIGNER_CERT_B64", "SIGNER_KEY_B64", "WWDR_B64"],
  samsung: ["CARD_ID", "PARTNER_ID", "CERTIFICATE_ID", "PUBLIC_CERT_B64", "SIGNER_KEY_B64"],
};
const icons = {
  "icon.png": "iVBORw0KGgoAAAANSUhEUgAAAB0AAAAdCAMAAABhTZc9AAAAVFBMVEX////+///+/v79/f36+vrl5ufWy8Ovra5xc3dPVFs4Qk0jLjobJzQbJjIaJjMaJjIZJzYZJTIZJDEYJDEXIzAUIC4SHisQHSoPHSoMGigKGCYGEyHT+163AAAA6UlEQVR42sXS227DIAwGYK+cDHh0jEMLef/3nEm0ldJod9O4idEXJPsHSL8t+GvNOe/fkPN3OWmMccdbDCn4PGuoTillW6ANuVCuXme9OQDA7ruVo2iUnlVKYVvxCiTgRmlRIfhs1AvOuhlGM+OkFgf2o/lFQRj+Q9cc05m+weWifQnpXMXo6BHEy1khbadzFQYErLz0rNwIKhK9n86rPHPpvb1kVQ+u2SHaEpecUxpRatqs1uah9+OOqPI1AKiPJ43VGWPsPVAbhUGPiD/KD6f3PraB++lbyXNXvIhoD5hn4epznug/XvsX1hc0C8PQk0sAAAAASUVORK5CYII=",
  "icon@2x.png": "iVBORw0KGgoAAAANSUhEUgAAADoAAAA6CAMAAADWZboaAAAAVFBMVEX////+///+/v79/f78/f38/Pz7+/z6+/vs7e7VycG/sKZ6e31NVmAoMj0cKDQbJzQbJjMaJjMaJTIZJTIZJDEYJDEXJDEUIS4PHCoMGScKFiQGEiDmwK7VAAAB2klEQVR42u2W7Y6sIAyGWRhHEIRxWAT0/u/ztFVnvwZZNjn/5o2JpvFJEd62svBnsRf6Qk/QieS/B0A1NCZSfLBT2pXn+xk6JaNIOrstYpc9ArHoT9BbNow0rJYCLo1yizA51tCu7+Da0Sk6yXrRiV7I8VhIOatg7Lpn9SEp1kFGwYG0oQG9LQORXAiz2NCA2kXDI5AdN6sNDShsLrtyQDumC2QBtXmUAsme6cWFFjRaxS5EDqvzDehiYXPxQ+E5Bh8a0Aybu5EqxSm0oKumY7mAiZILLaiGO8e9PSd/ooIpiXfO+oIViijqDUguK+QzlHP60KIVTrPuJpr/hOJ6U3tWWrBg0p7ubzErLllV2B8oh8PhfGdPvPTcEmCmrWpUDvfQakS0MNm57P7n9l83+8Oah+ybKgeKbnjkXY+teveo91qpz3nrhvjlh6nmSKqhUxw3lqOtKO9sR9QnixXaGnX+y85iGbis1TAMMFVu1WaajXwT1IcZdlNC1a9QbKe9ILbDwm3ICiwcLzVULPpsK+iXcUXstQPRvEqVBX8ZksQeU9KsJ1l9HLXRcJnHLPXRYIiCadz07HDgxYWUPqznl0PJx7Il4EVH+lxo7tAU/B18ePevv7UX+j/Qf9rX6Yc/Lu2MAAAAAElFTkSuQmCC",
  "icon@3x.png": "iVBORw0KGgoAAAANSUhEUgAAAFcAAABXCAMAAABGFileAAAAVFBMVEX///////7+/v79/f38/P38/Pz7/Pz19vbe4OLiybbet5mmq7BydHc9RU4dKTUcJzQbJzQaJzMaJjMZJTIYJTIZJDEYJDEYJDAWIi8PHCsJFiUHEyENoW8wAAACdElEQVR42u3Y3Y6rIBAAYBarQlVk4SwCvv97HsC/oT1pYZfNuWGumk7yhejMACL1O4GqW93qVre6ma6cj+CPKTGD4HmuNPaMRxakrF11jivMNJyxRKkZplxMRqS73I7oCBKtiBvWIxCDkSrLbbvWR9dGrkMo2jIu1aNhVV95LmrDepp4vWIdUHestUV0XqQq4DL3P2Tlq4eb7rI1YonUXBVwXSn0t2ZnG9RPhqkCLncswjuLHWuZKuDKRdP9T8e2KWyK+4dbUAodGlemSrjRO+vQkLDaFNezLWBXoUq4vhQaDFguS7ihFJqTJXqRqoArlaHnw3X9wLVQJVwBSsGzhqsSLiyF0GazKuHOnsVXmxmmirj2KgXfZms6+9oFU6FNa7MEFyNyTQXfZrMq4m52ZpslubgB7KdU5dZ7VBgxKo9NcRtMxZLJJrrMiPKufw5Mi/Kue290FeXeG8bROJfF1+vbLRN+1W89iVdcxvXzATU4d8NMmmfuN87c4FNcCeYvwl3OpEzfL8JkT4Yz9rewE61zEVcuZrjqLmOLe3d+EPoBZmnw2/MO15xc8M2NCrjXnzc6mX0+i048YQYB+LzRaZl9npztRGB/kHNqSj0eMT3culLO1QyWcYD3qSn1nd6pizsdrci/B/jL0A2hp0Olc48YzTdcxWF/XFPzcun33PjMfk7Nn7tSGtB4H/t54ueuIzToD7ydf/Jc3GEfLY7vxx7eMj7C1Mx8b2nfCbrJzianznrSbxG7/gZzZLb0ZNL7Qi2cnfH0LYXFoY+PNuZtHztYn/H03QjkfHy5uSNCvJ07oaaOeJH6Z7p+76tudatb3f/u/gXR3CYkwlTGJwAAAABJRU5ErkJggg=="
};
function json(value, status = 200) {
  return Response.json(value, { status, headers });
}
function settings(provider) {
  const prefix = "KOD_" + provider.toUpperCase() + "_";
  const config = Object.fromEntries(configKeys[provider].map(key => [key, Deno.env.get(prefix + key)]));
  return Object.values(config).every(Boolean) ? config : null;
}
function pem(value) {
  return Buffer.from(value, "base64").toString("utf8");
}
function printNumber(number) {
  return number.match(/.{4}/g).join(" ");
}
async function applePass(card, config) {
  const { PKPass } = await import("npm:passkit-generator@3.7.0");
  const assets = Object.fromEntries(Object.entries(icons).map(([name, data]) => [name, Buffer.from(data, "base64")]));
  const pass = new PKPass(assets, {
    wwdr: pem(config.WWDR_B64), signerCert: pem(config.SIGNER_CERT_B64), signerKey: pem(config.SIGNER_KEY_B64),
    signerKeyPassphrase: Deno.env.get("KOD_APPLE_KEY_PASSPHRASE") || undefined,
  }, {
    formatVersion: 1, passTypeIdentifier: config.PASS_TYPE_ID, teamIdentifier: config.TEAM_ID,
    serialNumber: card.number, organizationName: "KOD", description: "بطاقة عضوية كود للخصومات", logoText: "KOD",
    backgroundColor: "rgb(24, 36, 49)", foregroundColor: "rgb(255, 255, 255)", labelColor: "rgb(232, 188, 154)",
  });
  pass.type = "storeCard";
  const name = String(card.name || "").replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "").trim();
  pass.primaryFields.push({ key: "holder", label: "عضوية كود", value: name && !name.includes("@") && !/^[+\d٠-٩۰-۹ ().-]+$/.test(name) ? name.slice(0, 80) : "عضو كود" });
  pass.secondaryFields.push({ key: "number", label: "رقم العضوية", value: printNumber(card.number) });
  pass.backFields.push({ key: "usage", label: "عند الكاشير", value: "أبرز رمز الخصم في الفرع المشارك قبل الدفع. يتحقق الكاشير من صلاحية العضوية وقت استخدام البطاقة." });
  pass.setBarcodes({ format: "PKBarcodeFormatQR", message: app + "#cashier/" + card.number, messageEncoding: "iso-8859-1", altText: printNumber(card.number) });
  return pass.getAsBuffer();
}
async function samsungUrl(card, config, now = Date.now()) {
  const { default: jose } = await import("npm:node-jose@2.2.0");
  const [recipient, signer] = await Promise.all([
    jose.JWK.asKey(pem(config.PUBLIC_CERT_B64), "pem"),
    jose.JWK.asKey(pem(config.SIGNER_KEY_B64), "pem"),
  ]);
  const attributes = {
    title: "KOD", providerName: "KOD", appLinkName: "KOD",
    appLinkLogo: app + "k.png", appLinkData: app + "#membership",
    "barcode.value": app + "#cashier/" + card.number, "barcode.serialType": "QRCODE", "barcode.ptFormat": "QRCODE",
  };
  const payload = { card: { type: "loyalty", subType: "others", data: [{ refId: card.number, createdAt: now, updatedAt: now, language: "ar", attributes }] } };
  const encrypted = await jose.JWE.createEncrypt({ format: "compact", fields: { alg: "RSA1_5", enc: "A128GCM" } }, { key: recipient, reference: false })
    .update(Buffer.from(JSON.stringify(payload))).final();
  const fields = { alg: "RS256", cty: "CARD", ver: "3", certificateId: config.CERTIFICATE_ID, partnerId: config.PARTNER_ID, utc: now };
  const signed = await jose.JWS.createSign({ format: "compact", fields }, { key: signer, reference: false }).update(Buffer.from(encrypted)).final();
  if (signed.length > 2048) throw Error("wallet_link_too_long");
  return "https://a.swallet.link/atw/v3/" + encodeURIComponent(config.CARD_ID) + "#Clip?cdata=" + signed;
}
async function walletRequest(request) {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (request.method !== "POST") return json({ error: "method" }, 405);
  const authorization = request.headers.get("Authorization") || "";
  if (!/^Bearer [^\s]+$/i.test(authorization)) return json({ error: "login" }, 401);
  const body = await request.json().catch(() => null);
  if (!body || !["apple", "samsung"].includes(body.provider) || Object.keys(body).length !== 1) return json({ error: "provider" }, 400);
  try {
    // Private membership authority derives the member only from the authenticated session.
    const response = await fetch(Deno.env.get("SUPABASE_URL") + "/rest/v1/rpc/kod_member_card", {
      method: "POST", headers: { authorization, apikey: Deno.env.get("SUPABASE_ANON_KEY"), "Content-Type": "application/json" },
      body: JSON.stringify({ p_request: false }), signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) {
      if (response.status === 401) return json({ error: "login" }, 401);
      const detail = await response.json().catch(() => ({}));
      if (response.status === 403 || detail.message === "member_required") return json({ error: "member_required" }, 403);
      return json({ error: "membership_unavailable" }, 503);
    }
    const card = await response.json();
    if (!/^\d{16}$/.test(card?.number) || card.number === "0000000000000000") return json({ error: "member_required" }, 403);
    const config = settings(body.provider);
    if (!config) return json({ error: "issuer_pending" }, 503);
    if (body.provider === "samsung") return json({ url: await samsungUrl(card, config) });
    const pass = await applePass(card, config);
    return new Response(pass, { headers: { ...headers, "Content-Type": "application/vnd.apple.pkpass", "Content-Disposition": 'attachment; filename="KOD-Membership.pkpass"' } });
  } catch {
    return json({ error: "issuance_unavailable" }, 503);
  }
}
Deno.serve(walletRequest);

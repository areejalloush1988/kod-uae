// The website, card exports and wallet issuers use the same tier and printed details.
export const cardMetals={
  bronze:{mark:'برونزي',ink:'#32190f',sub:'#522b1a',glint:'#ffdfbf',base:'#cc916b',face:['#aa6e4f','#dc9d73','#f0c09b','#cb8963','#b77958']},
  silver:{mark:'فضي',ink:'#172a35',sub:'#324650',glint:'#f0fbff',base:'#adbdc9',face:['#94a5b3','#c2cdd4','#e5edf1','#afbec9','#91a4b2']},
  gold:{mark:'ذهبي',ink:'#342409',sub:'#493412',glint:'#fff2b9',base:'#ddb85b',face:['#c69739','#e5bb5c','#f6db90','#ddb65b','#c69839']},
  inactive:{mark:'بطاقة عضوية',ink:'#f4f5f6',sub:'#d3dade',glint:'#b9c7ce',base:'#34444b',face:['#2a3841','#364952','#465862','#33444c','#25343b']}
};

export function cardEntitlement(card,at=Date.now()){
  const expires=Date.parse(card?.expires_at);
  if(card?.status!=='active'||!(expires>at))return {tier:null,until:null};
  const periods=card.periods;
  if(!Array.isArray(periods)){
    const tier=['bronze','silver','gold'].includes(card.tier)?card.tier:'bronze';
    return {tier,until:expires};
  }
  const valid=periods.filter(p=>['bronze','silver','gold'].includes(p.tier)&&Date.parse(p.starts)<Date.parse(p.ends)).sort((a,b)=>Date.parse(a.starts)-Date.parse(b.starts));
  const current=valid.find(p=>Date.parse(p.starts)<=at&&at<Date.parse(p.ends));
  const tier=current?.tier||'bronze';
  // Time granted manually or as a referral has bronze benefits between paid terms.
  let until=tier==='bronze'?expires:Math.min(expires,Date.parse(current.ends));
  for(const p of valid){
    const start=Date.parse(p.starts);
    if(start<=at)continue;
    if(start>until)break;
    if(p.tier!==tier){until=Math.min(until,start);break;}
    if(tier!=='bronze')until=Math.min(expires,Math.max(until,Date.parse(p.ends)));
  }
  return {tier,until};
}

export function cardPrintedName(raw){
  const name=String(raw||'').replace(/[\u0000-\u001f\u007f\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,' ').replace(/\s+/g,' ').trim();
  return name&&!name.includes('@')&&!/^[+\d٠-٩۰-۹ ().-]+$/.test(name)?Array.from(name).slice(0,80).join(''):'عضو كود';
}

export function cardEndDate(until){
  if(!Number.isFinite(until))return '';
  return new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Dubai',day:'2-digit',month:'2-digit',year:'numeric'}).format(new Date(until-1));
}

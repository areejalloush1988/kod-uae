-- No credentials are created; all synthetic auth and identity rows roll back.
begin;
insert into auth.users(id,email,raw_user_meta_data,raw_app_meta_data)
 values('20000000-0000-4000-8000-000000000001','areejalloush1988@gmail.com','{"role":"developer"}','{}');
insert into auth.identities(provider_id,user_id,identity_data,provider)
 values('20000000-0000-4000-8000-000000000001','20000000-0000-4000-8000-000000000001','{"email":"areejalloush1988@gmail.com","email_verified":true}','email');
do $$begin
 if (select role from kod_private.kod_account_roles where user_id='20000000-0000-4000-8000-000000000001')<>'customer' then raise exception 'Unconfirmed email gained developer'; end if;
end$$;
update auth.users set email_confirmed_at=now() where id='20000000-0000-4000-8000-000000000001';
do $$begin
 if (select role from kod_private.kod_account_roles where user_id='20000000-0000-4000-8000-000000000001')<>'developer' then raise exception 'Confirmed owner did not gain developer'; end if;
 if (select account_role from public.kod_profiles where id='20000000-0000-4000-8000-000000000001')<>'developer' then raise exception 'Owner mirror inconsistent'; end if;
end$$;
insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data,raw_app_meta_data)
 values('20000000-0000-4000-8000-000000000002','kod-qa-impersonator@example.invalid',now(),'{"email":"areejalloush1988@gmail.com","email_verified":true,"role":"developer"}','{}');
insert into auth.identities(provider_id,user_id,identity_data,provider)
 values('20000000-0000-4000-8000-000000000002','20000000-0000-4000-8000-000000000002','{"email":"areejalloush1988@gmail.com","email_verified":true}','email');
do $$begin
 if (select role from kod_private.kod_account_roles where user_id='20000000-0000-4000-8000-000000000002')<>'customer' then raise exception 'Identity mismatch gained developer'; end if;
 if has_function_privilege('anon','public.rls_auto_enable()','EXECUTE') then raise exception 'Automatic RLS function is publicly executable'; end if;
end$$;
rollback;
select true as verified_owner_checks_passed, true as fixtures_rolled_back;

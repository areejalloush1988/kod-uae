-- Exercise a synthetic operator and two sessions. No real owner credential is read or changed.
begin;
do $test$
declare
  actor uuid:=gen_random_uuid(); other_actor uuid:=gen_random_uuid();
  sid uuid:=gen_random_uuid(); second_sid uuid:=gen_random_uuid();
  pin text:=lpad(((random()*999999)::int)::text,6,'0');
  next_pin text:=lpad(((random()*999999)::int)::text,6,'0'); claims jsonb; answer text; result_role text;
begin
  insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data,raw_app_meta_data) values
    (actor,'kod-owner-check-'||actor::text||'@example.invalid',now(),'{}','{}'),
    (other_actor,'kod-customer-check-'||other_actor::text||'@example.invalid',now(),'{"role":"developer","email_verified":true}','{}');
  if (select role from kod_private.kod_account_roles where user_id=other_actor)<>'customer' then raise exception 'metadata granted a privileged role'; end if;
  update kod_private.kod_account_roles set role='developer' where user_id=actor;
  insert into kod_private.kod_operator_security(user_id,email,pin_hash)
    select id,email,extensions.crypt(pin,extensions.gen_salt('bf',10)) from auth.users where id=actor;
  insert into auth.sessions(id,user_id,created_at,updated_at) values(sid,actor,now(),now()),(second_sid,actor,now(),now());
  claims=jsonb_build_object('sub',actor,'role','authenticated','session_id',sid,
    'amr',jsonb_build_array(jsonb_build_object('method','password','timestamp',extract(epoch from now())::bigint)));
  perform set_config('request.jwt.claim.sub',actor::text,true);
  perform set_config('request.jwt.claims',claims::text,true);
  execute 'set local role authenticated';
  if public.kod_my_role()<>'developer_locked' or public.kod_operator_access('unlock',pin)<>'proof_required'
    then raise exception 'password-only login granted admin'; end if;
  claims=jsonb_set(claims,'{amr,0,method}','"otp"');
  perform set_config('request.jwt.claims',claims::text,true);
  if public.kod_operator_access('unlock',null)<>'invalid_pin' or public.kod_my_role()<>'developer_locked'
    then raise exception 'missing PIN granted admin'; end if;
  answer=public.kod_operator_access('unlock',pin);
  result_role=public.kod_my_role();
  if answer<>'ok' or result_role<>'developer' then raise exception 'mailbox and PIN check failed, outcome %, role %',answer,result_role; end if;
  perform set_config('request.jwt.claims',jsonb_set(claims,'{session_id}',to_jsonb(second_sid))::text,true);
  if public.kod_my_role()<>'developer_locked' then raise exception 'grant traveled across sessions'; end if;
  answer=public.kod_operator_access('recover',null,next_pin);
  if answer<>'ok' then raise exception 'mailbox reset failed: %',answer; end if;
  answer=public.kod_operator_access('recover',null,next_pin);
  if answer<>'proof_required' then raise exception 'mailbox reset repeated: %',answer; end if;
  perform set_config('request.jwt.claims',claims::text,true);
  if public.kod_my_role()<>'developer_locked' then raise exception 'old grant survived PIN change'; end if;
  execute 'reset role';
end
$test$;
rollback;
select true as operator_checks_passed;

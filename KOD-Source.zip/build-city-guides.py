"""Generate the seven public, crawlable Tawfeer city guides from the dining directory."""
import base64
from collections import Counter
from html import escape
import json
from pathlib import Path
import re
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parent
SITE = "https://areejalloush1988.github.io/kod-uae/"
# Each selection contains one restaurant, cafe, and cafeteria from the emirate.
CITIES = {
    "dubai": (
        "دبي", "ابدأ من السطوة لغداء هندي، أو استكشف كافتيريات شارع شاطئ جميرا. يفتح الدليل على دبي لتبحث عن مطعمك بالاسم أو بنوع المطبخ.",
        "indian", ("n4898224460", "n11830263946", "n4507944117"),
    ),
    "abu-dhabi": (
        "أبوظبي", "بين جزيرة ياس ومدينة خليفة والعين، اختر المنطقة أولاً. افتح موقع الفرع على الخريطة لتعرف إن كان قريباً من وجهتك اليوم.",
        "khaleeji", ("n1704229127", "n13857220895", "n4463503389"),
    ),
    "sharjah": (
        "الشارقة", "لقهوة في قلب الشارقة أو وجبة في مويلح، تصفّح أماكن الإمارة ثم ابحث عن الحي. ستجد أيضاً فروعاً في الخان وعلى شاطئ الحيرة.",
        "cafe", ("n5281445985", "n10033062858", "w1511811167"),
    ),
    "ajman": (
        "عجمان", "إذا كانت وجهتك الرميلة أو الياسمين، ابحث باسم المنطقة في دليل عجمان. يمكنك الانتقال من غداء مندي إلى مقهى في الإمارة نفسها.",
        "grill", ("n4929638647", "n10605107926", "n10102935313"),
    ),
    "ras-al-khaimah": (
        "رأس الخيمة", "خطّط لاستراحة في جبل جيس أو قهوة في دفن الخور. افتح خريطة المكان قبل الانطلاق لتختار المحطة الأقرب لمسارك.",
        "breakfast", ("n4405637592", "w1523082811", "n5193792322"),
    ),
    "fujairah": (
        "الفجيرة", "اختر بين زيارة مطاعم الحليفات وجلسة في العقة. ابحث داخل دليل الفجيرة عن اسم المكان للتحقق من موقع الفرع قبل الزيارة.",
        "seafood", ("n5396197072", "n4291220592", "n10226409362"),
    ),
    "umm-al-quwain": (
        "أم القيوين", "من سيتي مول إلى منطقة منتجع باراكودا، استكشف أماكن الأكل والقهوة في أم القيوين. استخدم الخريطة لتضيف محطة قريبة إلى مشوارك.",
        "arabic", ("n4944358588", "n4933317739", "n4558925926"),
    ),
}
LABELS = {"restaurant": ("مطاعم", "مطعم"), "cafe": ("مقاهٍ", "مقهى"), "cafeteria": ("كافتيريات", "كافتيريا")}

CSS = """
*{box-sizing:border-box}html{color-scheme:light}body{margin:0;background:#fff;color:#000;font:400 16px/1.65 Cairo,Tahoma,Arial,sans-serif}
a{color:#000}a:focus-visible{outline:3px solid #800028;outline-offset:4px}p,h1,h2,h3{margin:0}p{color:#000}header{box-shadow:inset 0 4px #800028;border-bottom:1px solid #dfe2e1}
.wrap{max-width:1040px;margin-inline:auto;padding:0 26px}.top{min-height:72px;display:flex;align-items:center;justify-content:space-between;gap:16px}
.brand{display:inline-flex;gap:8px;align-items:center;font:800 30px/1.35 Cairo,Tahoma,sans-serif;text-decoration:none;color:#000}.brand img{border-radius:10px}
.top nav,.buttons,.cities{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.top nav a{font-weight:700;color:#000;text-decoration:none;padding:8px}
.hero{margin-block:41px 33px;display:grid;grid-template-columns:minmax(0,1.08fr) minmax(0,.92fr);align-items:center;gap:42px}
h1{font-size:clamp(34px,4.5vw,54px);line-height:1.25;letter-spacing:-.04em;margin-block-end:15px}h2{font-size:clamp(22px,3vw,29px);line-height:1.45;margin-block-end:14px}
.hero p{font-size:18px;max-width:43ch}.hero img{display:block;width:100%;height:clamp(210px,29vw,300px);object-fit:cover;border-radius:25px 25px 25px 6px}
.buttons{margin-block-start:22px}.btn{display:inline-flex;align-items:center;justify-content:center;border:1px solid #c5c9c9;border-radius:9px;padding:9px 15px;text-decoration:none;font-weight:700;color:#000}
.btn.primary{background:#ebbdcd;color:#000;border-color:#800028}.btn:hover{border-color:#800028}.btn.primary:hover{background:#dfa7bc}
.stats{display:grid;grid-template-columns:repeat(3,1fr);border-block:1px solid #dfe2e1;padding-block:17px;margin-block:0 35px}
.stats div{padding-inline:18px;border-inline-start:1px solid #dfe2e1}.stats div:first-child{border:0;padding-inline-start:0}
.stats dt{color:#000}.stats dd{font:700 clamp(24px,3.2vw,34px)/1.15 Cairo,Arial,sans-serif;margin:3px 0 0;font-variant-numeric:tabular-nums}
.places{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:13px;list-style:none;padding:0;margin:0}.place{padding:16px;border:1px solid #d7dddd;border-radius:12px}
.place small{color:#000;font-size:14px}.place h3{font-size:18px;margin-block:5px 12px}.place a,.info a,.small a{text-underline-offset:3px;font-weight:650}
.info{margin-block:27px;max-width:75ch}.cities{border-top:1px solid #dfe2e1;padding:20px 0}.cities strong{margin-inline-end:5px}.cities a{color:#000;text-underline-offset:3px}
.small{font-size:14px;padding:17px 0 28px;color:#000}.small bdi{direction:ltr}footer{border-top:1px solid #e6e9e8}
@media(max-width:660px){.wrap{padding-inline:18px}.top{min-height:60px}.top nav{gap:2px}.top nav a{padding:6px;font-size:14px}.hero{grid-template-columns:1fr;gap:19px;margin-block:28px 22px}
.hero img{height:165px;border-radius:17px 17px 17px 4px}.hero p{font-size:16px}.buttons{margin-block-start:16px}.places{grid-template-columns:1fr}.stats{margin-block-end:24px}.stats div{padding-inline:11px}
.place{display:grid;grid-template-columns:1fr auto;column-gap:12px;align-items:center}.place small{grid-column:1}.place h3{grid-column:1;grid-row:2;margin:0}.place a{grid-column:2;grid-row:1/3}.cities{gap:8px 14px}}
"""


def public_fonts():
    fonts = ROOT / "assets" / "fonts"
    css = (fonts / "cairo.css").read_text()
    for name in re.findall(r"url\(([^)]+)\)", css):
        encoded = base64.b64encode((fonts / name).read_bytes()).decode("ascii")
        css = css.replace(f"url({name})", f"url(data:font/woff2;base64,{encoded})")
    license_text = (fonts / "OFL.txt").read_text()
    return f"/* Cairo\n{license_text}\n*/\n{css}"


def osm_card(row):
    place_id = row["id"]
    kind = {"n": "node", "w": "way", "r": "relation"}[place_id[0]]
    name = escape(row["nameAr"] or row["name"] or row["nameEn"])
    return (
        f'<li class="place"><small>{LABELS[row["type"]][1]}</small><h3><bdi>{name}</bdi></h3>'
        f'<a href="https://www.openstreetmap.org/{kind}/{int(place_id[1:])}" '
        f'aria-label="موقع {name} على الخريطة">على الخريطة</a></li>'
    )


def render_city(slug, data, by_id, counts, catalog, photos, fonts):
    city, intro, photo_id, selections = CITIES[slug]
    rows = [by_id[place_id] for place_id in selections]
    if {row["type"] for row in rows} != set(LABELS) or any(row["emirate"] != city for row in rows):
        raise ValueError(f"Update the directory selections for {city}")
    title = f"مطاعم ومقاهي {city} | دليل توفير"
    summary = f"دليل توفير للمطاعم والمقاهي والكافتيريات في {city}. تعرّف على أماكن من الدليل وافتح مواقعها على الخريطة وتصفّح عضوية الخصومات."
    url = f"{SITE}city-{slug}.html"
    dirlink = f"./?area={slug}#directory"
    sublink = f"./?area={slug}#subscriptions"
    citylinks = " ".join(
        f'<a href="./city-{other}.html">{info[0]}</a>' for other, info in CITIES.items() if other != slug
    )
    stats = "".join(
        f'<div><dt>{names[0]}</dt><dd><bdi>{counts[(city, venue_type)]:,}</bdi></dd></div>'
        for venue_type, names in LABELS.items()
    )
    branches = [b for b in catalog["branches"] if b["emirate"] == city][:2]
    branch_links = "، و".join(
        f'<a href="{escape(b["url"], quote=True)}">{escape(b["name"])}</a> ({escape(b["area"])})'
        for b in branches
    )
    photo = photos[photo_id]
    hero_data = base64.b64encode((ROOT / "assets" / f"kod-{photo_id}.webp").read_bytes()).decode("ascii")
    structured = {
        "@context": "https://schema.org", "@type": "CollectionPage", "url": url, "name": title,
        "description": summary, "inLanguage": "ar-AE", "spatialCoverage": {"@type": "Place", "name": city},
        "isPartOf": {"@type": "WebSite", "name": "توفير", "url": SITE},
    }
    metadata = json.dumps(structured, ensure_ascii=False).replace("<", "\\u003c")
    return f'''<!doctype html>
<html lang="ar-AE" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><meta name="description" content="{summary}"><link rel="canonical" href="{url}"><link rel="icon" href="./k.png?brand=tawfeer"><meta name="theme-color" content="#800028">
<meta property="og:type" content="website"><meta property="og:locale" content="ar_AE"><meta property="og:site_name" content="توفير">
<meta property="og:title" content="{title}"><meta property="og:description" content="{summary}"><meta property="og:url" content="{url}">
<script type="application/ld+json">{metadata}</script><style>{fonts}{CSS}</style></head>
<body><header><div class="wrap top"><a class="brand" href="./" aria-label="توفير، الصفحة الرئيسية"><img src="./k.png?brand=tawfeer" alt="" width="36" height="36">توفير</a>
<nav aria-label="تصفح توفير"><a href="{dirlink}">دليل الأماكن</a><a href="{sublink}">عضوية توفير</a></nav></div></header>
<main class="wrap"><section class="hero"><div><h1>مطاعم ومقاهي {city}</h1><p>{intro}</p>
<div class="buttons"><a class="btn primary" href="{dirlink}">تصفّح دليل {city}</a><a class="btn" href="{sublink}">اعرض الاشتراكات</a></div></div>
<img alt="{escape(photo["alt"], quote=True)}" src="data:image/webp;base64,{hero_data}"></section>
<dl class="stats" aria-label="عدد الأماكن المسجلة في دليل {city}">{stats}</dl>
<section><h2>أماكن من دليل {city}</h2><ul class="places">{''.join(map(osm_card, rows))}</ul></section>
<div class="info"><h2>قبل الزيارة</h2><p>للتأكد من تفاصيل الفرع، تجد هنا صفحات {branch_links}. وللاستفادة من العضوية، راجع قائمة الفروع المشاركة ونسبة الخصم في <a href="./#membership">بطاقة توفير</a> قبل الطلب.</p></div>
<nav class="cities" aria-label="أدلة الإمارات"><strong>أدلة الإمارات</strong>{citylinks}</nav></main>
<footer><div class="wrap small">بيانات الأماكن بتاريخ <bdi>{escape(data["asOf"])}</bdi> من <a href="{escape(data["copyright"], quote=True)}" lang="en"><bdi>© OpenStreetMap contributors</bdi></a> بموجب <a href="{escape(data["license"], quote=True)}" lang="en">ODbL</a>. صورة الطعام من <a href="{escape(photo["url"], quote=True)}"><bdi>{escape(photo["photographer"])}</bdi></a>.</div></footer>
</body></html>
'''


def main():
    data = json.loads((ROOT / "uae-dining.json").read_text())
    rows = [dict(zip(data["fields"], row, strict=True)) for row in data["rows"]]
    by_id = {r["id"]: r for r in rows}
    counts = Counter((r["emirate"], r["type"]) for r in rows)
    catalog = json.loads((ROOT / "dining-catalog.json").read_text())
    photos = {r["id"]: r for r in json.loads((ROOT / "image-sources.json").read_text())}
    fonts = public_fonts()
    sitemap = ElementTree.Element("urlset", {"xmlns": "http://www.sitemaps.org/schemas/sitemap/0.9"})
    ElementTree.SubElement(ElementTree.SubElement(sitemap, "url"), "loc").text = SITE
    for slug in CITIES:
        filename = f"city-{slug}.html"
        (ROOT / filename).write_text(render_city(slug, data, by_id, counts, catalog, photos, fonts))
        ElementTree.SubElement(ElementTree.SubElement(sitemap, "url"), "loc").text = SITE + filename
    ElementTree.indent(sitemap)
    ElementTree.ElementTree(sitemap).write(ROOT / "sitemap.xml", encoding="utf-8", xml_declaration=True)


if __name__ == "__main__":
    main()

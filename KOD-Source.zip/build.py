"""Refresh the editable KOD components in the standalone GitHub Pages document."""
import base64
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
index = root / "index.html"
page = index.read_text()

def replace_section(source, start, end, content):
    before, rest = source.split(start, 1)
    _, after = rest.split(end, 1)
    return before + start + content + end + after

styles = (root / "base-layout.css").read_text() + "\n" + (root / "workspace-v6.css").read_text()
styles += "\n/* Campaign styles */\n" + (root / "campaign.css").read_text().rstrip()
page = replace_section(page, "<style>", "</style>", "\n" + styles + "\n")
page = replace_section(
    page, "/* KOD discovery components */", "/* End discovery components */",
    "\n" + (root / "discover.js").read_text().rstrip() + "\n",
)
workspace_marker = "/* KOD accounts and ordering. Public configuration contains no secret keys. */"
workspace = (root / "workspace-v6.js").read_text()
if not workspace.startswith(workspace_marker):
    raise ValueError("The account workspace marker is missing")
page = replace_section(page, workspace_marker, "function accountSettingsView()",
                       workspace.removeprefix(workspace_marker))

photo_line = re.compile(r"^const PHOTOS=(\{[^\n]+\});$", re.MULTILINE)
photos = json.loads(photo_line.search(page)[1])
image = (root / "assets" / "kod-campaign.webp").read_bytes()
photos["campaign"] = "data:image/webp;base64," + base64.b64encode(image).decode()
page = photo_line.sub(lambda _: "const PHOTOS=" + json.dumps(photos, separators=(",", ":")) + ";", page)
if index.read_text() != page:
    index.write_text(page)

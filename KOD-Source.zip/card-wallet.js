function cardFacePanel(card){
  const back=memberCardSide==='back';
  return '<div class="card-face-frame">'+memberArtHtml(card,memberCardSide)+'</div><div class="card-faces" role="group" aria-label="وجها بطاقة العضوية">'+
    '<button type="button" data-card-face="front" aria-pressed="'+!back+'">وجه البطاقة</button>'+
    '<button type="button" data-card-face="back" aria-pressed="'+back+'">رمز الخصم QR</button></div>';
}
let memberCardSide='front';
function cardWalletPanel(card){
  const sample=card.demo?'demo':'own';
  return '<section class="card-wallet"><h2>المحفظة والبطاقة البلاستيكية</h2><div class="wallet-choices">'+
    '<button type="button" class="wallet-choice" data-wallet="apple"><span lang="en" dir="ltr">Apple Wallet</span><small>على الآيفون</small></button>'+
    '<button type="button" class="wallet-choice" data-wallet="samsung"><span lang="en" dir="ltr">Samsung Wallet</span><small>على أجهزة Galaxy المتوافقة</small></button>'+
    '</div><div class="card-print"><div><strong>البطاقة البلاستيكية</strong><small>ملف PDF بوجهين، بمقاس بطاقة البنك.</small></div>'+
    '<button type="button" class="btn light" data-card-print="'+sample+'">'+(card.demo?'تنزيل نموذج للطباعة':'تنزيل ملف الطباعة')+'</button></div></section>';
}
function saveCardFile(blob,filename){
  const url=URL.createObjectURL(blob),link=document.createElement('a');
  link.href=url;link.download=filename;document.body.appendChild(link);link.click();link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),60000);
}
function canvasBlob(canvas,type,quality){
  return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('card_image_failed')),type,quality));
}
// Two independent, full-size CR80 pages. Stream lengths and xref positions are byte offsets.
function cardPrintPdf(images){
  const width=(85.60*72/25.4).toFixed(5),height=(53.98*72/25.4).toFixed(5);
  const encoded=new TextEncoder(),pieces=[],offsets=[0];
  let bytes=0;
  function write(value){
    const part=typeof value==='string'?encoded.encode(value):value;
    pieces.push(part);bytes+=part.byteLength;
  }
  function object(id,...parts){
    offsets[id]=bytes;write(id+' 0 obj\n');for(const part of parts)write(part);write('\nendobj\n');
  }
  write('%PDF-1.4\n');write(new Uint8Array([37,226,227,207,211,10]));
  object(1,'<< /Type /Catalog /Pages 2 0 R >>');
  object(2,'<< /Type /Pages /Count 2 /Kids [3 0 R 6 0 R] >>');
  images.forEach((image,i)=>{
    const page=3+i*3,draw='q\n'+width+' 0 0 '+height+' 0 0 cm\n/Face Do\nQ\n';
    object(page,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+width+' '+height+'] /Resources << /XObject << /Face '+(page+1)+' 0 R >> >> /Contents '+(page+2)+' 0 R >>');
    object(page+1,'<< /Type /XObject /Subtype /Image /Width '+image.width+' /Height '+image.height+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+image.data.length+' >>\nstream\n',image.data,'\nendstream');
    object(page+2,'<< /Length '+draw.length+' >>\nstream\n'+draw+'endstream');
  });
  const xref=bytes;
  write('xref\n0 9\n0000000000 65535 f \n');
  for(const pos of offsets.slice(1))write(String(pos).padStart(10,'0')+' 00000 n \n');
  write('trailer\n<< /Size 9 /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF\n');
  return new Blob(pieces,{type:'application/pdf'});
}
async function memberPrintFile(card){
  const images=await Promise.all(['front','back'].map(async side=>{
    const canvas=await memberArtCanvas(card,side,2,true);
    const jpeg=await canvasBlob(canvas,'image/jpeg',0.99);
    return {width:canvas.width,height:canvas.height,data:new Uint8Array(await jpeg.arrayBuffer())};
  }));
  return cardPrintPdf(images);
}
function walletMessage(provider,message,card){
  const samsung=provider==='samsung',brand=samsung?'Samsung Wallet':'Apple Wallet';
  let body='<p role="status">'+esc(message)+'</p>';
  if(samsung&&card)body+='<p>للإضافة اليدوية، احفظ صورة الرمز. في Samsung Wallet افتح «الكل»، ثم «العضويات» و«إضافة»، واختر الصورة من المعرض إذا ظهر الخيار على جهازك.</p><button class="btn light" data-card-gallery>حفظ صورة الرمز</button>';
  else if(card)body+='<button class="btn light" data-present-card>عرض رمز الخصم</button>';
  showModal('<div class="modal-body"><h2 id="modal-title" dir="ltr">'+brand+'</h2>'+body+'</div>');
}
async function openMemberWallet(provider,button){
  const card=connectedCard();
  if(!card){
    if(!appIdentity&&!previewRole){rememberCardRoute('membership');navigate('auth');}
    else walletMessage(provider,'تُضاف البطاقة الشخصية من حساب عضو كود.',null);
    return;
  }
  const epoch=workspaceEpoch,owner=appIdentity.id;
  if(button.disabled)return;
  button.disabled=true;
  const stillHere=()=>epoch===workspaceEpoch&&current==='membership'&&appIdentity?.id===owner;
  try{
    const client=await getKodClient(),{data,error}=await client.auth.getSession();
    if(!stillHere())return;
    if(error||!data.session||data.session.user.id!==owner)throw Error('login');
    const result=await fetch(KOD_CONFIG.supabaseUrl+'/functions/v1/kod-wallet-pass',{
      method:'POST',headers:{apikey:KOD_CONFIG.publishableKey,Authorization:'Bearer '+data.session.access_token,'Content-Type':'application/json'},
      body:JSON.stringify({provider}),credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(15000)
    });
    if(!stillHere())return;
    if(!result.ok){
      const body=await result.json().catch(()=>({}));if(!stillHere())return;
      const message=body.error==='issuer_pending'?'الإضافة المباشرة بانتظار تفعيل إصدار بطاقات كود لدى '+(provider==='apple'?'Apple.':'Samsung.'):
        result.status===401?'انتهت الجلسة. سجّل الدخول إلى حسابك مجدداً.':'تعذّر إصدار البطاقة من المحفظة حالياً.';
      walletMessage(provider,message,card);return;
    }
    if(provider==='apple'){
      if(!result.headers.get('Content-Type')?.startsWith('application/vnd.apple.pkpass'))throw Error('pass');
      const pass=await result.blob();if(!stillHere())return;
      saveCardFile(pass,'KOD-'+card.number.slice(-4)+'.pkpass');
      walletMessage(provider,'افتح ملف البطاقة على الآيفون واضغط «إضافة» لحفظه في Apple Wallet.',card);
    }else{
      const reply=await result.json(),url=new URL(reply.url);
      if(url.origin!=='https://a.swallet.link'||!url.pathname.startsWith('/atw/v3/')||!url.hash.startsWith('#Clip?cdata='))throw Error('wallet_url');
      if(stillHere())location.assign(url.href);
    }
  }catch(error){
    if(stillHere())walletMessage(provider,error.message==='login'?'سجّل الدخول من جديد لإصدار البطاقة.':'تعذّر الاتصال بخدمة المحفظة. يمكنك استخدام رمز البطاقة من التطبيق.',card);
  }finally{button.disabled=false;}
}

const VENUE_TYPES = {
  restaurant: { label:'مطاعم', single:'مطعم', icon:'food', search:'restaurant مطعم مطاعم' },
  cafe: { label:'مقاهٍ', single:'مقهى', icon:'coffee', search:'cafe coffee shop مقهى مقاهي كافيه كوفي قهوة' },
  cafeteria: { label:'كافتيريات', single:'كافتيريا', icon:'store', search:'cafeteria كافتيريا كافيتريا كافتيريات كفتيريا' }
};
const CUISINES = [
  ['indian','هندي','indian','indian south_indian north_indian dosa biryani punjabi kerala tandoori'],
  ['arabic','عربي','arabic','arab arabic arabian middle_eastern gulf yemeni syrian iraqi jordanian palestinian levantine lebanese egyptian emirati gulf_arabian'],
  ['western','غربي','western','western american burger burgers steak steak_house british french european portuguese german american_diner hot_dog fish_and_chips'],
  ['chinese','صيني','chinese','chinese cantonese szechuan sichuan dim_sum hotpot'],
  ['emirati','إماراتي','khaleeji','emirati emirate gulf_arabian'],
  ['italian','إيطالي','italian','italian pizza pasta'],
  ['japanese','ياباني','japanese','japanese sushi ramen teppanyaki'],
  ['levantine','شامي','shawarma','levantine lebanese syrian palestinian jordanian shawarma'],
  ['pakistani','باكستاني','indian','pakistani'],
  ['seafood','مأكولات بحرية','seafood','seafood fish fish_and_chips'],
  ['turkish','تركي','grill','turkish'],
  ['asian','آسيوي','chinese','asian thai korean vietnamese filipino malaysian indonesian asian_fusion'],
  ['mexican','مكسيكي','feast','mexican tex-mex tex_mex tacos'],
  ['cafe','قهوة وحلا','cafe','cafe coffee coffee_shop coffeehouse desserts dessert cake ice_cream bakery confectionery'],
  ['karak','شاي وكرك','karak','karak tea teahouse tea_shop chai'],
  ['international','عالمي','breakfast','international fusion regional world'],
  ['other','مطابخ أخرى','feast','other']
];
const CITY_EN = {'دبي':'Dubai','أبوظبي':'Abu Dhabi أبو ظبي','الشارقة':'Sharjah','عجمان':'Ajman','رأس الخيمة':'Ras Al Khaimah RAK','الفجيرة':'Fujairah','أم القيوين':'Umm Al Quwain UAQ'};
const byCuisine = new Map(CUISINES.map(c => [c[0],c]));
const cuisineTags = CUISINES.map(c => [c[0],new Set(c[3].split(' '))]);
const bridgeNames = [['starbucks','ستاربكس'],['costa coffee','كوستا'],['shake shack','شيك شاك'],['tim hortons','تيم هورتنز'],['mcdonald','ماكدونالدز'],['kfc','كنتاكي'],['filli','فيلي'],['gazebo','جازيبو'],['pizzaexpress','بيتزا إكسبرس'],['al fanar','الفنر'],['india palace','إنديا بالاس'],['nando','ناندوز']];
const directory = {type:'all',cuisine:'all',source:'map',limit:24};
let mapPlaces = [], mapByKey = new Map(), mapStatus = 'idle';
function norm(value) {
  return latinDigits(value).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0640]/g,'')
    .replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
}
function cuisineIds(raw) {
  const tags = new Set(String(raw || '').toLowerCase().split(/[;,]/).map(s=>s.trim().replace(/\s+/g,'_')).filter(Boolean));
  const ids = cuisineTags.filter(([,words]) => [...tags].some(t=>words.has(t))).map(([id])=>id);
  if(tags.size && !ids.length) ids.push('other');
  return ids;
}
function addSearchKey(place) {
  const nameWords = norm([place.name,place.en,place.local].join(' '));
  const aliases = bridgeNames.filter(([en,ar])=>nameWords.includes(en)||nameWords.includes(norm(ar))).flat();
  place.search = norm([nameWords, ...aliases, place.area,place.emirate,CITY_EN[place.emirate],
    VENUE_TYPES[place.type].search,place.raw,...place.cuisines.map(id=>byCuisine.get(id)?.[1])].join(' '));
  return place;
}
const officialPlaces = DINING_BRANCHES.map(b => addSearchKey({...b,key:'venue:'+b.id,official:true,
  cuisines:[...new Set([...b.cuisines,...(b.cuisines.some(c=>['emirati','levantine'].includes(c))?['arabic']:[])])]}));
const officialByKey = new Map(officialPlaces.map(p=>[p.key,p]));
function indexMapData(data) {
  const fields='id,name,nameAr,nameEn,type,emirate,cuisine,lat,lon,area';
  if(data.schema!==1||!Array.isArray(data.fields)||data.fields.join(',')!==fields||!Array.isArray(data.rows)) throw Error('Unknown dining dataset');
  return data.rows.map(row=>{
    const [id,local,ar,en,type,emirate,raw,lat,lon,area] = row;
    if(!/^[nwr]\d+$/.test(id)||!VENUE_TYPES[type]||!CITY_EN[emirate]||!(ar||local||en)||!Number.isFinite(lat)||!Number.isFinite(lon)) throw Error('Invalid place');
    return addSearchKey({key:'osm:'+id,id,name:ar||local||en,en:en||'',local,area,raw,type,emirate,cuisines:cuisineIds(raw),lat,lon});
  });
}
async function loadMapPlaces() {
  if(mapStatus==='loading'||mapStatus==='ready')return;
  mapStatus='loading';
  refreshDirectoryViews();
  try {
    const response=await fetch('./uae-dining.json?v='+encodeURIComponent(DINING_META.asOf),{credentials:'omit'});
    if(!response.ok)throw Error('Map download unavailable');
    const rows=indexMapData(await response.json());
    if(!rows.length) throw Error('Empty map download');
    mapPlaces=rows; mapByKey=new Map(rows.map(p=>[p.key,p])); mapStatus='ready';
  } catch { mapStatus='error'; }
  refreshDirectoryViews();
}
function refreshDirectoryViews() {
  if(current==='directory') updateDirectory();
  if(current==='favorites') updateDiningFavorites();
  if(current==='dashboard'&&isLiveOperator()&&ownerCustomerId&&mapStatus==='ready')render('dashboard');
}
function matchingPlaces(list) {
  const tokens=norm(query).split(' ').filter(Boolean);
  return list.filter(p=>(state.city==='all'||p.emirate===state.city) &&
    (directory.type==='all'||p.type===directory.type) &&
    (directory.cuisine==='all'||p.cuisines.includes(directory.cuisine)) &&
    tokens.every(token=>p.search.includes(token)));
}
function getPlace(key) { return officialByKey.get(key)||mapByKey.get(key); }
function placeCuisines(p) {
  const names=p.cuisines.filter(c=>c!=='arabic'||!p.cuisines.some(i=>i==='emirati'||i==='levantine')).filter(c=>c!=='other')
    .slice(0,3).map(id=>byCuisine.get(id)?.[1]).filter(Boolean);
  return names.length?names.join(' · '):String(p.raw||'').split(';').filter(Boolean).slice(0,2).map(v=>v.replaceAll('_',' ')).join(' · ');
}
function linkOut(url,label,cls='standard-link') {
  if(!/^https:\/\//i.test(url||''))return '';
  return '<a class="'+cls+'" href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">'+displayText(label)+' <span aria-hidden="true">↗</span></a>';
}
function mapsUrl(p) {
  if(Number.isFinite(p.lat)&&Number.isFinite(p.lon))return 'https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(p.lat+','+p.lon);
  return 'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent([p.en||p.name,p.area,p.emirate,'United Arab Emirates'].filter(Boolean).join(', '));
}
function placeRow(p) {
  const meta=[VENUE_TYPES[p.type].single,placeCuisines(p)].filter(Boolean).join(' · ');
  return '<article class="place-row"><div class="place-symbol" aria-hidden="true">'+icon(VENUE_TYPES[p.type].icon)+'</div>'+
    '<button class="place-info" data-place="'+esc(p.key)+'"><strong dir="auto">'+displayText(p.name)+'</strong>'+
    '<span>'+displayText([p.emirate,p.area].filter(Boolean).join(' · '))+'</span><small>'+displayText(meta)+'</small></button>'+heart(p.key,p.name)+'</article>';
}
function placeDetails(key) {
  const p=getPlace(key); if(!p)return;
  const osmTypes={n:'node',w:'way',r:'relation'};
  const source=p.official?p.url:'https://www.openstreetmap.org/'+osmTypes[p.id[0]]+'/'+p.id.slice(1);
  const cuisine=placeCuisines(p);
  showModal('<div class="modal-body place-detail"><p class="overline">'+displayText(VENUE_TYPES[p.type].single)+' · '+displayText(p.emirate)+'</p>'+
    '<h2 id="modal-title" dir="auto">'+displayText(p.name)+'</h2>'+(p.en&&norm(p.en)!==norm(p.name)?'<p dir="ltr" lang="en">'+displayText(p.en)+'</p>':'')+
    '<dl><div><dt>الموقع</dt><dd>'+displayText([p.area,p.emirate,'الإمارات'].filter(Boolean).join('، '))+'</dd></div>'+
    (cuisine?'<div><dt>المطبخ</dt><dd>'+displayText(cuisine)+'</dd></div>':'')+'</dl>'+
    '<div class="venue-actions">'+linkOut(mapsUrl(p),p.official?'ابحث عن الفرع في الخرائط':'الاتجاهات إلى المكان','map-action')+
    linkOut(source,p.official?'موقع الفرع أو الجهة الرسمية':'صفحة المكان على OpenStreetMap')+'</div></div>');
}
function dirFilters() {
  const opts=CUISINES.map(c=>'<option value="'+c[0]+'"'+(directory.cuisine===c[0]?' selected':'')+'>'+c[1]+'</option>').join('');
  const types=[['all','كل الأماكن'],...Object.entries(VENUE_TYPES).map(([k,v])=>[k,v.label])];
  return '<div class="directory-filter"><div class="type-tabs" role="group" aria-label="نوع المكان">'+types.map(([id,label])=>
    '<button data-list-type="'+id+'" aria-pressed="'+(directory.type===id)+'">'+label+'</button>').join('')+'</div>'+
    '<label class="cuisine-select">المطبخ <select id="cuisine-select" aria-label="المطبخ"><option value="all">كل المطابخ</option>'+opts+'</select></label></div>';
}
function directoryPage() {
  return '<section class="dining-directory"><div class="market-heading"><div><h1>دليل الأماكن</h1><p>ابحث عن مطعم أو مقهى أو كافتيريا بالاسم أو المنطقة أو المطبخ.</p></div></div>'+
    dirFilters()+'<div class="source-switch" role="group" aria-label="مصدر الأماكن"><button data-list-source="map">دليل الخريطة <b id="map-badge"></b></button>'+
    '<button data-list-source="official">فروع من مصادر رسمية <b id="official-badge"></b></button></div>'+
    '<div class="directory-summary"><p id="directory-status" role="status"></p><button class="text-button" data-directory-reset>مسح الفلاتر</button></div>'+
    '<div id="directory-list" class="place-list"></div><div id="directory-next"></div>'+attribution()+'</section>';
}
function attribution() {
  return '<p class="data-attribution">بيانات الخريطة © '+linkOut('https://www.openstreetmap.org/copyright','مساهمو OpenStreetMap')+
    ' · <a href="./uae-dining.json" download>تنزيل بيانات الأماكن</a> · <a href="./DATA-LICENSE.txt" target="_blank" rel="noopener">ترخيص البيانات</a></p>';
}
function emptyPlaces() {return '<div class="empty"><h3>لا توجد أماكن تطابق بحثك</h3><p>جرّب اسم المنطقة بالعربية أو الإنجليزية، أو أزل فلاتر البحث.</p><button class="btn light" data-directory-reset>عرض كل الأماكن</button></div>';}
function updateDirectory() {
  const list=document.getElementById('directory-list'); if(!list)return;
  const official=matchingPlaces(officialPlaces), mapped=mapStatus==='ready'?matchingPlaces(mapPlaces):[];
  const officialFallback=directory.source==='map'&&mapStatus==='ready'&&!mapped.length&&official.length>0;
  const shownSource=officialFallback?'official':directory.source;
  const isMap=shownSource==='map', entries=isMap?mapped:official;
  document.querySelectorAll('[data-list-source]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.listSource===shownSource)));
  document.querySelectorAll('[data-list-type]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.listType===directory.type)));
  document.getElementById('cuisine-select').value=directory.cuisine;
  document.getElementById('official-badge').textContent=number(official.length);
  document.getElementById('map-badge').textContent=mapStatus==='ready'?number(mapped.length):'';
  const status=document.getElementById('directory-status'), next=document.getElementById('directory-next');
  next.innerHTML='';
  if(isMap&&mapStatus!=='ready'){
    status.textContent=mapStatus==='error'?'تعذّر تحميل بيانات الخريطة.':'يجري تحميل أماكن الإمارات…';
    list.innerHTML=mapStatus==='error'?'<div class="empty"><button class="btn" data-directory-retry>أعد التحميل</button><button class="text-button" data-list-source="official">تصفّح الفروع الرسمية</button></div>':'';
    return;
  }
  status.textContent=number(entries.length)+(officialFallback?' من الفروع المطابقة من مصادر رسمية':' من الأماكن')+(state.city==='all'?' في الإمارات':' في '+state.city);
  list.innerHTML=entries.length?entries.slice(0,directory.limit).map(placeRow).join(''):emptyPlaces();
  if(entries.length>directory.limit)next.innerHTML='<button class="load-more" data-more-places>عرض أماكن أكثر '+icon('arrow')+'</button>';
}
function openDirectory(options={}) {
  directory.type=options.type||'all';directory.cuisine=options.cuisine||'all';directory.source=options.source||'map';directory.limit=24;
  query=options.query||'';
  if(options.city){state.city=options.city;persist();}
  if(current==='directory'){
    document.getElementById('city').value=state.city;document.getElementById('global-search').value=query;
    updateDirectory();if(directory.source==='map'&&mapStatus==='idle')loadMapPlaces();
  }else navigate('directory');
}

const STORIES = [
  {photo:'feast',label:'دليل مطاعم الإمارات',title:'وين ناكل اليوم؟',text:'من كافتيريا الحيّ إلى مائدة لشخصين. اكتشف الأماكن في الإمارات السبع.',action:'استكشف الدليل',attr:'data-directory-open="all"'},
  {photo:'indian',label:'من المطابخ الهندية',title:'على سفرة هندية',text:'اكتشف مطاعم البرياني والكاري، واختر الفرع في إمارتك.',action:'اكتشف الهندي',attr:'data-cuisine="indian"'},
  {photo:'chinese',label:'من المطابخ الصينية',title:'موعد مع الدِم سَم',text:'تصفّح المطاعم الصينية والأماكن المصنّفة كانتونية.',action:'اكتشف الصيني',attr:'data-cuisine="chinese"'}
];
let storyIndex=0, showDemoDeals=false;
const photoAlt = key=>DINING_IMAGES.find(i=>i.id===key)?.alt||'صورة توضيحية للطعام';
function photo(key,cls='',priority=false) {
  return '<img class="'+cls+'" src="'+(PHOTOS[key]||PHOTOS.feast)+'" alt="'+esc(photoAlt(key))+'" '+
    (priority?'fetchpriority="high"':'loading="lazy"')+' decoding="async">';
}
function isDiningFavorite(id) {
  return typeof id==='string'&&id.length<=80&&(/^(venue|deal):[a-z0-9-]+$/.test(id)||/^osm:[nwr]\d+$/.test(id)||OFFERS.some(o=>o.id===id));
}
function heart(key,name) {
  const on=state.favorites.includes(key), label=(on?'إزالة من المفضلة':'حفظ في المفضلة')+' · '+name;
  return '<button class="dining-heart'+(on?' saved':'')+'" data-favorite="'+esc(key)+'" data-favorite-name="'+esc(name)+'" aria-label="'+esc(label)+'" aria-pressed="'+on+'">'+icon('heart')+'</button>';
}
function updateHearts() {
  document.querySelectorAll('[data-favorite]').forEach(b=>{
    const on=state.favorites.includes(b.dataset.favorite);
    b.classList.toggle('saved',on); b.setAttribute('aria-pressed',String(on));
    b.setAttribute('aria-label',(on?'إزالة من المفضلة':'حفظ في المفضلة')+' · '+b.dataset.favoriteName);
  });
}
function navHtml(mobile) {
  const ids=mobile?['discover','directory','deals','favorites','account']:['discover','directory','deals','favorites','orders','membership','account'];
  const extra={directory:{name:'دليل الأماكن',short:'الدليل',icon:'pin'},deals:{name:'عروض المطاعم',short:'العروض',icon:'ticket'}};
  return ids.map(id=>{
    const row=extra[id]||NAV.find(n=>n.id===id);
    const selected=id===current||(id==='account'&&['auth','register','dashboard','merchant','developer'].includes(current));
    const label=id==='account'&&!appIdentity&&!previewRole?'الدخول':row[mobile?'short':'name'];
    return '<button data-go="'+id+'" class="'+(selected?'active':'')+'"'+(selected?' aria-current="page"':'')+'>'+icon(row.icon)+'<span>'+label+'</span></button>';
  }).join('');
}
function storyContent() {
  const s=STORIES[storyIndex];
  return '<div class="story-art">'+photo(s.photo,'',true)+'</div><div class="story-copy"><span class="story-label">'+s.label+'</span>'+
    '<h1 id="cover-title">'+s.title+'</h1><p>'+s.text+'</p><button class="story-cta" '+s.attr+'>'+s.action+' '+icon('arrow')+'</button></div>';
}
function storyCount() {return arabicNumber(storyIndex+1)+' من '+arabicNumber(STORIES.length);}
function changeStory(step) {
  const box=document.getElementById('lead-story');if(!box)return;
  storyIndex=(storyIndex+step+STORIES.length)%STORIES.length;box.dataset.photo=STORIES[storyIndex].photo;box.innerHTML=storyContent();
  document.getElementById('story-count').textContent=storyCount();
}
function campaignCover() {
  return '<div class="editorial-grid"><section class="lead-feature" aria-label="اختيارات المائدة">'+
    '<div class="lead-story" id="lead-story" data-photo="'+STORIES[storyIndex].photo+'" aria-live="polite">'+storyContent()+'</div>'+
    '<div class="story-controls" role="group" aria-label="تصفّح اختيارات المائدة"><button data-story-step="-1" aria-label="الاختيار السابق">'+icon('arrow')+'</button>'+
    '<span id="story-count">'+storyCount()+'</span><button data-story-step="1" aria-label="الاختيار التالي">'+icon('arrow')+'</button></div></section>'+
    '<div class="spotlights"><button class="spotlight cafe-spot" data-directory-open="cafe">'+
    '<span class="spotlight-copy"><small>المقاهي</small><strong>قهوة وحلا</strong><span class="spotlight-more">اكتشف المقاهي '+icon('arrow')+'</span></span>'+photo('cafe')+'</button>'+
    '<button class="spotlight karak-spot" data-directory-open="cafeteria"><span class="spotlight-copy"><small>الكافتيريات</small><strong>كرك على الطريق</strong>'+
    '<span class="spotlight-more">اكتشف الكافتيريات '+icon('arrow')+'</span></span>'+photo('karak')+'</button></div></div>';
}
function cuisineShelf() {
  return '<section class="cuisine-shelf" aria-labelledby="cuisine-title"><div class="market-heading"><h2 id="cuisine-title">أي مطبخ على بالك؟</h2>'+
    '<button class="plain-action" data-directory-open="all">كل المطابخ '+icon('arrow')+'</button></div><div class="cuisine-rail">'+
    CUISINES.slice(0,10).map(c=>'<button data-cuisine="'+c[0]+'"><span>'+photo(c[2])+'</span><strong>'+c[1]+'</strong></button>').join('')+'</div></section>';
}
function typeShelf() {
  return '<div class="type-entry" role="group" aria-label="اكتشف حسب نوع المكان">'+Object.entries(VENUE_TYPES).map(([id,t])=>
    '<button data-directory-open="'+id+'">'+icon(t.icon)+'<strong>'+t.label+'</strong><span>'+arabicNumber(DINING_META.types[id])+'</span></button>').join('')+'</div>';
}
function todayInUae() {
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Dubai',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
  const field=key=>parts.find(p=>p.type===key).value;
  return field('year')+'-'+field('month')+'-'+field('day');
}
function activeDeals(day=todayInUae()) {return PUBLIC_DEALS.filter(d=>!d.endDate||d.endDate>=day);}
function dealCard(d) {
  return '<article class="dining-deal"><div class="deal-image"><button data-public-deal="'+d.id+'" aria-label="تفاصيل '+esc(d.restaurant)+'">'+photo(d.photo)+'</button>'+
    '<b class="price-flag">'+esc(d.priceLabel)+'</b>'+heart('deal:'+d.id,d.restaurant)+'</div>'+
    '<button class="deal-copy" data-public-deal="'+d.id+'"><small>'+esc(d.restaurant)+' · '+esc(d.emirate)+'</small><h3>'+esc(d.title)+'</h3>'+
    '<span>'+esc(d.schedule)+'</span></button></article>';
}
function publicDealDetails(id) {
  const d=activeDeals().find(o=>o.id===id);if(!d){toast('انتهت مدة العرض المنشورة.');return;}
  const menu=d.menuUrl?linkOut(d.menuUrl,'قائمة العرض'):'';
  showModal('<div class="deal-modal-photo">'+photo(d.photo)+'</div><div class="modal-body place-detail"><p class="overline">'+esc(d.restaurant)+' · '+esc(d.emirate)+'</p>'+
    '<h2 id="modal-title">'+esc(d.title)+'</h2><strong class="deal-price">'+esc(d.priceLabel)+'</strong><dl><div><dt>الفرع</dt><dd>'+esc(d.branch)+'</dd></div>'+
    '<div><dt>وقت العرض</dt><dd>'+esc(d.schedule)+'</dd></div>'+(d.endDate?'<div><dt>متاح حتى</dt><dd dir="ltr">'+esc(d.endDate)+'</dd></div>':'')+
    '</dl><p class="description">'+esc(d.terms)+'</p><div class="venue-actions">'+linkOut(d.url,'شروط العرض لدى الجهة الناشرة','map-action')+menu+
    linkOut(mapsUrl({name:d.restaurant,en:d.en,area:d.branch,emirate:d.emirate}),'ابحث عن الفرع في الخرائط')+'</div>'+
    '<p class="tiny">آخر مراجعة '+esc(d.checkedOn)+' · تحقّق من التوافر مع الفرع. صورة الطعام توضيحية.</p></div>');
}
function homeDeals() {
  const all=activeDeals(),list=(state.city==='all'?all:all.filter(d=>d.emirate===state.city)).slice(0,4);
  return '<section class="published-shelf"><div class="market-heading"><div><h2>عروض من المطاعم</h2><p>السعر والفرع والشروط من الجهة الناشرة</p></div>'+
    '<button class="plain-action" data-go="deals">كل العروض '+icon('arrow')+'</button></div>'+
    (list.length?'<div class="market-card-grid">'+list.map(dealCard).join('')+'</div>':'<p>لم نرصد عرضاً منشوراً في هذه الإمارة حالياً.</p>')+'</section>';
}
function offerCard(o) {
  return '<article class="dining-deal"><div class="deal-image"><button data-offer="'+o.id+'" aria-label="تفاصيل '+esc(o.name)+'">'+photograph(o)+'</button>'+
    '<b class="price-flag">'+number(o.percent)+'% · تجريبي</b>'+heart(o.id,o.name)+'</div>'+
    '<button class="deal-copy" data-offer="'+o.id+'"><small>'+esc(o.name)+' · '+esc(o.city)+'</small><h3>'+esc(o.title)+'</h3>'+
    '<span>توفير تجريبي '+number(Math.round(o.base*o.percent)/100)+' د.إ على فاتورة '+number(o.base)+' د.إ</span></button>'+
    '<button class="demo-menu" data-menu="'+o.id+'">'+icon('food')+' جرّب المنيو والطلب</button></article>';
}
function dealsPage() {
  const list=(showDemoDeals?OFFERS:activeDeals()).filter(o=>state.city==='all'||(o.emirate||o.city)===state.city);
  return '<section class="deals-page"><div class="market-heading"><div><h1>عروض المطاعم والمقاهي</h1><p>'+
    (showDemoDeals?'نماذج لتجربة العضوية والتوفير والطلب.':'افتح العرض لمعرفة السعر والفرع وشروط الاستخدام لدى ناشره.')+'</p></div></div>'+
    '<div class="type-tabs" role="group" aria-label="نوع العرض"><button data-offer-mode="published" aria-pressed="'+!showDemoDeals+'">من المطاعم</button>'+
    '<button data-offer-mode="demo" aria-pressed="'+showDemoDeals+'">تجربة عضوية كود</button></div>'+
    (list.length?'<div class="market-card-grid">'+list.map(showDemoDeals?offerCard:dealCard).join('')+'</div>':
      '<div class="empty"><h3>ما في عروض مدرجة بهالإمارة حالياً</h3><p>فيك تكتشف المطاعم والكافتيريات الموجودة بالدليل.</p>'+
      '<button class="btn" data-directory-open="all">دليل الأماكن</button><button class="text-button" data-deals-all-cities>عروض كل الإمارات</button></div>')+'</section>';
}
function cityShelf() {
  return '<section class="city-board"><div class="city-heading">'+icon('pin')+'<h2>اكتشف حسب الإمارة</h2></div><div class="city-options">'+
    CITIES.slice(1).map(c=>'<button data-dining-city="'+c+'"><strong>'+c+'</strong><span>'+arabicNumber(DINING_META.cities[c])+' مكان</span>'+icon('arrow')+'</button>').join('')+'</div></section>';
}
function featuredBranches() {
  const list=officialPlaces.filter(p=>state.city==='all'||p.emirate===state.city).slice(0,4);
  return '<section class="official-shelf"><div class="market-heading"><div><h2>فروع من الدليل</h2><p>معلومات من المطعم أو الجهة المستضيفة</p></div>'+
    '<button class="plain-action" data-official-list>كل الفروع '+icon('arrow')+'</button></div><div class="place-list">'+list.map(placeRow).join('')+'</div></section>';
}
function discover() {
  return '<div class="market-home">'+campaignCover()+typeShelf()+cuisineShelf()+homeDeals()+featuredBranches()+cityShelf()+
    '<div class="market-links"><button data-go="food">'+icon('food')+' الطلب والتوصيل</button><button data-go="orders">'+icon('bag')+' طلباتي</button>'+
    '<button data-go="membership">'+icon('card')+' عضوية كود</button><button data-go="partner">'+icon('store')+' انضم بمطعمك أو مقهاك</button></div>'+attribution()+'</div>';
}
function favorites() {
  return '<section class="dining-favorites"><div class="market-heading"><div><h1>المفضلة</h1><p>مطاعمك ومقاهيك وعروضك المحفوظة</p></div></div><div id="favorites-content"></div></section>';
}
function updateDiningFavorites() {
  const el=document.getElementById('favorites-content');if(!el)return;
  const keys=state.favorites,city=state.city;
  const ps=keys.map(getPlace).filter(p=>p&&(city==='all'||p.emirate===city));
  const deals=activeDeals().filter(d=>keys.includes('deal:'+d.id)&&(city==='all'||d.emirate===city));
  const demos=OFFERS.filter(o=>keys.includes(o.id)&&(city==='all'||o.city===city));
  const waiting=keys.some(k=>k.startsWith('osm:'))&&mapStatus!=='ready';
  const pending=waiting?mapStatus==='error'?'<p>تعذّر تحميل الأماكن المحفوظة من الخريطة. <button class="text-button" data-directory-retry>أعد المحاولة</button></p>':'<p role="status">يجري تحميل الأماكن المحفوظة…</p>':'';
  el.innerHTML=(deals.length?'<h2>عروض المطاعم</h2><div class="market-card-grid">'+deals.map(dealCard).join('')+'</div>':'')+
    (ps.length?'<h2>الأماكن المحفوظة</h2><div class="place-list">'+ps.map(placeRow).join('')+'</div>':'')+
    (demos.length?'<h2>نماذج العضوية</h2><div class="market-card-grid">'+demos.map(offerCard).join('')+'</div>':'')+pending;
  if(!el.innerHTML)el.innerHTML='<div class="empty">'+icon('heart')+'<h3>احفظ الأماكن والعروض اللي بتحبّها</h3><p>اضغط على القلب في بطاقة المكان أو العرض.</p><button class="btn" data-directory-open="all">اكتشف الأماكن</button></div>';
}
function refreshDiningPage() {
  if(current==='directory'){
    updateDirectory();
    if(mapStatus==='idle'&&directory.source==='map')loadMapPlaces();
  }else if(current==='favorites'){
    updateDiningFavorites();
    if(mapStatus==='idle'&&state.favorites.some(k=>k.startsWith('osm:')))loadMapPlaces();
  }
}
function diningFavoriteChanged() {
  if(current==='favorites')updateDiningFavorites();
  else updateHearts();
}
function showSources() {
  const credits=DINING_IMAGES.map(i=>linkOut(i.url,i.photographer)).join('');
  showModal('<div class="modal-body"><h2 id="modal-title">مصادر الدليل والصور</h2><p class="description">دليل الخريطة يضم أماكن مسمّاة في بيانات OpenStreetMap بتاريخ '+
    esc(DINING_META.asOf)+'. التغطية مجتمعية وقد تتغيّر الفروع أو تغيب بعض المطاعم. يُعرض نوع المطبخ عندما تذكره البيانات.</p>'+attribution()+
    '<p class="description">الفروع المختارة وعروض المطاعم مرتبطة بمصادرها الرسمية داخل البطاقة. الإدراج في الدليل لا يعني وجود خصم أو شراكة مع كود.</p>'+
    '<details class="faq"><summary>مصوّرو صور المطابخ والأطباق</summary><div class="source-list">'+credits+'</div></details>'+
    '<details class="faq"><summary>صور نماذج عضوية كود</summary><div class="source-list">'+OFFERS.map(o=>linkOut(o.source,o.name)).join('')+'</div></details></div>');
}
document.addEventListener('click',event=>{
  const b=event.target.closest('button');if(!b)return;
  if(b.dataset.storyStep){changeStory(Number(b.dataset.storyStep));return;}
  if(b.dataset.directoryOpen){openDirectory({type:b.dataset.directoryOpen});return;}
  if(b.dataset.cuisine){openDirectory({cuisine:b.dataset.cuisine});return;}
  if(b.dataset.diningCity){openDirectory({city:b.dataset.diningCity});return;}
  if(b.hasAttribute('data-official-list')){openDirectory({source:'official'});return;}
  if(b.hasAttribute('data-directory-reset')){openDirectory({city:'all',source:directory.source});return;}
  if(b.hasAttribute('data-directory-retry')){loadMapPlaces();return;}
  if(b.hasAttribute('data-more-places')){directory.limit+=24;updateDirectory();return;}
  if(b.dataset.listType){directory.type=b.dataset.listType;directory.limit=24;updateDirectory();return;}
  if(b.dataset.listSource){directory.source=b.dataset.listSource;directory.limit=24;updateDirectory();if(directory.source==='map'&&mapStatus==='idle')loadMapPlaces();return;}
  if(b.dataset.place){placeDetails(b.dataset.place);return;}
  if(b.dataset.publicDeal){publicDealDetails(b.dataset.publicDeal);return;}
  if(b.dataset.offerMode){showDemoDeals=b.dataset.offerMode==='demo';render('deals');return;}
  if(b.hasAttribute('data-deals-all-cities')){state.city='all';persist();render('deals');}
});
let storyTouch=null;
document.addEventListener('touchstart',event=>{
  const t=event.touches[0];storyTouch=event.touches.length===1&&event.target.closest('#lead-story')&&!event.target.closest('button')?{x:t.clientX,y:t.clientY}:null;
},{passive:true});
document.addEventListener('touchend',event=>{
  if(!storyTouch)return;
  const t=event.changedTouches[0],dx=t.clientX-storyTouch.x,dy=t.clientY-storyTouch.y;storyTouch=null;
  if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.4)changeStory(dx>0?1:-1);
},{passive:true});
document.addEventListener('touchcancel',()=>{storyTouch=null;},{passive:true});

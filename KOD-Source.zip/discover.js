const PICK_GROUPS = [
  { key: 'all', label: 'من كل الفئات', ids: ['namshi', 'aquarium', 'urban-beauty', 'sharafdg'] },
  { key: 'shopping', label: 'تسوّق', ids: ['namshi', 'sharafdg', 'carrefour', 'centrepoint'] },
  { key: 'leisure', label: 'طلعات وسفر', ids: ['rayna', 'rove', 'aquarium', 'aquarium-family'] },
  { key: 'services', label: 'عناية وخدمات', ids: ['urban-beauty', 'fitnessfirst', 'urban-home', 'adnoc'] },
  { key: 'food', label: 'مطاعم وقهوة', ids: ['starbucks', 'shakeshack', 'paul', 'nandos'] }
];
const COLLECTION_NAMES = {
  all: 'كل العروض', leisure: 'خطّة الويكند', services: 'عناية وخدمات',
  online: 'تسوّق وإلكترونيات', high: 'خصم ٣٠٪ وأكثر', recent: 'وصل حديثاً', food: 'مطاعم ومقاهٍ'
};
let selectedPick = 'all';
let expandedCategories = false;

function navHtml(mobile) {
  const entries = mobile
    ? ['discover', 'favorites', 'orders', 'membership', 'account']
    : ['discover', 'catalog', 'favorites', 'orders', 'membership', 'account'];
  return entries.map(id => {
    const item = NAV.find(n => n.id === id) || { icon: 'grid', name: 'كل العروض', short: 'كل العروض' };
    const catalog = current === 'discover' && catalogMode;
    const account = id === 'account' && ['auth', 'register', 'dashboard', 'merchant', 'developer'].includes(current);
    const active = id === 'catalog' ? catalog : account || (id === current && (mobile || id !== 'discover' || !catalog));
    const action = id === 'catalog' ? 'data-catalog="all"' : 'data-go="' + id + '"';
    const label = id === 'account' && !appIdentity && !previewRole ? 'الدخول' : item[mobile ? 'short' : 'name'];
    return '<button ' + action + ' class="' + (active ? 'active' : '') + '"' +
      (active ? ' aria-current="page"' : '') + '>' + icon(item.icon) + '<span>' + label + '</span></button>';
  }).join('');
}

function offerCard(offer) {
  const category = CATEGORIES.find(c => c.id === offer.category);
  const saved = state.favorites.includes(offer.id);
  const menu = ['food', 'coffee'].includes(offer.category)
    ? '<div class="order-entry"><button data-menu="' + offer.id + '">' + icon('food') + ' جرّب المنيو والطلب</button></div>' : '';
  return '<article class="offer" data-offer-card="' + offer.id + '">' +
    '<div class="offer-image">' + photograph(offer) +
      '<span class="deal-badge"><bdi>' + number(offer.percent) + '%</bdi><small>خصم تجريبي</small></span>' +
      '<button class="favorite-button' + (saved ? ' saved' : '') + '" data-favorite="' + offer.id +
        '" aria-label="' + (saved ? 'إزالة ' : 'حفظ ') + esc(offer.name) + ' ' + (saved ? 'من المفضلة' : 'في المفضلة') +
        '" aria-pressed="' + saved + '">' + icon('heart') + '</button></div>' +
    '<button class="offer-open" data-offer="' + offer.id + '" aria-label="عرض تفاصيل ' + esc(offer.name) + '">' +
      '<span class="offer-meta"><span>' + esc(category.name) + '</span><span>' + icon('pin') + esc(offer.city) + '</span></span>' +
      '<h3><span class="ar">' + esc(offer.name) + '</span><span class="en" lang="en" dir="ltr">' + esc(offer.en) + '</span></h3>' +
      '<p class="offer-desc">' + esc(offer.title) + '</p>' +
      '<span class="offer-footer"><span>تفاصيل العرض</span>' + icon('arrow') + '</span></button>' + menu + '</article>';
}

function cardsFor(ids) {
  return ids.map(id => OFFERS.find(offer => offer.id === id)).filter(Boolean).map(offerCard).join('');
}

function campaignCover() {
  return `<div class="campaigns" id="market-campaigns">
    <section class="cover-ticket" aria-labelledby="cover-title">
      <div class="cover-copy">
        <span class="ticket-kicker">${icon('ticket')} دليل عروض الإمارات</span>
        <h1 id="cover-title">وين تحبّ<br>توفّر اليوم؟</h1>
        <p>تسوّق، طلعات، عناية وسفر. اختَر من ١٢ فئة.</p>
        <button class="cover-action" data-catalog="all">تصفّح كل العروض ${icon('arrow')}</button>
      </div>
      <div class="cover-art"><img src="${PHOTOS.campaign}" alt="حقيبة سفر صفراء وكيس تسوّق فوشيا وسماعات على خلفية زرقاء" width="720" height="540" fetchpriority="high"></div>
    </section>
    <button class="weekend-ticket" data-kind="leisure" aria-label="خطّة الويكند، استكشف الترفيه والسفر والفنادق">
      <img src="${PHOTOS.travel}" alt="عجلة ألعاب مضاءة ليلاً" width="520" height="293">
      <span class="weekend-copy"><span><strong>خطّة الويكند</strong><small>ترفيه، رحلات وإقامات</small></span><span class="round-arrow">${icon('arrow')}</span></span>
    </button>
  </div>`;
}

function categoryDirectory() {
  const buttons = CATEGORIES.map(c => `<button class="category" data-category="${c.id}" aria-pressed="false" style="--tile:${c.bg}">
    <span class="cat-icon">${icon(c.icon)}</span><span>${c.name}</span></button>`).join('');
  return `<section class="market-categories" aria-labelledby="category-title">
    <div class="market-heading"><h2 id="category-title">تصفّح حسب الفئة</h2>
      <button class="category-toggle" data-category-toggle aria-controls="market-category-grid" aria-expanded="${expandedCategories}">${expandedCategories ? 'عرض أقل' : 'كل الفئات (١٢)'}</button>
    </div><div class="market-category-grid${expandedCategories ? ' expanded' : ''}" id="market-category-grid">${buttons}</div>
  </section>`;
}

function pickShelf() {
  const group = PICK_GROUPS.find(g => g.key === selectedPick) || PICK_GROUPS[0];
  const tabs = PICK_GROUPS.map(g => `<button data-pick="${g.key}" aria-pressed="${g.key === group.key}">${g.label}</button>`).join('');
  return `<section class="picks-shelf" aria-labelledby="picks-title">
    <div class="market-heading"><h2 id="picks-title">اختيارات كود</h2>
      <button class="plain-action" data-catalog="all">كل العروض ${icon('arrow')}</button></div>
    <div class="pick-tabs" role="group" aria-label="اختيارات حسب الاهتمام">${tabs}</div>
    <div class="market-card-grid" id="pick-cards">${cardsFor(group.ids)}</div>
  </section>`;
}

function couponShelf() {
  const ids = ['namshi', 'sharafdg', 'carrefour', 'centrepoint'];
  const tickets = ids.map(id => {
    const o = OFFERS.find(offer => offer.id === id);
    return `<button class="cut-coupon" data-coupon="${id}" aria-label="عرض نموذج كوبون ${esc(o.name)}">
      <span class="coupon-main"><strong dir="ltr" lang="en">${esc(o.en)}</strong><span>عرض الكوبون ${icon('arrow')}</span></span>
      <span class="coupon-stub"><bdi>${number(o.percent)}%</bdi><small>خصم تجريبي</small></span></button>`;
  }).join('');
  return `<section class="market-shelf" aria-labelledby="coupons-title"><div class="market-heading">
    <h2 id="coupons-title">كوبونات المتاجر</h2></div><div class="coupon-board">${tickets}</div></section>`;
}

function interestShortcuts() {
  return `<div class="interest-shortcuts" aria-label="مجموعات العروض">
    <button data-kind="high"><span>${icon('ticket')} خصم ٣٠٪ وأكثر</span>${icon('arrow')}</button>
    <button data-kind="recent"><span>${icon('spark')} وصل حديثاً</span>${icon('arrow')}</button>
    <button data-kind="services"><span>${icon('home')} للبيت والعناية</span>${icon('arrow')}</button>
  </div>`;
}

function cityShelf() {
  const cities = CITIES.filter(city => OFFERS.some(offer => offer.city === city));
  const links = cities.map(city => {
    const count = OFFERS.filter(offer => offer.city === city).length;
    const label = count === 1 ? 'عرض واحد' : count === 2 ? 'عرضان' : number(count) + (count < 11 ? ' عروض' : ' عرضاً');
    return `<button data-market-city="${city}"><strong>${esc(city)}</strong><span>${label}</span>${icon('arrow')}</button>`;
  }).join('');
  return `<section class="city-board" aria-labelledby="city-shelf-title"><div class="city-heading">${icon('pin')}
    <h2 id="city-shelf-title">عروض حسب الإمارة</h2></div><div class="city-options">${links}</div></section>`;
}

function brandShelf() {
  const ids = ['namshi', 'sharafdg', 'rove', 'fitnessfirst', 'starbucks', 'carrefour'];
  return `<section class="market-shelf brands-shelf" aria-labelledby="brand-shelf-title">
    <div class="market-heading"><h2 id="brand-shelf-title">تصفّح حسب البراند</h2></div>
    <div class="brand-list">${ids.map(id => {
      const o = OFFERS.find(offer => offer.id === id);
      return '<button data-brand="' + esc(o.en) + '" lang="en" dir="ltr">' + esc(o.en) + '</button>';
    }).join('')}</div></section>`;
}

function catalogueResults() {
  return `<section id="catalog-panel" class="catalog-panel" hidden>
    <div class="market-heading catalogue-heading"><div><h1 id="market-results-title">كل العروض</h1><p id="result-count" aria-live="polite"></p></div>
      <div class="catalog-tools"><select id="sort" class="sort-select" aria-label="ترتيب العروض">
      ${[['recommended','اختيارات كود'],['discount','الأعلى خصماً'],['saving','الأكثر توفيراً']].map(([v,n]) =>
        '<option value="' + v + '"' + (sort === v ? ' selected' : '') + '>' + n + '</option>').join('')}</select>
      <button class="plain-action" data-action="clear-filters">الرئيسية ${icon('arrow')}</button></div></div>
    <div class="dining-route" id="market-dining-route" hidden><button class="btn" data-go="food">توصيل المطاعم ${icon('arrow')}</button></div>
    <div class="offer-grid" id="offers-grid"></div></section>`;
}

function discover() {
  return `<div class="market-home">${campaignCover()}${categoryDirectory()}
    <div id="home-sections">${pickShelf()}${interestShortcuts()}${couponShelf()}${cityShelf()}${brandShelf()}
      <div class="market-links"><button data-go="membership">${icon('card')} عضوية كود</button>
      <button data-go="food">${icon('food')} توصيل المطاعم</button><button data-go="partner">${icon('store')} مساحة الشركاء</button></div>
    </div>${catalogueResults()}</div>`;
}

function syncMarketFilters(isCatalog) {
  document.getElementById('market-campaigns')?.toggleAttribute('hidden', isCatalog);
  const title = document.getElementById('market-results-title');
  if (!title) return;
  const selectedCategory = CATEGORIES.find(c => c.id === filter);
  title.textContent = query.trim() ? 'نتائج البحث عن «' + query.trim() + '»' :
    selectedCategory?.name || COLLECTION_NAMES[activeKind] || 'كل العروض';
  document.getElementById('market-dining-route')?.toggleAttribute('hidden', !(['food','coffee'].includes(filter) || activeKind === 'food'));
  const more = expandedCategories || CATEGORIES.findIndex(c => c.id === filter) > 5;
  document.getElementById('market-category-grid')?.classList.toggle('expanded', more);
  const toggle = document.querySelector('[data-category-toggle]');
  if (toggle) { toggle.setAttribute('aria-expanded', String(more)); toggle.textContent = more ? 'عرض أقل' : 'كل الفئات (١٢)'; }
  const nav = document.getElementById('side-nav');
  if (nav) nav.innerHTML = navHtml(false);
}

document.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button) return;
  if (button.hasAttribute('data-category-toggle')) {
    const grid = document.getElementById('market-category-grid');
    expandedCategories = !grid.classList.contains('expanded');
    grid.classList.toggle('expanded', expandedCategories);
    button.setAttribute('aria-expanded', String(expandedCategories));
    button.textContent = expandedCategories ? 'عرض أقل' : 'كل الفئات (١٢)';
    return;
  }
  if (button.dataset.marketCity) {
    const city = button.dataset.marketCity;
    if (!CITIES.includes(city)) return;
    state.city = city;
    document.getElementById('city').value = city;
    persist();
    openCatalog('all');
    return;
  }
  if (button.dataset.pick) {
    const group = PICK_GROUPS.find(g => g.key === button.dataset.pick);
    if (!group) return;
    selectedPick = group.key;
    document.querySelectorAll('[data-pick]').forEach(tab => tab.setAttribute('aria-pressed', String(tab === button)));
    document.getElementById('pick-cards').innerHTML = cardsFor(group.ids);
  }
});

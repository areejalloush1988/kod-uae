const PICK_GROUPS = [
  { key: 'all', label: 'من كل الفئات', ids: ['namshi', 'aquarium', 'urban-beauty', 'sharafdg'] },
  { key: 'shopping', label: 'تسوّق', ids: ['namshi', 'sharafdg', 'carrefour', 'centrepoint'] },
  { key: 'leisure', label: 'طلعات وسفر', ids: ['rayna', 'rove', 'aquarium', 'aquarium-family'] },
  { key: 'services', label: 'عناية وخدمات', ids: ['urban-beauty', 'fitnessfirst', 'urban-home', 'adnoc'] },
  { key: 'food', label: 'مطاعم وقهوة', ids: ['starbucks', 'shakeshack', 'paul', 'nandos'] }
];
const COLLECTION_NAMES = {
  all: 'كل العروض', leisure: 'خطّة الويكند', services: 'عناية وخدمات',
  online: 'تسوّق وإلكترونيات', high: 'خصم ٣٠٪ وأكثر', recent: 'وصل حديثاً', food: 'مطاعم ومقاهٍ'
};
let selectedPick = 'all';
let expandedCategories = false;
let storyIndex = 0;

const STORIES = [
  { title: 'اختيارات الموسم', label: 'دليل عروض الإمارات', description: 'أزياء وعناية وتقنية من براندات تعرفها.', 
    photo: 'campaign', alt: 'صورة أزياء في رواق حجري مضاء بالشمس', action: 'تصفّح الاختيارات', category: 'all' },
  { title: 'تفاصيل العناية', label: 'العناية والجمال', description: 'جلسات عناية واسترخاء ضمن عروض الجمال.',
    photo: 'perfume', alt: 'زجاجة عطر تنعكس عليها أشعة الشمس', action: 'اكتشف عروض العناية', category: 'beauty' },
  { title: 'فسحة الويكند', label: 'السفر والترفيه', description: 'إقامات قصيرة وطلعات تغيّر جوّ الأسبوع.',
    photo: 'palm', alt: 'إطلالة من مسبح على البحر ونخلة جميرا في دبي', action: 'استكشف الطلعات', collection: 'leisure' }
];

const CATEGORY_PHOTOS = {
  shopping: 'fashion', entertainment: 'aquarium', beauty: 'beauty', electronics: 'headphones',
  travel: 'palm', food: 'pfchangs-story', grocery: 'grocery', hotels: 'hotel',
  fitness: 'gym', coffee: 'costa', home: 'home', car: 'car'
};

function editorialOrder(offers) {
  const groups = CATEGORIES.map(category => offers.filter(offer => offer.category === category.id));
  const ordered = [];
  const longest = Math.max(0, ...groups.map(group => group.length));
  for (let row = 0; row < longest; row++) {
    groups.forEach(group => { if (group[row]) ordered.push(group[row]); });
  }
  return ordered;
}

function navHtml(mobile) {
  const entries = mobile
    ? ['discover', 'favorites', 'orders', 'membership', 'account']
    : ['discover', 'catalog', 'favorites', 'orders', 'membership', 'account'];
  return entries.map(id => {
    const item = NAV.find(n => n.id === id) || { icon: 'grid', name: 'كل العروض', short: 'كل العروض' };
    const catalog = current === 'discover' && catalogMode;
    const account = id === 'account' && ['auth', 'register', 'dashboard', 'merchant', 'developer'].includes(current);
    const active = id === 'catalog' ? catalog : account || (id === current && (mobile || id !== 'discover' || !catalog));
    const action = id === 'catalog' ? 'data-catalog="all"' : 'data-go="' + id + '"';
    const label = id === 'account' && !appIdentity && !previewRole ? 'الدخول' : item[mobile ? 'short' : 'name'];
    return '<button ' + action + ' class="' + (active ? 'active' : '') + '"' +
      (active ? ' aria-current="page"' : '') + '>' + icon(item.icon) + '<span>' + label + '</span></button>';
  }).join('');
}

function offerCard(offer) {
  const category = CATEGORIES.find(c => c.id === offer.category);
  const saved = state.favorites.includes(offer.id);
  const saving = number(Math.round(offer.base * offer.percent) / 100);
  const menu = ['food', 'coffee'].includes(offer.category)
    ? '<div class="order-entry"><button data-menu="' + offer.id + '">' + icon('food') + ' جرّب المنيو والطلب</button></div>' : '';
  return '<article class="offer" data-offer-card="' + offer.id + '">' +
    '<div class="offer-image"><button class="offer-photo-link" data-offer="' + offer.id +
      '" aria-label="فتح عرض ' + esc(offer.name) + '">' + photograph(offer) + '</button>' +
      '<span class="deal-badge"><bdi>' + number(offer.percent) + '%</bdi> خصم تجريبي</span>' +
      '<button class="favorite-button' + (saved ? ' saved' : '') + '" data-favorite="' + offer.id +
        '" aria-label="' + (saved ? 'إزالة ' : 'حفظ ') + esc(offer.name) + ' ' + (saved ? 'من المفضلة' : 'في المفضلة') +
        '" aria-pressed="' + saved + '">' + icon('heart') + '</button></div>' +
    '<button class="offer-open" data-offer="' + offer.id + '" aria-label="عرض تفاصيل ' + esc(offer.name) + '">' +
      '<span class="offer-meta"><span>' + esc(category.name) + '</span><span>' + icon('pin') + esc(offer.city) + '</span></span>' +
      '<h3><span class="ar">' + esc(offer.name) + '</span><span class="en" lang="en" dir="ltr">' + esc(offer.en) + '</span></h3>' +
      '<p class="offer-desc">' + esc(offer.title) + '</p>' +
      '<span class="offer-footer"><span><strong>وفّر ' + saving + ' د.إ</strong><small>مثال على فاتورة ' +
      number(offer.base) + ' د.إ</small></span>' + icon('arrow') + '</span></button>' + menu + '</article>';
}

function cardsFor(ids) {
  return ids.map(id => OFFERS.find(offer => offer.id === id)).filter(Boolean).map(offerCard).join('');
}

function storyContent() {
  const story = STORIES[storyIndex];
  const action = story.collection ? 'data-kind="' + story.collection + '"' : 'data-catalog="' + story.category + '"';
  return `<div class="story-art"><img src="${PHOTOS[story.photo]}" alt="${story.alt}" fetchpriority="high" decoding="async"></div>
    <div class="story-copy"><span class="story-label">${story.label}</span>
      <h1 id="cover-title">${story.title}</h1><p>${story.description}</p>
      <button class="story-cta" ${action}>${story.action} ${icon('arrow')}</button></div>`;
}

function storyCount() {
  return (storyIndex + 1).toLocaleString('ar-EG') + ' من ' + STORIES.length.toLocaleString('ar-EG');
}

function changeStory(step) {
  storyIndex = (storyIndex + step + STORIES.length) % STORIES.length;
  const frame = document.getElementById('lead-story');
  frame.dataset.photo = STORIES[storyIndex].photo;
  frame.innerHTML = storyContent();
  document.getElementById('story-count').textContent = storyCount();
}

function campaignCover() {
  return `<div class="editorial-grid" id="market-campaigns">
    <section class="lead-feature" aria-label="اختيارات كود الموسمية">
      <div class="lead-story" id="lead-story" aria-live="polite" data-photo="${STORIES[storyIndex].photo}">${storyContent()}</div>
      <div class="story-controls" role="group" aria-label="تصفّح الاختيارات الموسمية">
        <button data-story-step="-1" aria-label="الاختيار السابق">${icon('arrow')}</button>
        <span id="story-count" dir="rtl">${storyCount()}</span>
        <button data-story-step="1" aria-label="الاختيار التالي">${icon('arrow')}</button></div>
    </section>
    <div class="spotlights">
      <button class="spotlight stay-spotlight" data-kind="leisure" aria-label="خطّة الويكند، استكشف الترفيه والسفر والفنادق">
        <span class="spotlight-copy"><small>إقامات وطلعات</small><strong>خطّة الويكند</strong><span class="spotlight-more">استكشف العروض ${icon('arrow')}</span></span>
        <img src="${PHOTOS.palm}" alt="البحر ونخلة جميرا من أعلى" width="350" height="235"></button>
      <button class="spotlight tech-spotlight" data-catalog="electronics" aria-label="اكتشف عروض الإلكترونيات">
        <span class="spotlight-copy"><small>هواتف وإكسسوارات</small><strong>عالم التقنية</strong><span class="spotlight-more">اكتشف التقنية ${icon('arrow')}</span></span>
        <img src="${PHOTOS.headphones}" alt="يدان تمسكان بسماعات لاسلكية بيضاء" width="350" height="235"></button>
    </div></div>`;
}

function categoryDirectory() {
  const buttons = CATEGORIES.map(c => `<button class="category" data-category="${c.id}" aria-pressed="false">
    <span class="department-photo"><img src="${PHOTOS[CATEGORY_PHOTOS[c.id]]}" alt="" width="96" height="96" loading="lazy" decoding="async"></span>
    <span>${c.name}</span></button>`).join('');
  return `<section class="market-categories" aria-labelledby="category-title">
    <div class="market-heading"><h2 id="category-title">تسوّق حسب الفئة</h2>
      <button class="category-toggle" data-category-toggle aria-controls="market-category-grid" aria-expanded="${expandedCategories}">${expandedCategories ? 'عرض أقل' : 'كل الفئات (١٢)'}</button>
    </div><div class="market-category-grid${expandedCategories ? ' expanded' : ''}" id="market-category-grid">${buttons}</div>
  </section>`;
}

function pickShelf() {
  const group = PICK_GROUPS.find(g => g.key === selectedPick) || PICK_GROUPS[0];
  const tabs = PICK_GROUPS.map(g => `<button data-pick="${g.key}" aria-pressed="${g.key === group.key}">${g.label}</button>`).join('');
  return `<section class="picks-shelf" aria-labelledby="picks-title">
    <div class="market-heading"><div><h2 id="picks-title">اختيارات كود</h2><p>عروض تجريبية من براندات تعرفها</p></div>
      <button class="plain-action" data-catalog="all">كل العروض ${icon('arrow')}</button></div>
    <div class="pick-tabs" role="group" aria-label="اختيارات حسب الاهتمام">${tabs}</div>
    <div class="market-card-grid" id="pick-cards">${cardsFor(group.ids)}</div>
  </section>`;
}

function recentShelf() {
  const featuredPhotos = new Set(OFFERS.filter(offer => PICK_GROUPS[0].ids.includes(offer.id)).map(offer => offer.photo));
  const recent = OFFERS.filter(offer => offer.recent && !featuredPhotos.has(offer.photo));
  const items = editorialOrder(recent).slice(0, 4);
  return `<section class="market-shelf" aria-labelledby="recent-title"><div class="market-heading">
    <h2 id="recent-title">وصل حديثاً</h2><button class="plain-action" data-kind="recent">كل الإضافات ${icon('arrow')}</button></div>
    <div class="market-card-grid">${items.map(offerCard).join('')}</div></section>`;
}

function couponShelf() {
  const ids = ['namshi', 'sharafdg', 'carrefour', 'centrepoint'];
  const tickets = ids.map(id => {
    const o = OFFERS.find(offer => offer.id === id);
    return `<button class="cut-coupon" data-coupon="${id}" aria-label="عرض نموذج كوبون ${esc(o.name)}">
      <span class="coupon-main"><strong dir="ltr" lang="en">${esc(o.en)}</strong><span>عرض الكوبون ${icon('arrow')}</span></span>
      <span class="coupon-stub"><bdi>${number(o.percent)}%</bdi><small>خصم تجريبي</small></span></button>`;
  }).join('');
  return `<section class="market-shelf" aria-labelledby="coupons-title"><div class="market-heading">
    <h2 id="coupons-title">كوبونات المتاجر</h2></div><div class="coupon-board">${tickets}</div></section>`;
}

function interestShortcuts() {
  return `<div class="interest-shortcuts" aria-label="مجموعات العروض">
    <button data-kind="high"><span>${icon('ticket')} خصم ٣٠٪ وأكثر</span>${icon('arrow')}</button>
    <button data-catalog="hotels"><span>${icon('pin')} إقامات وفنادق</span>${icon('arrow')}</button>
    <button data-kind="services"><span>${icon('home')} للبيت والعناية</span>${icon('arrow')}</button>
  </div>`;
}

function cityShelf() {
  const cities = CITIES.filter(city => OFFERS.some(offer => offer.city === city));
  const links = cities.map(city => {
    const count = OFFERS.filter(offer => offer.city === city).length;
    const label = count === 1 ? 'عرض واحد' : count === 2 ? 'عرضان' : number(count) + (count < 11 ? ' عروض' : ' عرضاً');
    return `<button data-market-city="${city}"><strong>${esc(city)}</strong><span>${label}</span>${icon('arrow')}</button>`;
  }).join('');
  return `<section class="city-board" aria-labelledby="city-shelf-title"><div class="city-heading">${icon('pin')}
    <h2 id="city-shelf-title">عروض حسب الإمارة</h2></div><div class="city-options">${links}</div></section>`;
}

function brandShelf() {
  const ids = ['namshi', 'sharafdg', 'rove', 'fitnessfirst', 'starbucks', 'carrefour'];
  return `<section class="market-shelf brands-shelf" aria-labelledby="brand-shelf-title">
    <div class="market-heading"><h2 id="brand-shelf-title">تصفّح حسب البراند</h2></div>
    <div class="brand-list">${ids.map(id => {
      const o = OFFERS.find(offer => offer.id === id);
      return '<button data-brand="' + esc(o.en) + '" lang="en" dir="ltr">' + esc(o.en) + '</button>';
    }).join('')}</div></section>`;
}

function catalogueResults() {
  return `<section id="catalog-panel" class="catalog-panel" hidden>
    <div class="market-heading catalogue-heading"><div><h1 id="market-results-title">كل العروض</h1><p id="result-count" aria-live="polite"></p></div>
      <div class="catalog-tools"><select id="sort" class="sort-select" aria-label="ترتيب العروض">
      ${[['recommended','اختيارات كود'],['discount','الأعلى خصماً'],['saving','الأكثر توفيراً']].map(([v,n]) =>
        '<option value="' + v + '"' + (sort === v ? ' selected' : '') + '>' + n + '</option>').join('')}</select>
      <button class="plain-action" data-action="clear-filters">الرئيسية ${icon('arrow')}</button></div></div>
    <div class="dining-route" id="market-dining-route" hidden><button class="btn" data-go="food">توصيل المطاعم ${icon('arrow')}</button></div>
    <div class="offer-grid" id="offers-grid"></div></section>`;
}

function discover() {
  return `<div class="market-home">${campaignCover()}${categoryDirectory()}
    <div id="home-sections">${pickShelf()}${interestShortcuts()}${brandShelf()}${recentShelf()}${couponShelf()}${cityShelf()}
      <div class="market-links"><button data-go="membership">${icon('card')} عضوية كود</button>
      <button data-go="food">${icon('food')} توصيل المطاعم</button><button data-go="partner">${icon('store')} مساحة الشركاء</button></div>
    </div>${catalogueResults()}</div>`;
}

function syncMarketFilters(isCatalog) {
  document.getElementById('market-campaigns')?.toggleAttribute('hidden', isCatalog);
  const title = document.getElementById('market-results-title');
  if (!title) return;
  const selectedCategory = CATEGORIES.find(c => c.id === filter);
  title.textContent = query.trim() ? 'نتائج البحث عن «' + query.trim() + '»' :
    selectedCategory?.name || COLLECTION_NAMES[activeKind] || 'كل العروض';
  document.getElementById('market-dining-route')?.toggleAttribute('hidden', !(['food','coffee'].includes(filter) || activeKind === 'food'));
  const more = expandedCategories || CATEGORIES.findIndex(c => c.id === filter) > 5;
  document.getElementById('market-category-grid')?.classList.toggle('expanded', more);
  const toggle = document.querySelector('[data-category-toggle]');
  if (toggle) { toggle.setAttribute('aria-expanded', String(more)); toggle.textContent = more ? 'عرض أقل' : 'كل الفئات (١٢)'; }
  const nav = document.getElementById('side-nav');
  if (nav) nav.innerHTML = navHtml(false);
}

document.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button) return;
  if (button.dataset.storyStep) {
    changeStory(Number(button.dataset.storyStep));
    return;
  }
  if (button.hasAttribute('data-category-toggle')) {
    const grid = document.getElementById('market-category-grid');
    expandedCategories = !grid.classList.contains('expanded');
    grid.classList.toggle('expanded', expandedCategories);
    button.setAttribute('aria-expanded', String(expandedCategories));
    button.textContent = expandedCategories ? 'عرض أقل' : 'كل الفئات (١٢)';
    return;
  }
  if (button.dataset.marketCity) {
    const city = button.dataset.marketCity;
    if (!CITIES.includes(city)) return;
    state.city = city;
    document.getElementById('city').value = city;
    persist();
    openCatalog('all');
    return;
  }
  if (button.dataset.pick) {
    const group = PICK_GROUPS.find(g => g.key === button.dataset.pick);
    if (!group) return;
    selectedPick = group.key;
    document.querySelectorAll('[data-pick]').forEach(tab => tab.setAttribute('aria-pressed', String(tab === button)));
    document.getElementById('pick-cards').innerHTML = cardsFor(group.ids);
  }
});

let storyTouch = null;
document.addEventListener('touchstart', event => {
  const inStory = event.target.closest('#lead-story') && !event.target.closest('button');
  const touch = event.touches[0];
  storyTouch = inStory && event.touches.length === 1 ? { x: touch.clientX, y: touch.clientY } : null;
}, { passive: true });
document.addEventListener('touchend', event => {
  if (!storyTouch) return;
  const touch = event.changedTouches[0];
  const dx = touch.clientX - storyTouch.x;
  const dy = touch.clientY - storyTouch.y;
  storyTouch = null;
  if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4 && document.getElementById('lead-story')) {
    changeStory(dx > 0 ? 1 : -1);
  }
}, { passive: true });
document.addEventListener('touchcancel', () => { storyTouch = null; }, { passive: true });

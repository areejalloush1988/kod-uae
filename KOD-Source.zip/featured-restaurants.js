// Paid branch placements have a separate invoice and publication window from member subscriptions.
let featuredPublic=null,featuredFetched=0,featuredPublicJob=null,featuredPublicError=false,featuredPageNo=0,featuredTimer=0;
let featuredDesk=null,featuredDeskKey='',featuredDeskJob=null,featuredDeskError=false;
function clearFeaturedAccount(){featuredDesk=null;featuredDeskKey='';featuredDeskJob=null;featuredDeskError=false;}
function isFeaturedStaff(){return !previewRole&&(isLiveOperator()||appIdentity?.role==='merchant');}
function featuredMerchantLink(){return '<button class="btn light" data-go="featured">'+icon('store')+' اشتراك المطاعم المميّزة</button>';}
function featuredBranchById(id){return featuredPublic?.restaurants?.find(r=>r.id===id&&Date.parse(r.ends)>Date.now());}
function featuredBranchPhoto(b){
  // New branches inherit a legacy brand-specific picture. Use neutral food photography in the sponsored rail.
  return b.category==='coffee'?'cafe':b.category==='cafeteria'?'karak':'grill';
}
function featuredRail(){
  const rows=(featuredPublic?.restaurants||[]).filter(r=>Date.parse(r.ends)>Date.now()&&(state.city==='all'||r.city===state.city));
  let content='';
  if(!featuredPublic)content='<p class="featured-empty" role="status">'+(featuredPublicError?'تعذّر تحميل المطاعم المميّزة.':'جارٍ تحميل الفروع…')+'</p>'+(featuredPublicError?'<button class="text-button" data-featured-refresh>إعادة المحاولة</button>':'');
  else if(!rows.length)content='<p class="featured-empty">تظهر هنا الفروع المشتركة'+(state.city!=='all'?' في '+displayText(state.city):'')+'.</p>';
  else{
    const last=Math.ceil(rows.length/3)-1;featuredPageNo=Math.min(last,Math.max(0,featuredPageNo));
    content='<ul class="featured-list">'+rows.slice(featuredPageNo*3,featuredPageNo*3+3).map(r=>'<li><button class="featured-place" data-featured-open="'+esc(r.id)+'">'+photo(featuredBranchPhoto(r),'featured-place-image')+'<span><strong>'+displayText(r.name)+'</strong><small>'+displayText([r.branch_address,r.city].filter(Boolean).join('، '))+'</small></span></button></li>').join('')+'</ul>';
    if(last)content+='<div class="club-terms"><button type="button" data-featured-step="-1" '+(featuredPageNo===0?'disabled':'')+'>السابق</button><span>'+number(featuredPageNo+1)+' / '+number(last+1)+'</span><button type="button" data-featured-step="1" '+(featuredPageNo===last?'disabled':'')+'>التالي</button></div>';
  }
  return '<header><span class="featured-kind">ظهور مدفوع</span><h2>مطاعم مميّزة</h2></header>'+content+'<button type="button" class="featured-cta" data-go="featured">ميّز مطعمك هنا</button>';
}
function featuredBookingState(b,at=Date.now()){
  if(b.state!=='paid')return {requested:'بانتظار الفاتورة',invoiced:'بانتظار تأكيد الدفع',cancelled:'ملغى',declined:'أغلقته الإدارة'}[b.state]||'قيد المراجعة';
  if(Date.parse(b.ends)<=at)return 'انتهت مدة الظهور';
  if(!b.approved)return 'الظهور متوقف لحين اعتماد الفرع';
  return Date.parse(b.starts)>at?'مجدول للفترة القادمة':'يظهر الآن';
}
function featurePaymentUrl(value){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password?u.href:'';}catch{return '';}}
function featureFils(value){const txt=latinDigits(String(value||'')).trim().replace('٫','.');return /^\d{1,5}(?:\.\d{1,2})?$/.test(txt)?Math.round(Number(txt)*100):0;}
function featurePrice(){return featuredPublic?money(featuredPublic.price_fils):featuredPublicError?'السعر غير متاح مؤقتاً':'جارٍ تحميل السعر…';}
function featureSubmit(label){return '<button class="btn" type="submit">'+label+'</button><p role="status" aria-live="polite"></p>';}
function featuredRequestForm(){
  if(previewRole)return '<p>اخرج من المعاينة لإدارة طلبات الظهور.</p>';
  if(!appIdentity||appIdentity.role==='developer_locked')return '<div class="promo-actions"><button class="btn" data-card-login="featured">دخول صاحب المطعم</button><button class="btn light" data-featured-register>تسجيل مطعم جديد</button></div>';
  const branchRows=(liveWorkspace.restaurants||[]).filter(r=>r.approved&&!r.is_demo&&(isLiveOperator()||r.owner_id===appIdentity.id));
  if(!isFeaturedStaff()||!branchRows.length)return '<p>سجّل بيانات الفرع. بعد اعتماده بتقدر تطلب الظهور من هون.</p><button class="btn light" data-go="partner">تسجيل فرع مطعم أو مقهى</button>';
  if(!featuredDesk||!featuredPublic)return '';
  const open=new Set(featuredDesk.bookings.filter(b=>['requested','invoiced'].includes(b.state)).map(b=>b.branch));
  const eligible=branchRows.filter(r=>!open.has(r.id));
  if(!eligible.length)return '<p>عندك طلب مفتوح. حالته وتفاصيل فاتورته موجودة تحت «طلبات الظهور».</p>';
  return '<form class="featured-form" data-feature-form="request" data-quoted="'+featuredPublic.price_fils+'"><label class="field">الفرع الذي سيظهر<select name="branch" required>'+eligible.map(r=>'<option value="'+esc(r.id)+'">'+displayText(r.name)+' · '+displayText(r.city)+'</option>').join('')+'</select></label><p>سعر هذا الطلب <strong>'+featurePrice()+'</strong> للفرع. تصلك فاتورته هنا، ويبدأ الظهور بعد تأكيد استلام الدفع.</p>'+featureSubmit('طلب فاتورة الظهور المميّز')+'</form>';
}
function featureOperatorTools(){
  if(!isLiveOperator()||!featuredDesk||!featuredPublic)return '';
  return '<details class="featured-box"><summary>تعديل سعر اشتراك المطاعم</summary><form class="featured-form" data-feature-form="price"><label class="field">سعر 30 يوم للفرع بالدرهم<input required name="price" type="number" lang="en" dir="ltr" step=".01" min="1" max="99999" value="'+(featuredPublic.price_fils/100)+'"></label><p>يسري السعر على الطلبات الجديدة.</p>'+featureSubmit('حفظ السعر')+'</form></details>';
}
function featuredOperatorBooking(b,product='restaurant'){
  if(!isLiveOperator()||!['requested','invoiced'].includes(b.state))return '';
  const id=esc(b.id),member=product==='member',formAttr=member?'data-member-form':'data-feature-form';
  const invoice='<details><summary>'+(b.state==='invoiced'?'تعديل تعليمات الفاتورة':'إصدار فاتورة الاشتراك')+'</summary><form class="featured-form" '+formAttr+'="invoice" data-booking="'+id+'"><label class="field">تعليمات الدفع<textarea name="note" maxlength="500" rows="2">'+esc(b.payment_note||'')+'</textarea></label><label class="field">رابط الدفع الإلكتروني (اختياري)<input type="url" dir="ltr" name="url" maxlength="1000" placeholder="https://" value="'+esc(b.payment_url||'')+'"></label><p>أضف تعليمات التحصيل أو رابط دفع خاصاً بهذه الفاتورة. تظهر التفاصيل داخل حساب صاحب الطلب.</p>'+featureSubmit('إتاحة الفاتورة لصاحب الطلب')+'</form></details>';
  const settle=b.state==='invoiced'?'<details><summary>تأكيد استلام الدفع</summary><form class="featured-form" '+formAttr+'="settle" data-booking="'+id+'"><label class="field">المبلغ المستلم بالدرهم<input name="amount" required type="number" dir="ltr" min="'+(member?'0.01':'1')+'" max="'+(member?'99999.99':'99999')+'" step=".01"></label><label class="field">مرجع عملية الدفع<input name="reference" required minlength="3" maxlength="100" dir="ltr"></label><label class="promo-check"><input type="checkbox" required> تحققت من استلام مبلغ الفاتورة</label>'+featureSubmit(member?'تأكيد الدفع وتفعيل العضوية':'تأكيد الدفع وجدولة الظهور')+'</form></details>':'';
  const decline='<details><summary>إغلاق الطلب</summary><form class="featured-form" '+formAttr+'="close" data-booking="'+id+'"><label class="field">سبب الإغلاق<input name="reason" required minlength="2" maxlength="220"></label>'+featureSubmit('إغلاق وإبلاغ صاحب الطلب')+'</form></details>';
  return invoice+settle+decline;
}
function featuredHistory(){
  if(!featuredDesk?.bookings?.length)return isFeaturedStaff()&&featuredDesk?'<section class="featured-box"><h2>طلبات الظهور</h2><p>تظهر هنا الطلبات والفواتير بعد اختيار الفرع وتقديم الطلب.</p></section>':'';
  return '<section class="featured-box"><h2>طلبات الظهور</h2>'+featuredDesk.bookings.map(b=>{
    const url=featurePaymentUrl(b.payment_url);
    const bill=b.invoiced?'<div class="featured-invoice"><strong>فاتورة KOD-'+esc(b.id.slice(0,8).toUpperCase())+'</strong><p>'+money(b.amount_fils)+' · '+clubStarts(b.invoiced)+'</p>'+(b.state==='invoiced'?((b.payment_note?'<p class="featured-pay-note">'+esc(b.payment_note)+'</p>':'')+(url?'<a class="btn light" href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">فتح رابط دفع الفاتورة</a>':'')):'')+'</div>':'';
    const timeline=b.state==='paid'?'<div class="featured-stats"><span>بداية الظهور <strong>'+clubStarts(b.starts)+'</strong></span><span>نهاية الظهور <strong>'+clubStarts(b.ends)+'</strong></span><span>أعضاء فتحوا الإعلان <strong>'+number(b.opens)+'</strong></span></div>':'';
    const cancel=!isLiveOperator()&&b.state==='requested'?'<form class="featured-form" data-feature-form="close" data-booking="'+esc(b.id)+'">'+featureSubmit('إلغاء طلب الفاتورة')+'</form>':'';
    return '<article class="featured-row"><header><h3>'+displayText(b.name)+'</h3><strong>'+featuredBookingState(b)+'</strong></header><p>'+displayText(b.city)+' · '+money(b.amount_fils)+' / '+number(b.days)+' يوم</p>'+bill+timeline+(b.review_note?'<p>'+esc(b.review_note)+'</p>':'')+featuredOperatorBooking(b)+cancel+'</article>';
  }).join('')+'</section>';
}
function featuredPrivateArea(){
  const problem=featuredPublicError||featuredDeskError;
  return '<section class="featured-box"><h2>اشتراك الفرع</h2>'+featuredRequestForm()+
    (problem?'<p role="status">تعذّر تحميل بيانات الاشتراك. <button class="text-button" data-featured-refresh>إعادة المحاولة</button></p>':isFeaturedStaff()&&!featuredDesk?'<p role="status">جارٍ تحميل طلبات الفروع…</p>':'')+
    '</section>'+featureOperatorTools()+featuredHistory();
}
function featuredPage(){return '<div class="featured-page"><header class="order-page-head"><div><h1>اشتراك المطاعم المميّزة</h1><p>مساحة لفرع مطعمك أو مقهاك على رئيسية توفير.</p></div></header>'+clubChoiceSwitch('featured')+ownerWorkspaceNav('featured')+
  '<section class="featured-pitch"><div><h2>خلّي الزبون يلاقي مطعمك من أول الصفحة</h2><p>بيظهر فرعك ضمن «مطاعم مميّزة» في إمارتك. بضغطة واحدة بيفتح الزبون معلومات الفرع وطرق التواصل والمنيو المتاحة.</p></div><div class="featured-price"><strong id="featured-price">'+featurePrice()+'</strong><span>للفرع / 30 يوم</span></div></section>'+
  '<div id="featured-account" class="promo-stack">'+featuredPrivateArea()+'</div></div>';}
function drawFeaturedRail(){
  const el=document.getElementById('featured-home-rail');
  if(current==='discover'&&el)el.innerHTML=featuredRail();
}
async function loadFeaturedPublic(force=false){
  if(featuredPublicJob)return featuredPublicJob;
  if(!force&&featuredFetched&&Date.now()-featuredFetched<60000)return;
  const job=(async()=>{
    try{const d=await publicPromoRpc('kod_featured_public',{});if(!Number.isInteger(d?.price_fils)||!Array.isArray(d?.restaurants))throw Error();
      featuredPublic=d;featuredPublicError=false;
    }catch{featuredPublicError=true;featuredPublic=null;}
    finally{featuredFetched=Date.now();drawFeaturedRail();}
  })();
  featuredPublicJob=job;try{await job;}finally{if(featuredPublicJob===job)featuredPublicJob=null;}
}
async function loadFeaturedDesk(force=false){
  if(!isFeaturedStaff())return;
  const key=workspaceEpoch+'|'+appIdentity.id,epoch=workspaceEpoch;
  if(featuredDeskJob?.key===key)return featuredDeskJob.promise;
  if(!force&&key===featuredDeskKey&&!featuredDeskError)return;
  const job=(async()=>{
    try{const d=await cardRpc('kod_featured_desk',{});if(!Array.isArray(d?.bookings))throw Error();
      if(epoch===workspaceEpoch&&isFeaturedStaff()){featuredDesk=d;featuredDeskError=false;featuredDeskKey=key;}
    }catch{if(epoch===workspaceEpoch){featuredDeskError=true;featuredDesk=null;}}
  })();
  featuredDeskJob={key,promise:job};try{await job;}finally{if(featuredDeskJob?.promise===job)featuredDeskJob=null;}
}
async function beginFeatured(force=false){
  clearTimeout(featuredTimer);
  const route=current,epoch=workspaceEpoch;
  await Promise.all([loadFeaturedPublic(force),route==='featured'?loadFeaturedDesk(force):null]);
  if(current!==route||epoch!==workspaceEpoch)return;
  if(route==='featured'){
    const panel=document.getElementById('featured-account'),price=document.getElementById('featured-price');
    if(price)price.textContent=featurePrice();
    if(panel&&!panel.contains?.(document.activeElement))panel.innerHTML=featuredPrivateArea();
    else if(panel&&force)panel.innerHTML=featuredPrivateArea();
  }
  if(route==='discover'){
    const ends=(featuredPublic?.restaurants||[]).map(r=>Date.parse(r.ends)-Date.now()).filter(v=>v>0);
    featuredTimer=setTimeout(()=>{if(current==='discover'){drawFeaturedRail();beginFeatured(true);}},Math.max(1000,Math.min(60000,...ends)+20));
  }
}
const FEATURE_ERRORS={price_changed:'تغيّر سعر الباقة. راجع السعر الجديد وأعد تقديم الطلب.',amount_mismatch:'المبلغ المستلم يجب أن يطابق مبلغ الفاتورة.',invalid_reference:'راجع مرجع عملية الدفع.',duplicate_reference:'تم تسجيل مرجع الدفع على فاتورة أخرى.',invalid_invoice:'أضف تعليمات دفع أو رابط HTTPS صالحاً.',branch_required:'هذا الفرع غير متاح لهذا الحساب.',booking_changed:'تغيّرت حالة الطلب. حدّث القائمة.',invalid_amount:'أدخل مبلغاً بين 1 و99,999 درهم.',reason_required:'أضف سبب الإغلاق.'};
document.addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.featuredStep){featuredPageNo+=Number(b.dataset.featuredStep);drawFeaturedRail();return;}
  if(b.hasAttribute('data-featured-refresh')){beginFeatured(true);return;}
  if(b.hasAttribute('data-featured-register')){authAccountType='merchant';rememberCardRoute('featured');navigate('register');return;}
  if(b.dataset.featuredOpen){
    const item=featuredBranchById(b.dataset.featuredOpen);
    if(!item){beginFeatured(true);toast('انتهت مدة ظهور الإعلان.');return;}
    showRestaurantOrder(item.id);
    if(!previewRole&&appIdentity?.role==='customer')cardRpc('kod_featured_open',{p_booking:item.booking}).catch(()=>{});
  }
});
document.addEventListener('submit',async e=>{
  const f=e.target,k=f.dataset?.featureForm;if(!k)return;e.preventDefault();
  if(!isFeaturedStaff()||f.dataset.busy==='true')return;
  const v=f.elements,id=f.dataset.booking,epoch=workspaceEpoch,msg=f.querySelector('[role=status]'),btn=f.querySelector('[type=submit]');
  f.dataset.busy='true';btn.disabled=true;msg.textContent='جارٍ الحفظ…';
  try{
    let result='';
    if(k==='request'){await cardRpc('kod_featured_request',{p_branch:v.branch.value,p_request:promoFormRequest(f),p_expected_fils:Number(f.dataset.quoted)});result='تم إرسال طلب فاتورة الظهور.';}
    else if(k==='invoice'){await cardRpc('kod_featured_invoice',{p_id:id,p_note:v.note.value.trim(),p_url:v.url.value.trim()});result='الفاتورة متاحة الآن في حساب الفرع.';}
    else if(k==='settle'){await cardRpc('kod_featured_settle',{p_id:id,p_fils:featureFils(v.amount.value),p_reference:v.reference.value.trim()});result='تم تسجيل الدفعة وجدولة مدة الظهور.';}
    else if(k==='close'){await cardRpc('kod_featured_close',{p_id:id,p_reason:v.reason?.value?.trim()||''});result='تم إغلاق الطلب.';}
    else if(k==='price'){await cardRpc('kod_featured_price',{p_fils:featureFils(v.price.value)});result='تم تحديث سعر الطلبات الجديدة.';}
    else return;
    if(epoch!==workspaceEpoch)return;toast(result);msg.textContent=result;await beginFeatured(true);
  }catch(error){
    if(epoch!==workspaceEpoch)return;
    const note=FEATURE_ERRORS[error.message]||'تعذّر حفظ العملية. تحقق من الاتصال وأعد المحاولة.';
    msg.textContent=note;
    if(error.message==='price_changed'||error.message==='booking_changed'){toast(note);await beginFeatured(true);}
  }finally{btn.disabled=false;delete f.dataset.busy;}
});

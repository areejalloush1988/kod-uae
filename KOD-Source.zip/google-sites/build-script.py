"""Build the single Google Apps Script file from the self-contained public HTML."""
import argparse
import base64
import gzip
import json
from pathlib import Path
import textwrap

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('public_html', type=Path)
p.add_argument('output', type=Path)
args = p.parse_args()
packed = base64.b64encode(gzip.compress(args.public_html.read_bytes(), compresslevel=9, mtime=0)).decode()
parts = [json.dumps(part) for part in textwrap.wrap(packed, width=4096)]
shell = json.dumps((root / 'host.html').read_text(), ensure_ascii=False)
code = (root / 'Code.gs').read_text() + '\nfunction tawfeerHostHtml_(){return ' + shell + ';}\n'
code += 'function tawfeerPackage_(){return [\n' + ',\n'.join(parts) + '\n].join("");}\n'
args.output.write_text(code)
print('Google Apps Script bytes', args.output.stat().st_size)

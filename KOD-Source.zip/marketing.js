// Member referrals and shareable savings. Private totals are keyed to the current session.
const PROMO_AREAS={dubai:'دبي','abu-dhabi':'أبوظبي',sharjah:'الشارقة',ajman:'عجمان','ras-al-khaimah':'رأس الخيمة',fujairah:'الفجيرة','umm-al-quwain':'أم القيوين'};
const PROMO_KINDS={restaurant:'مطعم أو مقهى',creator:'صانع محتوى',corporate:'عضوية شركة',area:'حملة حسب الإمارة',community:'مجموعة محلية'};
const promoSessionKey='kod-promotion-v1';
let promoEntry={},entryJob=null,rewardInfo=null,rewardKey='',rewardError=false,programDays=null,rewardJob=null;
let savingsDraft={bill:'350',percent:'20',source:'example'},companyToken='',companyResult='';
function readPromo(key){try{return JSON.parse(sessionStorage.getItem(key)||'null');}catch{return null;}}
function writePromo(key,value){try{if(value===null)sessionStorage.removeItem(key);else sessionStorage.setItem(key,JSON.stringify(value));}catch{}}
function cleanPromoEntry(){promoEntry={};entryJob=null;writePromo(promoSessionKey,null);}
function clearMarketingScope(){rewardInfo=null;rewardKey='';rewardJob=null;rewardError=false;resetPartnerDesk();savingsDraft={bill:'350',percent:'20',source:'example'};companyResult='';}
function promoHref(key,id){
  const url=new URL(KOD_CONFIG.publicAppUrl);
  if(key==='seat'){url.hash='company/'+id;return url.href;}
  url.searchParams.set(key,id);url.hash='subscriptions';return url.href;
}
function captureMarketingEntry(){
  const search=new URLSearchParams(location.search||''),stored=readPromo(promoSessionKey);
  if(stored&&stored.until>Date.now())promoEntry=stored;
  for(const key of ['invite','campaign']){
    const id=(search.get(key)||'').toLowerCase();
    if(billingUuid.test(id)&&id!==promoEntry[key]){promoEntry[key]=id;delete promoEntry[key+'Offer'];}
  }
  if(promoEntry.invite||promoEntry.campaign){promoEntry.until=Date.now()+7*86400000;writePromo(promoSessionKey,promoEntry);}
  applyPromoArea();
  companyToken=readPromo('kod-company-seat')||'';
}
function applyPromoArea(){const slug=new URLSearchParams(location.search||'').get('area');if(Object.hasOwn(PROMO_AREAS,slug))state.city=PROMO_AREAS[slug];}
function captureCompanyRoute(hash){
  if(!hash.startsWith('company/'))return false;
  const token=hash.slice(8);
  if(billingUuid.test(token)){companyToken=token;writePromo('kod-company-seat',token);}
  return true;
}
async function publicPromoRpc(name,args){
  const res=await fetch(KOD_CONFIG.supabaseUrl+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:KOD_CONFIG.publishableKey,'Content-Type':'application/json'},body:JSON.stringify(args),credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(10000)});
  if(!res.ok)throw Error('unavailable');
  return res.json();
}
function verifyPromoEntry(){
  if(entryJob)return entryJob;
  const target=promoEntry;
  entryJob=Promise.all(['invite','campaign'].map(async key=>{
    if(!target[key]||target[key+'Offer']?.ticket||target[key+'Offer']?.valid===false)return;
    try{
      const offer=key==='invite'?await publicPromoRpc('kod_invite_offer',{p_code:target.invite}):await publicPromoRpc('kod_campaign_offer',{p_campaign:target.campaign});
      if(target===promoEntry)target[key+'Offer']=offer;
    }catch{if(target===promoEntry)target[key+'Offer']={error:true};}
  })).then(()=>{if(target===promoEntry){if(target.invite||target.campaign)writePromo(promoSessionKey,target);entryJob=null;}});
  return entryJob;
}
async function registrationMarketingData(){
  await verifyPromoEntry();const data={};
  for(const key of ['invite','campaign']){
    const offer=promoEntry[key+'Offer'];
    if(offer?.ticket)data['kod_'+key+'_ticket']=offer.ticket;
    if(promoEntry[key]&&offer?.error)throw Error('invite_unavailable');
  }
  return data;
}
async function claimMarketingSignup(){
  if(!appIdentity||previewRole||(!promoEntry.invite&&!promoEntry.campaign))return;
  // Use the original, pre-signup ticket on a provider return. A later ticket cannot attribute an existing account.
  const original=promoEntry;
  try{
    for(const key of ['invite','campaign']){
      const ticket=original[key+'Offer']?.ticket;
      if(ticket)await cardRpc(key==='invite'?'kod_accept_invite':'kod_accept_campaign',{p_ticket:ticket});
    }
    if(original===promoEntry)cleanPromoEntry();
  }catch{}
}
function marketingBanner(){
  const notes=[];
  if(companyToken){notes.push('<div class="promo-note"><div><strong>عضوية موظفي الشركة</strong><p>'+esc(companyResult||'فعّل مقعد الشركة لإضافة أيام العضوية إلى بطاقتك الشخصية.')+'</p></div>'+(hasPersonalCard(appIdentity?.role)&&!previewRole?'<button class="btn" data-claim-seat>تفعيل المقعد على حسابي</button>':'<button class="btn" data-promo-join="subscriptions">دخول أو إنشاء حساب</button>')+'</div>');}
  for(const key of ['invite','campaign']){
    if(!promoEntry[key])continue;
    const o=promoEntry[key+'Offer'];
    let title=key==='invite'?'وصلتك دعوة إلى كود':'اشتراك من رابط شريك كود';
    let detail=!o?'جارٍ التحقق من الرابط…':o.error?'تعذّر التحقق من الرابط.':!o.valid?'الرابط غير صالح. يمكنك متابعة تصفّح الباقات.':key==='invite'?'افتح حساباً جديداً من هالرابط. عند تأكيد أول اشتراك مدفوع، يحصل صاحب الدعوة على '+number(o.days)+' أيام عضوية.':(o.label||'')+(o.city?' · '+o.city:'');
    if(key==='campaign'&&o?.kind==='area'&&o.city)title='اشتراكات كود في '+o.city;
    notes.push('<div class="promo-note"><div><strong>'+esc(title)+'</strong><p>'+esc(detail)+'</p></div>'+(o?.error?'<button class="text-button" data-promo-retry>إعادة التحقق</button>':o?.valid&&!appIdentity?'<button class="btn" data-promo-join="subscriptions">إنشاء حساب</button>':'')+'</div>');
  }
  const area=new URLSearchParams(location.search||'').get('area'),city=Object.hasOwn(PROMO_AREAS,area)?PROMO_AREAS[area]:'';
  if(city)notes.push('<div class="promo-note"><div><strong>عضوية كود في '+city+'</strong><p>اطّلع على الفروع التي تقبل بطاقة الخصم قبل الاشتراك.</p></div><button class="btn light" data-go="membership">عرض الفروع المشاركة</button></div>');
  return notes.join('');
}
function startMarketingEntry(){
  if(!['invite','campaign'].some(k=>promoEntry[k]&&!promoEntry[k+'Offer']))return;
  verifyPromoEntry().then(()=>{if(current==='subscriptions')redrawSubscriptions();});
}
function marketingHomeLink(){return '<section class="promo-home"><span class="promo-mark">'+icon('ticket')+'</span><div><strong>ادعُ صديقاً واكسب أيام عضوية</strong><p>شارك رابط اشتراكك وتابع مكافآتك.</p></div><button class="btn light" data-go="rewards">دعواتي ومكافآتي</button></section>';}
function promoAreaLinks(){return '<div class="promo-area-links">'+Object.entries(PROMO_AREAS).map(([slug,city])=>'<a href="./city-'+slug+'.html">'+city+'</a>').join('')+'</div>';}
function localGuideShare(slug){
  if(!Object.hasOwn(PROMO_AREAS,slug))slug='dubai';
  return promoShareTools(new URL('city-'+slug+'.html',KOD_CONFIG.publicAppUrl).href,'دليل كود للمطاعم والمقاهي في '+PROMO_AREAS[slug]+'.');
}
function promoShareTools(url,message){
  const encoded=encodeURIComponent(url),wa=encodeURIComponent(message+' '+url);
  return '<div class="promo-share"><button class="btn" type="button" data-share-url="'+esc(url)+'" data-share-text="'+esc(message)+'">مشاركة الرابط</button><button type="button" class="btn light" data-copy-url="'+esc(url)+'">نسخ الرابط</button><a target="_blank" rel="noopener noreferrer" href="https://wa.me/?text='+esc(wa)+'">واتساب</a><a target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/sharer/sharer.php?u='+esc(encoded)+'">فيسبوك</a></div>';
}
async function copyPromo(textValue){
  try{await navigator.clipboard.writeText(textValue);toast('تم نسخ الرابط.');}
  catch{showModal('<h2>انسخ الرابط</h2><label class="field">رابط المشاركة<input readonly dir="ltr" id="promo-copy-value" value="'+esc(textValue)+'"></label>');const n=document.getElementById('promo-copy-value');n?.focus();n?.select();}
}
function rewardPanel(){
  const personal=hasPersonalCard(appIdentity?.role)&&!previewRole,days=personal?rewardInfo?.days||programDays:programDays;
  let actions='';
  if(previewRole)actions='<p>اخرج من المعاينة لعرض دعوات حسابك.</p>';
  else if(personal&&rewardInfo)actions=promoShareTools(promoHref('invite',rewardInfo.code),'هاي دعوتي لعضوية كود لخصومات المطاعم والمقاهي في الإمارات.');
  else if(personal)actions=rewardError?'<button class="btn light" data-reload-rewards>إعادة تحميل رابط الدعوة</button>':'<p role="status">جارٍ تحميل رابطك الشخصي…</p>';
  else if(appIdentity?.role==='merchant')actions='<button class="btn light" data-go="marketing">تسويق فرعي</button>';
  else actions='<button class="btn" data-card-login="rewards">سجّل الدخول للحصول على رابطك</button>';
  const s=personal?rewardInfo:null;
  return '<section class="promo-invite"><div class="promo-invite-copy"><span class="promo-kicker">مكافآت كود</span><h1>ادعُ صديقاً،<br>واكسب أيام عضوية.</h1><p>لما صديقك يسجّل من رابطك ويدفع أول اشتراك، بتنضاف مكافأتك لبطاقة كود.</p>'+actions+'</div><div class="promo-days">'+icon('ticket')+'<strong>'+(days?number(days):'كود')+'</strong><span>'+(days?'أيام لكل اشتراك مؤهّل':'أيام عضوية إضافية')+'</span></div></section>'+
    (s?'<section class="promo-metrics">'+[[s.joined,'أصدقاء سجّلوا'],[s.paid,'أصدقاء دفعوا'],[s.earned_days,'أيام مكتسبة']].map(([v,l])=>'<div><strong>'+number(v)+'</strong><span>'+l+'</span></div>').join('')+'</section>'+(s.earned_days>s.applied_days?'<p class="promo-note">لديك '+number(s.earned_days-s.applied_days)+' أيام محفوظة بانتظار إعادة تفعيل البطاقة.</p>':''):'');
}
async function beginRewardsPage(force=false){
  const id=appIdentity?.id||'',key=workspaceEpoch+'|'+id+'|'+(previewRole||''),epoch=workspaceEpoch;
  if(!force&&(rewardKey===key||rewardJob===key))return;
  rewardJob=key;
  try{
    if(hasPersonalCard(appIdentity?.role)&&!previewRole){
      const data=await cardRpc('kod_referral_home',{});if(epoch!==workspaceEpoch||id!==appIdentity?.id||previewRole)return;
      rewardInfo=data;programDays=data.days;
    }else{const data=await publicPromoRpc('kod_invite_offer',{p_code:null});if(epoch===workspaceEpoch)programDays=data.days;}
    if(epoch===workspaceEpoch)rewardError=false;
  }catch{if(epoch===workspaceEpoch)rewardError=true;}
  finally{if(epoch===workspaceEpoch&&rewardJob===key){rewardKey=key;rewardJob=null;const panel=document.getElementById('promo-reward-panel');if(current==='rewards'&&panel)panel.innerHTML=rewardPanel();}}
}
function savingsRecords(){
  if(previewRole||!hasPersonalCard(appIdentity?.role))return [];
  const uid=appIdentity.id;
  const local=(liveWorkspace.cardReceipts||[]).filter(r=>r.customer_id===uid&&r.discount_cents>0).map(r=>({key:'card-'+r.id,beforeFils:r.bill_cents,afterFils:r.net_cents,label:r.restaurant_name,date:r.created_at}));
  const online=(liveWorkspace.orders||[]).filter(o=>o.customer_id===uid&&o.status==='delivered'&&o.discount_cents>0).map(o=>({key:'order-'+o.id,beforeFils:o.subtotal_cents,afterFils:o.subtotal_cents-o.discount_cents,label:o.restaurant_name,date:o.created_at}));
  return local.concat(online).sort((a,b)=>String(b.date).localeCompare(String(a.date)));
}
function shareAmounts(){
  if(savingsDraft.source!=='example'){const r=savingsRecords().find(r=>r.key===savingsDraft.source);if(r)return {beforeFils:r.beforeFils,afterFils:r.afterFils,label:r.label,example:false};}
  const b=Number(latinDigits(savingsDraft.bill)),p=Number(latinDigits(savingsDraft.percent));
  if(!savingsDraft.bill.trim()||!savingsDraft.percent.trim()||!Number.isFinite(b)||!Number.isFinite(p)||b<=0||b>1000000||p<0||p>100)return null;
  const beforeFils=Math.round(b*100);
  return {beforeFils,afterFils:beforeFils-Math.round(beforeFils*p/100),label:'حاسبة كود',example:true};
}
function shareAmountsView(){
  const data=shareAmounts();if(!data)return '<p role="status">أدخل قيمة فاتورة موجبة ونسبة بين 0 و100.</p>';
  const saved=data.beforeFils-data.afterFils,net=saved-SUBSCRIPTION_PLANS[0].price*100;
  return '<div class="promo-bill"><span>قبل الخصم <strong>'+money(data.beforeFils)+'</strong></span><span>بعد الخصم <strong>'+money(data.afterFils)+'</strong></span><span>التوفير <strong>'+money(saved)+'</strong></span></div>'+
    '<p class="promo-small">'+(data.example?'مثال توضيحي. ':'')+(net>=0?'التوفير يغطي الاشتراك الشهري ('+money(SUBSCRIPTION_PLANS[0].price*100)+')'+(net>0?' ويزيد عنه '+money(net):'')+'.':'المتبقي لتغطية الاشتراك الشهري من التوفير '+money(-net)+'.')+'</p>'+
    '<div class="promo-actions"><button type="button" class="btn light" data-export-savings="image">حمّل صورة التوفير</button>'+(canMakeSavingsVideo()?'<button type="button" class="btn light" data-export-savings="video">حمّل فيديو قصير</button>':'')+'</div><p role="status" id="promo-export-status"></p>';
}
function savingsStudio(){
  const rows=savingsRecords(),example=savingsDraft.source==='example'||!rows.some(r=>r.key===savingsDraft.source);
  return '<section class="promo-box"><h2>شارك قديش وفّرت</h2><p>جهّز صورة أو فيديو عمودي للواتساب وإنستغرام وتيك توك.</p>'+
    '<label class="field">مصدر المبلغ<select id="promo-source"><option value="example">مثال من حاسبة التوفير</option>'+rows.map(r=>'<option value="'+esc(r.key)+'"'+(r.key===savingsDraft.source?' selected':'')+'>'+displayText(r.label||'فاتورة كود')+' · '+money(r.beforeFils)+'</option>').join('')+'</select></label>'+
    (example?'<div class="promo-inputs"><label class="field">الفاتورة بالدرهم<input id="promo-bill" type="number" min="0.01" step="0.01" max="1000000" lang="en" dir="ltr" value="'+esc(savingsDraft.bill)+'"></label><label class="field">الخصم (%)<input id="promo-percent" type="number" min="0" step="0.01" max="100" lang="en" dir="ltr" value="'+esc(savingsDraft.percent)+'"></label></div>':'')+
    '<div id="promo-amounts" aria-live="polite">'+shareAmountsView()+'</div></section>';
}
function rewardsPage(){return '<div class="promo-page"><div id="promo-reward-panel">'+rewardPanel()+'</div><div id="promo-studio">'+savingsStudio()+'</div><section class="promo-box"><h2>اكتشف أماكن في إمارتك</h2>'+promoAreaLinks()+'</section><button class="text-button" data-go="marketing">الشراكات وحملات كود</button></div>';}
document.addEventListener('input',e=>{
  if(!['promo-bill','promo-percent'].includes(e.target.id))return;
  savingsDraft[e.target.id==='promo-bill'?'bill':'percent']=e.target.value;
  document.getElementById('promo-amounts').innerHTML=shareAmountsView();
});
document.addEventListener('change',e=>{if(e.target.id==='promo-local-guide'){document.getElementById('promo-local-share').innerHTML=localGuideShare(e.target.value);return;}if(e.target.id==='promo-source'){savingsDraft.source=e.target.value;document.getElementById('promo-studio').innerHTML=savingsStudio();}});
document.addEventListener('click',async e=>{
  const b=e.target.closest('button');if(!b)return;
  const d=b.dataset;
  if(d.copyUrl){await copyPromo(d.copyUrl);return;}
  if(d.shareUrl){if(typeof navigator.share==='function'){try{await navigator.share({title:'كود',text:d.shareText,url:d.shareUrl});return;}catch(err){if(err.name==='AbortError')return;}}await copyPromo(d.shareUrl);return;}
  if(b.hasAttribute('data-forget-invite')){cleanPromoEntry();history.replaceState(null,'',location.pathname+location.hash);render(current);return;}
  if(d.promoJoin){rememberCardRoute(d.promoJoin);authAccountType='customer';navigate('register');return;}
  if(b.hasAttribute('data-reload-rewards')){beginRewardsPage(true);return;}
  if(b.hasAttribute('data-promo-retry')){await verifyPromoEntry();redrawSubscriptions();return;}
  if(b.hasAttribute('data-claim-seat')&&companyToken&&!previewRole&&hasPersonalCard(appIdentity?.role)){
    const epoch=workspaceEpoch;b.disabled=true;
    try{const days=await cardRpc('kod_claim_seat',{p_token:companyToken});if(epoch!==workspaceEpoch)return;
      companyToken='';writePromo('kod-company-seat',null);history.replaceState(null,'',location.pathname+'#membership');await refreshLiveWorkspace();render('membership');toast('تمت إضافة '+number(days)+' أيام إلى بطاقتك.');
    }catch{if(epoch===workspaceEpoch){companyResult='تعذّر تفعيل المقعد. راجع صلاحية الرابط أو تحقق من استخدام مقعد لهذه الشركة سابقاً.';redrawSubscriptions();}}return;
  }
  if(d.exportSavings){
    const data=shareAmounts(),status=document.getElementById('promo-export-status'),epoch=workspaceEpoch;if(!data)return;
    b.disabled=true;const video=d.exportSavings==='video';status.textContent=video?'جارٍ تجهيز الفيديو…':'جارٍ تجهيز الصورة…';
    try{const blob=video?await savingsShareVideo(data):await savingsSharePng(data);if(epoch!==workspaceEpoch||current!=='rewards')return;
      saveCardFile(blob,'KOD-Savings.'+(video?(blob.type.includes('mp4')?'mp4':'webm'):'png'));status.textContent='تم تجهيز الملف للمشاركة.';
    }catch{status.textContent='تعذّر إنشاء الملف على هذا الجهاز. جرّب صورة التوفير.';}finally{b.disabled=false;}
  }
});

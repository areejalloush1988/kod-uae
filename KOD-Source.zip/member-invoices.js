// Member invoices use the same settlement and membership periods as hosted checkout.
let memberBills=null,memberBillsKey='',memberBillsJob=null,memberBillsError=false;
function clearMemberInvoiceScope(){memberBills=null;memberBillsKey='';memberBillsJob=null;memberBillsError=false;}
function canUseMemberInvoices(){return !previewRole&&hasPersonalCard(appIdentity?.role);}
function memberInvoiceBody(){
  if(!canUseMemberInvoices())return !appIdentity||appIdentity.role==='developer_locked'?'<button class="btn light" data-card-login="subscriptions">سجّل الدخول لطلب فاتورة</button>':'';
  const plan=selectedPlan(),admin=isLiveOperator(),invoices=memberBills?.invoices||[];
  const pending=invoices.some(b=>b.mine&&receiptTier(b)===plan.tier&&b.months===plan.months&&['requested','invoiced'].includes(b.state));
  let action='';
  if(pending)action='<p>عندك طلب مفتوح لهذه الفئة والمدة. تابع حالته أدناه.</p>';
  else if(plan.amount_fils!==null&&!priceListError)action='<form class="featured-form" data-member-form="request" data-tier="'+plan.tier+'" data-months="'+plan.months+'" data-quoted="'+plan.amount_fils+'">'+featureSubmit('طلب فاتورة العضوية '+CLUB_TIERS[plan.tier].name+' · '+plan.label+' · '+money(plan.amount_fils))+'</form>';
  else action='<p>'+(!plan.months?'اختر الفئة والمدة لطلب فاتورة.':membershipCatalog?'طلب الفاتورة يتطلب سعراً معتمداً لهذا الخيار.':'جارٍ التحقق من السعر…')+'</p>';
  let history='';
  if(invoices.length)history='<h3>'+(admin?'طلبات فواتير العضوية':'فواتيري')+'</h3>'+invoices.map(b=>{
    const url=featurePaymentUrl(b.url),label={requested:'بانتظار إصدار الفاتورة',invoiced:'الفاتورة جاهزة للدفع',paid:'مدفوعة',cancelled:'ملغاة',declined:'أغلقتها الإدارة'}[b.state]||'قيد المراجعة';
    const details=b.state==='invoiced'?((b.note?'<p class="featured-pay-note">'+esc(b.note)+'</p>':'')+(url?'<a class="btn light" href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">فتح رابط دفع الفاتورة</a>':'')):'';
    const cancel=b.state==='requested'&&b.mine&&!admin?'<form class="featured-form" data-member-form="close" data-booking="'+esc(b.id)+'">'+featureSubmit('إلغاء الطلب')+'</form>':'';
    const period=b.state==='paid'?'<p>مدة العضوية من '+clubStarts(b.starts)+' إلى '+cardLastDay(b.ends)+'</p>'+(b.mine?'<button class="text-button" data-go="membership">عرض بطاقتي</button>':''):'';
    const term=SUBSCRIPTION_TERMS.find(p=>p.months===b.months);
    return '<article class="featured-row"><header><h4>'+CLUB_TIERS[receiptTier(b)].name+' · '+term.label+'</h4><strong>'+label+'</strong></header><p>'+(admin?displayText(b.name)+' · ':'')+money(b.amount_fils)+' · <bdi>KOD-'+esc(b.id.slice(0,8).toUpperCase())+'</bdi></p>'+details+period+(b.review_note?'<p>'+esc(b.review_note)+'</p>':'')+featuredOperatorBooking({id:b.id,state:b.state,payment_note:b.note,payment_url:b.url},'member')+cancel+'</article>';
  }).join('');
  const loading=memberBillsError?'تعذّر تحميل فواتير العضوية.':!memberBills?'جارٍ تحميل الفواتير…':'';
  return action+'<div class="member-invoice-history">'+history+'<p aria-live="polite">'+loading+'</p><button type="button" class="text-button" data-member-bills-refresh>تحديث الفواتير</button></div>';
}
function memberInvoiceSection(){
  if(previewRole||appIdentity?.role==='merchant')return '';
  return '<section class="featured-box member-bills" id="member-bills" tabindex="-1"><h2>الدفع بفاتورة كود</h2><p>اطلب فاتورة للباقة المختارة. بتلاقي تعليمات الدفع هون، وبتنضاف مدة الباقة لبطاقتك بعد تأكيد استلام المبلغ.</p><div id="member-bills-body">'+memberInvoiceBody()+'</div></section>';
}
async function loadMemberInvoices(force=false){
  if(!canUseMemberInvoices())return;
  const epoch=workspaceEpoch,key=epoch+'|'+appIdentity.id;
  if(memberBillsJob?.key===key)return memberBillsJob.promise;
  if(!force&&memberBillsKey===key&&!memberBillsError)return;
  const work=(async()=>{
    try{
      const result=await cardRpc('kod_member_invoice_desk',{});
      if(!Array.isArray(result?.invoices))throw Error();
      if(epoch!==workspaceEpoch||!canUseMemberInvoices())return;
      memberBills=result;memberBillsKey=key;memberBillsError=false;
    }catch{if(epoch!==workspaceEpoch)return;memberBillsError=true;}
    const panel=document.getElementById('member-bills-body');
    if(current==='subscriptions'&&panel&&(!panel.contains?.(document.activeElement)||force))panel.innerHTML=memberInvoiceBody();
  })();
  memberBillsJob={key,promise:work};try{await work;}finally{if(memberBillsJob?.promise===work)memberBillsJob=null;}
}
document.addEventListener('click',e=>{
  if(current!=='subscriptions')return;
  const b=e.target.closest('button');if(!b)return;
  if(b.hasAttribute('data-scroll-bills')){const panel=document.getElementById('member-bills');panel?.scrollIntoView({behavior:'smooth',block:'start'});panel?.focus({preventScroll:true});}
  if(b.hasAttribute('data-member-bills-refresh'))loadMemberInvoices(true);
});
document.addEventListener('submit',async e=>{
  const form=e.target,action=form.dataset?.memberForm;if(!action)return;e.preventDefault();
  if(!canUseMemberInvoices()||form.dataset.busy==='true')return;
  const epoch=workspaceEpoch,v=form.elements,msg=form.querySelector('[role=status]'),button=form.querySelector('[type=submit]');
  button.disabled=true;form.dataset.busy='true';msg.textContent='جارٍ الحفظ…';
  try{
    if(action==='request')await cardRpc('kod_request_plan_invoice',{p_tier:form.dataset.tier,p_months:Number(form.dataset.months),p_expected_fils:Number(form.dataset.quoted),p_request:promoFormRequest(form)});
    else await cardRpc('kod_member_invoice_update',{p_id:form.dataset.booking,p_action:action,p_note:(v.note?.value||v.reason?.value||'').trim(),p_url:(v.url?.value||'').trim(),p_fils:v.amount?featureFils(v.amount.value):null,p_reference:(v.reference?.value||'').trim()});
    if(epoch!==workspaceEpoch)return;
    toast({request:'تم إرسال طلب الفاتورة.',invoice:'الفاتورة متاحة في حساب العضو.',settle:'تم تأكيد الدفع وإضافة مدة العضوية.',close:'تم إغلاق الطلب.'}[action]);
    await loadMemberInvoices(true);
    if(action==='settle'&&epoch===workspaceEpoch)await Promise.all([refreshLiveWorkspace(),loadSubscriptionReceipts(true)]);
  }catch(error){if(epoch===workspaceEpoch){msg.textContent=({price_unset:'لم يُحدد سعر هذا الخيار.',invoice_open:'لديك فاتورة مفتوحة تحتفظ بسعرها السابق.'})[error.message]||FEATURE_ERRORS[error.message]||'تعذّر حفظ العملية. تحقق من الاتصال وأعد المحاولة.';if(['booking_changed','invoice_open'].includes(error.message))await loadMemberInvoices(true);if(['price_unset','price_changed'].includes(error.message)){toast(msg.textContent);await loadMembershipCatalog(true);redrawSubscriptions(true);}}}
  finally{button.disabled=false;delete form.dataset.busy;}
});

// The wallet preview, printable faces and saved image share the same 85.6:54 artwork.
const memberArtSize={width:856,height:540};
const memberArtBorder='M 34 0 H 822 Q 856 0 856 34 V 506 Q 856 540 822 540 H 34 Q 0 540 0 506 V 34 Q 0 0 34 0 Z';
const memberArtTile={x:51,y:172,width:285};
const memberArtFonts={
  arabic:'Cairo, Tahoma, Arial, sans-serif',
  brand:'Arial, "Liberation Sans", Helvetica, sans-serif',
  digits:'Consolas, "Liberation Mono", "Courier New", monospace'
};
const memberArtGradients={
  ink:{line:[0,0,815,557],stops:[[0,'#233748'],[.43,'#142533'],[1,'#0b151f']]},
  reverse:{line:[0,45,856,490],stops:[[0,'#142836'],[.6,'#14222f'],[1,'#101a25']]},
  copper:{line:[41,0,814,0],stops:[[0,'#d69c79'],[.2,'#f2c7a1'],[.47,'#a57660'],[.74,'#ddb08e'],[1,'#b58269']]},
  face:{line:[0,293,0,349],stops:[[0,'#faf1e1'],[.38,'#ebe5d8'],[.6,'#d7d0c4'],[.81,'#cfb9a1'],[1,'#f0dcc3']]}
};
let memberArtInstance=0;

function memberArtHolder(card,measure){
  const raw=String(card.name||'').replace(/[\u0000-\u001f\u007f\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,' ').replace(/\s+/g,' ').trim();
  const name=raw&&!raw.includes('@')&&!/^[+\d٠-٩۰-۹ ().-]+$/.test(raw)?raw:'عضو كود';
  let text=name,size=43;
  if(measure){
    const maxWidth=665;
    measure.font='700 '+size+'px '+memberArtFonts.arabic;
    if(measure.measureText(text).width>maxWidth){
      size=34;
      measure.font='700 '+size+'px '+memberArtFonts.arabic;
      if(measure.measureText(text).width>maxWidth){
        const chars=Array.from(text);
        while(chars.length&&measure.measureText(chars.join('')+'…').width>maxWidth)chars.pop();
        text=chars.join('').trimEnd()+'…';
      }
    }
  }
  return {name,text,size,dir:/^[^A-Za-z]*[\u0590-\u08ff]/.test(text)?'rtl':'ltr'};
}

function memberArtQr(url){
  if(!url||typeof qrcode!=='function')return null;
  const qr=qrcode(0,'M');
  qr.addData(url,'Byte');
  qr.make();
  const size=qr.getModuleCount(),runs=[];
  // The four blank modules on every edge are part of the encoded artwork.
  for(let y=0;y<size;y++){
    for(let x=0;x<size;){
      if(!qr.isDark(y,x)){x++;continue;}
      const start=x++;
      while(x<size&&qr.isDark(y,x))x++;
      runs.push([start+4,y+4,x-start]);
    }
  }
  return {modules:size+8,runs};
}

function memberArtScene(card,side,measure){
  if(side!=='front'&&side!=='back')throw Error('invalid_member_card_side');
  const digits=String(card.number||'').replace(/[\s-]/g,'');
  if(!/^\d{16}$/.test(digits))throw Error('invalid_member_card_number');
  const groups=digits.match(/.{4}/g),number=groups.join(' ');
  const holder=memberArtHolder(card,measure),paths=[],labels=[];
  const front=side==='front',qr=front?null:memberArtQr(card.url);
  const paper='#f5f2e9',muted='#cfcec8',foil='#e6ba98';
  function path(d,fill='none',stroke='none',width=1,opacity=1){
    paths.push({d,fill,stroke,width,opacity});
  }
  function label(text,x,y,size,weight,font,align,dir,color){
    labels.push({text,x,y,size,weight,font,align,dir,color});
  }
  function ar(text,x,y,size,weight,color){
    label(text,x,y,size,weight,'arabic','right','rtl',color);
  }
  path('M0 0H856V540H0Z',front?'@ink':'@reverse');
  // Engraved contour lines sweep beyond the upper and right trim edges.
  for(let i=0;i<17;i++){
    const dx=i*8,dy=i*2;
    const contour='M '+(354+dx)+' -34 C '+(283+dx)+' 81 '+(379+dx)+' '+(172+dy)+' '+(532+dx)+' '+(157+dy)+
      ' C '+(665+dx)+' '+(144+dy)+' '+(724+dx)+' '+(181+dy)+' '+(751+dx)+' '+(239+dy)+
      ' S '+(808+dx)+' '+(382+dy)+' '+(931+dx)+' '+(367+dy);
    path(contour,'none','@copper',i%4===0?1.5:1,front?(i%4===0?.24:.135):.075);
  }
  // The wordmark is outlined so the period and letter spacing are identical in print.
  path('M50 45H62V68L83 45H98L74 71L100 100H84L62 75V100H50Z',paper);
  path('M127 44C143 44 154 56 154 72.5S143 101 127 101S100 89 100 72.5S111 44 127 44Z M127 55C118 55 112 62 112 72.5S118 90 127 90S142 83 142 72.5S136 55 127 55Z',paper);
  path('M164 45H185C203 45 214 55.5 214 72.5S203 100 185 100H164Z M176 56V89H184.5C196 89 202 83.5 202 72.5S196 56 184.5 56Z',paper);
  path('M226 88H238V100H226Z','@copper');

  if(card.demo){
    path('M275 54H339Q351 54 351 66V82Q351 94 339 94H275Q263 94 263 82V66Q263 54 275 54Z','#1b2934','#b18b72',1.4);
    label('نموذج',307,82,22,700,'arabic','center','rtl',foil);
  }
  if(front){
    const level=!card.demo&&activeClubTier(card);
    ar(level?'العضوية '+CLUB_TIERS[level].name:'بطاقة العضوية',805,86,35,700,paper);
    // A raised dining emblem uses the fork and knife from KOD's restaurant identity.
    path('M86 152A40 40 0 1 1 86 232A40 40 0 1 1 86 152Z','#192d3a','@copper',2.2);
    path('M86 158A34 34 0 1 1 86 226A34 34 0 1 1 86 158Z','none','#b18b74',.9,.78);
    path('M73 174V186Q73 191 79 191Q85 191 85 186V174 M79 174V212 M98 174Q89 181 90 195H98 M98 174V212','none','@copper',2.8);
    ar('رقم العضوية',805,270,24,600,foil);
    const positions=[48,249,450,651];
    groups.forEach((group,index)=>{
      const x=positions[index];
      label(group,x+1.6,349.5,63,700,'digits','left','ltr','#070e16');
      label(group,x,347,63,700,'digits','left','ltr','@face');
    });
    path('M50 383H806','none','#b4bcc1',1,.27);
    path('M50 383H123','none','@copper',2);
    ar('اسم العضو',805,424,23,600,foil);
    label(holder.text,805,485,holder.size,700,'arabic','right',holder.dir,paper);
  }else{
    ar('بطاقة الخصومات',805,86,35,700,paper);
    path('M50 132H806','none','#a6b3bd',1,.30);
    path('M50 132H123','none','@copper',2);
    ar('عند الكاشير',805,209,40,700,paper);
    ar(qr?'أبرز الرمز قبل الدفع':'أبرز رقم العضوية قبل الدفع',805,261,28,600,muted);
    path('M389 316H805','none','#a6b3bd',1,.32);
    ar('رقم العضوية للإدخال اليدوي',805,366,26,600,foil);
    label(number,805,420,35,700,'digits','right','ltr',paper);
    if(qr){
      const {x,y,width}=memberArtTile;
      path('M'+x+' '+y+'h'+width+'v'+width+'h-'+width+'Z','#ffffff');
    }
  }
  return {side,paths,labels,qr,number,name:holder.name};
}

function memberArtHtml(card,side='front'){
  const measure=typeof document==='undefined'?null:document.createElement('canvas').getContext?.('2d');
  const scene=memberArtScene(card,side,measure),prefix='kod-member-art-'+(++memberArtInstance);
  const paint=color=>color.startsWith('@')?'url(#'+prefix+'-'+color.slice(1)+')':color;
  const gradients=Object.entries(memberArtGradients).map(([key,gradient])=>{
    const [x1,y1,x2,y2]=gradient.line;
    return '<linearGradient id="'+prefix+'-'+key+'" gradientUnits="userSpaceOnUse" x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'">'+
      gradient.stops.map(([offset,color])=>'<stop offset="'+offset+'" stop-color="'+color+'"/>').join('')+'</linearGradient>';
  }).join('');
  const paths=scene.paths.map(p=>'<path d="'+p.d+'" fill="'+paint(p.fill)+'" fill-rule="evenodd" stroke="'+paint(p.stroke)+'" stroke-width="'+p.width+'" stroke-linecap="round" stroke-linejoin="round" opacity="'+p.opacity+'"/>').join('');
  let qr='';
  if(scene.qr){
    const {x,y,width}=memberArtTile,{modules,runs}=scene.qr;
    const d=runs.map(([col,row,len])=>'M'+col+' '+row+'h'+len+'v1h-'+len+'z').join('');
    qr='<svg x="'+x+'" y="'+y+'" width="'+width+'" height="'+width+'" viewBox="0 0 '+modules+' '+modules+'"><path fill="#101923" shape-rendering="crispEdges" d="'+d+'"/></svg>';
  }
  const labels=scene.labels.map(item=>{
    const anchor=item.align==='center'?'middle':(item.align==='left')===(item.dir==='ltr')?'start':'end';
    return '<text x="'+item.x+'" y="'+item.y+'" direction="'+item.dir+'" text-anchor="'+anchor+'" font-family="'+esc(memberArtFonts[item.font])+'" font-weight="'+item.weight+'" font-size="'+item.size+'" fill="'+paint(item.color)+'">'+esc(item.text)+'</text>';
  }).join('');
  const description=(card.demo?'نموذج بطاقة عضوية كود':'بطاقة عضوية كود')+'، '+scene.name+'، رقم '+scene.number+(side==='back'?'، ظهر البطاقة':'، وجه البطاقة');
  return '<svg class="kod-member-art" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 856 540" width="856" height="540" style="display:block;width:100%;height:auto;max-width:600px" role="img" aria-label="'+esc(description)+'" direction="ltr">'+
    '<defs>'+gradients+'<clipPath id="'+prefix+'-clip"><path d="'+memberArtBorder+'"/></clipPath></defs><g clip-path="url(#'+prefix+'-clip)">'+paths+qr+labels+'</g></svg>';
}

async function memberArtCanvas(card,side='front',scale=2,printBleed=false){
  if(!Number.isFinite(scale)||scale<=0)throw Error('invalid_member_card_scale');
  if(document.fonts?.load){
    const sample='بطاقة العضوية اسم العضو رقم الخصومات عند الكاشير '+(card.name||'كود');
    await Promise.all([600,700].map(weight=>document.fonts.load(weight+' 40px Cairo',sample))).catch(()=>{});
  }
  const canvas=document.createElement('canvas');
  canvas.width=Math.round(memberArtSize.width*scale);
  canvas.height=Math.round(memberArtSize.height*scale);
  const ctx=canvas.getContext('2d');
  if(!ctx)throw Error('member_card_image_unavailable');
  const scene=memberArtScene(card,side,ctx);
  if(side==='back'&&!scene.qr)throw Error('member_card_qr_unavailable');
  const sx=canvas.width/memberArtSize.width,sy=canvas.height/memberArtSize.height;
  ctx.scale(sx,sy);
  ctx.save();
  if(!printBleed)ctx.clip(new Path2D(memberArtBorder));
  const gradients={};
  for(const [key,definition] of Object.entries(memberArtGradients)){
    const gradient=ctx.createLinearGradient(...definition.line);
    for(const [offset,color] of definition.stops)gradient.addColorStop(offset,color);
    gradients['@'+key]=gradient;
  }
  ctx.lineJoin='round';
  ctx.lineCap='round';
  for(const item of scene.paths){
    const shape=new Path2D(item.d);
    ctx.globalAlpha=item.opacity;
    if(item.fill!=='none'){
      ctx.fillStyle=gradients[item.fill]||item.fill;
      ctx.fill(shape,'evenodd');
    }
    if(item.stroke!=='none'){
      ctx.strokeStyle=gradients[item.stroke]||item.stroke;
      ctx.lineWidth=item.width;
      ctx.stroke(shape);
    }
  }
  ctx.globalAlpha=1;
  if(scene.qr){
    const {x,y,width}=memberArtTile,{modules,runs}=scene.qr;
    // Integer device pixels keep the QR crisp in downloads and the print renderer.
    const pixel=Math.floor(width*Math.min(sx,sy)/modules);
    if(!pixel)throw Error('member_card_qr_too_small');
    const left=Math.round(x*sx+(width*sx-modules*pixel)/2);
    const top=Math.round(y*sy+(width*sy-modules*pixel)/2);
    ctx.save();
    ctx.setTransform(1,0,0,1,0,0);
    ctx.fillStyle='#101923';
    for(const [col,row,len] of runs)ctx.fillRect(left+col*pixel,top+row*pixel,len*pixel,pixel);
    ctx.restore();
  }
  for(const item of scene.labels){
    ctx.font=item.weight+' '+item.size+'px '+memberArtFonts[item.font];
    ctx.direction=item.dir;
    ctx.textAlign=item.align;
    ctx.textBaseline='alphabetic';
    ctx.fillStyle=gradients[item.color]||item.color;
    ctx.fillText(item.text,item.x,item.y);
  }
  ctx.restore();
  return canvas;
}

async function memberArtPng(card){
  const [front,back]=await Promise.all([memberArtCanvas(card,'front'),memberArtCanvas(card,'back')]);
  const canvas=document.createElement('canvas'),gutter=32;
  canvas.width=front.width;
  canvas.height=front.height+gutter+back.height;
  const ctx=canvas.getContext('2d');
  if(!ctx)throw Error('member_card_image_unavailable');
  ctx.fillStyle='#ffffff';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.drawImage(front,0,0);
  ctx.drawImage(back,0,front.height+gutter);
  return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('member_card_image_unavailable')),'image/png'));
}

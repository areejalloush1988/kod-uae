// The screen and the downloadable card use the same geometry, text and local QR matrix.
const memberArtSize={width:856,height:540};
const memberArtBorder='M 35 1 H 821 Q 855 1 855 35 V 505 Q 855 539 821 539 H 35 Q 1 539 1 505 V 35 Q 1 1 35 1 Z';
const memberArtTile={x:45,y:185,width:252,codeWidth:228};
const memberArtFonts={arabic:'Cairo, Tahoma, Arial, sans-serif',brand:'Arial, "Liberation Sans", Helvetica, sans-serif',digits:'Consolas, "Liberation Mono", monospace'};
let memberArtInstance=0;

function memberArtScene(card,measure){
  const digits=String(card.number||'').replace(/[\s-]/g,'');
  if(!/^\d{16}$/.test(digits))throw Error('invalid_member_card_number');
  const number=digits.match(/.{4}/g).join(' ');
  const rawName=String(card.name||'').replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g,' ').replace(/\s+/g,' ').trim();
  const name=rawName&&!rawName.includes('@')&&!/^[+\d٠-٩۰-۹ ().-]+$/.test(rawName)?rawName:'عضو كود';
  let visibleName=name,nameSize=43;
  if(measure){
    const width=462;
    measure.font='700 '+nameSize+'px '+memberArtFonts.arabic;
    if(measure.measureText(name).width>width){
      nameSize=35;
      measure.font='700 '+nameSize+'px '+memberArtFonts.arabic;
      if(measure.measureText(name).width>width){
        const chars=Array.from(name);
        while(chars.length&&measure.measureText(chars.join('')+'…').width>width)chars.pop();
        visibleName=chars.join('').trimEnd()+'…';
      }
    }
  }
  const bands=Array.from({length:9},(_,i)=>'M -114 '+(240+i*9)+' C 62 '+(32+i*8)+' 179 '+(350+i*5)+' 377 '+(220+i*5)+' S 574 '+(21+i*5)+' '+(706+i*7)+' -48');
  let qrSize=0;const runs=[];
  if(typeof qrcode==='function'&&card.url){
    const qr=qrcode(0,'M');
    qr.addData(card.url,'Byte');qr.make();qrSize=qr.getModuleCount();
    for(let row=0;row<qrSize;row++){
      for(let col=0;col<qrSize;){
        if(!qr.isDark(row,col)){col++;continue;}
        const start=col++;
        while(col<qrSize&&qr.isDark(row,col))col++;
        runs.push([start+4,row+4,col-start]);
      }
    }
  }
  const white='#ffffff',muted='#d6cdd4',copper='#f29a77';
  const labels=[
    {text:'KOD',x:43,y:107,size:77,weight:800,font:'brand',align:'left',dir:'ltr',color:white},
    {text:'بطاقة العضوية',x:811,y:96,size:39,weight:700,font:'arabic',align:'right',dir:'rtl',color:white},
    {text:'رقم العضوية',x:811,y:235,size:27,weight:600,font:'arabic',align:'right',dir:'rtl',color:muted},
    {text:number,x:813,y:298,size:40,weight:600,font:'digits',align:'right',dir:'ltr',color:white},
    {text:'اسم العضو',x:811,y:361,size:27,weight:600,font:'arabic',align:'right',dir:'rtl',color:muted},
    {text:visibleName,x:811,y:424,size:nameSize,weight:700,font:'arabic',align:'right',dir:/^[^A-Za-z]*[\u0590-\u08ff]/.test(visibleName)?'rtl':'ltr',color:white},
    {text:qrSize?'للمسح عند الكاشير':'استخدم رقم العضوية',x:171,y:483,size:26,weight:600,font:'arabic',align:'center',dir:'rtl',color:muted}
  ];
  if(card.demo)labels.push({text:'نموذج',x:490,y:92,size:27,weight:700,font:'arabic',align:'center',dir:'rtl',color:copper});
  const codeWidth=qrSize>33?memberArtTile.codeWidth:memberArtTile.width;
  return {number,name,bands,qrSize,codeWidth,runs,labels};
}

function memberArtHtml(card){
  const measure=typeof document==='undefined'?null:document.createElement('canvas').getContext?.('2d');
  const scene=memberArtScene(card,measure),tile=memberArtTile,prefix='kod-member-art-'+(++memberArtInstance);
  const box=scene.qrSize+8,pad=(tile.width-scene.codeWidth)/2;
  const qr=scene.qrSize?'<rect x="'+tile.x+'" y="'+tile.y+'" width="'+tile.width+'" height="'+tile.width+'" rx="15" fill="#fff"/><svg x="'+(tile.x+pad)+'" y="'+(tile.y+pad)+'" width="'+scene.codeWidth+'" height="'+scene.codeWidth+'" viewBox="0 0 '+box+' '+box+'"><path fill="#151923" shape-rendering="crispEdges" d="'+scene.runs.map(([x,y,w])=>'M'+x+' '+y+'h'+w+'v1h-'+w+'z').join('')+'"/></svg>':'';
  const text=scene.labels.map(label=>{
    const anchor=label.align==='center'?'middle':(label.align==='left')===(label.dir==='ltr')?'start':'end';
    return '<text x="'+label.x+'" y="'+label.y+'" direction="'+label.dir+'" text-anchor="'+anchor+'" font-family="'+esc(memberArtFonts[label.font])+'" font-weight="'+label.weight+'" font-size="'+label.size+'" fill="'+label.color+'">'+esc(label.text)+'</text>';
  }).join('');
  const description=(card.demo?'نموذج بطاقة عضوية كود':'بطاقة عضوية كود')+'، '+scene.name+'، رقم '+scene.number;
  return '<svg class="kod-member-art" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 856 540" width="856" height="540" style="display:block;width:100%;height:auto;max-width:600px" role="img" aria-label="'+esc(description)+'" direction="ltr">'+
    '<defs><linearGradient id="'+prefix+'-ink" x1="0" x2="1" y1="0" y2="0.85" gradientUnits="objectBoundingBox"><stop stop-color="#51383f"/><stop offset=".48" stop-color="#292631"/><stop offset="1" stop-color="#161b29"/></linearGradient><clipPath id="'+prefix+'-clip"><path d="'+memberArtBorder+'"/></clipPath></defs>'+
    '<g clip-path="url(#'+prefix+'-clip)"><path d="'+memberArtBorder+'" fill="url(#'+prefix+'-ink)"/>'+
    scene.bands.map((p,i)=>'<path d="'+p+'" fill="none" stroke="#d99279" stroke-width="'+(i===8?2.2:1.2)+'" opacity="'+(i===8?.38:.21)+'"/>').join('')+
    '<path d="M45 147 H811" stroke="#ffffff" stroke-opacity=".22"/><path d="'+memberArtBorder+'" fill="none" stroke="#aa8386" stroke-opacity=".48" stroke-width="2"/>'+
    '<circle cx="229" cy="100" r="7" fill="#f29a77"/>'+
    (card.demo?'<rect x="438" y="52" width="104" height="58" rx="28" fill="#392d35" stroke="#cd8b75" stroke-opacity=".7" stroke-width="1.6"/>':'')+
    qr+text+'</g></svg>';
}

async function memberArtPng(card){
  if(document.fonts?.load){
    const sample='بطاقة العضوية '+(card.name||'كود');
    await Promise.all([600,700].map(weight=>document.fonts.load(weight+' 40px Cairo',sample))).catch(()=>{});
  }
  const canvas=document.createElement('canvas'),scale=2;
  canvas.width=memberArtSize.width*scale;canvas.height=memberArtSize.height*scale;
  const ctx=canvas.getContext('2d');
  if(!ctx)throw Error('member_card_image_unavailable');
  const scene=memberArtScene(card,ctx);
  if(!scene.qrSize)throw Error('member_card_qr_unavailable');
  ctx.scale(scale,scale);
  const border=new Path2D(memberArtBorder);
  ctx.save();ctx.clip(border);
  const gradient=ctx.createLinearGradient(0,0,856,459);
  gradient.addColorStop(0,'#51383f');gradient.addColorStop(.48,'#292631');gradient.addColorStop(1,'#161b29');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,856,540);
  scene.bands.forEach((d,i)=>{
    ctx.strokeStyle=i===8?'rgba(217,146,121,.38)':'rgba(217,146,121,.21)';
    ctx.lineWidth=i===8?2.2:1.2;ctx.stroke(new Path2D(d));
  });
  ctx.lineWidth=1;ctx.strokeStyle='rgba(255,255,255,.22)';ctx.stroke(new Path2D('M45 147 H811'));
  ctx.lineWidth=2;ctx.strokeStyle='rgba(170,131,134,.48)';ctx.stroke(border);
  ctx.beginPath();ctx.arc(229,100,7,0,2*Math.PI);ctx.fillStyle='#f29a77';ctx.fill();
  if(card.demo){
    const badge=new Path2D('M467 52 H513 A29 29 0 0 1 513 110 H467 A29 29 0 0 1 467 52Z');
    ctx.fillStyle='#392d35';ctx.fill(badge);ctx.strokeStyle='rgba(205,139,117,.7)';ctx.lineWidth=1.6;ctx.stroke(badge);
  }
  const tile=memberArtTile;
  ctx.fillStyle='#fff';ctx.fill(new Path2D('M60 185 H282 Q297 185 297 200 V422 Q297 437 282 437 H60 Q45 437 45 422 V200 Q45 185 60 185Z'));
  // Use integer output pixels and a quiet zone of at least four modules on every side.
  const box=scene.qrSize+8,pixel=Math.floor(scene.codeWidth*scale/box),margin=Math.floor((tile.width*scale-box*pixel)/2);
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#151923';
  for(const [x,y,width] of scene.runs)ctx.fillRect(tile.x*scale+margin+x*pixel,tile.y*scale+margin+y*pixel,width*pixel,pixel);
  ctx.restore();
  for(const label of scene.labels){
    ctx.fillStyle=label.color;ctx.font=label.weight+' '+label.size+'px '+memberArtFonts[label.font];
    ctx.direction=label.dir;ctx.textAlign=label.align;ctx.textBaseline='alphabetic';ctx.fillText(label.text,label.x,label.y);
  }
  ctx.restore();
  return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('member_card_image_unavailable')),'image/png'));
}

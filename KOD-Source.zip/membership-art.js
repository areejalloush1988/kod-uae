// The wallet preview, printable faces and saved image share the same 85.6:54 artwork.
const memberArtSize={width:856,height:540};
const memberArtBorder='M 34 0 H 822 Q 856 0 856 34 V 506 Q 856 540 822 540 H 34 Q 0 540 0 506 V 34 Q 0 0 34 0 Z';
const memberArtTile={x:51,y:172,width:285};
const memberArtFonts={
  arabic:'Cairo, Tahoma, Arial, sans-serif',
  brand:'Arial, "Liberation Sans", Helvetica, sans-serif',
  digits:'Consolas, "Liberation Mono", "Courier New", monospace'
};
let memberArtInstance=0;

function memberArtHolder(card,measure){
  const name=cardPrintedName(card.name);
  let text=name,size=48;
  if(measure){
    const maxWidth=470;
    measure.font='700 '+size+'px '+memberArtFonts.arabic;
    if(measure.measureText(text).width>maxWidth){
      size=38;
      measure.font='700 '+size+'px '+memberArtFonts.arabic;
      if(measure.measureText(text).width>maxWidth){
        const chars=Array.from(text);
        while(chars.length&&measure.measureText(chars.join('')+'…').width>maxWidth)chars.pop();
        text=chars.join('').trimEnd()+'…';
      }
    }
  }
  return {name,text,size,dir:/^[^A-Za-z]*[\u0590-\u08ff]/.test(text)?'rtl':'ltr'};
}

function memberArtQr(url){
  if(!url||typeof qrcode!=='function')return null;
  const qr=qrcode(0,'M');
  qr.addData(url,'Byte');
  qr.make();
  const size=qr.getModuleCount(),runs=[];
  // The four blank modules on every edge are part of the encoded artwork.
  for(let y=0;y<size;y++){
    for(let x=0;x<size;){
      if(!qr.isDark(y,x)){x++;continue;}
      const start=x++;
      while(x<size&&qr.isDark(y,x))x++;
      runs.push([start+4,y+4,x-start]);
    }
  }
  return {modules:size+8,runs};
}

// Decorative line engraving on the right shoulder of the card, clear of the printed fields.
function memberArtEngraving(path, ink, glint) {
  for (let thread = 0; thread < 17; thread++) {
    const ridge = thread * 2;
    const d = 'M ' + (493 + ridge) + ' ' + (224 + ridge) +
      ' C ' + (560 + ridge) + ' ' + (222 + ridge) + ' ' + (604 + ridge) + ' ' + (128 - thread) + ' 687 ' + (126 + thread) +
      ' S 798 ' + (266 + thread) + ' 907 ' + (187 + ridge);
    path(d, 'none', thread % 4 === 0 ? glint : ink, thread % 4 === 0 ? 1.7 : 1.05, thread % 4 === 0 ? .55 : .23);
  }
  for (let thread = 0; thread < 9; thread++) {
    const lift = thread * 3;
    const d = 'M ' + (646 + lift) + ' ' + (207 + lift) + ' C 713 ' + (265 + lift) +
      ' 776 ' + (126 - thread) + ' 902 ' + (134 + lift);
    path(d, 'none', ink, 1, .19);
  }
}

// An illustrated foil chip. All contacts share a single cut outline and a restrained inset bevel.
function memberArtChip(path, ink, glint, chipFill = '@chip') {
  const edge = 'M64 151H137Q149 151 149 163V211Q149 223 137 223H64Q52 223 52 211V163Q52 151 64 151Z';
  path(edge, chipFill, ink, 1.8, 1);
  path('M66 154H136Q146 154 146 164V210Q146 220 136 220H66Q55 220 55 210V164Q55 154 66 154Z', 'none', glint, 1.3, .83);
  const cut = 'M90 170H111L120 179V196L111 205H90L81 196V179Z ' +
    'M78 153V159L90 170 M122 153V159L111 170 M78 221V216L90 205 M122 221V216L111 205 ' +
    'M53 175H69L81 182 M53 199H69L81 192 M148 175H132L120 182 M148 199H132L120 192';
  path(cut, 'none', ink, 2, .73);
  path('M91 172H110L117 179 M84 195L91 202H108', 'none', glint, 1.3, .78);
}

function memberArtScene(card,side,measure){
  if(side!=='front'&&side!=='back')throw Error('invalid_member_card_side');
  const digits=String(card.number||'').replace(/[\s-]/g,'');
  if(!/^\d{16}$/.test(digits))throw Error('invalid_member_card_number');
  const groups=digits.match(/.{4}/g),number=groups.join(' '),front=side==='front';
  const qr=front?null:memberArtQr(card.url),holder=memberArtHolder(card,measure);
  const {tier,until}=cardEntitlement(card);
  const key=card.demo&&['bronze','silver','gold'].includes(card.tier)?card.tier:tier||'inactive';
  const metal=cardMetals[key],ink=metal.ink,sub=metal.sub,glint=metal.glint;
  const gradients={
    metal:{line:[15,510,820,5],stops:metal.face.map((tone,i)=>[[0,.28,.49,.72,1][i],tone])},
    chip:{line:[52,222,148,151],stops:[[0,'#9c7b45'],[.24,'#d2b983'],[.51,'#f6e8bc'],[.71,'#c7ac71'],[1,'#ddc89c']]}
  };
  const paths=[],labels=[];
  function path(d,fill='none',stroke='none',width=1,opacity=1){paths.push({d,fill,stroke,width,opacity});}
  function label(text,x,y,size,weight,font,align,dir,color){labels.push({text,x,y,size,weight,font,align,dir,color});}
  function ar(text,x,y,size,weight,color,align='right'){label(text,x,y,size,weight,'arabic',align,'rtl',color);}

  path('M0 0H856V540H0Z','@metal');
  // Subtle grain and a fine metal rim extend to every edge, including print bleed.
  const grain=[];
  for(let y=4;y<540;y+=7)grain.push('M0 '+y+'H856');
  path(grain.join(' '),'none',glint,.8,.13);
  path('M33 3H823Q853 3 853 33V507Q853 537 823 537H33Q3 537 3 507V33Q3 3 33 3Z','none',ink,1.7,.35);
  path('M36 7H820Q849 7 849 36V504','none',glint,1.4,.68);
  if(front)memberArtEngraving(path,ink,glint);
  // KOD's own wordmark.
  path('M50 45H62V68L83 45H98L74 71L100 100H84L62 75V100H50Z',ink);
  path('M127 44C143 44 154 56 154 72.5S143 101 127 101S100 89 100 72.5S111 44 127 44Z M127 55C118 55 112 62 112 72.5S118 90 127 90S142 83 142 72.5S136 55 127 55Z',ink);
  path('M164 45H185C203 45 214 55.5 214 72.5S203 100 185 100H164Z M176 56V89H184.5C196 89 202 83.5 202 72.5S196 56 184.5 56Z',ink);
  path('M226 88H238V100H226Z',ink);
  if(card.demo){
    path('M275 55H341Q353 55 353 67V83Q353 95 341 95H275Q263 95 263 83V67Q263 55 275 55Z','none',sub,1.4,.7);
    ar('نموذج',308,83,22,700,sub,'center');
  }
  ar(metal.mark,803,102,key==='inactive'?43:60,800,ink);
  const validity=cardEndDate(until);
  if(front){
    memberArtChip(path,'#59442a','#fff1cd');
    ar('رقم العضوية',52,281,28,650,sub,'left');
    const positions=[50,252,453,654];
    groups.forEach((group,i)=>{
      const x=positions[i];
      label(group,x+1.5,351,61,600,'digits','left','ltr',glint);
      label(group,x,349,61,600,'digits','left','ltr',ink);
    });
    path('M51 383H805','none',ink,1.4,.30);
    ar('حامل البطاقة',804,427,28,650,sub);
    label(holder.text,804,489,holder.size,700,'arabic','right',holder.dir,ink);
    if(tier||card.demo){
      ar('صالحة حتى',52,427,28,650,sub,'left');
      label(validity||'—',52,487,validity?38:44,600,'digits','left','ltr',ink);
    }else{
      ar('حالة العضوية',52,427,28,650,sub,'left');
      ar(card.status==='cancelled'?'موقوفة':card.status==='active'?'منتهية':card.requested_at?'قيد التفعيل':'غير مفعّلة',52,487,37,700,ink,'left');
    }
  }else{
    path('M51 132H805','none',ink,1.4,.32);
    ar('عند الكاشير',805,205,42,750,ink);
    ar(qr?'أبرز الرمز قبل الدفع':'أبرز رقم العضوية قبل الدفع',805,262,28,600,sub);
    path('M389 314H805','none',ink,1.2,.32);
    ar('رقم العضوية للإدخال اليدوي',805,365,26,650,sub);
    label(number,805,420,35,700,'digits','right','ltr',ink);
    if(qr){
      const {x,y,width}=memberArtTile;
      path('M'+x+' '+y+'h'+width+'v'+width+'h-'+width+'Z','#fff');
    }
  }
  return {side,paths,labels,qr,gradients,key,mark:metal.mark,number,name:holder.name,validity};
}

function memberArtHtml(card,side='front'){
  const measure=typeof document==='undefined'?null:document.createElement('canvas').getContext?.('2d');
  const scene=memberArtScene(card,side,measure),prefix='kod-member-art-'+(++memberArtInstance);
  const paint=color=>color.startsWith('@')?'url(#'+prefix+'-'+color.slice(1)+')':color;
  const gradients=Object.entries(scene.gradients).map(([key,gradient])=>{
    const [x1,y1,x2,y2]=gradient.line;
    return '<linearGradient id="'+prefix+'-'+key+'" gradientUnits="userSpaceOnUse" x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'">'+
      gradient.stops.map(([offset,color])=>'<stop offset="'+offset+'" stop-color="'+color+'"/>').join('')+'</linearGradient>';
  }).join('');
  const paths=scene.paths.map(p=>'<path d="'+p.d+'" fill="'+paint(p.fill)+'" fill-rule="evenodd" stroke="'+paint(p.stroke)+'" stroke-width="'+p.width+'" stroke-linecap="round" stroke-linejoin="round" opacity="'+p.opacity+'"/>').join('');
  let qr='';
  if(scene.qr){
    const {x,y,width}=memberArtTile,{modules,runs}=scene.qr;
    const d=runs.map(([col,row,len])=>'M'+col+' '+row+'h'+len+'v1h-'+len+'z').join('');
    qr='<svg x="'+x+'" y="'+y+'" width="'+width+'" height="'+width+'" viewBox="0 0 '+modules+' '+modules+'"><path fill="#101923" shape-rendering="crispEdges" d="'+d+'"/></svg>';
  }
  const labels=scene.labels.map(item=>{
    const anchor=item.align==='center'?'middle':(item.align==='left')===(item.dir==='ltr')?'start':'end';
    return '<text x="'+item.x+'" y="'+item.y+'" direction="'+item.dir+'" text-anchor="'+anchor+'" font-family="'+esc(memberArtFonts[item.font])+'" font-weight="'+item.weight+'" font-size="'+item.size+'" fill="'+paint(item.color)+'">'+esc(item.text)+'</text>';
  }).join('');
  const description=(card.demo?'نموذج بطاقة عضوية كود':'بطاقة عضوية كود')+'، '+scene.mark+'، '+scene.name+'، رقم '+scene.number+(scene.validity?'، صالحة حتى '+scene.validity:'')+(side==='back'?'، ظهر البطاقة':'، وجه البطاقة');
  return '<svg class="kod-member-art" data-card-metal="'+scene.key+'" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 856 540" width="856" height="540" style="display:block;width:100%;height:auto;max-width:600px" role="img" aria-label="'+esc(description)+'" direction="ltr">'+
    '<defs>'+gradients+'<clipPath id="'+prefix+'-clip"><path d="'+memberArtBorder+'"/></clipPath></defs><g clip-path="url(#'+prefix+'-clip)">'+paths+qr+labels+'</g></svg>';
}

async function memberArtCanvas(card,side='front',scale=2,printBleed=false){
  if(!Number.isFinite(scale)||scale<=0)throw Error('invalid_member_card_scale');
  if(document.fonts?.load){
    const sample='برونزي فضي ذهبي بطاقة عضوية حامل البطاقة رقم العضوية صالحة حتى عند الكاشير '+(card.name||'كود');
    await Promise.all([600,650,700,750,800].map(weight=>document.fonts.load(weight+' 40px Cairo',sample))).catch(()=>{});
  }
  const canvas=document.createElement('canvas');
  canvas.width=Math.round(memberArtSize.width*scale);
  canvas.height=Math.round(memberArtSize.height*scale);
  const ctx=canvas.getContext('2d');
  if(!ctx)throw Error('member_card_image_unavailable');
  const scene=memberArtScene(card,side,ctx);
  if(side==='back'&&!scene.qr)throw Error('member_card_qr_unavailable');
  const sx=canvas.width/memberArtSize.width,sy=canvas.height/memberArtSize.height;
  ctx.scale(sx,sy);
  ctx.save();
  if(!printBleed)ctx.clip(new Path2D(memberArtBorder));
  const gradients={};
  for(const [key,definition] of Object.entries(scene.gradients)){
    const gradient=ctx.createLinearGradient(...definition.line);
    for(const [offset,color] of definition.stops)gradient.addColorStop(offset,color);
    gradients['@'+key]=gradient;
  }
  ctx.lineJoin='round';
  ctx.lineCap='round';
  for(const item of scene.paths){
    const shape=new Path2D(item.d);
    ctx.globalAlpha=item.opacity;
    if(item.fill!=='none'){
      ctx.fillStyle=gradients[item.fill]||item.fill;
      ctx.fill(shape,'evenodd');
    }
    if(item.stroke!=='none'){
      ctx.strokeStyle=gradients[item.stroke]||item.stroke;
      ctx.lineWidth=item.width;
      ctx.stroke(shape);
    }
  }
  ctx.globalAlpha=1;
  if(scene.qr){
    const {x,y,width}=memberArtTile,{modules,runs}=scene.qr;
    // Integer device pixels keep the QR crisp in downloads and the print renderer.
    const pixel=Math.floor(width*Math.min(sx,sy)/modules);
    if(!pixel)throw Error('member_card_qr_too_small');
    const left=Math.round(x*sx+(width*sx-modules*pixel)/2);
    const top=Math.round(y*sy+(width*sy-modules*pixel)/2);
    ctx.save();
    ctx.setTransform(1,0,0,1,0,0);
    ctx.fillStyle='#101923';
    for(const [col,row,len] of runs)ctx.fillRect(left+col*pixel,top+row*pixel,len*pixel,pixel);
    ctx.restore();
  }
  for(const item of scene.labels){
    ctx.font=item.weight+' '+item.size+'px '+memberArtFonts[item.font];
    ctx.direction=item.dir;
    ctx.textAlign=item.align;
    ctx.textBaseline='alphabetic';
    ctx.fillStyle=gradients[item.color]||item.color;
    ctx.fillText(item.text,item.x,item.y);
  }
  ctx.restore();
  return canvas;
}

async function memberArtPng(card){
  const [front,back]=await Promise.all([memberArtCanvas(card,'front'),memberArtCanvas(card,'back')]);
  const canvas=document.createElement('canvas'),gutter=32;
  canvas.width=front.width;
  canvas.height=front.height+gutter+back.height;
  const ctx=canvas.getContext('2d');
  if(!ctx)throw Error('member_card_image_unavailable');
  ctx.fillStyle='#ffffff';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.drawImage(front,0,0);
  ctx.drawImage(back,0,front.height+gutter);
  return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('member_card_image_unavailable')),'image/png'));
}

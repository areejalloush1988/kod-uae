const CARD_RECEIPT_FIELDS='id,customer_id,restaurant_id,restaurant_name,business_day,invoice_ref,bill_cents,percent,discount_cents,net_cents,created_at';
const CARD_DEMO={number:'0000000000000000',name:'عضو كود',demo:true,url:KOD_CONFIG.publicAppUrl+'#membership'};
let scannedCard='',cashierDraft=null,cashierQuote=null,cashierReceipt=null;
function cardRoute(){
  const hash=location.hash.slice(1),scan=/^cashier\/(\d{16})$/.exec(hash);
  if(scan){if(scannedCard!==scan[1])clearCashier();scannedCard=scan[1];return 'cashier';}
  return APP_ROUTES.has(hash)?hash:'discover';
}
function clearCashier(){scannedCard='';cashierDraft=null;cashierQuote=null;cashierReceipt=null;}
function rememberCardRoute(route){
  try{sessionStorage.setItem('kod-card-return',JSON.stringify({route,serial:route==='cashier'?scannedCard:'',until:Date.now()+10*60*1000}));}catch{}
}
function resumeCardRoute(){
  try{
    const v=JSON.parse(sessionStorage.getItem('kod-card-return'));sessionStorage.removeItem('kod-card-return');
    if(!v||v.until<Date.now()||!['membership','cashier'].includes(v.route))return '';
    if(v.route==='cashier'&&/^\d{16}$/.test(v.serial))scannedCard=v.serial;
    return v.route;
  }catch{return '';}
}
function connectedCard(){
  const card=liveWorkspace.card;
  if(previewRole||appIdentity?.role!=='customer'||!card||!/^\d{16}$/.test(card.number))return null;
  return {...card,demo:false,url:KOD_CONFIG.publicAppUrl+'#cashier/'+card.number};
}
function cardIsActive(c){return c?.status==='active'&&Date.parse(c.expires_at)>Date.now();}
function cardLastDay(iso){return new Date(Date.parse(iso)-1).toLocaleDateString(UI_LOCALE,{timeZone:'Asia/Dubai',day:'numeric',month:'short',year:'numeric'});}
function cardPartners(){return liveWorkspace.restaurants.filter(r=>r.approved&&!r.is_demo&&r.instore_percent>0);}
function cardPartnersView(){
  const places=cardPartners();
  return '<section class="box member-partners"><h2>أين أستخدم البطاقة؟</h2>'+(places.length?'<ul>'+places.map(r=>'<li><span><strong>'+displayText(r.name)+'</strong><small>'+displayText([r.branch_address,r.city].filter(Boolean).join('، '))+'</small></span><bdi>'+number(r.instore_percent)+'%</bdi></li>').join('')+'</ul>':'<p>'+ (orderDataStatus==='loading'?'يجري تحميل الفروع المشاركة…':orderDataStatus==='error'?'تعذّر تحميل الفروع. حدّث الصفحة للمحاولة مجدداً.':'تظهر هنا المطاعم والمقاهي عند تفعيل خصم البطاقة في فروعها.')+'</p>')+'</section>';
}
function memberReceipts(rows,title){
  if(!rows?.length)return '';
  return '<section class="box member-history"><h2>'+title+'</h2><ul>'+rows.slice(0,10).map(r=>'<li><div><strong>'+displayText(r.restaurant_name)+'</strong><small>'+displayText(r.invoice_ref)+' · '+new Date(r.created_at).toLocaleDateString(UI_LOCALE,{timeZone:'Asia/Dubai'})+'</small></div><span>وفّرت '+money(r.discount_cents)+'</span></li>').join('')+'</ul></section>';
}
function memberInstructions(){return '<section class="box card-steps"><h2>عند الكاشير</h2><ol><li>أبرز بطاقتك قبل الدفع في فرع مشارك.</li><li>يمسح الكاشير رمز QR أو يُدخل رقم البطاقة.</li><li>يظهر الخصم والمبلغ المطلوب على الفاتورة.</li></ol></section>';}
function memberPage(){
  if(previewRole)return membership();
  const guest=!appIdentity,card=connectedCard(),status=cardIsActive(card)?'مفعّلة':card?.requested_at?'طلب التفعيل قيد المراجعة':card?.status==='active'?'منتهية':card?.status==='cancelled'?'موقوفة':'غير مفعّلة';
  const heading='<header class="order-page-head"><div><h1>بطاقة عضوية كود</h1><p>خصمك عند الكاشير في المطاعم والمقاهي المشاركة.</p></div></header>';
  if(!guest&&appIdentity.role!=='customer')return heading+cardPartnersView()+'<button class="btn" data-go="cashier">فتح شاشة الكاشير</button>';
  let personal='';
  if(guest){
    personal=memberArtHtml(CARD_DEMO)+'<div class="member-actions"><button class="btn" data-card-login="membership">تسجيل الدخول لعرض بطاقتي</button><button class="text-button" data-card-download="demo">تنزيل نموذج البطاقة</button></div>';
  }else if(card){
    const active=cardIsActive(card);
    personal=memberArtHtml(card)+'<div class="card-status"><strong>'+status+'</strong>'+(active?'<span>صالحة حتى '+cardLastDay(card.expires_at)+'</span>':'')+'</div>'+
      '<div class="member-actions"><button class="btn" data-card-download="own">'+icon('wallet')+' حفظ البطاقة على الموبايل</button>'+
      (!active&&!card.requested_at?'<button class="text-button" data-request-membership>طلب تفعيل العضوية</button>':'')+'</div>'+
      '<details class="card-name"><summary>الاسم على البطاقة</summary><form id="card-name-form" class="field"><label for="member-name">اسم حامل البطاقة</label><input id="member-name" name="holder" autocomplete="name" maxlength="80" value="'+esc(liveWorkspace.profiles.find(p=>p.id===appIdentity.id)?.full_name||'')+'" required><button class="btn light">حفظ الاسم</button><span role="status"></span></form></details>';
  }else personal='<div class="box"><p role="status">تعذّر تحميل بطاقتك. تحقّق من الاتصال وحاول مجدداً.</p><button class="text-button" data-card-reload>أعد المحاولة</button></div>';
  const history=appIdentity?(liveWorkspace.cardReceipts||[]).filter(r=>r.customer_id===appIdentity.id):[];
  return heading+'<div class="member-layout"><div class="member-display">'+personal+'</div><div class="member-guidance">'+memberInstructions()+cardPartnersView()+'</div></div>'+(liveWorkspace.cardReceiptError&&appIdentity?'<p role="status">تعذّر تحميل سجل الفواتير.</p>':memberReceipts(history,'خصوماتي عند الكاشير'))+(guest?'<button class="text-button" data-go="membership-demo">تجربة عروض العضوية</button>':'');
}
function memberAdminForm(p,m){
  if(!isLiveOperator())return '';
  return '<form class="box card-admin-form" id="member-access-form" data-member="'+esc(p.id)+'"><h3>تفعيل بطاقة العضوية</h3>'+(m?.activation_requested_at?'<p>طلب العميل تفعيل بطاقته.</p>':'')+'<div class="field"><label for="card-until">آخر يوم للعضوية</label><input type="date" id="card-until" name="ends" required min="'+todayInUae()+'"></div><button class="btn" type="submit">'+(cardIsActive(m)?'تحديث الصلاحية':'تفعيل البطاقة')+'</button>'+(cardIsActive(m)?'<button type="button" class="text-button" data-card-stop="'+esc(p.id)+'">إيقاف العضوية</button>':'')+'<p role="status"></p></form>';
}
function ratePanel(r){
  if(!r?.approved||r.is_demo||previewRole)return '';
  return '<form class="box card-admin-form" data-card-rate data-branch="'+esc(r.id)+'"><h3>قبول بطاقات كود داخل الفرع</h3><div class="field"><label for="card-rate-'+esc(r.id)+'">خصم البطاقة (%) · '+displayText(r.name)+'</label><input dir="ltr" id="card-rate-'+esc(r.id)+'" type="number" min="0" max="70" step="1" name="rate" required value="'+Number(r.instore_percent||0)+'"></div><p>أدخل النسبة المتفق عليها لهذا الفرع. القيمة 0 توقف قبول البطاقة.</p><button class="btn">حفظ نسبة الفرع</button><p role="status"></p></form>';
}
function cashierBranches(){return (liveWorkspace.restaurants||[]).filter(r=>r.approved&&!r.is_demo&&(isLiveOperator()||r.owner_id===appIdentity?.id));}
function cashierConfigured(){return cashierBranches().filter(r=>r.instore_percent>0);}
function deskLink(){return !previewRole&&['merchant','developer'].includes(appIdentity?.role)?'<button class="btn light" data-go="cashier">'+icon('ticket')+' خصم عند الكاشير</button>':'';}
function summaryOfBill(v){return '<div class="card-bill"><h2>'+displayText(v.restaurant_name)+'</h2><p>الفاتورة <bdi>'+displayText(v.invoice_ref)+'</bdi></p><div><span>المبلغ المشمول بالخصم</span><strong>'+money(v.bill_cents)+'</strong></div><div><span>خصم البطاقة <bdi>'+number(v.percent)+'%</bdi></span><strong>− '+money(v.discount_cents)+'</strong></div><div><span>المطلوب بعد الخصم</span><strong>'+money(v.net_cents)+'</strong></div></div>';}
function cashierPage(){
  const head='<header class="order-page-head"><div><h1>خصم عند الكاشير</h1><p>التحقّق من بطاقة كود وتسجيل خصم الفاتورة.</p></div></header>';
  if(!appIdentity||previewRole)return head+'<section class="box"><p>ادخل بحساب الفرع لاستخدام البطاقة.</p><button class="btn" data-card-login="cashier">تسجيل دخول الفرع</button></section>';
  if(!['developer','merchant'].includes(appIdentity.role))return head+'<section class="box"><p>يمسح الكاشير الرمز من حساب المطعم. أبرز بطاقتك قبل الدفع.</p><button class="btn" data-go="membership">عرض بطاقتي</button></section>';
  if(cashierReceipt)return head+'<section class="box card-counter"><p class="card-confirmed">'+icon('check')+' تم تسجيل الخصم</p>'+summaryOfBill(cashierReceipt)+'<button class="btn" data-new-bill>فاتورة جديدة</button></section>';
  if(cashierQuote)return head+'<section class="box card-counter"><p class="card-confirmed">'+icon('check')+' البطاقة مفعّلة</p>'+summaryOfBill(cashierQuote)+'<div class="member-actions"><button class="btn" data-confirm-bill>تأكيد خصم الفاتورة</button><button class="text-button" data-change-bill>تعديل الفاتورة</button></div><p role="status" id="bill-status"></p></section>';
  const places=cashierConfigured();
  if(!places.length)return head+'<section class="box"><p>يتاح الخصم بعد اعتماد الفرع وتفعيل نسبة بطاقة كود في إعداداته.</p><button class="btn light" data-card-settings>إعدادات الفروع</button></section>';
  const d=cashierDraft||{},selected=places.some(r=>r.id===d.branch)?d.branch:places[0].id;
  return head+'<form class="box card-counter" id="card-bill-form"><div class="field"><label for="cash-branch">الفرع</label><select id="cash-branch" name="branch">'+places.map(r=>'<option value="'+esc(r.id)+'"'+(r.id===selected?' selected':'')+'>'+displayText(r.name)+' · '+number(r.instore_percent)+'%</option>').join('')+'</select></div><div class="field"><label for="cash-member">رقم بطاقة كود</label><input id="cash-member" dir="ltr" inputmode="numeric" name="card" maxlength="23" autocomplete="off" required value="'+esc(d.serial||scannedCard)+'"><small>امسح QR بكاميرا الهاتف لفتح البطاقة هنا، أو أدخل رقمها.</small></div><div class="field"><label for="cash-ticket">رقم فاتورة المطعم</label><input id="cash-ticket" name="invoice" maxlength="48" required value="'+esc(d.invoice||'')+'"></div><div class="field"><label for="cash-value">المبلغ المشمول بالخصم (د.إ)</label><input id="cash-value" name="bill" dir="ltr" inputmode="decimal" required placeholder="0.00" value="'+esc(d.amount||'')+'"></div><button class="btn full">تحقّق واحسب الخصم</button><p role="status"></p></form>'+memberReceipts((liveWorkspace.cardReceipts||[]).filter(r=>places.some(p=>p.id===r.restaurant_id)),'آخر خصومات الفرع');
}
function cardCents(text){const value=latinDigits(text).trim().replace('٫','.');if(!/^\d{1,6}(?:\.\d{1,2})?$/.test(value))return 0;const [units,fraction='']=value.split('.');return Number(units)*100+Number(fraction.padEnd(2,'0'));}
function cardError(error){
  const errors={operator_required:'هذا الإجراء متاح للمطوّر فقط.',member_required:'يلزم حساب عميل.',invalid_end_date:'اختر تاريخ صلاحية من اليوم فما بعد.',branch_required:'هذا الفرع غير متاح لهذا الحساب.',invalid_rate:'أدخل نسبة بين 0 و70.',invalid_invoice:'راجع رقم الفاتورة والمبلغ.',card_unavailable:'تعذّر قبول البطاقة. راجع الرقم وصلاحية العضوية.',branch_unavailable:'الفرع لا يقبل البطاقة حالياً.',invoice_already_used:'سُجّل خصم لهذه الفاتورة مسبقاً.',quote_changed:'تغيّرت نسبة الفرع. أعد حساب الفاتورة.',request_mismatch:'تغيّرت بيانات الفاتورة. أعد التحقق.'};
  return errors[error?.message]||'تعذّر الاتصال أو حفظ العملية. أعد المحاولة.';
}
async function cardRpc(name,args){const client=await getKodClient();const res=await client.rpc(name,args);if(res.error)throw res.error;return res.data;}
async function reloadCardScreen(epoch){await refreshLiveWorkspace();if(epoch===workspaceEpoch)render(current);}
function cardSavedDownload(blob,card){
  const link=document.createElement('a'),url=URL.createObjectURL(blob);link.href=url;link.download=card.demo?'KOD-Card-Sample.png':'KOD-Member-'+card.number.slice(-4)+'.png';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
document.addEventListener('submit',async e=>{
  const form=e.target,actions=['card-bill-form','card-rate-form','member-access-form','card-name-form'];
  const action=form.dataset.cardRate!==undefined?'card-rate-form':form.id;
  if(!actions.includes(action))return;
  e.preventDefault();if(!appIdentity||previewRole)return;
  const button=e.submitter||form.querySelector('button'),feedback=form.querySelector('[role=status]'),epoch=workspaceEpoch;
  if(button.disabled)return;button.disabled=true;feedback.textContent='';
  try{
    const f=form.elements;
    if(form.id==='card-bill-form'){
      const serial=latinDigits(f.card.value).replace(/[\s-]/g,''),amount=latinDigits(f.bill.value).trim(),bill=cardCents(amount),invoice=f.invoice.value.trim(),branch=f.branch.value;
      if(!/^\d{16}$/.test(serial))throw Error('card_unavailable');if(!bill||!invoice)throw Error('invalid_invoice');
      const draft={serial,branch,invoice,amount,args:{p_card_number:serial,p_restaurant_id:branch,p_invoice:invoice,p_bill_cents:bill},request:crypto.randomUUID()};
      const q=await cardRpc('kod_instore_bill',draft.args);
      if(epoch===workspaceEpoch&&current==='cashier'){cashierDraft=draft;cashierQuote=q;render('cashier');}
      return;
    }
    if(action==='card-rate-form')await cardRpc('kod_set_instore_rate',{p_restaurant_id:form.dataset.branch,p_percent:Number(f.rate.value)});
    if(form.id==='member-access-form')await cardRpc('kod_set_member_access',{p_member:form.dataset.member,p_active:true,p_ends_on:f.ends.value});
    if(form.id==='card-name-form'){
      const name=f.holder.value.trim();if(!name){feedback.textContent='أدخل اسم حامل البطاقة.';return;}
      const uid=appIdentity.id,client=await getKodClient();if(epoch!==workspaceEpoch)return;
      const result=await client.from('kod_profiles').update({full_name:name}).eq('id',uid).select('id').single();if(result.error)throw result.error;
    }
    if(epoch===workspaceEpoch){await reloadCardScreen(epoch);if(epoch===workspaceEpoch)toast('تم حفظ التغيير.');}
  }catch(err){if(epoch===workspaceEpoch)feedback.textContent=cardError(err);}finally{button.disabled=false;}
});
document.addEventListener('click',async e=>{
  const b=e.target.closest('button');if(!b)return;
  const d=b.dataset,epoch=workspaceEpoch;
  if(d.cardLogin){rememberCardRoute(d.cardLogin);navigate('auth');return;}
  if(b.hasAttribute('data-card-settings')){merchantTab='settings';navigate('merchant');return;}
  if(b.hasAttribute('data-change-bill')){cashierQuote=null;render('cashier');return;}
  if(b.hasAttribute('data-new-bill')){clearCashier();history.replaceState(null,'',location.pathname+location.search+'#cashier');render('cashier');return;}
  if(d.cardStop){showModal('<div class="modal-body"><h2 id="modal-title">إيقاف عضوية العميل؟</h2><p>سيصبح الخصم بهذه البطاقة غير متاح حتى تفعيلها مجدداً.</p><button class="btn" data-stop-member="'+esc(d.cardStop)+'">إيقاف العضوية</button><button class="text-button" data-action="close-modal">رجوع</button></div>');return;}
  if(!d.cardDownload&&!d.stopMember&&!b.hasAttribute('data-confirm-bill')&&!b.hasAttribute('data-request-membership')&&!b.hasAttribute('data-card-reload'))return;
  if(b.disabled)return;b.disabled=true;
  try{
    if(d.cardDownload){const card=d.cardDownload==='demo'?CARD_DEMO:connectedCard();if(!card)return;const blob=await memberArtPng(card);if(epoch===workspaceEpoch)cardSavedDownload(blob,card);return;}
    if(b.hasAttribute('data-card-reload')){await reloadCardScreen(epoch);return;}
    if(!appIdentity||previewRole)return;
    if(b.hasAttribute('data-confirm-bill')){
      if(!cashierQuote||!cashierDraft)return;
      const draft=cashierDraft,q=cashierQuote;
      const receipt=await cardRpc('kod_instore_bill',{...draft.args,p_request_id:draft.request,p_expected_percent:q.percent});
      if(epoch===workspaceEpoch){cashierReceipt=receipt;cashierDraft=null;cashierQuote=null;if(current==='cashier')render('cashier');refreshLiveWorkspace().catch(()=>{});}
      return;
    }
    if(d.stopMember){await cardRpc('kod_set_member_access',{p_member:d.stopMember,p_active:false,p_ends_on:null});if(epoch===workspaceEpoch)closeModal();}
    if(b.hasAttribute('data-request-membership'))await cardRpc('kod_member_card',{p_request:true});
    if(epoch===workspaceEpoch)await reloadCardScreen(epoch);
  }catch(error){
    if(epoch!==workspaceEpoch)return;
    const message=d.cardDownload?'تعذّر حفظ الصورة. جرّب فتح البطاقة في متصفّح الهاتف.':cardError(error);
    if(b.hasAttribute('data-confirm-bill')){
      if(['quote_changed','card_unavailable','invoice_already_used','branch_unavailable'].includes(error?.message)){cashierQuote=null;render('cashier');}
      const status=document.querySelector('#card-bill-form [role=status], #bill-status');if(status)status.textContent=message;
    }else toast(message);
  }finally{b.disabled=false;}
});

let ownerCustomerId='',ownerRestaurantId='';
function isLiveOperator(){return !previewRole&&appIdentity?.role==='developer';}
function ownerWorkspaceNav(active){
  if(!isLiveOperator())return '';
  return '<nav class="owner-areas" aria-label="لوحات التحكم">'+[
    ['developer','لوحة المطوّر','grid'],['dashboard','لوحة العملاء','user'],['merchant','لوحة المطاعم','store'],['membership','بطاقتي','card'],['subscriptions','باقات الاشتراك','ticket'],['marketing','التسويق والشراكات','store'],['featured','المطاعم المميّزة','food']
  ].map(([route,label,symbol])=>'<button class="owner-area" data-go="'+route+'"'+(active===route?' aria-current="page"':'')+'>'+icon(symbol)+' '+label+'</button>').join('')+'</nav>';
}
function customerFavoriteLabel(key){
  const place=getPlace(key);
  return place?.name||PUBLIC_DEALS.find(d=>'deal:'+d.id===key)?.title||OFFERS.find(o=>o.id===key)?.name||key;
}
function membershipLabel(member){
  if(member?.status==='active'&&Date.parse(member.expires_at)>Date.now())return 'مفعّلة حتى '+new Date(member.expires_at).toLocaleDateString(UI_LOCALE);
  if(member?.status==='cancelled')return 'ملغاة';
  return member?.status==='expired'||(member?.status==='active'&&member.expires_at)?'منتهية':'غير مفعّلة';
}
function ownerCustomersView(){
  if(!isLiveOperator())return accessView('customer');
  const {profiles,contacts,orders,memberships,favorites}=liveWorkspace;
  const customers=profiles.filter(p=>p.account_role==='customer');
  const contactById=new Map(contacts.map(c=>[c.user_id,c]));
  const name=p=>p.full_name||contactById.get(p.id)?.login_email||contactById.get(p.id)?.mobile||'حساب كود';
  const selected=customers.find(p=>p.id===ownerCustomerId);
  const selector='<div class="owner-selector field"><label for="owner-customer">العميل</label><select id="owner-customer"><option value="">كل العملاء</option>'+customers.map(p=>'<option value="'+esc(p.id)+'"'+(p.id===selected?.id?' selected':'')+'>'+displayText(name(p))+'</option>').join('')+'</select></div>';
  let body;
  if(selected){
    const contact=contactById.get(selected.id);
    const history=orders.filter(o=>o.customer_id===selected.id);
    const saved=favorites.filter(f=>f.user_id===selected.id);
    const member=memberships.find(m=>m.user_id===selected.id);
    body='<section class="box"><h2>'+displayText(name(selected))+'</h2>'+
      '<div class="settings-row"><span>البريد الإلكتروني</span><bdi>'+displayText(contact?.login_email||'—')+'</bdi></div>'+
      '<div class="settings-row"><span>رقم الموبايل</span><bdi>'+displayText(contact?.mobile||'—')+'</bdi></div>'+
      '<div class="settings-row"><span>العضوية</span><strong>'+membershipLabel(member)+'</strong></div>'+
      '<div class="settings-row"><span>توفير الطلبات المسلّمة</span><strong>'+money(history.filter(o=>o.status==='delivered').reduce((v,o)=>v+o.discount_cents,0))+'</strong></div></section>'+memberAdminForm(selected,member)+
      '<section class="box"><h2>المفضّلة</h2>'+(saved.length?'<ul>'+saved.map(f=>'<li>'+displayText(customerFavoriteLabel(f.offer_key))+'</li>').join('')+'</ul>':'<p>لا توجد أماكن أو عروض محفوظة.</p>')+'</section>'+
      '<section class="box"><h2>طلبات العميل</h2><div class="orders-list">'+(history.length?history.slice().reverse().map(o=>orderCard(o)).join(''):'<p>لا توجد طلبات لهذا العميل.</p>')+'</div></section>';
  }else{
    const orderCounts=new Map();
    for(const order of orders)orderCounts.set(order.customer_id,(orderCounts.get(order.customer_id)||0)+1);
    const membershipById=new Map(memberships.map(m=>[m.user_id,m]));
    body='<section class="box"><h2>حسابات العملاء <small>('+number(customers.length)+')</small></h2>'+(customers.length?'<div class="table-scroll"><table class="data-table"><thead><tr><th>العميل</th><th>البريد الإلكتروني</th><th>العضوية</th><th>الطلبات</th><th>التفاصيل</th></tr></thead><tbody>'+
      customers.map(p=>'<tr><td>'+displayText(p.full_name||'حساب كود')+'</td><td><bdi>'+displayText(contactById.get(p.id)?.login_email||'—')+'</bdi></td><td>'+(membershipById.get(p.id)?.activation_requested_at?'طلب تفعيل':membershipLabel(membershipById.get(p.id)))+'</td><td>'+number(orderCounts.get(p.id)||0)+'</td><td><button class="text-button" data-owner-customer="'+esc(p.id)+'">فتح الحساب</button></td></tr>').join('')+'</tbody></table></div>':'<p>ما في حسابات عملاء مسجّلة بعد.</p>')+'</section>';
  }
  return workspaceHeader('لوحة العملاء','الحسابات والعضويات وطلبات كل عميل.')+ownerWorkspaceNav('dashboard')+selector+'<div class="owner-sections">'+body+'</div>';
}
function ownerRestaurantsView(){
  if(!isLiveOperator())return accessView('merchant');
  const places=liveWorkspace.restaurants;
  const selected=places.find(r=>r.id===ownerRestaurantId);
  const visible=selected?[selected]:places;
  const ids=new Set(visible.map(r=>r.id));
  const names=new Map(visible.map(r=>[r.id,r.name]));
  const selector='<div class="owner-selector field"><label for="owner-restaurant">المطعم</label><select id="owner-restaurant"><option value="">كل المطاعم</option>'+places.map(r=>'<option value="'+esc(r.id)+'"'+(selected?.id===r.id?' selected':'')+'>'+displayText(r.name)+'</option>').join('')+'</select></div>';
  let body;
  if(merchantTab==='menu'){
    const menu=liveWorkspace.menus.filter(m=>ids.has(m.restaurant_id));
    body='<section class="box"><h2>أصناف المنيو</h2>'+(menu.length?'<div class="table-scroll"><table class="data-table"><thead><tr><th>المطعم</th><th>الصنف</th><th>السعر</th><th>التوفر</th></tr></thead><tbody>'+menu.map(m=>'<tr><td>'+displayText(names.get(m.restaurant_id))+'</td><td>'+displayText(m.name)+'</td><td>'+money(m.price_cents)+'</td><td><button class="availability '+(m.is_available?'available':'')+'" data-toggle-item="'+esc(m.id)+'">'+(m.is_available?'متاح':'غير متاح')+'</button></td></tr>').join('')+'</tbody></table></div>':'<p>لا توجد أصناف مسجّلة.</p>')+(visible.length?menuCreateForm(visible):'')+'</section>';
  }else if(merchantTab==='settings'){
    body='<section class="box"><h2>إعدادات المطاعم</h2>'+(visible.length?'<div class="table-scroll"><table class="data-table"><thead><tr><th>المطعم</th><th>الإمارة</th><th>رسوم التوصيل</th><th>الاعتماد</th><th>استقبال الطلبات</th></tr></thead><tbody>'+visible.map(r=>'<tr><td>'+displayText(r.name)+'</td><td>'+displayText(r.city)+'</td><td>'+money(r.delivery_fee_cents)+'</td><td><button class="text-button" data-review-restaurant="'+esc(r.id)+'">'+(r.approved?'إيقاف الاعتماد':'اعتماد المطعم')+'</button></td><td><button class="availability '+(r.is_open?'available':'')+'" data-toggle-restaurant="'+esc(r.id)+'"'+(!r.approved||r.is_demo?' disabled':'')+'>'+(r.is_open?'مفتوح':'متوقف')+'</button></td></tr>').join('')+'</tbody></table></div>':'<p>ما في مطاعم مسجّلة في نظام الطلبات بعد.</p>')+'</section>'+(selected?editContactPanel(selected)+ratePanel(selected):places.length===1?editContactPanel(places[0])+ratePanel(places[0]):'');
  }else{
    const history=liveWorkspace.orders.filter(o=>ids.has(o.restaurant_id));
    body='<section class="box"><h2>طلبات المطاعم <small>('+number(history.length)+')</small></h2><div class="orders-list">'+(history.length?history.slice().reverse().map(o=>orderCard(o,true)).join(''):'<p>لا توجد طلبات مسجّلة.</p>')+'</div></section>';
  }
  return workspaceHeader('لوحة المطاعم','الطلبات والمنيو وإعدادات كل مطعم.')+ownerWorkspaceNav('merchant')+deskLink()+selector+
    workspaceTabs('merchant',[['orders','الطلبات','bag'],['menu','المنيو','food'],['settings','إعدادات المطاعم','store']],merchantTab)+body;
}
document.addEventListener('change',event=>{
  if(!isLiveOperator())return;
  if(event.target.id==='owner-customer'){ownerCustomerId=event.target.value;render('dashboard');}
  if(event.target.id==='owner-restaurant'){ownerRestaurantId=event.target.value;render('merchant');}
});
document.addEventListener('click',event=>{
  const button=event.target.closest('[data-owner-customer]');
  if(button&&isLiveOperator()){ownerCustomerId=button.dataset.ownerCustomer;navigate('dashboard');}
});

// The share artwork only receives public offer text and two amounts in fils.
const kodSavingsArtwork = (() => {
  const width = 1080;
  const height = 1350;
  const navy = '#182b3a';
  const clay = '#a94633';
  const muted = '#50616d';
  const white = '#ffffff';
  const cairo = 'Cairo, Tahoma, Arial, sans-serif';
  const integers = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
  const unsupported = 'حفظ الفيديو غير متاح في هذا المتصفح. يمكنك تنزيل الصورة.';
  const videoTypes = [
    'video/mp4;codecs=avc1.42E028', 'video/mp4',
    'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'
  ];

  function amount(fils) {
    const whole = integers.format(Math.floor(fils / 100));
    const fraction = fils % 100;
    return fraction ? whole + '.' + String(fraction).padStart(2, '0') : whole;
  }

  function publicLabel(value) {
    const label = String(value ?? '').slice(0, 600)
      .replace(/[\u0000-\u001f\u007f\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, ' ')
      .replace(/[٠-٩۰-۹]/g, digit => String(digit.charCodeAt(0) % 16))
      .replace(/\s+/g, ' ').trim();
    if (/@|https?:\/\/|www\.|(?:\d[+ ().-]*){7}/i.test(label)) return '';
    return label;
  }

  function canvas(frameHeight = height) {
    const element = document.createElement('canvas');
    element.width = width;
    element.height = frameHeight;
    return element;
  }

  function setType(ctx, size, weight, dir = 'rtl', align = 'right') {
    ctx.font = weight + ' ' + size + 'px ' + cairo;
    ctx.direction = dir;
    ctx.textAlign = align;
    ctx.textBaseline = 'alphabetic';
  }

  function write(ctx, value, x, y, size, color, weight = 700, dir = 'rtl', maxWidth) {
    setType(ctx, size, weight, dir);
    if (maxWidth) {
      const occupied = ctx.measureText(value).width;
      if (occupied > maxWidth) setType(ctx, Math.floor(size * maxWidth / occupied), weight, dir);
    }
    ctx.fillStyle = color;
    ctx.fillText(value, x, y);
  }

  function drawLabel(ctx, value) {
    if (!value) return;
    setType(ctx, 37, 600);
    ctx.fillStyle = muted;
    const limit = 918;
    if (ctx.measureText(value).width <= limit) {
      ctx.fillText(value, 996, 423);
      return;
    }
    const characters = typeof Intl.Segmenter === 'function'
      ? Array.from(new Intl.Segmenter('ar', { granularity: 'grapheme' }).segment(value), s => s.segment)
      : Array.from(value);
    let first = 0;
    let space = 0;
    while (first < characters.length && ctx.measureText(characters.slice(0, first + 1).join('')).width <= limit) {
      if (characters[first] === ' ') space = first;
      first++;
    }
    const split = space || first;
    ctx.fillText(characters.slice(0, split).join('').trimEnd(), 996, 408);
    const rest = characters.slice(split);
    while (rest.length && rest[0] === ' ') rest.shift();
    let last = rest.length;
    if (ctx.measureText(rest.join('')).width > limit) {
      while (last && ctx.measureText(rest.slice(0, last).join('') + '…').width > limit) last--;
    }
    ctx.fillText(rest.slice(0, last).join('').trimEnd() + (last < rest.length ? '…' : ''), 996, 464);
  }

  function rounded(ctx, x, y, w, h, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
  }

  function rule(ctx, x1, y1, x2, y2, color, weight = 2) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineWidth = weight;
    ctx.strokeStyle = color;
    ctx.stroke();
  }

  function receipt(ctx) {
    ctx.save();
    ctx.translate(162, 627);
    ctx.rotate(-0.09);
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#91a6af';
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(127, 0);
    ctx.lineTo(127, 181);
    for (let i = 7; i >= 0; i--) ctx.lineTo(i * 127 / 8, i % 2 ? 168 : 181);
    ctx.closePath();
    ctx.stroke();
    rule(ctx, 24, 39, 101, 39, '#91a6af', 4);
    rule(ctx, 24, 64, 81, 64, '#91a6af', 4);
    rule(ctx, 24, 100, 101, 100, '#506b79', 3);
    rule(ctx, 65, 126, 101, 126, '#e4a688', 6);
    ctx.restore();
  }

  function draw(data, beforeOnly = false) {
    const element = canvas();
    const ctx = element.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('تعذّر إنشاء صورة المشاركة.');
    ctx.fillStyle = white;
    ctx.fillRect(0, 0, width, height);

    ctx.font = 'bold 72px Georgia, "Times New Roman", serif';
    ctx.textBaseline = 'alphabetic';
    ctx.direction = 'ltr';
    ctx.textAlign = 'left';
    ctx.fillStyle = navy;
    ctx.fillText('KOD', 78, 143);
    const markEnd = 78 + ctx.measureText('KOD').width + 7;
    ctx.fillStyle = clay;
    ctx.fillRect(markEnd, 133, 10, 10);
    if (data.example) {
      setType(ctx, 30, 700);
      const badgeWidth = Math.ceil(ctx.measureText('مثال توضيحي').width) + 49;
      rounded(ctx, 1000 - badgeWidth, 89, badgeWidth, 64, 32);
      ctx.strokeStyle = clay;
      ctx.lineWidth = 2;
      ctx.stroke();
      write(ctx, 'مثال توضيحي', 975, 132, 30, clay);
    }
    rule(ctx, 80, 200, 1000, 200, '#d7dee1');
    write(ctx, 'قبل وبعد الخصم', 998, 338, 88, navy, 800);
    drawLabel(ctx, data.label);

    rounded(ctx, 76, 513, 928, 403, 32);
    ctx.fillStyle = navy;
    ctx.fill();
    receipt(ctx);
    write(ctx, beforeOnly ? 'السعر قبل الخصم' : 'قيمة التوفير', 943, 622, 43, white);
    write(ctx, beforeOnly ? data.before : data.saved, 946, 797, 145, white, 800, 'ltr', 590);
    write(ctx, 'درهم إماراتي', 943, 858, 33, '#cedbe0', 600);

    rule(ctx, 540, 997, 540, 1151, '#d7dee1');
    write(ctx, 'قبل الخصم', 990, 1040, 38, muted, 600);
    write(ctx, 'بعد الخصم', 484, 1040, 38, muted, 600);
    write(ctx, data.before, 992, 1144, 76, navy, 700, 'ltr', 393);
    write(ctx, beforeOnly ? '…' : data.after, 486, 1144, 76, clay, 700, 'ltr', 402);
    rule(ctx, 80, 1206, 1000, 1206, '#d7dee1');
    write(ctx, 'المبالغ بالدرهم الإماراتي', 996, 1277, 32, muted, 600);
    return element;
  }

  async function prepare(data = {}) {
    const { beforeFils, afterFils } = data;
    if (!Number.isSafeInteger(beforeFils) || !Number.isSafeInteger(afterFils)
        || afterFils < 0 || beforeFils < afterFils) {
      throw new RangeError('تحقّق من المبلغين قبل الخصم وبعده.');
    }
    if (document.fonts && typeof document.fonts.load === 'function') {
      const sample = 'قيمة التوفير 0123456789';
      await Promise.all([600, 700, 800].map(weight => document.fonts.load(weight + ' 40px Cairo', sample).catch(() => [])));
    }
    return { before: amount(beforeFils), after: amount(afterFils), saved: amount(beforeFils - afterFils),
      label: publicLabel(data.label), example: data.example === true };
  }

  async function png(input) {
    const still = draw(await prepare(input));
    return new Promise((resolve, reject) => {
      still.toBlob(blob => blob ? resolve(blob) : reject(new Error('تعذّر حفظ الصورة.')), 'image/png');
    });
  }

  function supportedTypes() {
    if (typeof MediaRecorder === 'undefined' || typeof HTMLCanvasElement === 'undefined'
        || typeof HTMLCanvasElement.prototype.captureStream !== 'function') return [];
    return typeof MediaRecorder.isTypeSupported === 'function'
      ? videoTypes.filter(type => MediaRecorder.isTypeSupported(type)) : [''];
  }

  async function video(input) {
    const types = supportedTypes();
    if (!types.length) throw new Error(unsupported);
    const data = await prepare(input);
    const before = draw(data, true);
    const after = draw(data);
    const movie = canvas(1920);
    const ctx = movie.getContext('2d', { alpha: false });
    if (!ctx) throw new Error(unsupported);
    const duration = 6000;
    const offset = 220;
    function paint(elapsed) {
      ctx.fillStyle = white;
      ctx.fillRect(0, 0, width, movie.height);
      ctx.drawImage(before, 0, offset);
      const mix = Math.min(1, Math.max(0, (elapsed - 2200) / 420));
      if (mix > 0) {
        ctx.globalAlpha = mix;
        ctx.drawImage(after, 0, offset);
        ctx.globalAlpha = 1;
      }
      const progress = 920 * Math.min(1, elapsed / duration);
      ctx.fillStyle = clay;
      ctx.fillRect(1000 - progress, 1204 + offset, progress, 4);
    }
    paint(0);
    let stream;
    try {
      stream = movie.captureStream(15);
    } catch {
      throw new Error(unsupported);
    }
    let timer;
    let recorder;
    try {
      for (const type of types) {
        try {
          const options = { videoBitsPerSecond: 3600000 };
          if (type) options.mimeType = type;
          recorder = new MediaRecorder(stream, options);
          recorder.start();
          break;
        } catch {
          recorder = null;
        }
      }
      if (!recorder) throw new Error(unsupported);
      return await new Promise((resolve, reject) => {
        const chunks = [];
        recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
        recorder.onerror = () => reject(new Error('تعذّر تسجيل الفيديو. يمكنك تنزيل الصورة.'));
        recorder.onstop = () => {
          if (!chunks.length) return reject(new Error('تعذّر حفظ الفيديو. يمكنك تنزيل الصورة.'));
          resolve(new Blob(chunks, { type: recorder.mimeType || chunks[0].type }));
        };
        const start = performance.now();
        timer = setInterval(() => {
          const elapsed = performance.now() - start;
          if (elapsed > duration + 1100) {
            reject(new Error('توقّف التسجيل مؤقتًا. افتح الصفحة وأعد المحاولة أو نزّل الصورة.'));
            return;
          }
          paint(elapsed);
          if (elapsed >= duration && recorder.state === 'recording') recorder.stop();
        }, 1000 / 15);
      });
    } finally {
      clearInterval(timer);
      if (recorder && recorder.state !== 'inactive') recorder.stop();
      stream.getTracks().forEach(track => track.stop());
    }
  }
  return { png, video, canVideo: () => supportedTypes().length > 0 };
})();

async function savingsSharePng(data) { return kodSavingsArtwork.png(data); }
async function savingsShareVideo(data) { return kodSavingsArtwork.video(data); }
function canMakeSavingsVideo() { return kodSavingsArtwork.canVideo(); }

const SUBSCRIPTION_PLANS=[
  {months:1,label:'شهر واحد',price:69}, {months:3,label:'3 أشهر',price:189},
  {months:6,label:'6 أشهر',price:359}, {months:12,label:'سنة كاملة',price:599}
];
const SUBSCRIPTION_METHODS=[
  {id:'stripe',label:'بطاقة ائتمان أو محفظة',detail:'Visa · Mastercard · Apple Pay · Google Pay',symbol:'card'},
  {id:'etisalat',label:'فاتورة اتصالات',detail:'e& UAE',symbol:'phone'},
  {id:'du',label:'فاتورة دو',detail:'du',symbol:'phone'}
];
const BILLING_URL=KOD_CONFIG.supabaseUrl+'/functions/v1/kod-payments';
const RECEIPT_COLUMNS='id,months,amount_fils,rail,status,created_at,paid_at,valid_from,valid_until,club_tier';
const billingUuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
let chosenTerm=1,chosenRail='stripe',paymentAvailability=null,availabilityAt=0,checkingMethods=false;
let subscriptionReceipts=[],returnedReceipt=null,receiptLoadedFor='',receiptFailed=false,receiptTimer=0;
let receiptTries=0,receiptsLoading=false,paymentBusy=false,paymentMessage='',receiptEmail='';
function clearSubscriptionScope(){
  clearMemberInvoiceScope();
  clearTimeout(receiptTimer);subscriptionReceipts=[];returnedReceipt=null;receiptLoadedFor='';receiptFailed=false;
  receiptTries=0;receiptsLoading=false;paymentBusy=false;paymentMessage='';receiptEmail='';
}
function returnedOrderId(){
  const id=new URLSearchParams(location.search||'').get('subscription')||'';
  return billingUuid.test(id)?id:'';
}
function selectedPlan(){return SUBSCRIPTION_PLANS.find(p=>p.months===chosenTerm)||SUBSCRIPTION_PLANS[0];}
function enabledForTerm(id){return paymentAvailability?.[id]?.includes(chosenTerm)===true;}
function rememberPlan(){
  try{sessionStorage.setItem('kod-selected-plan',JSON.stringify({months:chosenTerm,rail:chosenRail}));}catch{}
}
function restorePlan(){
  try{
    const v=JSON.parse(sessionStorage.getItem('kod-selected-plan')||'null');
    if(v&&SUBSCRIPTION_PLANS.some(p=>p.months===v.months)&&SUBSCRIPTION_METHODS.some(m=>m.id===v.rail)){
      chosenTerm=v.months;chosenRail=v.rail;
    }
  }catch{}
}
function paymentRequestId(newAttempt=false){
  const key='kod-subscription-'+appIdentity.id+'-'+chosenTerm+'-'+chosenRail;
  try{
    const old=JSON.parse(sessionStorage.getItem(key)||'null');
    if(!newAttempt&&old?.until>Date.now()&&billingUuid.test(old.id))return old.id;
    const id=crypto.randomUUID();sessionStorage.setItem(key,JSON.stringify({id,until:Date.now()+15*60000}));return id;
  }catch{return crypto.randomUUID();}
}
function planButtons(){
  const chosen=clubTierForMonths(chosenTerm);
  const cards=Object.entries(CLUB_TIERS).map(([key,tier])=>{
    const months=key==='gold'&&chosen==='gold'?chosenTerm:tier.months,plan=SUBSCRIPTION_PLANS.find(p=>p.months===months);
    return '<button type="button" id="club-plan-'+key+'" class="club-plan" data-tier="'+key+'" data-sub-term="'+months+'" aria-pressed="'+(key===chosen)+'">'+
      '<span class="club-metal" aria-hidden="true"><i class="club-chip"></i></span><strong class="club-tier-name">'+tier.name+'</strong>'+
      '<span class="club-tier-price"><bdi>'+plan.price+'</bdi> د.إ <small>/ '+plan.label+'</small></span><span class="club-tier-benefit">'+tier.benefit+'</span></button>';
  }).join('');
  const terms=chosen==='gold'?'<div class="club-terms" role="group" aria-label="مدة العضوية الذهبية"><strong>مدة الذهبية</strong>'+SUBSCRIPTION_PLANS.filter(p=>p.months>=6).map(p=>'<button id="club-term-'+p.months+'" type="button" data-sub-term="'+p.months+'" aria-pressed="'+(p.months===chosenTerm)+'">'+p.label+' · '+p.price+' د.إ</button>').join('')+'</div>':'';
  return '<div class="club-plans" role="group" aria-label="فئة العضوية">'+cards+'</div>'+terms+clubBranchOffers();
}
function methodButtons(){
  return SUBSCRIPTION_METHODS.map(m=>{
    const state=paymentAvailability===null?'جارٍ التحقق':enabledForTerm(m.id)?'متاح':paymentAvailability.error?'تعذّر التحقق':'بانتظار التفعيل';
    return '<button type="button" class="subscription-method" data-sub-rail="'+m.id+'" aria-pressed="'+(m.id===chosenRail)+'">'+icon(m.symbol)+
      '<span><strong>'+m.label+'</strong><small dir="ltr">'+m.detail+'</small></span><small class="sub-method-state">'+state+'</small></button>';
  }).join('');
}
function receiptHistory(){
  const id=returnedOrderId();
  let result='';
  if(id){
    if(!appIdentity||appIdentity.role==='developer_locked')result='<div class="sub-result"><button class="text-button" data-card-login="subscriptions">تسجيل الدخول للاطّلاع على نتيجة الدفع</button></div>';
    else if(!previewRole&&hasPersonalCard(appIdentity.role)){
      if(returnedReceipt?.status==='paid')result='<div class="sub-result" role="status"><strong>'+icon('check')+' تم دفع اشتراك العضوية '+CLUB_TIERS[clubTierForMonths(returnedReceipt.months)].name+'</strong><span>'+((Date.parse(returnedReceipt.valid_from)>Date.now())?'تبدأ في '+clubStarts(returnedReceipt.valid_from)+'، ':'')+'صالحة حتى '+cardLastDay(returnedReceipt.valid_until)+'.</span><button class="text-button" data-go="membership">عرض بطاقتي</button></div>';
      else result='<div class="sub-result" role="status"><strong>'+(receiptFailed?'تعذّر التحقق من حالة الدفع':returnedReceipt?'بانتظار تأكيد الدفع':receiptLoadedFor?'لا توجد عملية مطابقة في هذا الحساب':'جارٍ التحقق من نتيجة الدفع')+'</strong><button type="button" class="text-button" data-sub-refresh>تحديث الحالة</button></div>';
    }
  }
  if(!subscriptionReceipts.length)return result;
  return result+'<section class="box sub-history"><h2>اشتراكاتي المدفوعة</h2>'+subscriptionReceipts.map(r=>'<div><span>'+CLUB_TIERS[clubTierForMonths(r.months)].name+' · '+SUBSCRIPTION_PLANS.find(p=>p.months===r.months)?.label+'</span><strong>'+money(r.amount_fils)+'</strong><small>حتى '+cardLastDay(r.valid_until)+'</small></div>').join('')+'</section>';
}
function subscriptionPage(){
  const p=selectedPlan(),available=enabledForTerm(chosenRail);
  let action='';
  if(previewRole)action='<p>اخرج من المعاينة لاستخدام حسابك.</p>';
  else if(appIdentity?.role==='merchant')action='<p>الاشتراك متاح من حساب عضو كود.</p>';
  else if(paymentAvailability?.error)action='<p>تعذّر التحقق من توفر الدفع.</p><button type="button" class="text-button" data-sub-refresh>أعد المحاولة</button>';
  else if(!available)action='<p class="sub-availability" role="status">'+(!paymentAvailability?'جارٍ التحقق من وسيلة الدفع…':'الدفع بهذه الوسيلة بانتظار التفعيل.')+'</p>';
  else if(!appIdentity||appIdentity.role==='developer_locked')action='<button type="button" class="btn" data-card-login="subscriptions">سجّل الدخول للدفع</button>';
  else action=(chosenRail!=='stripe'&&!appIdentity.email?'<label class="field" for="sub-email">بريد إيصال الدفع<input type="email" id="sub-email" name="receipt_email" autocomplete="email" dir="ltr" maxlength="254" value="'+esc(receiptEmail)+'" required></label>':'')+
      '<button class="btn" type="submit" '+(paymentBusy?'disabled':'')+'>'+(paymentBusy?'جارٍ فتح بوابة الدفع…':'متابعة للدفع · '+p.price+' د.إ')+'</button>';
  return '<div class="subscriptions"><header class="order-page-head"><div><h1>باقات الاشتراك</h1><p>اختر عضويتك وشوف السعر والخصم المتاح في الفروع المشاركة.</p></div><button class="btn light" data-go="membership">'+icon('card')+' بطاقتي</button></header>'+
    clubChoiceSwitch('subscriptions')+marketingBanner()+(returnedOrderId()?receiptHistory():'')+'<section aria-label="اختر الباقة">'+planButtons()+'</section>'+
    '<div class="sub-checkout"><section class="sub-methods"><h2>وسيلة الدفع</h2><div>'+methodButtons()+'</div></section>'+
    '<form class="sub-summary" id="kod-subscribe-form"><h2>ملخّص الاشتراك</h2><div><span>العضوية</span><strong>'+CLUB_TIERS[clubTierForMonths(p.months)].name+' · '+p.label+'</strong></div><div class="sub-total"><span>الإجمالي</span><strong><bdi>'+p.price+'</bdi> د.إ</strong></div><p>دفعة واحدة للمدة المختارة، بدون تجديد تلقائي.</p>'+(cardIsActive(liveWorkspace.card)?'<p>بتبدأ الباقة الجديدة بعد انتهاء مدة عضويتك الحالية.</p>':'')+action+(!available&&!previewRole&&appIdentity?.role!=='merchant'?'<button type="button" class="btn" data-scroll-bills>الدفع بفاتورة كود</button>':'')+
    '<p class="sub-error" aria-live="polite" id="sub-payment-error">'+esc(paymentMessage)+'</p></form></div>'+memberInvoiceSection()+(!returnedOrderId()?receiptHistory():'')+'<button class="text-button" data-go="rewards">ادعُ صديقاً واكسب أيام عضوية</button></div>';
}
function redrawSubscriptions(){
  if(current!=='subscriptions')return;
  const focus=document.activeElement;
  if(focus?.closest?.('#member-bills form'))return;
  const keep=focus?.dataset?.subTerm&&focus.id?'#'+focus.id:focus?.dataset?.subRail?'[data-sub-rail="'+focus.dataset.subRail+'"]':focus?.id==='sub-email'?'#sub-email':'';
  document.getElementById('view').innerHTML=subscriptionPage();
  if(keep)document.querySelector(keep)?.focus({preventScroll:true});
}
async function checkSubscriptionMethods(force=false){
  if(checkingMethods||(!force&&availabilityAt&&Date.now()-availabilityAt<60000))return;
  checkingMethods=true;
  try{
    const r=await fetch(KOD_CONFIG.supabaseUrl+'/rest/v1/rpc/kod_subscription_methods',{method:'POST',headers:{apikey:KOD_CONFIG.publishableKey,'Content-Type':'application/json'},body:'{}',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(10000)});
    if(!r.ok)throw Error();
    const methods=await r.json();
    if(!SUBSCRIPTION_METHODS.every(m=>Array.isArray(methods?.[m.id])))throw Error();
    paymentAvailability=methods;
  }catch{paymentAvailability={error:true};}
  finally{availabilityAt=Date.now();checkingMethods=false;redrawSubscriptions();}
}
async function loadSubscriptionReceipts(force=false){
  if(previewRole||!hasPersonalCard(appIdentity?.role)||receiptsLoading)return;
  const owner=appIdentity.id,id=returnedOrderId(),key=owner+'|'+id,epoch=workspaceEpoch;
  if(!force&&receiptLoadedFor===key)return;
  receiptsLoading=true;clearTimeout(receiptTimer);
  try{
    const client=await getKodClient();
    if(id){
      const session=(await client.auth.getSession()).data.session;
      if(session?.user.id===owner)await fetch(BILLING_URL+'/check-order',{method:'POST',headers:{apikey:KOD_CONFIG.publishableKey,Authorization:'Bearer '+session.access_token,'Content-Type':'application/json'},body:JSON.stringify({order_id:id}),signal:AbortSignal.timeout(12000)}).catch(()=>{});
    }
    const mine=()=>client.from('kod_subscription_orders').select(RECEIPT_COLUMNS).eq('user_id',owner);
    const [history,result]=await Promise.all([mine().eq('status','paid').order('paid_at',{ascending:false}).limit(8),id?mine().eq('id',id).maybeSingle():{data:null}]);
    if(history.error||result.error)throw Error();
    if(epoch!==workspaceEpoch)return;
    subscriptionReceipts=history.data||[];returnedReceipt=result.data;receiptFailed=false;
    if(returnedReceipt?.status==='pending'&&receiptTries<6)receiptTimer=setTimeout(()=>{
      if(current==='subscriptions'&&workspaceEpoch===epoch)loadSubscriptionReceipts(true);
    },2500+(receiptTries++)*1000);
    if(returnedReceipt?.status==='paid'&&(!liveWorkspace.card||liveWorkspace.card.expires_at!==returnedReceipt.valid_until)){
      refreshLiveWorkspace().then(()=>{if(current==='membership'&&workspaceEpoch===epoch)render(current);}).catch(()=>{});
    }
  }catch{if(epoch===workspaceEpoch)receiptFailed=true;}
  finally{if(epoch===workspaceEpoch){receiptsLoading=false;receiptLoadedFor=key;redrawSubscriptions();}}
}
function beginSubscriptionPage(){startMarketingEntry();checkSubscriptionMethods();loadSubscriptionReceipts();loadMemberInvoices();}
const checkoutMessages={checkout_starting:'يجري تجهيز الدفع. حاول بعد لحظات.',checkout_expired:'انتهت مهلة هذه المحاولة. يمكنك البدء من جديد.',method_unavailable:'الدفع بهذه الوسيلة بانتظار التفعيل.',email_required:'أدخل بريد إيصال دفع صالحاً.',login_required:'سجّل الدخول مجدداً للمتابعة.',member_required:'يلزم حساب عضو كود للدفع.'};
async function openSubscriptionCheckout(){
  if(paymentBusy||previewRole||!hasPersonalCard(appIdentity?.role)||!enabledForTerm(chosenRail))return;
  const epoch=workspaceEpoch,rail=chosenRail,months=chosenTerm;
  paymentBusy=true;paymentMessage='';redrawSubscriptions();
  try{
    const c=await getKodClient(),session=(await c.auth.getSession()).data.session;
    if(!session||session.user.id!==appIdentity?.id)throw Error('login_required');
    const r=await fetch(BILLING_URL+'/checkout',{method:'POST',headers:{'Content-Type':'application/json',apikey:KOD_CONFIG.publishableKey,Authorization:'Bearer '+session.access_token},
      body:JSON.stringify({months,rail,request_id:paymentRequestId(),receipt_email:rail==='stripe'?undefined:receiptEmail||undefined}),signal:AbortSignal.timeout(35000)});
    const reply=await r.json();
    if(epoch!==workspaceEpoch||current!=='subscriptions')return;
    if(!r.ok){if(reply.error==='checkout_expired')paymentRequestId(true);if(reply.error==='method_unavailable')checkSubscriptionMethods(true);throw Error(reply.error);}
    if(reply.paid&&billingUuid.test(reply.id)){location.assign(KOD_CONFIG.publicAppUrl+'?subscription='+reply.id+'#subscriptions');return;}
    const url=new URL(reply.url),host=rail==='stripe'?'checkout.stripe.com':'checkout.apaya.io';
    if(url.protocol!=='https:'||url.host!==host||url.username||url.password)throw Error();
    location.assign(url.href);
  }catch(error){if(epoch===workspaceEpoch)paymentMessage=checkoutMessages[error.message]||'تعذّر فتح بوابة الدفع. حاول مجدداً.';}
  finally{if(epoch===workspaceEpoch){paymentBusy=false;redrawSubscriptions();}}
}
document.addEventListener('click',e=>{
  const button=e.target.closest('button');if(!button||current!=='subscriptions'||paymentBusy)return;
  const {subTerm,subRail}=button.dataset;
  if(subTerm&&SUBSCRIPTION_PLANS.some(p=>p.months===Number(subTerm)))chosenTerm=Number(subTerm);
  else if(subRail&&SUBSCRIPTION_METHODS.some(m=>m.id===subRail))chosenRail=subRail;
  else if(button.hasAttribute('data-sub-refresh')){receiptTries=0;checkSubscriptionMethods(true);loadSubscriptionReceipts(true);return;}
  else return;
  paymentMessage='';rememberPlan();redrawSubscriptions();
});
document.addEventListener('input',e=>{if(e.target.id==='sub-email')receiptEmail=e.target.value;});
document.addEventListener('submit',e=>{if(e.target.id==='kod-subscribe-form'){e.preventDefault();openSubscriptionCheckout();}});
restorePlan();

const SUBSCRIPTION_TERMS=[
  {months:1,label:'شهري'},{months:3,label:'3 أشهر'},{months:6,label:'6 أشهر'},{months:12,label:'سنوي'}
];
const SUBSCRIPTION_METHODS=[
  {id:'stripe',label:'بطاقة ائتمان أو محفظة',detail:'Visa · Mastercard · Apple Pay · Google Pay',symbol:'card'},
  {id:'etisalat',label:'فاتورة اتصالات',detail:'e& UAE',symbol:'phone'},
  {id:'du',label:'فاتورة دو',detail:'du',symbol:'phone'}
];
const BILLING_URL=KOD_CONFIG.supabaseUrl+'/functions/v1/kod-payments';
const RECEIPT_COLUMNS='id,months,amount_fils,rail,status,created_at,paid_at,valid_from,valid_until,club_tier';
const billingUuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
let chosenTier='bronze',chosenTerm=0,chosenRail='stripe',paymentAvailability=null,availabilityAt=0,checkingMethods=false;
let subscriptionReceipts=[],returnedReceipt=null,receiptLoadedFor='',receiptFailed=false,receiptTimer=0;
let receiptTries=0,receiptsLoading=false,paymentBusy=false,paymentMessage='',receiptEmail='';
function clearSubscriptionScope(){
  clearMemberInvoiceScope();clearPriceEditor();
  clearTimeout(receiptTimer);subscriptionReceipts=[];returnedReceipt=null;receiptLoadedFor='';receiptFailed=false;
  receiptTries=0;receiptsLoading=false;paymentBusy=false;paymentMessage='';receiptEmail='';
}
function returnedOrderId(){
  const id=new URLSearchParams(location.search||'').get('subscription')||'';
  return billingUuid.test(id)?id:'';
}
function selectedPlan(){
  const term=SUBSCRIPTION_TERMS.find(p=>p.months===chosenTerm),entry=catalogEntry(chosenTier,chosenTerm);
  return {tier:chosenTier,months:chosenTerm,label:term?.label||'',amount_fils:entry?.amount_fils??null,carrier_allowed:entry?.carrier_allowed===true};
}
function enabledForTerm(id){
  const plan=selectedPlan();
  return plan.amount_fils!==null&&(id==='stripe'||plan.carrier_allowed)&&paymentAvailability?.[id]?.includes(chosenTerm)===true;
}
function rememberPlan(){
  try{sessionStorage.setItem('kod-selected-plan',JSON.stringify({tier:chosenTier,months:chosenTerm,rail:chosenRail}));}catch{}
}
function restorePlan(){
  try{
    const v=JSON.parse(sessionStorage.getItem('kod-selected-plan')||'null');
    if(v&&(v.months===0||SUBSCRIPTION_TERMS.some(p=>p.months===v.months))&&SUBSCRIPTION_METHODS.some(m=>m.id===v.rail)){
      chosenTier=['bronze','silver','gold'].includes(v.tier)?v.tier:legacyTierForMonths(v.months);
      chosenTerm=v.months;chosenRail=v.rail;
    }
  }catch{}
}
function paymentRequestId(newAttempt=false){
  const key='kod-subscription-'+appIdentity.id+'-'+chosenTier+'-'+chosenTerm+'-'+selectedPlan().amount_fils+'-'+chosenRail;
  try{
    const old=JSON.parse(sessionStorage.getItem(key)||'null');
    if(!newAttempt&&old?.until>Date.now()&&billingUuid.test(old.id))return old.id;
    const id=crypto.randomUUID();sessionStorage.setItem(key,JSON.stringify({id,until:Date.now()+15*60000}));return id;
  }catch{return crypto.randomUUID();}
}
function planButtons(){
  const cards=Object.entries(CLUB_TIERS).map(([key,tier])=>
    '<button type="button" id="club-plan-'+key+'" class="club-plan" data-tier="'+key+'" data-sub-tier="'+key+'" aria-pressed="'+(key===chosenTier)+'">'+
    '<span class="club-metal" aria-hidden="true"><i class="club-chip"></i></span><strong class="club-tier-name">'+tier.name+'</strong><span class="club-tier-benefit">'+tier.benefit+'</span></button>'
  ).join('');
  const terms='<div class="club-terms club-duration-picker" role="group" aria-label="مدة العضوية"><strong>مدة الاشتراك</strong>'+SUBSCRIPTION_TERMS.map(p=>
    '<button id="club-term-'+p.months+'" type="button" data-sub-term="'+p.months+'" aria-pressed="'+(p.months===chosenTerm)+'">'+p.label+'</button>').join('')+'</div>';
  return '<div class="club-plans" role="group" aria-label="فئة العضوية">'+cards+'</div>'+terms+clubBranchOffers();
}
function methodButtons(){
  return SUBSCRIPTION_METHODS.map(m=>{
    const state=!chosenTerm?'اختر مدة الاشتراك':membershipCatalog&&selectedPlan().amount_fils===null?'بانتظار تسعير الباقة':paymentAvailability===null?'جارٍ التحقق':enabledForTerm(m.id)?'متاح':paymentAvailability.error?'تعذّر التحقق':'بانتظار التفعيل';
    return '<button type="button" class="subscription-method" data-sub-rail="'+m.id+'" aria-pressed="'+(m.id===chosenRail)+'">'+icon(m.symbol)+
      '<span><strong>'+m.label+'</strong><small dir="ltr">'+m.detail+'</small></span><small class="sub-method-state">'+state+'</small></button>';
  }).join('');
}
function receiptHistory(){
  const id=returnedOrderId();
  let result='';
  if(id){
    if(!appIdentity||appIdentity.role==='developer_locked')result='<div class="sub-result"><button class="text-button" data-card-login="subscriptions">تسجيل الدخول للاطّلاع على نتيجة الدفع</button></div>';
    else if(!previewRole&&hasPersonalCard(appIdentity.role)){
      if(returnedReceipt?.status==='paid')result='<div class="sub-result" role="status"><strong>'+icon('check')+' تم دفع اشتراك العضوية '+CLUB_TIERS[receiptTier(returnedReceipt)].name+'</strong><span>'+((Date.parse(returnedReceipt.valid_from)>Date.now())?'تبدأ في '+clubStarts(returnedReceipt.valid_from)+'، ':'')+'صالحة حتى '+cardLastDay(returnedReceipt.valid_until)+'.</span><button class="text-button" data-go="membership">عرض بطاقتي</button></div>';
      else result='<div class="sub-result" role="status"><strong>'+(receiptFailed?'تعذّر التحقق من حالة الدفع':returnedReceipt?'بانتظار تأكيد الدفع':receiptLoadedFor?'لا توجد عملية مطابقة في هذا الحساب':'جارٍ التحقق من نتيجة الدفع')+'</strong><button type="button" class="text-button" data-sub-refresh>تحديث الحالة</button></div>';
    }
  }
  if(!subscriptionReceipts.length)return result;
  return result+'<section class="box sub-history"><h2>اشتراكاتي المدفوعة</h2>'+subscriptionReceipts.map(r=>'<div><span>'+CLUB_TIERS[receiptTier(r)].name+' · '+SUBSCRIPTION_TERMS.find(p=>p.months===r.months)?.label+'</span><strong>'+money(r.amount_fils)+'</strong><small>حتى '+cardLastDay(r.valid_until)+'</small></div>').join('')+'</section>';
}
function subscriptionPage(){
  const p=selectedPlan(),available=enabledForTerm(chosenRail),canBuy=p.amount_fils!==null&&!previewRole&&appIdentity?.role!=='merchant';
  let action='';
  if(!chosenTerm)action='<p role="status">اختر مدة الاشتراك لعرض الإجمالي.</p>';
  else if(priceListError)action='<p role="status">تعذّر تحديث الأسعار.</p><button type="button" class="text-button" data-sub-refresh>تحديث الأسعار</button>';
  else if(!membershipCatalog)action='<p role="status">جارٍ تحميل السعر…</p>';
  else if(p.amount_fils===null)action='<p role="status">الدفع متاح بعد تحديد سعر هذه المدة. يمكنك اختيار مدة أو فئة أخرى.</p>';
  else if(previewRole)action='<p>اخرج من المعاينة لاستخدام حسابك.</p>';
  else if(appIdentity?.role==='merchant')action='<p>الاشتراك متاح من حساب عضو كود.</p>';
  else if(paymentAvailability?.error)action='<p>تعذّر التحقق من توفر الدفع.</p><button type="button" class="text-button" data-sub-refresh>أعد المحاولة</button>';
  else if(!available)action='<p class="sub-availability" role="status">'+(!paymentAvailability?'جارٍ التحقق من وسيلة الدفع…':'الدفع بهذه الوسيلة بانتظار التفعيل.')+'</p>';
  else if(!appIdentity||appIdentity.role==='developer_locked')action='<button type="button" class="btn" data-card-login="subscriptions">سجّل الدخول للدفع</button>';
  else action=(chosenRail!=='stripe'&&!appIdentity.email?'<label class="field" for="sub-email">بريد إيصال الدفع<input type="email" id="sub-email" name="receipt_email" autocomplete="email" dir="ltr" maxlength="254" value="'+esc(receiptEmail)+'" required></label>':'')+
    '<button class="btn" type="submit" '+(paymentBusy?'disabled':'')+'>'+(paymentBusy?'جارٍ فتح بوابة الدفع…':'متابعة للدفع · '+money(p.amount_fils))+'</button>';
  const total=chosenTerm&&membershipCatalog?'<div class="sub-total"><span>الإجمالي</span><strong>'+ (p.amount_fils===null?'بانتظار تحديد السعر':money(p.amount_fils))+'</strong></div>':'';
  const summary='<form class="sub-summary" id="kod-subscribe-form"><h2>ملخّص الاشتراك</h2><div><span>العضوية</span><strong>'+CLUB_TIERS[p.tier].name+(p.label?' · '+p.label:'')+'</strong></div>'+
    total+(canBuy?'<p>دفعة واحدة للمدة المختارة، بدون تجديد تلقائي.</p>':'')+(cardIsActive(liveWorkspace.card)&&canBuy?'<p>بتبدأ الباقة الجديدة بعد انتهاء مدة عضويتك الحالية.</p>':'')+action+
    (canBuy&&!available?'<button type="button" class="btn" data-scroll-bills>الدفع بفاتورة كود</button>':'')+
    '<p class="sub-error" aria-live="polite" id="sub-payment-error">'+esc(paymentMessage)+'</p></form>';
  return '<div class="subscriptions"><header class="order-page-head"><div><h1>باقات الاشتراك</h1><p>اختر فئة العضوية ومدتها.</p></div><button class="btn light" data-go="membership">'+icon('card')+' بطاقتي</button></header>'+
    clubChoiceSwitch('subscriptions')+marketingBanner()+(returnedOrderId()?receiptHistory():'')+'<section aria-label="اختر الباقة">'+planButtons()+'</section>'+
    '<div class="sub-checkout">'+summary+'<section class="sub-methods"><h2>وسيلة الدفع</h2><div>'+methodButtons()+'</div></section></div>'+
    memberInvoiceSection()+(!returnedOrderId()?receiptHistory():'')+'<button class="text-button" data-go="rewards">ادعُ صديقاً واكسب أيام عضوية</button></div>';
}
function redrawSubscriptions(force=false){
  if(current!=='subscriptions')return;
  const focus=document.activeElement;
  if(!force&&focus?.closest?.('#member-bills form'))return;
  const keep=(focus?.dataset?.subTerm||focus?.dataset?.subTier)&&focus.id?'#'+focus.id:focus?.dataset?.subRail?'[data-sub-rail="'+focus.dataset.subRail+'"]':focus?.id==='sub-email'?'#sub-email':'';
  document.getElementById('view').innerHTML=subscriptionPage();
  if(keep)document.querySelector(keep)?.focus({preventScroll:true});
}
async function checkSubscriptionMethods(force=false){
  if(checkingMethods||(!force&&availabilityAt&&Date.now()-availabilityAt<60000))return;
  checkingMethods=true;
  try{
    const r=await fetch(KOD_CONFIG.supabaseUrl+'/rest/v1/rpc/kod_subscription_methods',{method:'POST',headers:{apikey:KOD_CONFIG.publishableKey,'Content-Type':'application/json'},body:'{}',credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(10000)});
    if(!r.ok)throw Error();
    const methods=await r.json();
    if(!SUBSCRIPTION_METHODS.every(m=>Array.isArray(methods?.[m.id])))throw Error();
    paymentAvailability=methods;
  }catch{paymentAvailability={error:true};}
  finally{availabilityAt=Date.now();checkingMethods=false;redrawSubscriptions();}
}
async function loadSubscriptionReceipts(force=false){
  if(previewRole||!hasPersonalCard(appIdentity?.role)||receiptsLoading)return;
  const owner=appIdentity.id,id=returnedOrderId(),key=owner+'|'+id,epoch=workspaceEpoch;
  if(!force&&receiptLoadedFor===key)return;
  receiptsLoading=true;clearTimeout(receiptTimer);
  try{
    const client=await getKodClient();
    if(id){
      const session=(await client.auth.getSession()).data.session;
      if(session?.user.id===owner)await fetch(BILLING_URL+'/check-order',{method:'POST',headers:{apikey:KOD_CONFIG.publishableKey,Authorization:'Bearer '+session.access_token,'Content-Type':'application/json'},body:JSON.stringify({order_id:id}),signal:AbortSignal.timeout(12000)}).catch(()=>{});
    }
    const mine=()=>client.from('kod_subscription_orders').select(RECEIPT_COLUMNS).eq('user_id',owner);
    const [history,result]=await Promise.all([mine().eq('status','paid').order('paid_at',{ascending:false}).limit(8),id?mine().eq('id',id).maybeSingle():{data:null}]);
    if(history.error||result.error)throw Error();
    if(epoch!==workspaceEpoch)return;
    subscriptionReceipts=history.data||[];returnedReceipt=result.data;receiptFailed=false;
    if(returnedReceipt?.status==='pending'&&receiptTries<6)receiptTimer=setTimeout(()=>{
      if(current==='subscriptions'&&workspaceEpoch===epoch)loadSubscriptionReceipts(true);
    },2500+(receiptTries++)*1000);
    if(returnedReceipt?.status==='paid'&&(!liveWorkspace.card||liveWorkspace.card.expires_at!==returnedReceipt.valid_until)){
      refreshLiveWorkspace().then(()=>{if(current==='membership'&&workspaceEpoch===epoch)render(current);}).catch(()=>{});
    }
  }catch{if(epoch===workspaceEpoch)receiptFailed=true;}
  finally{if(epoch===workspaceEpoch){receiptsLoading=false;receiptLoadedFor=key;redrawSubscriptions();}}
}
function beginSubscriptionPage(){loadMembershipCatalog();startMarketingEntry();checkSubscriptionMethods();loadSubscriptionReceipts();loadMemberInvoices();}
const checkoutMessages={price_changed:'تغيّر سعر الاشتراك. راجع الإجمالي الجديد قبل المتابعة.',price_unset:'سعر هذا الخيار قيد التحديد.',request_mismatch:'تغيّرت بيانات الاشتراك. أعد اختيار الباقة.',checkout_starting:'يجري تجهيز الدفع. حاول بعد لحظات.',checkout_expired:'انتهت مهلة هذه المحاولة. يمكنك البدء من جديد.',method_unavailable:'الدفع بهذه الوسيلة بانتظار التفعيل.',email_required:'أدخل بريد إيصال دفع صالحاً.',login_required:'سجّل الدخول مجدداً للمتابعة.',member_required:'يلزم حساب عضو كود للدفع.'};
async function openSubscriptionCheckout(){
  if(paymentBusy||previewRole||!hasPersonalCard(appIdentity?.role)||!enabledForTerm(chosenRail))return;
  const epoch=workspaceEpoch,rail=chosenRail,plan=selectedPlan(),months=plan.months,request=paymentRequestId();
  paymentBusy=true;paymentMessage='';redrawSubscriptions();
  try{
    const c=await getKodClient(),session=(await c.auth.getSession()).data.session;
    if(!session||session.user.id!==appIdentity?.id)throw Error('login_required');
    const reserved=await cardRpc('kod_reserve_membership_checkout',{p_tier:plan.tier,p_months:months,p_rail:rail,p_expected_fils:plan.amount_fils,p_request:request});
    if(epoch!==workspaceEpoch||current!=='subscriptions')return;
    if(!billingUuid.test(reserved))throw Error('invalid_plan');
    const r=await fetch(BILLING_URL+'/checkout',{method:'POST',headers:{'Content-Type':'application/json',apikey:KOD_CONFIG.publishableKey,Authorization:'Bearer '+session.access_token},
      body:JSON.stringify({months,rail,request_id:reserved,receipt_email:rail==='stripe'?undefined:receiptEmail||undefined}),signal:AbortSignal.timeout(35000)});
    const reply=await r.json();
    if(epoch!==workspaceEpoch||current!=='subscriptions')return;
    if(!r.ok){if(reply.error==='checkout_expired')paymentRequestId(true);if(reply.error==='method_unavailable')checkSubscriptionMethods(true);throw Error(reply.error);}
    if(reply.paid&&billingUuid.test(reply.id)){location.assign(KOD_CONFIG.publicAppUrl+'?subscription='+reply.id+'#subscriptions');return;}
    const url=new URL(reply.url),host=rail==='stripe'?'checkout.stripe.com':'checkout.apaya.io';
    if(url.protocol!=='https:'||url.host!==host||url.username||url.password)throw Error();
    location.assign(url.href);
  }catch(error){
    if(epoch===workspaceEpoch){paymentMessage=checkoutMessages[error.message]||'تعذّر فتح بوابة الدفع. حاول مجدداً.';if(['price_changed','price_unset','request_mismatch'].includes(error.message))await loadMembershipCatalog(true);}
  }
  finally{if(epoch===workspaceEpoch){paymentBusy=false;redrawSubscriptions();}}
}
document.addEventListener('click',e=>{
  const button=e.target.closest('button');if(!button||current!=='subscriptions'||paymentBusy)return;
  const {subTier,subTerm,subRail}=button.dataset;
  if(subTier&&Object.hasOwn(CLUB_TIERS,subTier))chosenTier=subTier;
  else if(subTerm&&SUBSCRIPTION_TERMS.some(p=>p.months===Number(subTerm)))chosenTerm=Number(subTerm);
  else if(subRail&&SUBSCRIPTION_METHODS.some(m=>m.id===subRail))chosenRail=subRail;
  else if(button.hasAttribute('data-sub-refresh')){receiptTries=0;loadMembershipCatalog(true);checkSubscriptionMethods(true);loadSubscriptionReceipts(true);return;}
  else return;
  paymentMessage='';rememberPlan();redrawSubscriptions();loadMembershipCatalog();
});
document.addEventListener('input',e=>{if(e.target.id==='sub-email')receiptEmail=e.target.value;});
document.addEventListener('submit',e=>{if(e.target.id==='kod-subscribe-form'){e.preventDefault();openSubscriptionCheckout();}});
restorePlan();

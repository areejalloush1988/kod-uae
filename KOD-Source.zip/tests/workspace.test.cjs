const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
let source=fs.readFileSync(__dirname+'/../index.html','utf8').split('<script>')[1].split('</script>')[0];
source=source.replace(/\nrender\(APP_ROUTES\.has\(location\.hash\.slice\(1\)\).*?\nif\(backendReady\(\)\).*?;\s*$/s,'');
const handlers={};
const nodes=new Map();
function node(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',style:{},hidden:false,value:'',classList:{toggle(){}},toggleAttribute(){},setAttribute(){},addEventListener(){},scrollIntoView(){},focus(){},select(){}});return nodes.get(id);}
const sandbox={console,Intl,Date,Math,Set,Map,JSON,Number,String,Promise,crypto:require('node:crypto').webcrypto,URL,localStorage:{getItem:()=>null,setItem(){}},document:{addEventListener:(name,fn)=>(handlers[name]??=[]).push(fn),getElementById:node,querySelectorAll:()=>[],body:{style:{},appendChild(){}},createElement:()=>node('new')},window:{addEventListener(){},scrollTo(){}},location:{hash:''},setTimeout:()=>0,clearTimeout(){}};
vm.createContext(sandbox);vm.runInContext(source,sandbox);
vm.runInContext(`
const assert=(b,m)=>{if(!b)throw Error(m)};
const testMenu=[{id:'one',price_cents:3500,is_available:true},{id:'two',price_cents:1000,is_available:true}];
let q=quoteCart([{itemId:'one',quantity:2},{itemId:'two',quantity:1}],testMenu,25,700,'delivery');
assert(q.subtotal_cents===8000&&q.discount_cents===2000&&q.total_cents===6700,'discount and delivery total');
q=quoteCart([{itemId:'one',quantity:1}],testMenu,0,700,'pickup');assert(q.total_cents===3500&&q.delivery_fee_cents===0,'pickup excludes delivery');
for(const lines of [[],[{itemId:'missing',quantity:1}],[{itemId:'one',quantity:0}],[{itemId:'one',quantity:1.5}],[{itemId:'one',quantity:21}],[{itemId:'one',quantity:1},{itemId:'one',quantity:2}]]){let rejected=false;try{quoteCart(lines,testMenu,25,700,'delivery')}catch{rejected=true}assert(rejected,'invalid basket accepted');}
assert(backendReady(),'production backend must be configured');
assert(canRoute('customer','developer')===false&&canRoute('merchant','developer')===false,'developer access gate');
assert(developerDashboard().includes('ادخل بحسابك'),'direct developer route must not open');
assert(authView().includes('data-email-link')&&KOD_CONFIG.providers.email,'email-only login action must be available');
assert(!KOD_CONFIG.providers.phone&&!KOD_CONFIG.providers.google&&!KOD_CONFIG.providers.uaepass,'unconfigured external providers must remain disabled');
assert(KOD_CONFIG.publicAppUrl==='https://areejalloush1988.github.io/kod-uae/','stable owner-hosted app origin');
assert(!authView(true).includes('data-account-type="developer"'),'no public developer signup');
document.querySelector=()=>null;
render('discover');
assert(CATEGORIES.length===12,'category directory');
for(const group of PICK_GROUPS){
  assert(group.ids.every(id=>OFFERS.some(offer=>offer.id===id)),'missing pick in '+group.key);
}
const firstPicks=PICK_GROUPS[0].ids.map(id=>OFFERS.find(offer=>offer.id===id).category);
assert(new Set(firstPicks).size===4&&!firstPicks.includes('food'),'mixed lead offers');
openCatalog('all','','leisure',false);
assert(new Set(getOffers().map(offer=>offer.category)).size===3&&getOffers().every(offer=>['travel','hotels','entertainment'].includes(offer.category)),'weekend collection');
openCatalog('all','','high',false);
assert(getOffers().length>0&&getOffers().every(offer=>offer.percent>=30),'discount filter');
state.city='الشارقة';openCatalog('all','','all',false);
assert(getOffers().length>0&&getOffers().every(offer=>offer.city===state.city),'emirate filter');
state.city='all';openCatalog('electronics','شرف دي جي','all',false);
assert(getOffers().length===2,'search and category');
openCatalog('food','','all',false);
assert(getOffers().some(offer=>offerCard(offer).includes('data-menu=')),'restaurants from category');
filter='all';query='';activeKind='all';catalogMode=false;
console.log('PASS: 12 categories, mixed picks, weekend, discount, emirate, search and food entry');
for(const role of ['customer','merchant','developer']){previewRole=role;for(const route of [ROLE_ROUTES[role],'account','orders','food'])render(route);}
previewRole='customer';activeRestaurant='shakeshack';render('menu');addCartItem('shakeshack-item-0');addCartItem('shakeshack-item-0');
assert(cart.lines[0].quantity===2,'cart accumulates quantity');render('cart');assert(cartView().includes('تأكيد طلب تجريبي'),'demo checkout must be explicit');
previewRole='developer';assert(developerDashboard().includes('areejalloush1988@gmail.com'),'owner reference');
for(const tab of ['overview','orders','restaurants','users','offers','settings']){developerTab=tab;assert(developerDashboard().length>300,'developer tab '+tab);}
previewRole='merchant';for(const tab of ['orders','menu','settings']){merchantTab=tab;assert(merchantDashboard().length>300,'merchant tab '+tab);}
assert(ORDER_TRANSITIONS.preparing.includes('out_for_delivery')&&ORDER_TRANSITIONS.preparing.includes('ready_for_pickup'),'fulfillment routes');
console.log('PASS: pricing, delivery/pickup, invalid carts, role guards, provider state, all dashboards and cart rendering');
`,sandbox);
vm.runInContext(`(async()=>{
previewRole='customer';state.membership=true;cart={restaurantId:'shakeshack',lines:[{itemId:'shakeshack-item-0',quantity:2}],method:'delivery',requestId:crypto.randomUUID()};
const before=previewOrders.length,form={elements:{notes:{value:'ملاحظة تجريبية'}},querySelector:()=>({disabled:false})};
await checkoutSubmit(form);assert(previewOrders.length===before+1,'order not created');const created=previewOrders.at(-1);assert(created.total_cents===5950,'checkout total');assert(cart===null,'cart not cleared');
await changeOrderStatus(created.id,'accepted');assert(created.status==='pending','customer could accept order');
previewRole='merchant';for(const next of ['accepted','preparing','out_for_delivery','delivered'])await changeOrderStatus(created.id,next);
assert(created.status==='delivered'&&created.events.length===5,'merchant fulfillment journey');
previewRole='customer';await changeOrderStatus(created.id,'cancelled',true);assert(created.status==='delivered','delivered order cancelled');
console.log('PASS: demo checkout, 59.50 AED total, customer/merchant separation, full delivery timeline, terminal-state protection');
})()`,sandbox).catch(e=>{console.error(e);process.exitCode=1;});

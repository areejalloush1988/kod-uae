const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
let source=fs.readFileSync(__dirname+'/../index.html','utf8').split('<script>')[1].split('</script>')[0];
source=source.replace(/\nrender\(APP_ROUTES\.has\(location\.hash\.slice\(1\)\).*?\nif\(backendReady\(\)\).*?;\s*$/s,'');
const handlers={};
const nodes=new Map();
function node(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',style:{},hidden:false,value:'',classList:{toggle(){}},toggleAttribute(){},setAttribute(){},addEventListener(){},scrollIntoView(){},focus(){},select(){}});return nodes.get(id);}
const geoFixture=JSON.parse(fs.readFileSync(__dirname+'/../uae-dining.json','utf8'));
const sandbox={geoFixture,console,Intl,Date,Math,Set,Map,JSON,Number,String,Promise,crypto:require('node:crypto').webcrypto,URL,localStorage:{getItem:()=>null,setItem(){}},document:{addEventListener:(name,fn)=>(handlers[name]??=[]).push(fn),getElementById:node,querySelectorAll:()=>[],body:{style:{},appendChild(){}},createElement:()=>node('new')},window:{addEventListener(){},scrollTo(){}},location:{hash:''},setTimeout:()=>0,clearTimeout(){}};
vm.createContext(sandbox);vm.runInContext(source,sandbox);
vm.runInContext(`
const assert=(b,m)=>{if(!b)throw Error(m)};
const testMenu=[{id:'one',price_cents:3500,is_available:true},{id:'two',price_cents:1000,is_available:true}];
let q=quoteCart([{itemId:'one',quantity:2},{itemId:'two',quantity:1}],testMenu,25,700,'delivery');
assert(q.subtotal_cents===8000&&q.discount_cents===2000&&q.total_cents===6700,'discount and delivery total');
q=quoteCart([{itemId:'one',quantity:1}],testMenu,0,700,'pickup');assert(q.total_cents===3500&&q.delivery_fee_cents===0,'pickup excludes delivery');
for(const lines of [[],[{itemId:'missing',quantity:1}],[{itemId:'one',quantity:0}],[{itemId:'one',quantity:1.5}],[{itemId:'one',quantity:21}],[{itemId:'one',quantity:1},{itemId:'one',quantity:2}]]){let rejected=false;try{quoteCart(lines,testMenu,25,700,'delivery')}catch{rejected=true}assert(rejected,'invalid basket accepted');}
assert(backendReady(),'production backend must be configured');
assert(canRoute('customer','developer')===false&&canRoute('merchant','developer')===false,'developer access gate');
assert(developerDashboard().includes('ادخل بحسابك'),'direct developer route must not open');
assert(authView().includes('data-go="forgot"')&&authView().includes('autocomplete="current-password"'),'login and recovery');
assert(authView(true).includes('maxlength="6"')&&authView(true).includes('inputmode="numeric"')&&!authView(true).includes('name="full_name"'),'email and six digits are sufficient');
assert(pinPattern.test(latinDigits('٠٠١٢٣٤'))&&!pinPattern.test('12345a')&&!pinPattern.test('1234567'),'PIN shape and leading zeros');
assert(normalizedPhone('٠٥٠ ١٢٣ ٤٥٦٧')==='+971501234567'&&normalizedPhone('00971 50 1234567')==='+971501234567'&&!normalizedPhone('a123'),'phone formats');
assert(APP_ROUTES.has('forgot')&&APP_ROUTES.has('reset-key')&&APP_ROUTES.has('reset-password')&&APP_ROUTES.has('change-password'),'password routes');
assert(!authView(true).includes('data-preview-role="developer"')&&operatorView().includes('auth-form'),'guest cannot access operator challenge');
assert(forgotView().includes('data-go="reset-key"')&&resetKeyView().includes('id="reset-key-form"'),'one-use recovery route');
assert(passwordView(true).includes('data-go="forgot"')&&!passwordView(true).includes('id="password-form"'),'unverified reset gated');
appIdentity={id:'customer-a',role:'customer'};scopeUser='customer-a';state.favorites=['deal:first'];liveWorkspace.profiles=[{id:'customer-a'}];cart={restaurantId:'test'};switchScope('customer-b');
assert(!appIdentity&&!cart&&!state.favorites.length&&!liveWorkspace.profiles.length,'previous customer memory immediately cleared');
switchScope(null);
assert(!KOD_CONFIG.providers.phone&&!KOD_CONFIG.providers.google&&!KOD_CONFIG.providers.uaepass,'unconfigured external providers must remain disabled');
assert(KOD_CONFIG.publicAppUrl==='https://areejalloush1988.github.io/kod-uae/','stable owner-hosted app origin');
assert(!authView(true).includes('data-account-type="developer"'),'no public developer signup');
document.querySelector=()=>null;
render('discover');
assert(number(6434)==='6,434'&&number(25.5)==='25.5','Latin digits with grouping and decimal separators');
assert(latinDigits('١٢:٣٠ / ۴۵')==='12:30 / 45','times and both digit scripts in external text');
assert(norm('القطاع ٣٢')===norm('القطاع 32')&&norm('القطاع ۳۲')===norm('القطاع 32'),'branch search accepts all digit forms');
assert(!/[٠-٩۰-۹]/.test(new Date('2026-11-18T12:30:00Z').toLocaleTimeString(UI_LOCALE)+' '+new Date('2026-11-18T12:30:00Z').toLocaleDateString(UI_LOCALE)),'Latin digits in Arabic dates and times');
const testBranch={...officialPlaces[0],name:'فرع ٢٢',area:'القطاع ۳۲'};
const branchCard=placeRow(testBranch);
assert(branchCard.includes('فرع 22')&&branchCard.includes('القطاع 32')&&!/[٠-٩۰-۹]/.test(branchCard),'directory uses Latin digits in imported names and addresses');
const dealWithDigits={...PUBLIC_DEALS[0],priceLabel:'٢٥ د.إ',schedule:'١٢:٣٠',title:'قائمة ٢'};
assert([storyContent(dealWithDigits),dealCard(dealWithDigits)].every(html=>html.includes('25 د.إ')&&html.includes('12:30')&&!/[٠-٩۰-۹]/.test(html)),'featured and listed offers share numeral handling');
assert(CATEGORIES.length===3&&OFFERS.every(o=>['food','coffee','cafeteria'].includes(o.category)),'dining-only data');
assert(APP_ROUTES.has('directory')&&APP_ROUTES.has('deals'),'deep links');
assert(DINING_META.count===geoFixture.rows.length&&Object.keys(DINING_META.cities).length===7,'country coverage and count');
mapPlaces=indexMapData(geoFixture);mapByKey=new Map(mapPlaces.map(p=>[p.key,p]));mapStatus='ready';
assert(mapByKey.size===mapPlaces.length&&mapPlaces.every(p=>p.search&&p.lat&&p.lon),'unique and geocoded locations');
for(const city of CITIES.slice(1))for(const type of Object.keys(VENUE_TYPES)){
  state.city=city;directory.type=type;
  const list=matchingPlaces(mapPlaces);assert(list.length&&list.every(p=>p.emirate===city&&p.type===type),'emirate × type '+city+' '+type);
}
state.city='all';directory.type='all';
for(const cuisine of ['arabic','emirati','indian','western','chinese','italian','japanese','pakistani']){
  directory.cuisine=cuisine;
  assert(matchingPlaces(officialPlaces).length>0,'official cuisine '+cuisine);
  if(cuisine!=='emirati')assert(matchingPlaces(mapPlaces).length>0,'mapped cuisine '+cuisine);
}
directory.cuisine='all';query='الفنر';
assert(matchingPlaces(officialPlaces).every(p=>p.name.includes('الفنر'))&&matchingPlaces(officialPlaces).length>=2,'Arabic branch search');
query='Al Fanar';assert(matchingPlaces(officialPlaces).length>=2,'English name lookup');query='';
assert(state.favorites.length===0&&isDiningFavorite(mapPlaces[0].key)&&!isDiningFavorite('namshi'),'saved dining keys and old retail exclusions');
assert(PUBLIC_DEALS.length>=3&&activeDeals('2027-01-01').every(d=>d.id!=='refuel-creek-coffee-pastry'),'public offer expiry');
assert([...CUISINES.map(c=>c[2]),...Object.values(FEATURED_MENUS).map(s=>s.photo).filter(Boolean),...PUBLIC_DEALS.map(d=>d.photo)].every(p=>Boolean(PHOTOS[p])),'photographs resolve');
assert(officialPlaces.length===38&&new Set(officialPlaces.map(p=>p.emirate)).size===7,'primary-source branches');
assert(offerCard(OFFERS.find(o=>o.id==='shakeshack')).includes('data-menu='),'restaurant menu entry');
const featured=featuredDeals();
assert(featured[0].id==='grand-beirut-galleria-lunch','featured restaurant');
for(let i=1;i<=featured.length;i++){
  changeStory(1);
  assert(document.getElementById('lead-story').innerHTML.includes('data-public-deal="'+featured[i%featured.length].id+'"'),'next cover opens its own offer');
}
assert(storyIndex===0,'carousel loops');
state.city='عجمان';
assert(!featuredDeals().length&&campaignCover().includes('data-directory-open="all"')&&!campaignCover().includes('data-story-step'),'directory cover for an emirate with no active deals');
assert(Object.values(DINING_META.cityTypes[state.city]).reduce((a,b)=>a+b,0)===DINING_META.cities[state.city],'current emirate counts');
state.city='all';
const demoHome=discover();
assert(demoHome.includes('data-directory-open="cafeteria"')&&demoHome.includes('عروض المطاعم والمقاهي')&&!demoHome.includes('نمشي'),'dining homepage');
render('directory');render('deals');render('favorites');
console.log('PASS: nationwide directory, 21 emirate/type combinations, cuisines and bilingual search, published deals and saved keys');
for(const role of ['customer','merchant','developer']){previewRole=role;for(const route of [ROLE_ROUTES[role],'account','orders','food'])render(route);}
previewRole='customer';activeRestaurant='shakeshack';render('menu');addCartItem('shakeshack-item-0');addCartItem('shakeshack-item-0');
assert(cart.lines[0].quantity===2,'cart accumulates quantity');render('cart');assert(cartView().includes('تأكيد طلب تجريبي'),'demo checkout must be explicit');
previewRole='developer';assert(developerDashboard().includes('areejalloush1988@gmail.com'),'owner reference');
for(const tab of ['overview','orders','restaurants','users','offers','settings']){developerTab=tab;assert(developerDashboard().length>300,'developer tab '+tab);}
previewRole='merchant';for(const tab of ['orders','menu','settings']){merchantTab=tab;assert(merchantDashboard().length>300,'merchant tab '+tab);}
assert(ORDER_TRANSITIONS.preparing.includes('out_for_delivery')&&ORDER_TRANSITIONS.preparing.includes('ready_for_pickup'),'fulfillment routes');
console.log('PASS: pricing, delivery/pickup, invalid carts, role guards, provider state, all dashboards and cart rendering');
`,sandbox);
vm.runInContext(`(async()=>{
previewRole='customer';state.membership=true;cart={restaurantId:'shakeshack',lines:[{itemId:'shakeshack-item-0',quantity:2}],method:'delivery',requestId:crypto.randomUUID()};
const before=previewOrders.length,form={elements:{notes:{value:'ملاحظة تجريبية'}},querySelector:()=>({disabled:false})};
await checkoutSubmit(form);assert(previewOrders.length===before+1,'order not created');const created=previewOrders.at(-1);assert(created.total_cents===5950,'checkout total');assert(cart===null,'cart not cleared');
await changeOrderStatus(created.id,'accepted');assert(created.status==='pending','customer could accept order');
previewRole='merchant';for(const next of ['accepted','preparing','out_for_delivery','delivered'])await changeOrderStatus(created.id,next);
assert(created.status==='delivered'&&created.events.length===5,'merchant fulfillment journey');
previewRole='customer';await changeOrderStatus(created.id,'cancelled',true);assert(created.status==='delivered','delivered order cancelled');
console.log('PASS: demo checkout, 59.50 AED total, customer/merchant separation, full delivery timeline, terminal-state protection');
})()`,sandbox).catch(e=>{console.error(e);process.exitCode=1;});

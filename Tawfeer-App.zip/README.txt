العربية

تطبيق توفير

للوصول إلى حسابك وعضويتك افتح الرابط التالي من متصفح جهازك
https://sites.google.com/view/tawfeer-uae/app

بعد فك الضغط، يمكنك فتح Tawfeer.html والضغط على «فتح وتثبيت توفير». يمكنك أيضاً مسح الرمز الظاهر فيه بكاميرا الهاتف.
من داخل التطبيق، زر «تثبيت التطبيق» موجود بجانب البحث. بعد الإضافة افتح «توفير» من أيقونته.
على iPhone وiPad افتح الرابط في Safari واختر «مشاركة» ثم «إضافة إلى الشاشة الرئيسية».
يحتاج الحساب والطلب والخصم والدفع إلى الإنترنت.

يحتوي مجلد web على النسخة الكاملة لواجهة التطبيق القابلة للنشر عبر HTTPS. استخدمه للنشر على مسار التطبيق الحالي مع خدماته المتصلة.
يحتوي مجلد logo على الشعار الشفاف عالي الدقة ونسخته المتجهية المناسبة للطباعة.


English

Tawfeer app

To access your account and membership, open the following link in your device’s browser.
https://sites.google.com/view/tawfeer-uae/app

After extracting the files, open Tawfeer.html and select “Open and install Tawfeer”. You can also scan the code on that page with your phone’s camera.
In the app, you’ll find “Install app” next to the search box. Once it’s added, open Tawfeer from its icon.
On iPhone and iPad, open the link in Safari, tap Share, then Add to Home Screen.
An internet connection is required to access your account, place an order, use a discount or pay.

The web folder contains the full app interface for deployment over HTTPS. Use it to deploy the app at its current path with its connected services.
The logo folder contains the high-resolution logo with a transparent background and a vector version for print.

اردو

توفیر ایپ

اپنے اکاؤنٹ اور رکنیت تک رسائی کے لیے اپنے آلے کے براؤزر میں درج ذیل لنک کھولیں۔
https://sites.google.com/view/tawfeer-uae/app

فائلیں نکالنے کے بعد Tawfeer.html کھولیں اور «توفیر کھولیں اور انسٹال کریں» منتخب کریں۔ آپ اسی صفحے پر دکھایا گیا کوڈ فون کے کیمرے سے بھی اسکین کر سکتے ہیں۔
ایپ میں سرچ باکس کے ساتھ «ایپ انسٹال کریں» کا بٹن ہے۔ ایپ شامل ہونے کے بعد توفیر کے آئیکن سے اسے کھولیں۔
iPhone اور iPad پر لنک Safari میں کھولیں، «شیئر کریں» اور پھر «ہوم اسکرین پر شامل کریں» منتخب کریں۔
اکاؤنٹ کھولنے، آرڈر دینے، رعایت حاصل کرنے اور ادائیگی کے لیے انٹرنیٹ کنکشن درکار ہے۔

web فولڈر میں ایپ کا مکمل انٹرفیس موجود ہے جسے HTTPS پر شائع کیا جا سکتا ہے۔ متعلقہ سروسز کے ساتھ ایپ کو اس کے موجودہ پتے پر شائع کرنے کے لیے یہی فولڈر استعمال کریں۔
logo فولڈر میں شفاف پس منظر والا اعلیٰ ریزولوشن لوگو اور پرنٹ کے لیے اس کا ویکٹر ورژن موجود ہے۔

فارسی

برنامهٔ توفیر

برای دسترسی به حساب و عضویت خود، لینک زیر را در مرورگر دستگاهتان باز کنید.
https://sites.google.com/view/tawfeer-uae/app

پس از خارج کردن فایل‌ها از حالت فشرده، می‌توانید Tawfeer.html را باز کنید و «باز کردن و نصب توفیر» را بزنید. همچنین می‌توانید کد روی صفحه را با دوربین گوشی اسکن کنید.
در برنامه، دکمهٔ «نصب برنامه» کنار کادر جست‌وجو است. پس از افزودن، توفیر را از نماد آن باز کنید.
در iPhone و iPad، لینک را در Safari باز کنید، «اشتراک‌گذاری» و سپس «افزودن به صفحهٔ اصلی» را بزنید.
برای دسترسی به حساب، ثبت سفارش، استفاده از تخفیف و پرداخت، به اینترنت نیاز دارید.

پوشهٔ web شامل نسخهٔ کامل رابط برنامه برای انتشار از طریق HTTPS است. از آن برای انتشار در مسیر فعلی برنامه با سرویس‌های متصل آن استفاده کنید.
پوشهٔ logo شامل نشان باوضوح بالا و پس‌زمینهٔ شفاف و نسخهٔ برداری مناسب چاپ است.

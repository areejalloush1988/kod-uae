const pinPattern = /^[0-9]{6}$/;
let authFeatures = {...KOD_CONFIG.providers};
let recoveryUser = null, phoneChallenge = null;
let scopeUser = null, scopeSession = null, workspaceEpoch = 0, workspaceJob = null;

function normalizedPhone(value) {
  let phone = latinDigits(value).trim().replace(/[\s()\-]/g,'');
  if (/^05[0-9]{8}$/.test(phone)) phone = '+971'+phone.slice(1);
  if (phone.startsWith('00')) phone = '+'+phone.slice(2);
  if (/^971[0-9]{9}$/.test(phone)) phone = '+'+phone;
  return /^\+[1-9][0-9]{7,14}$/.test(phone) ? phone : '';
}
function newPinField(id,label,autocomplete='new-password') {
  return '<div class="field"><label for="'+id+'">'+label+'</label><input id="'+id+'" name="'+id+'" type="password" inputmode="numeric" dir="ltr" minlength="6" maxlength="6" pattern="[0-9٠-٩۰-۹]{6}" title="أدخل 6 أرقام" autocomplete="'+autocomplete+'" required></div>';
}
function credentialField() {
  const phone=authMethod==='phone';
  return '<div class="field"><label for="auth-identifier">'+(phone?'رقم الموبايل':'البريد الإلكتروني')+'</label>'+
    '<input id="auth-identifier" name="identifier" type="'+(phone?'tel':'email')+'" autocomplete="'+(phone?'tel':'username')+'" dir="ltr" placeholder="'+(phone?'+971 50 123 4567':'name@example.com')+'" required></div>';
}
function authMethods() {
  return '<div class="method-switch" role="group" aria-label="طريقة الدخول">'+[['email','البريد الإلكتروني'],['phone','رقم الموبايل']].map(([key,label])=>'<button type="button" data-auth-method="'+key+'" aria-pressed="'+(authMethod===key)+'" class="'+(authMethod===key?'active':'')+'">'+label+'</button>').join('')+'</div>';
}
function formStatus(){return '<p class="auth-feedback" id="auth-error" role="status" aria-live="polite"></p>'+((promoEntry.invite||promoEntry.campaign)&&['register','auth'].includes(current)?'<button type="button" class="auth-link" data-forget-invite>المتابعة بدون رابط الدعوة</button>':'');}
function authPanel(title,content) {
  return '<section class="auth-panel"><div class="auth-visual" aria-hidden="true">'+photo('lebanese-table')+'</div><div class="auth-fields"><h1>'+title+'</h1>'+content+'</div></section>';
}
function googleControl() {
  const content='<b aria-hidden="true" lang="en">G</b> المتابعة باستخدام Google';
  if(!authFeatures.google)return '<button class="provider google" disabled>'+content+' <small>قريباً</small></button>';
  const embedded=window.top!==window.self, directWindow=Boolean(window.TawfeerGoogle?.directWindow);
  const attribution=['invite','campaign'].filter(key=>billingUuid.test(promoEntry[key]||''));
  if(embedded&&!directWindow&&attribution.length){
    const entry=new URL(KOD_CONFIG.publicAppUrl);
    if(APP_LANGUAGE!=='ar')entry.searchParams.set('lang',APP_LANGUAGE);
    for(const key of attribution)entry.searchParams.set(key,promoEntry[key]);
    entry.hash='auth';
    return '<a class="provider google" target="_blank" rel="noopener noreferrer" href="'+esc(entry.href)+'">'+content+'</a>';
  }
  if(attribution.some(key=>!promoEntry[key+'Offer']?.ticket && promoEntry[key+'Offer']?.valid!==false))
    return '<button class="provider google" type="button" data-provider="google">'+content+'</button>';
  const authorize=new URL('/auth/v1/authorize',KOD_CONFIG.supabaseUrl);
  authorize.searchParams.set('provider','google');
  authorize.searchParams.set('redirect_to',KOD_CONFIG.oauthReturnUrl);
  const target=directWindow?'_top':embedded?'_blank':'_self';
  return '<a class="provider google" rel="noopener noreferrer" target="'+target+'" href="'+esc(authorize.href)+'">'+content+'</a>';
}
function authView(register=false) {
  if(appIdentity&&!previewRole&&appIdentity.role!=='developer_locked')return accountSettingsView();
  const available=authFeatures[authMethod],phone=authMethod==='phone';
  const currentPassword='<div class="field"><label for="auth-password">كلمة المرور</label><input id="auth-password" name="password" type="password" dir="ltr" autocomplete="current-password" required></div>';
  const typeChoice=register?'<div class="account-type" aria-label="نوع الحساب">'+[['customer','حساب عميل'],['merchant','حساب مطعم']].map(([id,label])=>'<button type="button" data-account-type="'+id+'" class="'+(authAccountType===id?'active':'')+'" aria-pressed="'+(authAccountType===id)+'">'+label+'</button>').join('')+'</div>':'';
  return authPanel(register?'إنشاء حساب':'تسجيل الدخول',
    '<div class="auth-tabs"><button data-go="auth" class="'+(!register?'active':'')+'">تسجيل الدخول</button><button data-go="register" class="'+(register?'active':'')+'">إنشاء حساب</button></div>'+
    authMethods()+typeChoice+(available?
      '<form id="auth-form" data-register="'+register+'">'+credentialField() +
      (register?newPinField('auth-new-pin','كلمة المرور · 6 أرقام'):currentPassword)+
      (!register?'<button class="auth-link" type="button" data-go="forgot">نسيت كلمة المرور؟</button>':'')+
      formStatus()+'<button class="btn full" id="auth-submit" type="submit">'+(register?'إنشاء حساب':'تسجيل الدخول')+'</button></form>':
      '<p class="auth-unavailable">'+(phone?'تسجيل الموبايل بانتظار ربط خدمة رسائل التحقق. يمكن استخدام البريد الإلكتروني الآن.':'الدخول بالبريد غير متاح حالياً.')+'</p>')+
    '<div class="auth-divider"><span>أو</span></div>'+googleControl());
}
function forgotView() {
  const isPhone=authMethod==='phone';
  return authPanel('استعادة كلمة المرور','<p>إذا حفظت مفتاح الاستعادة عند التسجيل، تقدر تختار كلمة مرور جديدة فوراً.</p><button class="btn full" data-go="reset-key">استخدم مفتاح الاستعادة</button><div class="auth-divider"><span>أو</span></div>'+authMethods()+(authFeatures[authMethod]?
    '<form id="forgot-form"><p>'+(isPhone?'سنرسل رمزاً إلى رقم حسابك.':(KOD_CONFIG.publicRecoveryMail?'أدخل بريد حسابك ليصلك رابط تعيين كلمة مرور جديدة.':'رابط البريد متاح حالياً لحساب المطوّر. لباقي الحسابات استخدم مفتاح الاستعادة.'))+'</p>'+
    credentialField()+formStatus()+'<button class="btn full">'+(isPhone?'أرسل رمز التحقق':'أرسل رابط الاستعادة')+'</button></form>':
    '<p class="auth-unavailable">استعادة الحساب برسالة نصية بانتظار ربط مزوّد الرسائل.</p>')+
    '<button type="button" class="auth-link" data-go="auth">العودة إلى تسجيل الدخول</button>');
}
function resetKeyView() {
  return authPanel('الاستعادة بالمفتاح','<form id="reset-key-form">'+
    '<div class="field"><label for="recovery-identifier">بريد الحساب أو رقم الموبايل</label><input id="recovery-identifier" name="identifier" type="text" dir="ltr" autocomplete="username" required></div>'+
    '<div class="field"><label for="recovery-key">مفتاح الاستعادة</label><input id="recovery-key" name="key" type="text" dir="ltr" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="54" required></div>'+
    newPinField('next-pin','كلمة المرور الجديدة · 6 أرقام')+newPinField('repeat-pin','أعد كتابة كلمة المرور الجديدة')+
    formStatus()+'<button class="btn full">حفظ كلمة المرور الجديدة</button></form><button class="auth-link" data-go="auth">العودة لتسجيل الدخول</button>');
}
async function resetWithKey(form) {
  const raw=form.elements.identifier.value.trim();
  const identifier=raw.includes('@')?raw.toLowerCase():normalizedPhone(raw);
  const key=form.elements.key.value.toUpperCase().replace(/[\s-]/g,'');
  const password=latinDigits(form.elements['next-pin'].value);
  if(!identifier||!/^[0-9A-F]{36}$/.test(key))throw Error('invalid_recovery_key');
  if(!pinPattern.test(password))throw Error('bad_pin');
  if(password!==latinDigits(form.elements['repeat-pin'].value))throw Error('different_pin');
  const c=await getKodClient();
  const result=await c.rpc('kod_reset_with_recovery_key',{p_identifier:identifier,p_key:key,p_new_pin:password});
  if(result.error)throw result.error;
  if(!result.data)throw Error('invalid_recovery_key');
  form.reset();recoveryUser=null;phoneChallenge=null;
  if(scopeUser)await c.auth.signOut({scope:'local'});
  navigate('auth');toast('تم تغيير كلمة المرور. استخدم الأرقام الجديدة لتسجيل الدخول.');
}
async function offerRecoveryKey(replace=false) {
  const user=appIdentity;
  if(!user||previewRole||!['customer','merchant'].includes(user.role))return;
  const c=await getKodClient();
  const {data,error}=await c.rpc('kod_issue_recovery_key',{p_replace:replace});
  if(scopeUser!==user.id||previewRole)return;
  if(error){if(replace)throw error;return;}
  if(typeof data!=='string'||!/^[A-F0-9]{36}$/.test(data))return;
  const grouped=data.match(/.{6}/g).join('-');
  showModal('<h2>احفظ مفتاح الاستعادة</h2><p>هذا المفتاح يفتح لك استعادة الحساب إذا نسيت كلمة المرور. يظهر مرة واحدة. احفظه في مكان خاص بك.</p>'+
    '<div class="field"><label for="my-recovery-key">مفتاحك الشخصي</label><input id="my-recovery-key" dir="ltr" type="text" readonly autocomplete="off" value="'+grouped+'"></div>'+
    '<div class="workspace-actions"><button class="btn" type="button" data-key-action="copy">نسخ المفتاح</button><button class="text-button" type="button" data-action="close-modal">تم</button></div>');
}
document.addEventListener('click',async event=>{
  const action=event.target.closest('[data-key-action]')?.dataset.keyAction;
  if(!action)return;
  if(action==='copy'){
    const field=document.getElementById('my-recovery-key');if(!field)return;
    try{await navigator.clipboard.writeText(field.value);toast('تم نسخ مفتاح الاستعادة.');}
    catch{field.focus();field.select();toast('اضغط مطولاً لنسخ المفتاح المحدد.');}
  }else if(action==='manage'){
    showModal('<h2>مفتاح الاستعادة</h2><p>يمكن إصدار مفتاح لحسابك بعد تسجيل دخول حديث. عند إصدار مفتاح جديد تنتهي صلاحية أي مفتاح سابق.</p><button class="btn full" data-key-action="replace">إصدار مفتاح جديد</button>');
  }else if(action==='replace'){
    event.target.disabled=true;
    try{await offerRecoveryKey(true);}catch(error){closeModal();toast(authError(error));}
  }
});
function phoneCodeView() {
  if(!phoneChallenge)return appIdentity?accountSettingsView():authView();
  const back=phoneChallenge.kind==='link'?'account':phoneChallenge.kind==='recovery'?'forgot':'register';
  return authPanel('رمز التحقق','<form id="phone-code-form"><p>أدخل رمز الرسالة المرسلة إلى <bdi>'+displayText(phoneChallenge.phone)+'</bdi>.</p>'+
    '<div class="field"><label for="phone-code">رمز الرسالة</label><input id="phone-code" name="code" type="text" dir="ltr" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9٠-٩۰-۹]{6,10}" minlength="6" maxlength="10" required></div>'+
    formStatus()+'<button class="btn full" type="submit">تحقّق من الرمز</button><button class="auth-link" data-resend-phone type="button">إعادة إرسال الرمز</button></form><button data-go="'+back+'" class="auth-link">الرجوع وتعديل الرقم</button>');
}
function confirmedMobile(user){
  const phone=String(user?.phone||'').replace(/^\+/,'');
  return user?.phone_confirmed_at && /^\d{8,15}$/.test(phone)?'+'+phone:'';
}
function phoneAccountSettings(){
  if(!appIdentity||previewRole||appIdentity.role==='developer_locked')return '';
  const number=appIdentity.verifiedPhone;
  const status=number?'<strong><bdi>'+displayText(number)+'</bdi> · رقم مؤكّد</strong>':'<span>لم يتم ربط رقم بعد</span>';
  const form=authFeatures.phone?'<details><summary class="text-button">'+(number?'تغيير رقم الموبايل':'ربط رقم الموبايل')+'</summary><form id="link-phone-form">'+
    '<div class="field"><label for="link-phone">رقم الموبايل مع رمز الدولة</label><input id="link-phone" name="phone" type="tel" dir="ltr" autocomplete="tel" placeholder="+971 50 123 4567" required></div>'+
    formStatus()+'<button class="btn" type="submit">إرسال رمز برسالة نصية</button></form></details>':'<p class="small">خدمة رسائل التفعيل غير متاحة حالياً.</p>';
  return '<section class="phone-account"><div class="settings-row"><span>رقم الموبايل</span>'+status+'</div>'+form+'</section>';
}
async function linkPhone(form){
  const owner=appIdentity?.id,phone=normalizedPhone(form.elements.phone.value);
  if(!owner||previewRole||scopeUser!==owner)throw Error('session_expired');
  if(!authFeatures.phone)throw Error('provider_disabled');
  if(!phone)throw Error('bad_phone');
  if(appIdentity.verifiedPhone===phone)return 'هذا الرقم مؤكّد على حسابك.';
  const c=await getKodClient();
  const identity=await c.auth.getUser();
  if(identity.error||identity.data.user?.id!==owner||scopeUser!==owner)throw Error('session_expired');
  const result=await c.auth.updateUser({phone});
  if(result.error)throw result.error;
  if(scopeUser!==owner||result.data.user?.id!==owner)throw Error('session_expired');
  phoneChallenge={kind:'link',phone,owner};form.reset();navigate('phone-code');
}
async function resendPhone(){
  const challenge=phoneChallenge;
  if(!authFeatures.phone||!challenge)throw Error('provider_disabled');
  const c=await getKodClient();
  if(challenge.kind==='link'&&scopeUser!==challenge.owner)throw Error('session_expired');
  const result=challenge.kind==='recovery'
    ?await c.auth.signInWithOtp({phone:challenge.phone,options:{channel:'sms',shouldCreateUser:false}})
    :await c.auth.resend({phone:challenge.phone,type:challenge.kind==='link'?'phone_change':'sms'});
  if(result.error)throw result.error;
  return 'تم طلب رمز جديد.';
}
document.addEventListener('click',async event=>{
  const button=event.target.closest('[data-resend-phone]');if(!button||button.disabled)return;
  const feedback=button.form.querySelector('#auth-error');
  button.disabled=true;
  try{feedback.textContent=await resendPhone();}catch(error){feedback.textContent=authError(error);}
  finally{button.disabled=false;}
});
function passwordView(reset=false) {
  if(!appIdentity || previewRole || (reset&&recoveryUser!==appIdentity.id))return authPanel('استعادة كلمة المرور','<p>اطلب رابطاً أو رمزاً جديداً لإكمال الاستعادة.</p><button class="btn full" data-go="forgot">استعادة الحساب</button>');
  if(!reset&&appIdentity.role==='developer_locked')return authView();
  return authPanel(reset?'تعيين كلمة مرور جديدة':'تغيير كلمة المرور','<form id="password-form" data-recovery="'+reset+'">'+
    (!reset&&!appIdentity.googleOnly?'<div class="field"><label for="current-password">كلمة المرور الحالية</label><input type="password" name="old" id="current-password" autocomplete="current-password" dir="ltr" required></div>':'')+
    newPinField('next-pin','كلمة المرور الجديدة · 6 أرقام')+newPinField('repeat-pin','أعد كتابة كلمة المرور الجديدة')+
    formStatus()+'<button class="btn full">حفظ كلمة المرور</button></form><button data-go="account" class="auth-link">العودة إلى الحساب</button>');
}
function freshWorkspace(){return {orders:[],restaurants:[],menus:[],profiles:[],memberships:[],favorites:[],contacts:[],settings:{ordering_enabled:false}};}
// This identifier only invalidates local UI caches. PostgreSQL authorizes each request.
function sessionId(session){
  if(!session?.access_token)return null;
  try{return JSON.parse(atob(session.access_token.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).session_id||null;}
  catch{return null;}
}
function switchScope(uid,sid=null) {
  if(scopeUser===uid&&scopeSession===sid)return;
  if(phoneChallenge?.kind==='link'&&phoneChallenge.owner!==uid)phoneChallenge=null;
  if(scopeUser&&scopeUser!==uid){clearGuestCheckout();try{sessionStorage.removeItem(basketKey(scopeUser));}catch{}}
  orderContact={};lastReceipt=null;orderDataStatus='loading';clearCashier();clearSubscriptionScope();clearMarketingScope();clearFeaturedAccount();if(location.hash.startsWith('#cashier/'))cardRoute();
  scopeSession=sid;scopeUser=uid; workspaceEpoch++; workspaceJob=null;
  appIdentity=null; liveWorkspace=freshWorkspace(); cart=null; previewRole=null;
  previewOrders=initialPreviewOrders(); placingOrder=false;
  ownerCustomerId=''; ownerRestaurantId=''; query=''; merchantTab='orders'; developerTab='overview'; orderFilter='all'; try{activeRestaurant=sessionStorage.getItem('kod-menu')||null;}catch{activeRestaurant=null;}
  state=uid?emptyState():loadState();applyPromoArea();
  recoveryUser=null;
  if(liveOrderChannel&&kodClient)kodClient.removeChannel(liveOrderChannel).catch(()=>{});
  liveOrderChannel=null; liveOrderUser=null;
  if(!document.getElementById('modal-shell').hidden)closeModal();
  document.getElementById('modal').innerHTML='';
  previousFocus=null;
  clearTimeout(toastTimer);
  const toastBox=document.getElementById('toast');toastBox.textContent='';toastBox.hidden=true;
  render(current);
}
async function accountFetch(resource, options) {
  const url=new URL(typeof resource==='string'||resource instanceof URL?resource:resource.url,KOD_CONFIG.supabaseUrl);
  const method=(options?.method||resource.method||'GET').toUpperCase();
  const isAuth=url.pathname.startsWith('/auth/v1/');
  const workspaceRead=(method==='GET'&&url.pathname.startsWith('/rest/v1/'))||
    ['/rest/v1/rpc/kod_my_role','/rest/v1/rpc/kod_operator_directory'].includes(url.pathname);
  if(url.origin!==KOD_CONFIG.supabaseUrl||(!isAuth&&!workspaceRead))return fetch(resource,options);
  const incoming=options?.signal||resource.signal;
  const deadline=new AbortController();
  const relay=()=>deadline.abort(incoming.reason);
  if(incoming?.aborted)relay();
  else incoming?.addEventListener('abort',relay,{once:true});
  let timedOut=false;
  const timer=setTimeout(()=>{timedOut=true;deadline.abort();},15000);
  try{return await fetch(resource,{...options,signal:deadline.signal});}
  catch(error){
    if(!timedOut)throw error;
    return new Response(JSON.stringify({error_code:'request_timeout',code:'request_timeout',message:'Connection timeout'}),{
      status:408,headers:{'Content-Type':'application/json'}
    });
  }finally{
    clearTimeout(timer);
    incoming?.removeEventListener('abort',relay);
  }
}
async function readFeatures() {
  try {
    const response=await accountFetch(KOD_CONFIG.supabaseUrl+'/auth/v1/settings',{headers:{apikey:KOD_CONFIG.publishableKey},credentials:'omit'});
    if(!response.ok)return;
    const settings=await response.json(),values={...settings.external};
    values.phone=Boolean(values.phone)&&settings.phone_autoconfirm===false;
    const changed=['email','phone','google'].some(k=>authFeatures[k]!==Boolean(values[k]));
    for(const key of ['email','phone','google']) authFeatures[key]=Boolean(values[key]);
    if(changed&&['account','auth','register','forgot'].includes(current)&&!document.activeElement?.closest('form'))render(current);
  }catch{}
}
async function getKodClient() {
  if(kodClient)return kodClient;
  if(!window.supabase?.createClient)throw Error('client_unavailable');
  kodClient=window.supabase.createClient(KOD_CONFIG.supabaseUrl,KOD_CONFIG.publishableKey,{
    auth:{flowType:'implicit',persistSession:true,detectSessionInUrl:true},
    global:{fetch:accountFetch}
  });
  kodClient.auth.onAuthStateChange((event,session)=>{
    const uid=session?.user?.id||null,sid=sessionId(session),changed=scopeUser!==uid||scopeSession!==sid;
    if(changed)switchScope(uid,sid);
    if(event==='PASSWORD_RECOVERY'&&uid)recoveryUser=uid;
    if(changed||event==='SIGNED_OUT'||event==='PASSWORD_RECOVERY'){
      setTimeout(()=>{if(scopeUser!==uid||scopeSession!==sid)return;refreshLiveWorkspace().then(()=>{
        if(scopeUser!==uid||scopeSession!==sid)return;
        if(recoveryUser&&recoveryUser===uid)navigate('reset-password');
        else if(['auth','register','operator','account','dashboard','developer','merchant','orders','favorites','change-password','membership','cashier'].includes(current))render(current);
      }).catch(()=>{});},0);
    }
  });
  return kodClient;
}
async function allWorkspaceRows(factory,epoch){
  const data=[],pageSize=250;
  while(epoch===workspaceEpoch){
    const result=await factory().range(data.length,data.length+pageSize-1);
    if(result.error)return result;
    data.push(...result.data);
    if(result.data.length<pageSize)break;
  }
  return {data,error:null};
}
async function refreshLiveWorkspace() {
  if(previewRole)return;
  const c=await getKodClient();
  const {data:{session},error:sessionError}=await c.auth.getSession();
  if(sessionError)throw sessionError;
  const uid=session?.user?.id||null;
  switchScope(uid,sessionId(session));
  if(workspaceJob)return workspaceJob;
  const epoch=workspaceEpoch;
  const work=(async()=>{
    let identity=null;
    if(uid){
      const {data:{user},error}=await c.auth.getUser(); if(error||user?.id!==uid)throw Error('session_expired');
      const role=await c.rpc('kod_my_role'); if(role.error)throw role.error;
      identity={id:uid,email:user.email||'',phone:user.phone||'',verifiedPhone:confirmedMobile(user),name:user.user_metadata?.full_name||'حساب توفير',
        role:role.data||'customer',googleOnly:user.app_metadata?.provider==='google'&&!(user.identities||[]).some(i=>i.provider==='email')};
    }
    const operator=identity?.role==='developer';
    const customer=identity&&identity.role!=='developer'&&identity.role!=='merchant';
    function rows(factory){return operator?allWorkspaceRows(factory,epoch):factory();}
    const jobs=[
      rows(()=>c.from('kod_restaurants').select('*').order('id')),
      rows(()=>c.from('kod_menu_items').select('*').order('id')),
      c.from('kod_platform_settings').select('*').eq('id',1).single()
    ];
    if(identity){
      jobs.push(
        rows(()=>{const q=c.from('kod_orders').select('*');return (customer?q.eq('customer_id',uid):q).order('created_at').order('id');}),
        rows(()=>{const q=c.from('kod_profiles').select('*');return (operator?q:q.eq('id',uid)).order('id');}),
        rows(()=>{const q=c.from('kod_memberships').select('*');return (operator?q:q.eq('user_id',uid)).order('user_id');}),
        rows(()=>{const q=c.from('kod_favorites').select('user_id,offer_key');return (operator?q:q.eq('user_id',uid)).order('user_id').order('offer_key');})
      );
      if(operator)jobs.push(rows(()=>c.rpc('kod_operator_directory').order('user_id')));
    }
    const cardJob=hasPersonalCard(identity?.role)?c.rpc('kod_member_card',{p_request:false}):Promise.resolve({data:null});
    const receiptJob=identity?allWorkspaceRows(()=>{
      let q=c.from('kod_instore_receipts').select(CARD_RECEIPT_FIELDS);
      if(customer)q=q.eq('customer_id',uid);
      return q.order('created_at',{ascending:false}).order('id');
    },epoch):Promise.resolve({data:[]});
    const [responses,cardResult,receiptResult]=await Promise.all([Promise.all(jobs),Promise.resolve(cardJob).catch(error=>({error})),Promise.resolve(receiptJob).catch(error=>({error}))]);
    if(epoch!==workspaceEpoch)return;
    appIdentity=identity;
    const failed=responses.find(r=>r.error);
    if(failed){orderDataStatus='error';throw failed.error;}
    const [places,items,settings,orders,profiles,memberships,favorites,contacts]=responses.map(r=>r.data);
    orderDataStatus='ready';
    liveWorkspace={restaurants:places,menus:items,settings,orders:orders||[],profiles:profiles||[],memberships:memberships||[],favorites:favorites||[],contacts:contacts||[],card:cardResult.data||null,cardReceipts:receiptResult.data||[],cardReceiptError:Boolean(receiptResult.error)};
    restoreBasket(uid);
    if(uid)state.favorites=liveWorkspace.favorites.filter(x=>x.user_id===uid).map(x=>x.offer_key).filter(isDiningFavorite);
    if(uid&&liveOrderUser!==uid){
      liveOrderUser=uid;
      liveOrderChannel=c.channel('kod-orders-'+uid).on('postgres_changes',{event:'*',schema:'public',table:'kod_orders'},()=>{
        if(scopeUser!==uid||previewRole)return;
        refreshLiveWorkspace().then(()=>{if(scopeUser===uid&&['dashboard','orders','receipt','merchant','developer'].includes(current)&&document.getElementById('modal-shell').hidden)render(current);}).catch(()=>{});
      }).subscribe();
    }
  })();
  workspaceJob=work;
  try{await work;}finally{if(workspaceJob===work)workspaceJob=null;}
}
async function refreshAfterPassword(){
  if(workspaceJob)await workspaceJob.catch(()=>{});
  try{await refreshLiveWorkspace();}
  catch(error){if(!appIdentity||appIdentity.id!==scopeUser)throw error;orderDataStatus='error';}
}
const afterLogin=()=>recoveryUser&&appIdentity?.id===recoveryUser?'reset-password':resumeGuestCheckout()?'cart':resumeCardRoute()||ROLE_ROUTES[appIdentity?.role]||'account';
async function submitAuth(form) {
  const c=await getKodClient(),register=form.dataset.register==='true',method=authMethod;
  const identifier=method==='email'?form.elements.identifier.value.trim().toLowerCase():normalizedPhone(form.elements.identifier.value);
  if(!identifier)throw Error('bad_phone');
  if(!authFeatures[method])throw Error('provider_disabled');
  const raw=register?form.elements['auth-new-pin'].value:form.elements.password.value;
  const asDigits=latinDigits(raw),password=pinPattern.test(asDigits)?asDigits:raw;
  if(register&&!pinPattern.test(password))throw Error('bad_pin');
  const credentials={[method]:identifier,password};
  const attribution=register&&authAccountType==='customer'?await registrationMarketingData():{};
  const delivery=method==='phone'?{channel:'sms'}:{emailRedirectTo:KOD_CONFIG.oauthReturnUrl};
  const result=register?await c.auth.signUp({...credentials,options:{data:{requested_account_type:authAccountType,...attribution},...delivery}}):await c.auth.signInWithPassword(credentials);
  if(!register&&method==='phone'&&result.error?.code==='phone_not_confirmed'){
    const resend=await c.auth.resend({phone:identifier,type:'sms'});if(resend.error)throw resend.error;
    phoneChallenge={phone:identifier,kind:'signup'};navigate('phone-code');return;
  }
  if(result.error)throw result.error;
  if(!result.data.session){
    if(register&&method==='phone'){phoneChallenge={phone:identifier,kind:'signup'};form.reset();navigate('phone-code');return;}
    throw Error('signup_incomplete');
  }
  form.reset();previewRole=null;recoveryUser=null;await refreshAfterPassword();await claimMarketingSignup();navigate(afterLogin());await offerRecoveryKey();
}
async function startProvider(provider) {
  if(provider!=='google'||!authFeatures.google)throw Error('provider_disabled');
  await registrationMarketingData();
  if(!['auth','register'].includes(current)||appIdentity)return;
  showModal('<h2>تسجيل الدخول</h2>'+googleControl());
}
async function requestRecovery(form) {
  const c=await getKodClient();
  if(authMethod==='phone'){
    const phone=normalizedPhone(form.elements.identifier.value);
    if(!phone)throw Error('bad_phone');
    if(!authFeatures.phone)throw Error('provider_disabled');
    const {error}=await c.auth.signInWithOtp({phone,options:{channel:'sms',shouldCreateUser:false}});
    if(error&&error.code!=='user_not_found')throw error;
    phoneChallenge={phone,kind:'recovery'};navigate('phone-code');return;
  }
  const email=form.elements.identifier.value.trim().toLowerCase();
  const {error}=await c.auth.resetPasswordForEmail(email,{redirectTo:KOD_CONFIG.oauthReturnUrl});
  if(error&&!['user_not_found','email_address_not_authorized'].includes(error.code))throw error;
  const confirmation='إذا كان البريد مرتبطاً بحساب، يصلك رابط الاستعادة. تفقد الرسائل غير المرغوب فيها أيضاً.';
  if(KOD_CONFIG.publicRecoveryMail)return confirmation;
  return confirmation+' '+'اختر «استخدم مفتاح الاستعادة» وأدخل المفتاح الخاص بحسابك.';
}
async function checkPhoneCode(form) {
  const challenge=phoneChallenge;if(!challenge)throw Error('otp_expired');
  const linking=challenge.kind==='link',token=latinDigits(form.elements.code.value).trim();
  if(!/^\d{6,10}$/.test(token))throw Error('otp_expired');
  const c=await getKodClient();
  if(linking&&(scopeUser!==challenge.owner||appIdentity?.id!==challenge.owner))throw Error('session_expired');
  const result=await c.auth.verifyOtp({phone:challenge.phone,token,type:linking?'phone_change':'sms'});
  if(result.error)throw result.error;
  if(phoneChallenge!==challenge)throw Error('session_expired');
  const user=result.data.user;
  if(!user||(!linking&&!result.data.session)||confirmedMobile(user)!==challenge.phone)throw Error('otp_expired');
  if(linking&&(user.id!==challenge.owner||scopeUser!==challenge.owner))throw Error('session_expired');
  phoneChallenge=null;form.reset();await refreshAfterPassword();
  if(appIdentity?.id!==user.id)throw Error('session_expired');
  if(linking){navigate('account');toast('تم تأكيد رقم الموبايل وربطه بحسابك.');return;}
  if(challenge.kind==='recovery')recoveryUser=user.id;
  navigate(afterLogin());
  if(challenge.kind==='signup'){await claimMarketingSignup();await offerRecoveryKey();}
}
async function changePassword(form) {
  const next=latinDigits(form.elements['next-pin'].value),repeat=latinDigits(form.elements['repeat-pin'].value);
  if(!pinPattern.test(next))throw Error('bad_pin');
  if(next!==repeat)throw Error('different_pin');
  const user=appIdentity,reset=form.dataset.recovery==='true';
  if(!user||previewRole||(reset&&recoveryUser!==user.id))throw Error('proof_required');
  const old=form.elements.old?.value||'',oldNormalized=pinPattern.test(latinDigits(old))?latinDigits(old):old;
  const c=await getKodClient();
  if(!reset&&!user.googleOnly){
    const check=await c.auth.signInWithPassword({[user.email?'email':'phone']:user.email||user.phone,password:oldNormalized});
    if(check.error||check.data.user?.id!==user.id)throw Error('wrong_current');
  }else if(!reset&&user.googleOnly){
    const proof=await c.auth.getClaims();
    const claims=proof.data?.claims;
    if(proof.error||claims?.sub!==user.id||!claims.amr?.some(m=>m.method==='oauth'&&m.timestamp>Date.now()/1000-900))
      throw Error('recent_google_required');
  }
  if(scopeUser!==user.id)throw Error('session_expired');
  const {error}=await c.auth.updateUser({password:next,...(!reset&&old?{current_password:oldNormalized}:{})});
  if(error)throw error;
  if(reset&&user.role==='developer_locked'){
    recoveryUser=null;
    const signed=await c.auth.signInWithPassword({email:user.email,password:next});
    if(signed.error){
      await signOutKod();toast('تم حفظ كلمة المرور. سجّل الدخول بها.');return;
    }
  }
  form.reset();recoveryUser=null;await refreshAfterPassword();navigate(reset?afterLogin():'account');toast('تم حفظ كلمة المرور الجديدة.');
}
function authError(error){
  const code=error?.code||error?.message||'';
  if(error?.status===408||code==='request_timeout'||error?.name==='AbortError')
    return 'استغرق الاتصال وقتاً طويلاً. تحقق من الإنترنت وأعد المحاولة.';
  if(/rate_limit|too_many|retry_later/.test(code))return 'محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة.';
  if(code.includes('recent_login_required')||error?.message?.includes('recent_login_required'))return 'سجّل الخروج وادخل من جديد، ثم اطلب مفتاح الاستعادة من الإعدادات.';
  const messages={invite_unavailable:'تعذّر تثبيت رابط الدعوة. أعد المحاولة بعد التحقق من الاتصال.',bad_phone:'أدخل رقم موبايل صحيحاً مع رمز الدولة.',bad_pin:'كلمة المرور تتكون من 6 أرقام فقط.',recent_google_required:'ادخل مجدداً باستخدام Google، ثم اختر كلمة المرور من الإعدادات.',invalid_recovery_key:'راجع بريد الحساب أو رقمه ومفتاح الاستعادة. يمكن استخدام كل مفتاح مرة واحدة.',
    session_expired:'سجّل الدخول مجدداً وأعد المحاولة.',sms_send_failed:'تعذّر إرسال الرسالة. أعد المحاولة لاحقاً.',phone_exists:'تعذّر ربط هذا الرقم بالحساب.',different_pin:'كلمتا المرور غير متطابقتين.',wrong_current:'كلمة المرور الحالية غير صحيحة.',
    invalid_credentials:'بيانات الدخول غير صحيحة.',proof_required:'افتح رابطاً جديداً في بريد الحساب وأعد المحاولة.',
    user_already_exists:'تعذّر إنشاء الحساب. جرّب تسجيل الدخول أو استعادة كلمة المرور.',
    otp_expired:'رمز التحقق أو الرابط منتهي الصلاحية. اطلب رمزاً جديداً.',provider_disabled:'طريقة الدخول هذه غير متاحة حالياً.',
    same_password:'اختر كلمة مرور مختلفة عن الحالية.',weak_password:'تعذّر قبول كلمة المرور. أدخل 6 أرقام.',
    email_address_not_authorized:'خدمة بريد توفير غير مهيأة لإرسال رسائل إلى هذا العنوان حالياً.',signup_incomplete:'لم تكتمل جلسة التسجيل. راجع طريقة الدخول وحاول مجدداً.'};
  return messages[code]||'تعذّر إكمال الطلب. راجع الاتصال والبيانات ثم حاول مجدداً.';
}
document.addEventListener('submit',async event=>{
  const form=event.target,handlers={'auth-form':submitAuth,'forgot-form':requestRecovery,'reset-key-form':resetWithKey,'phone-code-form':checkPhoneCode,'link-phone-form':linkPhone,'password-form':changePassword};
  const handler=handlers[form.id];if(typeof handler!=='function'||!Object.hasOwn(handlers,form.id))return;
  event.preventDefault();event.stopImmediatePropagation();
  const status=form.querySelector('#auth-error'),button=event.submitter||form.querySelector('button[type="submit"],button.btn');
  if(button?.disabled)return;
  if(button){button.disabled=true;button.setAttribute('aria-busy','true');}
  status.textContent='جارٍ التحقق…';
  try{status.textContent=(await handler(form))||'';}
  catch(error){status.textContent=authError(error);}
  finally{if(button){button.disabled=false;button.removeAttribute('aria-busy');}}
});
async function initializeKod() {
  const raw=location.hash.slice(1),params=new URLSearchParams(raw),custom=raw.startsWith('confirm?');
  const sessionCallback=params.has('access_token'),isRecovery=params.get('type')==='recovery';
  readFeatures();
  try{
    const c=await getKodClient();
    if(custom){
      const data=new URLSearchParams(raw.slice(8)),type=data.get('type');
      history.replaceState(null,'',location.pathname+'#auth');
      if(!['email','recovery','magiclink'].includes(type)||!data.get('token_hash'))throw Error('otp_expired');
      const result=await c.auth.verifyOtp({type,token_hash:data.get('token_hash')});if(result.error)throw result.error;
      if(type==='recovery'){switchScope(result.data.user.id,sessionId(result.data.session));recoveryUser=result.data.user.id;}
    }
    await refreshLiveWorkspace();
    if(appIdentity)await claimMarketingSignup();
    if(isRecovery&&sessionCallback&&appIdentity)recoveryUser=appIdentity.id;
    if(params.has('error')){history.replaceState(null,'',location.pathname+'#forgot');render('forgot');toast('انتهت صلاحية الرابط. اطلب رابطاً جديداً.');return;}
    if(appIdentity&&(custom||sessionCallback||recoveryUser||['auth','register'].includes(current))){
      navigate(afterLogin());
      if((custom||sessionCallback)&&!recoveryUser)await offerRecoveryKey();
    }else if(!document.activeElement?.closest('form'))render(current);
  }catch(error){orderDataStatus='error';if(current==='food')render('food');if(custom||sessionCallback)toast(authError(error));}
}
async function signOutKod() {
  try{sessionStorage.removeItem('kod-card-return');}catch{}
  const c=await getKodClient();
  const {error}=await c.auth.signOut({scope:'local'});
  if(error)throw error;
  cleanPromoEntry();companyToken='';writePromo('kod-company-seat',null);recoveryUser=null;phoneChallenge=null;switchScope(null);navigate('auth');
}

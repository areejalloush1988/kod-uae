-- An operator is provisioned by verified user ID in the private role table.
-- Keep registrations independent of any personal mailbox.
begin;
drop trigger if exists kod_verified_owner_identity on auth.identities;
drop trigger if exists kod_verified_owner_confirmation on auth.users;
drop function if exists kod_private.kod_verified_owner_identity();
drop function if exists kod_private.kod_verified_owner_confirmation();
-- Supabase's automatic RLS event trigger does not need public RPC access.
do $$begin
 if to_regprocedure('public.rls_auto_enable()') is not null then
  revoke execute on function public.rls_auto_enable() from public,anon,authenticated;
 end if;
end$$;
commit;

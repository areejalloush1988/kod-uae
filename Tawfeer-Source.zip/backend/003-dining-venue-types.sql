begin;
set local lock_timeout = '4s';
-- Expand the existing dining classification on new and existing databases.
alter table public.kod_restaurants
  drop constraint kod_restaurants_category_check,
  add constraint kod_restaurants_category_check check (category in ('food','coffee','cafeteria')),
  alter column photo set default 'feast';
grant insert (category) on public.kod_restaurants to authenticated;
commit;

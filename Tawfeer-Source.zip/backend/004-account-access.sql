-- Apply while the existing operator account is still verified. New installations
-- provision the operator role by verified user UUID through a trusted admin.
begin;
drop trigger if exists kod_verified_owner_identity on auth.identities;
drop trigger if exists kod_verified_owner_confirmation on auth.users;
drop function if exists kod_private.kod_verified_owner_identity();
drop function if exists kod_private.kod_verified_owner_confirmation();

create table if not exists kod_private.kod_operator_security (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  pin_hash text,
  failures integer not null default 0,
  retry_at timestamptz
);
create table if not exists kod_private.kod_operator_sessions (
  session_id uuid primary key references auth.sessions(id) on delete cascade,
  user_id uuid not null references kod_private.kod_operator_security(user_id) on delete cascade,
  unlocked_until timestamptz,
  recovery_used boolean not null default false
);
alter table kod_private.kod_operator_security enable row level security;
alter table kod_private.kod_operator_sessions enable row level security;
revoke all on kod_private.kod_operator_security,kod_private.kod_operator_sessions from public,anon,authenticated;

insert into kod_private.kod_operator_security(user_id,email)
select u.id,lower(u.email) from auth.users u join kod_private.kod_account_roles r on r.user_id=u.id
where r.role='developer' and u.email_confirmed_at is not null and u.email is not null
on conflict (user_id) do nothing;

-- Customer access is scoped to the existing UID. An operator also needs an
-- independently authenticated mailbox and a PIN grant in this exact session.
create or replace function kod_private.kod_role() returns text
language sql stable security definer set search_path='' as $$
  select case when r.role='developer' and not exists(
    select 1 from kod_private.kod_operator_sessions g join auth.sessions s on s.id=g.session_id
    where g.user_id=r.user_id and s.user_id=r.user_id
      and g.session_id=nullif(auth.jwt()->>'session_id','')::uuid and g.unlocked_until>now()
  ) then 'developer_locked' else r.role end
  from kod_private.kod_account_roles r where r.user_id=(select auth.uid())
$$;

-- A contact used for operator proof cannot be relinked through a client session.
create or replace function kod_private.kod_guard_operator_contact() returns trigger
language plpgsql security definer set search_path='' as $$
begin
  if exists(select 1 from kod_private.kod_operator_security p where p.user_id=old.id)
     and (lower(coalesce(old.email,''))<>lower(coalesce(new.email,'')) or coalesce(old.phone,'')<>coalesce(new.phone,'')) then
    raise exception 'operator_contact_locked';
  end if;
  return new;
end$$;
drop trigger if exists kod_guard_operator_contact on auth.users;
create trigger kod_guard_operator_contact before update of email,phone on auth.users
for each row execute function kod_private.kod_guard_operator_contact();

create or replace function kod_private.kod_operator_access(p_action text,p_pin text,p_new_pin text default null)
returns text language plpgsql security definer set search_path='' as $$
declare
  actor uuid := auth.uid();
  sid uuid := nullif(auth.jwt()->>'session_id','')::uuid;
  credential kod_private.kod_operator_security%rowtype;
  proof_at timestamptz;
  had_recovery boolean;
begin
  if actor is null or sid is null or p_action not in ('unlock','change','recover')
     or not exists(select 1 from auth.sessions s where s.id=sid and s.user_id=actor) then return 'denied'; end if;
  select p.* into credential from kod_private.kod_operator_security p
  join auth.users u on u.id=p.user_id join kod_private.kod_account_roles r on r.user_id=u.id
  where p.user_id=actor and r.role='developer' and lower(u.email)=p.email and u.email_confirmed_at is not null
    and coalesce(u.phone,'')='' for update of p;
  if not found then return 'denied'; end if;
  select max(to_timestamp((m->>'timestamp')::double precision)) into proof_at
  from jsonb_array_elements(coalesce(auth.jwt()->'amr','[]'::jsonb)) m
  where m->>'method' in ('otp','magiclink','recovery');
  if proof_at is null or proof_at < now()-interval '12 hours' then return 'proof_required'; end if;
  if p_action in ('change','recover') and (p_new_pin is null or p_new_pin !~ '^[0-9]{6}$') then return 'invalid_pin'; end if;
  if p_action='recover' then
    -- Hosted Auth also records email recovery links as 'otp'. Only a fresh
    -- verified mailbox proof for the pinned, phone-free account can recover it.
    if not exists(select 1 from jsonb_array_elements(auth.jwt()->'amr') m where m->>'method' in ('recovery','otp','magiclink')
       and to_timestamp((m->>'timestamp')::double precision)>now()-interval '15 minutes') then return 'proof_required'; end if;
    select recovery_used into had_recovery from kod_private.kod_operator_sessions where session_id=sid;
    if coalesce(had_recovery,false) then return 'proof_required'; end if;
  else
    if credential.retry_at>now() then return 'retry_later'; end if;
    if p_pin is null or p_pin !~ '^[0-9]{6}$' or credential.pin_hash is null then return 'invalid_pin'; end if;
    if extensions.crypt(p_pin,credential.pin_hash)<>credential.pin_hash then
      update kod_private.kod_operator_security set failures=case when failures>=4 then 0 else failures+1 end,
        retry_at=case when failures>=4 then now()+interval '15 minutes' else null end where user_id=actor;
      return 'invalid_pin';
    end if;
    if p_action='change' and not exists(select 1 from kod_private.kod_operator_sessions where session_id=sid
       and user_id=actor and unlocked_until>now()) then return 'proof_required'; end if;
  end if;
  if p_action in ('change','recover') then
    update kod_private.kod_operator_security set pin_hash=extensions.crypt(p_new_pin,extensions.gen_salt('bf',10))
      where user_id=actor;
    update kod_private.kod_operator_sessions set unlocked_until=null where user_id=actor;
  end if;
  update kod_private.kod_operator_security set failures=0,retry_at=null where user_id=actor;
  insert into kod_private.kod_operator_sessions(session_id,user_id,unlocked_until,recovery_used)
  values(sid,actor,least(now()+interval '8 hours',proof_at+interval '12 hours'),p_action='recover')
  on conflict(session_id) do update set unlocked_until=excluded.unlocked_until,
     recovery_used=kod_private.kod_operator_sessions.recovery_used or excluded.recovery_used;
  return 'ok';
end$$;
create or replace function public.kod_operator_access(p_action text,p_pin text,p_new_pin text default null)
returns text language sql security invoker set search_path='' as $$
  select kod_private.kod_operator_access(p_action,p_pin,p_new_pin)
$$;
revoke all on function kod_private.kod_guard_operator_contact() from public,anon,authenticated;
revoke all on function kod_private.kod_operator_access(text,text,text),public.kod_operator_access(text,text,text) from public,anon;
grant execute on function kod_private.kod_operator_access(text,text,text),public.kod_operator_access(text,text,text) to authenticated;
commit;

begin;
create table if not exists kod_private.kod_recovery_keys (
  user_id uuid primary key references auth.users(id) on delete cascade,
  key_digest bytea not null unique,
  issued_at timestamptz not null default now()
);
alter table kod_private.kod_recovery_keys enable row level security;
revoke all on kod_private.kod_recovery_keys from public,anon,authenticated;
create or replace function kod_private.kod_issue_recovery_key(p_replace boolean default false)
returns text language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); recovery_key text;
begin
  if actor is null or not exists(select 1 from kod_private.kod_account_roles where user_id=actor and role in('customer','merchant'))
    or not exists(select 1 from auth.sessions s where s.id=nullif(auth.jwt()->>'session_id','')::uuid and s.user_id=actor)
    or not exists(select 1 from jsonb_array_elements(coalesce(auth.jwt()->'amr','[]'::jsonb)) m
      where m->>'method' in ('password','otp','oauth','recovery','magiclink','email/signup')
      and to_timestamp((m->>'timestamp')::double precision)>now()-interval '15 minutes') then raise exception 'recent_login_required'; end if;
  recovery_key=encode(extensions.gen_random_bytes(18),'hex');
  insert into kod_private.kod_recovery_keys as existing(user_id,key_digest)
  values(actor,extensions.digest(recovery_key,'sha256')) on conflict(user_id) do update
    set key_digest=excluded.key_digest,issued_at=now() where p_replace;
  if not found then return null; end if;
  return upper(recovery_key);
end$$;
create or replace function public.kod_issue_recovery_key(p_replace boolean default false)
returns text language sql security invoker set search_path='' as $$
  select kod_private.kod_issue_recovery_key(p_replace)
$$;
revoke all on function kod_private.kod_issue_recovery_key(boolean),public.kod_issue_recovery_key(boolean) from public,anon;
grant execute on function kod_private.kod_issue_recovery_key(boolean),public.kod_issue_recovery_key(boolean) to authenticated;

-- The key, the identifier, and the new password must match in a single transaction.
-- Public callers see a boolean. No caller supplies a user ID or receives a session.
create or replace function kod_private.kod_reset_with_recovery_key(p_identifier text,p_key text,p_new_pin text)
returns boolean language plpgsql security definer set search_path='' as $$
declare actor uuid; identifier text; candidate bytea;
begin
  if p_identifier is null or length(p_identifier) not between 4 and 320
     or p_key is null or p_key !~ '^[0-9A-Fa-f]{36}$'
     or p_new_pin is null or p_new_pin !~ '^[0-9]{6}$' then return false; end if;
  identifier=lower(btrim(p_identifier));
  candidate=extensions.digest(lower(p_key),'sha256');
  delete from kod_private.kod_recovery_keys k using auth.users u,kod_private.kod_account_roles r
  where k.key_digest=candidate and k.user_id=u.id and r.user_id=u.id
    and r.role in ('customer','merchant') and u.deleted_at is null
    and (lower(u.email)=identifier or (coalesce(u.phone,'')<>'' and ltrim(u.phone,'+')=ltrim(identifier,'+')))
  returning k.user_id into actor;
  if actor is null then return false; end if;
  update auth.users set encrypted_password=extensions.crypt(p_new_pin,extensions.gen_salt('bf',10)),
    updated_at=clock_timestamp(),recovery_token='',recovery_sent_at=null where id=actor;
  delete from auth.sessions where user_id=actor;
  return true;
end$$;
create or replace function public.kod_reset_with_recovery_key(p_identifier text,p_key text,p_new_pin text)
returns boolean language sql security invoker set search_path='' as $$
  select kod_private.kod_reset_with_recovery_key(p_identifier,p_key,p_new_pin)
$$;
revoke all on function kod_private.kod_reset_with_recovery_key(text,text,text),public.kod_reset_with_recovery_key(text,text,text) from public;
grant execute on function kod_private.kod_reset_with_recovery_key(text,text,text),public.kod_reset_with_recovery_key(text,text,text) to anon,authenticated;
drop function if exists public.kod_claim_recovery_key(text,text,uuid);
drop function if exists public.kod_finish_recovery_key(uuid,uuid,boolean);
commit;

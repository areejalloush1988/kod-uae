begin;
-- Reuse the existing verified account and its native Auth password. The cutoff
-- asks older password-only sessions to sign in once under the new policy.
alter table kod_private.kod_operator_security
  add column if not exists direct_login_from timestamptz not null default date_trunc('second',now());

create or replace function kod_private.kod_role() returns text
language sql stable security definer set search_path='' as $$
  select case
    when r.role<>'developer' then r.role
    when exists(
      select 1 from kod_private.kod_operator_security p
      join auth.users u on u.id=p.user_id and lower(u.email)=p.email
      join auth.sessions s on s.user_id=u.id and s.id=nullif(auth.jwt()->>'session_id','')::uuid
      where p.user_id=r.user_id and u.email_confirmed_at is not null
        and (s.not_after is null or s.not_after>now()) and (
          exists(select 1 from jsonb_array_elements(coalesce(auth.jwt()->'amr','[]'::jsonb)) m
            where m->>'method'='password'
            and to_timestamp((m->>'timestamp')::double precision)>=p.direct_login_from)
          or exists(select 1 from kod_private.kod_operator_sessions old_grant
            where old_grant.session_id=s.id and old_grant.user_id=u.id and old_grant.unlocked_until>now())
        )
    ) then 'developer' else 'developer_locked' end
  from kod_private.kod_account_roles r where r.user_id=(select auth.uid())
$$;

-- Existing fully unlocked sessions can finish normally; no new legacy grants can be issued.
drop function if exists public.kod_operator_access(text,text,text);
drop function if exists kod_private.kod_operator_access(text,text,text);

create or replace function kod_private.kod_operator_directory()
returns table(user_id uuid,login_email text,mobile text)
language plpgsql stable security definer set search_path='' as $$
begin
  if auth.uid() is null or not kod_private.kod_is_developer() then
    raise exception using errcode='42501',message='developer_required';
  end if;
  return query select p.id,u.email::text,u.phone::text
    from public.kod_profiles p join auth.users u on u.id=p.id where u.deleted_at is null;
end$$;
create or replace function public.kod_operator_directory()
returns table(user_id uuid,login_email text,mobile text)
language sql stable security invoker set search_path='' as $$
  select * from kod_private.kod_operator_directory()
$$;
revoke all on function kod_private.kod_operator_directory(),public.kod_operator_directory() from public,anon;
grant execute on function kod_private.kod_operator_directory(),public.kod_operator_directory() to authenticated;

drop policy if exists kod_operator_favorites_read on public.kod_favorites;
create policy kod_operator_favorites_read on public.kod_favorites for select to authenticated
  using((select kod_private.kod_is_developer()));
drop policy if exists kod_operator_menu_insert on public.kod_menu_items;
create policy kod_operator_menu_insert on public.kod_menu_items for insert to authenticated
  with check ((select kod_private.kod_is_developer()));
drop policy if exists kod_operator_menu_update on public.kod_menu_items;
create policy kod_operator_menu_update on public.kod_menu_items for update to authenticated
  using ((select kod_private.kod_is_developer())) with check ((select kod_private.kod_is_developer()));

create or replace function kod_private.kod_set_restaurant_open(p_restaurant_id uuid,p_open boolean) returns void
language plpgsql security definer set search_path='' as $$
begin
  if auth.uid() is null or not (kod_private.kod_is_developer() or
    (coalesce(kod_private.kod_role(),'')='merchant' and kod_private.kod_owns_restaurant(p_restaurant_id))) then
    raise exception 'merchant_required';
  end if;
  if p_open is null then raise exception 'open_state_required'; end if;
  update public.kod_restaurants set is_open=p_open where id=p_restaurant_id and approved and not is_demo;
  if not found then raise exception 'restaurant_not_approved'; end if;
end$$;
commit;

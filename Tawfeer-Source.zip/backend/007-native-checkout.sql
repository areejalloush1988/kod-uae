begin;

-- Each signed-in role can buy for its own account. The private function
-- still derives the buyer from auth.uid() and enforces each restaurant's status.
create or replace function kod_private.kod_place_order(
 p_restaurant_id uuid,p_lines jsonb,p_fulfillment text,p_customer_name text,p_contact_phone text,
 p_delivery_address text,p_notes text,p_request_id uuid
) returns public.kod_orders language plpgsql security definer set search_path=''
as $$declare
 v_uid uuid:=auth.uid(); v_r public.kod_restaurants; v_item public.kod_menu_items;
 v_order public.kod_orders; v_line jsonb; v_items jsonb:='[]'; v_seen uuid[]:='{}';
 v_item_id uuid; v_qty integer; v_sub integer:=0; v_discount integer:=0; v_fee integer:=0;
 v_percent integer:=0; v_fingerprint text;
begin
 if v_uid is null then raise exception 'authentication_required'; end if;
 if coalesce(kod_private.kod_role(),'') not in ('customer','merchant','developer') then raise exception 'customer_account_required'; end if;
 if p_request_id is null then raise exception 'request_id_required'; end if;
 if p_fulfillment not in('delivery','pickup') or p_fulfillment is null then raise exception 'invalid_fulfillment'; end if;
 if char_length(trim(p_customer_name)) not between 1 and 60 or p_customer_name is null
 or p_contact_phone is null or p_contact_phone !~ '^\+[1-9][0-9]{7,14}$'
 or coalesce(char_length(p_delivery_address),0)>300 or coalesce(char_length(p_notes),0)>300
 or (p_fulfillment='delivery' and coalesce(char_length(trim(p_delivery_address)),0)<5)
 then raise exception 'invalid_contact_details'; end if;
 if p_lines is null or jsonb_typeof(p_lines)<>'array' or jsonb_array_length(p_lines) not between 1 and 20
 then raise exception 'invalid_lines'; end if;
 v_fingerprint:=encode(sha256(convert_to(jsonb_build_object('r',p_restaurant_id,'l',p_lines,'f',p_fulfillment,'n',p_customer_name,'p',p_contact_phone,'a',p_delivery_address,'notes',p_notes)::text,'UTF8')),'hex');
 perform pg_advisory_xact_lock(hashtextextended(v_uid::text||p_request_id::text,0));
 select * into v_order from public.kod_orders where customer_id=v_uid and request_id=p_request_id;
 if found then
  if v_order.request_fingerprint<>v_fingerprint then raise exception 'idempotency_conflict'; end if;
  return v_order;
 end if;
 if not exists(select 1 from public.kod_platform_settings where id=1 and ordering_enabled) then raise exception 'ordering_not_enabled'; end if;
 select * into v_r from public.kod_restaurants where id=p_restaurant_id for update;
 if not found or not v_r.approved or not v_r.is_open or v_r.is_demo then raise exception 'restaurant_unavailable'; end if;
 for v_line in select value from jsonb_array_elements(p_lines) loop
  if jsonb_typeof(v_line)<>'object' or coalesce(v_line->>'quantity','') !~ '^[1-9][0-9]?$'
  then raise exception 'invalid_quantity'; end if;
  v_qty:=(v_line->>'quantity')::integer;
  if v_qty not between 1 and 20 then raise exception 'invalid_quantity'; end if;
  v_item_id:=(v_line->>'item_id')::uuid;
  if v_item_id is null or v_item_id=any(v_seen) then raise exception 'duplicate_or_missing_item'; end if;
  v_seen:=array_append(v_seen,v_item_id);
  select * into v_item from public.kod_menu_items where id=v_item_id and restaurant_id=p_restaurant_id for share;
  if not found or not v_item.is_available then raise exception 'item_unavailable'; end if;
  v_sub:=v_sub+v_item.price_cents*v_qty;
  if v_sub>200000 then raise exception 'order_limit_exceeded'; end if;
  v_items:=v_items||jsonb_build_array(jsonb_build_object('item_id',v_item.id,'name',v_item.name,'quantity',v_qty,'unit_price_cents',v_item.price_cents));
 end loop;
 if v_sub<v_r.minimum_order_cents then raise exception 'minimum_order_not_met'; end if;
 if exists(select 1 from public.kod_memberships where user_id=v_uid and status='active' and expires_at>now()) then v_percent:=v_r.percent; end if;
 v_discount:=round(v_sub::numeric*v_percent/100)::integer;
 v_fee:=case when p_fulfillment='delivery' then v_r.delivery_fee_cents else 0 end;
 insert into public.kod_orders(customer_id,restaurant_id,restaurant_name,request_id,request_fingerprint,customer_name,contact_phone,delivery_address,notes,fulfillment,items,subtotal_cents,discount_cents,delivery_fee_cents,total_cents,events)
 values(v_uid,v_r.id,v_r.name,p_request_id,v_fingerprint,trim(p_customer_name),p_contact_phone,
 case when p_fulfillment='delivery' then trim(p_delivery_address) else '' end,coalesce(p_notes,''),p_fulfillment,v_items,v_sub,v_discount,v_fee,v_sub-v_discount+v_fee,jsonb_build_array(jsonb_build_object('status','pending','at',now())))
 returning * into v_order;
 return v_order;
end$$;
create or replace function public.kod_checkout_order(
 p_restaurant_id uuid,p_lines jsonb,p_fulfillment text,p_customer_name text,p_contact_phone text,
 p_delivery_address text,p_notes text,p_request_id uuid,p_expected_total integer
) returns public.kod_orders language plpgsql security invoker set search_path=''
as $$
declare placed public.kod_orders;
begin
 if p_expected_total is null or p_expected_total < 0 then raise exception 'price_changed'; end if;
 placed := kod_private.kod_place_order(p_restaurant_id,p_lines,p_fulfillment,p_customer_name,
   p_contact_phone,p_delivery_address,p_notes,p_request_id);
 if placed.total_cents <> p_expected_total then raise exception 'price_changed'; end if;
 return placed;
end
$$;
revoke all on function public.kod_checkout_order(uuid,jsonb,text,text,text,text,text,uuid,integer) from public,anon;
grant execute on function public.kod_checkout_order(uuid,jsonb,text,text,text,text,text,uuid,integer) to authenticated;
update public.kod_platform_settings set ordering_enabled=true where id=1;
notify pgrst,'reload schema';
commit;

begin;
-- Only contact information the business publishes for customers belongs here.
alter table public.kod_restaurants
  add column branch_address text check (char_length(branch_address) between 1 and 200),
  add column public_phone text check (public_phone ~ '^[+][1-9][0-9]{7,14}$'),
  add column public_whatsapp text check (public_whatsapp ~ '^[+][1-9][0-9]{7,14}$');
grant insert (branch_address,public_phone,public_whatsapp),
      update (branch_address,public_phone,public_whatsapp) on public.kod_restaurants to authenticated;
create policy kod_restaurant_contact_edit on public.kod_restaurants for update to authenticated
  using (owner_id=(select auth.uid()) or (select kod_private.kod_is_developer()))
  with check (owner_id=(select auth.uid()) or (select kod_private.kod_is_developer()));
notify pgrst,'reload schema';
commit;

begin;

create table public.kod_subscription_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_id uuid not null,
  months smallint not null check (months in (1,3,6,12)),
  amount_fils integer not null check (amount_fils>0),
  rail text not null check (rail in ('stripe','etisalat','du')),
  product_ref text not null default '',
  status text not null default 'pending' check (status in ('pending','paid')),
  created_at timestamptz not null default now(),
  lease_id uuid, lease_until timestamptz,
  checkout_ref text, checkout_url text, checkout_until timestamptz,
  transaction_ref text, paid_at timestamptz, valid_until timestamptz,
  unique (user_id,request_id)
);
create index kod_sub_orders_member_idx on public.kod_subscription_orders(user_id, created_at desc);
create unique index kod_sub_orders_transaction_idx on public.kod_subscription_orders
  ((case when rail='stripe' then 'stripe' else 'apaya' end),transaction_ref) where transaction_ref is not null;

alter table public.kod_subscription_orders enable row level security;
revoke all on public.kod_subscription_orders from public, anon, authenticated;
grant select(id,user_id,months,amount_fils,rail,status,created_at,paid_at,valid_until)
  on public.kod_subscription_orders to authenticated;
create policy kod_sub_own_receipts on public.kod_subscription_orders for select to authenticated
  using (user_id=(select auth.uid()));
grant select,insert,update on public.kod_subscription_orders to service_role;
grant select,insert,update on public.kod_memberships to service_role;

-- These three functions are invoker-only APIs for the payment server, never the browser.
create function public.kod_prepare_subscription(p_user uuid,p_request uuid,p_months integer,p_rail text,p_product text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare
  item public.kod_subscription_orders%rowtype; moment timestamptz:=clock_timestamp();
  amount integer:=case p_months when 1 then 6900 when 3 then 18900 when 6 then 35900 when 12 then 59900 end;
begin
  if p_user is null or p_request is null or amount is null or p_rail is null or p_rail not in ('stripe','etisalat','du')
    or p_product is null or (p_rail<>'stripe' and p_product !~ '^[0-9]+$') then raise exception 'invalid_plan'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_user::text,74123));
  select * into item from public.kod_subscription_orders where user_id=p_user and request_id=p_request for update;
  if found and (item.months<>p_months or item.rail<>p_rail or item.product_ref<>p_product) then raise exception 'request_mismatch'; end if;
  if item.id is null then
    select * into item from public.kod_subscription_orders
      where user_id=p_user and months=p_months and rail=p_rail and product_ref=p_product and status='pending'
        and (checkout_until>moment+interval '1 minute' or (checkout_ref is null and created_at>moment-interval '15 minutes'))
      order by created_at desc limit 1 for update;
  end if;
  if item.id is null then
    insert into public.kod_subscription_orders(user_id,request_id,months,amount_fils,rail,product_ref)
      values (p_user,p_request,p_months,amount,p_rail,p_product) returning * into item;
  end if;
  if item.status='paid' then return jsonb_build_object('id',item.id,'state','paid'); end if;
  if item.checkout_url is not null and item.checkout_until>moment+interval '1 minute' then
    return jsonb_build_object('id',item.id,'state','ready','url',item.checkout_url);
  end if;
  if item.checkout_ref is not null or item.created_at<moment-interval '30 minutes' then
    return jsonb_build_object('id',item.id,'state','expired');
  end if;
  if item.lease_until>moment then return jsonb_build_object('id',item.id,'state','starting'); end if;
  update public.kod_subscription_orders set lease_id=gen_random_uuid(),lease_until=moment+interval '40 seconds'
    where id=item.id returning * into item;
  return jsonb_build_object('id',item.id,'state','new','lease',item.lease_id,'amount',item.amount_fils);
end $$;

create function public.kod_attach_checkout(p_id uuid,p_lease uuid,p_ref text,p_url text,p_until timestamptz)
returns boolean language sql security invoker set search_path='' as $$
  with attached as (
    update public.kod_subscription_orders set checkout_ref=p_ref,checkout_url=p_url,checkout_until=p_until,lease_until=null,lease_id=null
    where id=p_id and lease_id=p_lease and status='pending' and checkout_ref is null and length(p_ref)>0
      and p_url like 'https://%' and p_until>now() returning id
  ) select exists(select 1 from attached)
$$;

create function public.kod_settle_subscription(p_id uuid,p_rail text,p_checkout text,p_payment text,p_product text,p_currency text,p_fils integer)
returns void language plpgsql security invoker set search_path='' as $$
declare
  item public.kod_subscription_orders%rowtype; member public.kod_memberships%rowtype;
  moment timestamptz:=clock_timestamp(); starts timestamptz; ends timestamptz;
begin
  select * into item from public.kod_subscription_orders where id=p_id for update;
  if not found or item.rail is distinct from p_rail or item.amount_fils is distinct from p_fils
    or upper(p_currency) is distinct from 'AED' or item.product_ref is distinct from p_product
    or nullif(p_payment,'') is null or item.checkout_ref is null
    or (p_checkout is not null and item.checkout_ref<>p_checkout)
    or (p_rail='stripe' and p_checkout is null) then raise exception 'payment_mismatch'; end if;
  if item.status='paid' then
    if item.transaction_ref<>p_payment then raise exception 'transaction_mismatch'; end if;
    return;
  end if;
  insert into public.kod_memberships(user_id) values(item.user_id) on conflict(user_id) do nothing;
  select * into strict member from public.kod_memberships where user_id=item.user_id for update;
  starts:=case when member.status='active' and member.expires_at>moment then member.expires_at else moment end;
  ends:=((starts at time zone 'Asia/Dubai')+make_interval(months=>item.months)) at time zone 'Asia/Dubai';
  update public.kod_subscription_orders set status='paid',transaction_ref=p_payment,paid_at=moment,valid_until=ends,checkout_url=null
    where id=item.id;
  update public.kod_memberships set status='active',expires_at=ends,activation_requested_at=null where user_id=item.user_id;
end $$;
revoke all on function public.kod_prepare_subscription(uuid,uuid,integer,text,text),public.kod_attach_checkout(uuid,uuid,text,text,timestamptz),public.kod_settle_subscription(uuid,text,text,text,text,text,integer)
  from public,anon,authenticated;
grant execute on function public.kod_prepare_subscription(uuid,uuid,integer,text,text),public.kod_attach_checkout(uuid,uuid,text,text,timestamptz),public.kod_settle_subscription(uuid,text,text,text,text,text,integer)
  to service_role;
notify pgrst,'reload schema';
commit;

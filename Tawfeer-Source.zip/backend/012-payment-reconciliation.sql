begin;
alter table public.kod_subscription_orders add column next_check timestamptz not null default now();
create index kod_sub_pending_check_idx on public.kod_subscription_orders(next_check)
  where status='pending' and checkout_ref is not null;

-- Only non-secret availability indicators are published to browsing customers.
create table public.kod_billing_availability (
  id smallint primary key check(id=1),methods jsonb not null,checked_at timestamptz not null
);
alter table public.kod_billing_availability enable row level security;
revoke all on public.kod_billing_availability from public,anon,authenticated;
grant select on public.kod_billing_availability to anon,authenticated;
grant select,insert,update on public.kod_billing_availability to service_role;
create policy kod_public_billing_status on public.kod_billing_availability for select to anon,authenticated using(id=1);
insert into public.kod_billing_availability values(1,'{"stripe":[],"etisalat":[],"du":[]}',now());

create function public.kod_subscription_methods() returns jsonb language sql stable security invoker set search_path='' as $$
  select case when checked_at>now()-interval '10 minutes' then methods else '{"stripe":[],"etisalat":[],"du":[]}'::jsonb end
    from public.kod_billing_availability where id=1
$$;
revoke all on function public.kod_subscription_methods() from public;
grant execute on function public.kod_subscription_methods() to anon,authenticated,service_role;

create function public.kod_claim_payment_checks(p_user uuid,p_order uuid)
returns table(id uuid,rail text,checkout_ref text,product_ref text,amount_fils integer)
language sql security invoker set search_path='' as $$
  with due as (
    select o.id from public.kod_subscription_orders o where o.status='pending' and o.checkout_ref is not null
      and o.next_check<=now() and ((p_user is null and p_order is null) or (o.user_id=p_user and o.id=p_order))
    order by o.next_check limit 12 for update skip locked
  ), reserved as (
    update public.kod_subscription_orders o set next_check=now()+
      case when o.checkout_until>now() then interval '1 minute' when o.checkout_until>now()-interval '1 day' then interval '15 minutes' else interval '1 day' end
    from due where o.id=due.id returning o.id,o.rail,o.checkout_ref,o.product_ref,o.amount_fils
  ) select * from reserved
$$;
revoke all on function public.kod_claim_payment_checks(uuid,uuid) from public,anon,authenticated;
grant execute on function public.kod_claim_payment_checks(uuid,uuid) to service_role;

-- Authenticated service-to-service scheduling. The timer stays idle until the merchant configures its worker credential in Vault.
create extension if not exists pg_cron;
create extension if not exists pg_net with schema extensions;
create or replace function kod_private.kod_run_payment_checks() returns void
language plpgsql security invoker set search_path='' as $$
declare credential text;
begin
  select decrypted_secret into credential from vault.decrypted_secrets where name='kod_payments_worker_jwt' limit 1;
  if nullif(credential,'') is null then return;end if;
  perform net.http_post(
    url:='https://eepditobrybbimnrbwur.supabase.co/functions/v1/kod-payments/reconcile',
    headers:=jsonb_build_object('Content-Type','application/json','Authorization','Bearer '||credential),
    body:='{}'::jsonb,timeout_milliseconds:=45000);
end $$;
revoke all on function kod_private.kod_run_payment_checks() from public,anon,authenticated;
select cron.schedule('kod-payment-confirmations','* * * * *','select kod_private.kod_run_payment_checks()');
notify pgrst,'reload schema';
commit;

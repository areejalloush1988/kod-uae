begin;

create table kod_private.kod_referral_program (
  id boolean primary key default true check(id),
  reward_days integer not null default 7 check(reward_days between 1 and 365),
  signing_key text not null default (gen_random_uuid()::text || gen_random_uuid()::text)
);
insert into kod_private.kod_referral_program(id) values(true);
create table kod_private.kod_referral_links (
  user_id uuid primary key references auth.users(id) on delete cascade,
  code uuid not null unique default gen_random_uuid()
);
create table kod_private.kod_referrals (
  invitee uuid primary key references auth.users(id) on delete cascade,
  inviter uuid not null references auth.users(id) on delete cascade,
  days integer not null check(days between 1 and 365),
  joined_at timestamptz not null default now(),
  paid_order uuid unique references public.kod_subscription_orders(id),
  earned_at timestamptz,
  applied_at timestamptz,
  check(invitee<>inviter),
  check((paid_order is null)=(earned_at is null)),
  check(applied_at is null or earned_at is not null)
);
create index kod_referrals_inviter on kod_private.kod_referrals(inviter,joined_at desc);
alter table kod_private.kod_referral_program enable row level security;
alter table kod_private.kod_referral_links enable row level security;
alter table kod_private.kod_referrals enable row level security;
revoke all on kod_private.kod_referral_program,kod_private.kod_referral_links,kod_private.kod_referrals from public,anon,authenticated;

-- Date the invite before account creation for every provider, including a Google redirect.
create function kod_private.kod_invite_offer(p_code text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare cfg kod_private.kod_referral_program%rowtype; payload text; stamp bigint;
begin
 select * into strict cfg from kod_private.kod_referral_program where id;
 if p_code is null then return jsonb_build_object('days',cfg.reward_days); end if;
 if p_code !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then return jsonb_build_object('valid',false);end if;
 if not exists(select from kod_private.kod_referral_links where code=p_code::uuid) then return jsonb_build_object('valid',false);end if;
 stamp:=floor(extract(epoch from clock_timestamp())*1000)::bigint;
 payload:=p_code||'.'||stamp||'.'||cfg.reward_days;
 return jsonb_build_object('valid',true,'days',cfg.reward_days,'ticket',payload||'.'||encode(extensions.hmac(payload,cfg.signing_key,'sha256'),'hex'));
end $$;

create function kod_private.kod_attach_invite(p_user uuid,p_ticket text) returns boolean
language plpgsql security definer set search_path='' as $$
declare parts text[]; payload text; sponsor uuid; signed_at timestamptz; born timestamptz; key text;
begin
 if p_ticket is null or length(p_ticket)>130 then return false; end if;
 parts:=regexp_match(p_ticket,'^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.([0-9]{13})\.([1-9][0-9]{0,2})\.([0-9a-f]{64})$');
 if parts is null or parts[3]::integer>365 then return false;end if;
 select signing_key into key from kod_private.kod_referral_program where id;
 payload:=parts[1]||'.'||parts[2]||'.'||parts[3];
 if parts[4]<>encode(extensions.hmac(payload,key,'sha256'),'hex') then return false;end if;
 select user_id into sponsor from kod_private.kod_referral_links where code=parts[1]::uuid;
 if sponsor is null or sponsor=p_user then return false;end if;
 signed_at:=to_timestamp(parts[2]::bigint/1000.0);
 select u.created_at into born from auth.users u join public.kod_profiles p on p.id=u.id
  join kod_private.kod_account_roles r on r.user_id=u.id
  where u.id=p_user and r.role='customer' and p.requested_account_type='customer';
 if born is null or born<signed_at or signed_at>clock_timestamp() then return false;end if;
 -- The first settled order also locks the invitee membership, serializing payment and claim.
 perform 1 from public.kod_memberships where user_id=p_user for update;
 if exists(select from public.kod_subscription_orders where user_id=p_user and status='paid') then return false;end if;
 insert into kod_private.kod_referrals(invitee,inviter,days) values(p_user,sponsor,parts[3]::int) on conflict(invitee) do nothing;
 return exists(select from kod_private.kod_referrals where invitee=p_user and inviter=sponsor);
end $$;
create function kod_private.kod_signup_invite() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if new.raw_user_meta_data ? 'kod_invite_ticket' then perform kod_private.kod_attach_invite(new.id,new.raw_user_meta_data->>'kod_invite_ticket');end if;
 return new;
end $$;
create trigger kod_referral_signup after insert on auth.users for each row execute function kod_private.kod_signup_invite();
create function kod_private.kod_accept_invite(p_ticket text) returns boolean
language sql security definer set search_path='' as $$select case when auth.uid() is not null then kod_private.kod_attach_invite(auth.uid(),p_ticket) else false end$$;

-- An earned day is applied once. Suspended memberships retain their days until reactivation.
create function kod_private.kod_apply_referral_days() returns trigger
language plpgsql security definer set search_path='' as $$
declare extra integer; moment timestamptz:=clock_timestamp();
begin
 if new.status='active' then
  with redeemed as (update kod_private.kod_referrals set applied_at=moment
    where inviter=new.user_id and earned_at is not null and applied_at is null returning days)
    select sum(days)::integer into extra from redeemed;
  if extra is not null then new.expires_at:=greatest(coalesce(new.expires_at,moment),moment)+make_interval(days=>extra);end if;
 end if;
 return new;
end $$;
create trigger kod_extend_rewarded_membership before update of status,expires_at on public.kod_memberships for each row execute function kod_private.kod_apply_referral_days();

create function kod_private.kod_reward_first_subscription() returns trigger
language plpgsql security definer set search_path='' as $$
declare sponsor uuid; moment timestamptz:=clock_timestamp();
begin
 update kod_private.kod_referrals set paid_order=new.id,earned_at=moment
  where invitee=new.user_id and paid_order is null returning inviter into sponsor;
 if sponsor is not null then
  update public.kod_memberships set status='active',expires_at=case when status='active' then greatest(expires_at,moment) else moment end
   where user_id=sponsor and status<>'cancelled';
 end if;
 return new;
end $$;
create trigger kod_reward_paid_referral after update of status on public.kod_subscription_orders
 for each row when (old.status='pending' and new.status='paid') execute function kod_private.kod_reward_first_subscription();

create function kod_private.kod_referral_home() returns jsonb
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); invite_code uuid; result jsonb;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('customer','developer') then raise exception 'member_required';end if;
 insert into public.kod_memberships(user_id) values(actor) on conflict(user_id) do nothing;
 insert into kod_private.kod_referral_links(user_id) values(actor) on conflict(user_id) do nothing;
 select code into strict invite_code from kod_private.kod_referral_links where user_id=actor;
 select jsonb_build_object('code',invite_code,'days',(select reward_days from kod_private.kod_referral_program where id),
  'joined',count(*),'paid',count(paid_order),'earned_days',coalesce(sum(days) filter(where earned_at is not null),0),
  'applied_days',coalesce(sum(days) filter(where applied_at is not null),0)) into result from kod_private.kod_referrals where inviter=actor;
 return result;
end $$;
create function kod_private.kod_referral_admin(p_days integer default null) returns jsonb
language plpgsql security definer set search_path='' as $$
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if p_days is not null then
  if p_days not between 1 and 365 then raise exception 'invalid_days';end if;
  update kod_private.kod_referral_program set reward_days=p_days where id;
 end if;
 return (select jsonb_build_object('days',(select reward_days from kod_private.kod_referral_program where id),'joined',count(*),'paid',count(paid_order),'earned_days',coalesce(sum(days) filter(where earned_at is not null),0)) from kod_private.kod_referrals);
end $$;

create function public.kod_invite_offer(p_code text default null) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_invite_offer(p_code)$$;
create function public.kod_accept_invite(p_ticket text) returns boolean language sql security invoker set search_path='' as $$select kod_private.kod_accept_invite(p_ticket)$$;
create function public.kod_referral_home() returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_referral_home()$$;
create function public.kod_referral_admin(p_days integer default null) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_referral_admin(p_days)$$;
revoke all on function kod_private.kod_attach_invite(uuid,text),kod_private.kod_signup_invite(),kod_private.kod_apply_referral_days(),kod_private.kod_reward_first_subscription(),kod_private.kod_invite_offer(text),public.kod_invite_offer(text),kod_private.kod_accept_invite(text),public.kod_accept_invite(text),kod_private.kod_referral_home(),public.kod_referral_home(),kod_private.kod_referral_admin(integer),public.kod_referral_admin(integer) from public,anon,authenticated;
grant execute on function kod_private.kod_invite_offer(text),public.kod_invite_offer(text) to anon,authenticated;
grant execute on function kod_private.kod_accept_invite(text),public.kod_accept_invite(text),kod_private.kod_referral_home(),public.kod_referral_home(),kod_private.kod_referral_admin(integer),public.kod_referral_admin(integer) to authenticated;
notify pgrst,'reload schema';
commit;

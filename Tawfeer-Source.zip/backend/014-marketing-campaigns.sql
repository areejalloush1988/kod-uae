begin;
create table kod_private.kod_partner_requests (
 id uuid primary key default gen_random_uuid(), applicant uuid not null references auth.users(id) on delete cascade,
 kind text not null check(kind in ('corporate','creator')), name text not null, contact text not null,
 city text not null, seats integer, status text not null default 'pending' check(status in ('pending','approved')),
 created_at timestamptz not null default now(), unique(applicant,kind)
);
create table kod_private.kod_campaigns (
 id uuid primary key default gen_random_uuid(), kind text not null check(kind in ('restaurant','creator','corporate','area','community')),
 label text not null, city text not null default '', branch_id uuid unique references public.kod_restaurants(id),
 request_id uuid unique references kod_private.kod_partner_requests(id) on delete set null,
 commission_percent integer not null default 0 check(commission_percent between 0 and 100),
 active boolean not null default true, created_at timestamptz not null default now()
);
create table kod_private.kod_campaign_members (
 member_id uuid primary key references auth.users(id) on delete cascade, campaign_id uuid not null references kod_private.kod_campaigns(id),
 joined_at timestamptz not null default now(), agreed_percent integer not null check(agreed_percent between 0 and 100),
 paid_order uuid unique references public.kod_subscription_orders(id), amount_fils integer not null default 0, commission_fils integer not null default 0
);
create index kod_campaign_member_counts on kod_private.kod_campaign_members(campaign_id);
create table kod_private.kod_company_seats (
 token uuid primary key default gen_random_uuid(), campaign_id uuid not null references kod_private.kod_campaigns(id),
 batch_id uuid not null, days integer not null check(days between 1 and 365), employee uuid references auth.users(id) on delete set null,
 redeemed_at timestamptz, unique(campaign_id,employee)
);
create index kod_company_batches on kod_private.kod_company_seats(campaign_id,batch_id);
alter table kod_private.kod_partner_requests enable row level security;
alter table kod_private.kod_campaigns enable row level security;
alter table kod_private.kod_campaign_members enable row level security;
alter table kod_private.kod_company_seats enable row level security;
revoke all on kod_private.kod_partner_requests,kod_private.kod_campaigns,kod_private.kod_campaign_members,kod_private.kod_company_seats from public,anon,authenticated;

create function kod_private.kod_promo_city(p_city text) returns boolean language sql immutable set search_path='' as $$
 select p_city in ('','دبي','أبوظبي','الشارقة','عجمان','رأس الخيمة','الفجيرة','أم القيوين')
$$;
create function kod_private.kod_partner_apply(p_kind text,p_name text,p_contact text,p_city text,p_seats integer) returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); rtn uuid;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('merchant','developer','customer') then raise exception 'login_required';end if;
 if p_kind is null or p_kind not in ('corporate','creator') or coalesce(length(trim(p_name)),0) not between 2 and 80
  or coalesce(length(trim(p_contact)),0) not between 5 and 150 or p_contact !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'
  or not coalesce(kod_private.kod_promo_city(p_city),false) or (p_kind='corporate' and not coalesce(p_seats between 1 and 100000,false)) then raise exception 'invalid_request';end if;
 insert into kod_private.kod_partner_requests(applicant,kind,name,contact,city,seats) values(actor,p_kind,trim(p_name),trim(p_contact),p_city,case when p_kind='corporate' then p_seats end)
 on conflict(applicant,kind) do update set name=excluded.name,contact=excluded.contact,city=excluded.city,seats=excluded.seats
 where kod_private.kod_partner_requests.status='pending' returning id into rtn;
 if rtn is null then select id into rtn from kod_private.kod_partner_requests where applicant=actor and kind=p_kind;end if;
 return rtn;
end $$;
create function kod_private.kod_branch_campaign(p_branch uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare branch public.kod_restaurants%rowtype; link uuid;
begin
 select * into branch from public.kod_restaurants where id=p_branch and approved and not is_demo and instore_percent>0;
 if not found or auth.uid() is null or not (kod_private.kod_is_developer() or (kod_private.kod_role()='merchant' and branch.owner_id=auth.uid())) then raise exception 'branch_required';end if;
 insert into kod_private.kod_campaigns(kind,label,city,branch_id) values('restaurant',branch.name,coalesce(branch.city,''),branch.id)
 on conflict(branch_id) do update set label=excluded.label,city=excluded.city returning id into link;
 return link;
end $$;
create function kod_private.kod_create_campaign(p_kind text,p_label text,p_city text,p_percent integer,p_request uuid,p_nonce uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare link uuid; lead kod_private.kod_partner_requests%rowtype;
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if p_kind is null or p_kind not in ('creator','corporate','area','community') or coalesce(length(trim(p_label)),0) not between 2 and 80
  or not coalesce(kod_private.kod_promo_city(p_city),false) or not coalesce(p_percent between 0 and 100,false) or (p_kind<>'creator' and p_percent<>0) or p_nonce is null then raise exception 'invalid_request';end if;
 if p_request is not null then
  select * into lead from kod_private.kod_partner_requests where id=p_request and kind=p_kind for update;
  if not found then raise exception 'invalid_request';end if;
  select id into link from kod_private.kod_campaigns where request_id=p_request;
  if link is not null then return link;end if;
 end if;
 insert into kod_private.kod_campaigns(id,kind,label,city,request_id,commission_percent) values(p_nonce,p_kind,trim(p_label),p_city,p_request,p_percent)
  on conflict(id) do nothing;
 if not exists(select from kod_private.kod_campaigns where id=p_nonce and kind=p_kind and label=trim(p_label) and city=p_city and commission_percent=p_percent and request_id is not distinct from p_request) then raise exception 'request_mismatch';end if;
 if p_request is not null then update kod_private.kod_partner_requests set status='approved' where id=p_request;end if;
 return p_nonce;
end $$;
create function kod_private.kod_campaign_offer(p_campaign uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare row kod_private.kod_campaigns%rowtype; payload text; key text;
begin
 select * into row from kod_private.kod_campaigns c where c.id=p_campaign and c.active and (c.branch_id is null or exists(select from public.kod_restaurants r where r.id=c.branch_id and r.approved and not r.is_demo and r.instore_percent>0));
 if not found then return jsonb_build_object('valid',false);end if;
 select signing_key into key from kod_private.kod_referral_program where id;
 payload:='C.'||p_campaign::text||'.'||floor(extract(epoch from clock_timestamp())*1000)::bigint;
 return jsonb_build_object('valid',true,'label',row.label,'city',row.city,'kind',row.kind,'ticket',payload||'.'||encode(extensions.hmac(payload,key,'sha256'),'hex'));
end $$;
create function kod_private.kod_attach_campaign(p_actor uuid,p_ticket text) returns boolean language plpgsql security definer set search_path='' as $$
declare parts text[]; payload text; key text; code uuid; stamp timestamptz; born timestamptz;
begin
 if p_actor is null or p_ticket is null or length(p_ticket)>130 then return false;end if;
 parts:=regexp_match(p_ticket,'^C\.([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\.([0-9]{13})\.([0-9a-f]{64})$');
 if parts is null then return false;end if;
 select signing_key into key from kod_private.kod_referral_program where id;
 payload:='C.'||parts[1]||'.'||parts[2];
 if parts[3]<>encode(extensions.hmac(payload,key,'sha256'),'hex') then return false;end if;
 code:=parts[1]::uuid; stamp:=to_timestamp(parts[2]::bigint/1000.0);
 select u.created_at into born from auth.users u join public.kod_profiles p on p.id=u.id
  join kod_private.kod_account_roles ar on ar.user_id=u.id where u.id=p_actor and ar.role='customer' and p.requested_account_type='customer';
 if born is null or born<stamp or stamp>clock_timestamp() then return false;end if;
 perform 1 from public.kod_memberships where user_id=p_actor for update;
 if exists(select from public.kod_subscription_orders where user_id=p_actor and status='paid') then return false;end if;
 insert into kod_private.kod_campaign_members(member_id,campaign_id,agreed_percent)
  select p_actor,c.id,c.commission_percent from kod_private.kod_campaigns c left join kod_private.kod_partner_requests r on r.id=c.request_id
  where c.id=code and c.active and r.applicant is distinct from p_actor
   and (c.branch_id is null or exists(select from public.kod_restaurants br where br.id=c.branch_id and br.approved and not br.is_demo and br.instore_percent>0))
  on conflict(member_id) do nothing;
 return exists(select from kod_private.kod_campaign_members where member_id=p_actor and campaign_id=code);
end $$;
create function kod_private.kod_signup_campaign() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.raw_user_meta_data ? 'kod_campaign_ticket' then perform kod_private.kod_attach_campaign(new.id,new.raw_user_meta_data->>'kod_campaign_ticket');end if;
 return new;
end $$;
create trigger kod_track_new_campaign_member after insert on auth.users for each row execute function kod_private.kod_signup_campaign();
create function kod_private.kod_campaign_conversion() returns trigger language plpgsql security definer set search_path='' as $$
begin
 update kod_private.kod_campaign_members set paid_order=new.id,amount_fils=new.amount_fils,
   commission_fils=round(new.amount_fils::numeric*agreed_percent/100)::integer where member_id=new.user_id and paid_order is null;
 return new;
end $$;
create trigger kod_track_campaign_payment after update of status on public.kod_subscription_orders
 for each row when(old.status='pending' and new.status='paid') execute function kod_private.kod_campaign_conversion();

create function kod_private.kod_marketing_desk() returns jsonb language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); admin boolean:=kod_private.kod_is_developer(); campaigns jsonb; requests jsonb;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('customer','merchant','developer') then raise exception 'login_required';end if;
 select coalesce(jsonb_agg(to_jsonb(src) order by src.created_at desc),'[]') into campaigns from (
  select c.id,c.kind,c.label,c.city,c.commission_percent,c.active,c.created_at,
   count(m.member_id) as joined,count(m.paid_order) as paid,coalesce(sum(m.commission_fils),0) as commission_fils,
   (select count(*) from kod_private.kod_company_seats s where s.campaign_id=c.id) as seats,
   (select count(*) from kod_private.kod_company_seats s where s.campaign_id=c.id and s.redeemed_at is not null) as used
  from kod_private.kod_campaigns c left join kod_private.kod_campaign_members m on m.campaign_id=c.id
  where admin or exists(select from kod_private.kod_partner_requests r where r.id=c.request_id and r.applicant=actor)
   or exists(select from public.kod_restaurants b where b.id=c.branch_id and b.owner_id=actor and kod_private.kod_role()='merchant')
  group by c.id
 ) src;
 select coalesce(jsonb_agg(to_jsonb(src) order by src.created_at desc),'[]') into requests from (
  select id,kind,name,contact,city,seats,status,created_at from kod_private.kod_partner_requests where admin or applicant=actor
 ) src;
 return jsonb_build_object('campaigns',campaigns,'requests',requests);
end $$;
create function kod_private.kod_company_batch(p_campaign uuid,p_batch uuid,p_seats integer,p_days integer) returns integer language plpgsql security definer set search_path='' as $$
declare existing integer;
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if p_batch is null or not coalesce(p_seats between 1 and 1000,false) or not coalesce(p_days between 1 and 365,false) then raise exception 'invalid_request';end if;
 perform 1 from kod_private.kod_campaigns where id=p_campaign and kind='corporate' and active for update;
 if not found then raise exception 'invalid_request';end if;
 select count(*) into existing from kod_private.kod_company_seats where campaign_id=p_campaign and batch_id=p_batch;
 if existing>0 then return existing;end if;
 insert into kod_private.kod_company_seats(campaign_id,batch_id,days) select p_campaign,p_batch,p_days from generate_series(1,p_seats);
 return p_seats;
end $$;
create function kod_private.kod_company_codes(p_campaign uuid) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not exists(select from kod_private.kod_campaigns c left join kod_private.kod_partner_requests q on q.id=c.request_id where c.id=p_campaign and c.kind='corporate' and (kod_private.kod_is_developer() or q.applicant=auth.uid())) then raise exception 'operator_required';end if;
 return (select coalesce(jsonb_agg(jsonb_build_object('token',token,'days',days) order by token),'[]') from kod_private.kod_company_seats where campaign_id=p_campaign and redeemed_at is null);
end $$;
create function kod_private.kod_claim_seat(p_token uuid) returns integer language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); seat kod_private.kod_company_seats%rowtype; membership public.kod_memberships%rowtype; moment timestamptz:=clock_timestamp();
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('customer','developer') then raise exception 'member_required';end if;
 select * into strict membership from public.kod_memberships where user_id=actor for update;
 select s.* into seat from kod_private.kod_company_seats s join kod_private.kod_campaigns c on c.id=s.campaign_id where s.token=p_token and c.active for update of s;
 if not found or (seat.redeemed_at is not null and seat.employee is distinct from actor) or membership.status='cancelled' then raise exception 'invalid_seat';end if;
 if seat.redeemed_at is not null then return seat.days;end if;
 if exists(select from kod_private.kod_company_seats where campaign_id=seat.campaign_id and employee=actor) then raise exception 'already_used';end if;
 update kod_private.kod_company_seats set employee=actor,redeemed_at=moment where token=p_token;
 update public.kod_memberships set status='active',expires_at=(case when status='active' then greatest(expires_at,moment) else moment end)+make_interval(days=>seat.days),activation_requested_at=null where user_id=actor;
 return seat.days;
end $$;
create function kod_private.kod_accept_campaign(p_ticket text) returns boolean language sql security definer set search_path='' as $$select kod_private.kod_attach_campaign(auth.uid(),p_ticket)$$;

create function public.kod_partner_apply(p_kind text,p_name text,p_contact text,p_city text,p_seats integer) returns uuid language sql security invoker set search_path='' as $$select kod_private.kod_partner_apply(p_kind,p_name,p_contact,p_city,p_seats)$$;
create function public.kod_branch_campaign(p_branch uuid) returns uuid language sql security invoker set search_path='' as $$select kod_private.kod_branch_campaign(p_branch)$$;
create function public.kod_create_campaign(p_kind text,p_label text,p_city text,p_percent integer,p_request uuid,p_nonce uuid) returns uuid language sql security invoker set search_path='' as $$select kod_private.kod_create_campaign(p_kind,p_label,p_city,p_percent,p_request,p_nonce)$$;
create function public.kod_campaign_offer(p_campaign uuid) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_campaign_offer(p_campaign)$$;
create function public.kod_accept_campaign(p_ticket text) returns boolean language sql security invoker set search_path='' as $$select kod_private.kod_accept_campaign(p_ticket)$$;
create function public.kod_marketing_desk() returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_marketing_desk()$$;
create function public.kod_company_batch(p_campaign uuid,p_batch uuid,p_seats integer,p_days integer) returns integer language sql security invoker set search_path='' as $$select kod_private.kod_company_batch(p_campaign,p_batch,p_seats,p_days)$$;
create function public.kod_company_codes(p_campaign uuid) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_company_codes(p_campaign)$$;
create function public.kod_claim_seat(p_token uuid) returns integer language sql security invoker set search_path='' as $$select kod_private.kod_claim_seat(p_token)$$;

do $grants$
declare sig text; ns text;
begin
 foreach sig in array array['kod_partner_apply(text,text,text,text,integer)','kod_branch_campaign(uuid)','kod_create_campaign(text,text,text,integer,uuid,uuid)','kod_campaign_offer(uuid)','kod_accept_campaign(text)','kod_marketing_desk()','kod_company_batch(uuid,uuid,integer,integer)','kod_company_codes(uuid)','kod_claim_seat(uuid)'] loop
  foreach ns in array array['public','kod_private'] loop
   execute format('revoke all on function %I.%s from public,anon,authenticated',ns,sig);
   execute format('grant execute on function %I.%s to authenticated',ns,sig);
   if sig='kod_campaign_offer(uuid)' then execute format('grant execute on function %I.%s to anon',ns,sig);end if;
  end loop;
 end loop;
end $grants$;
revoke all on function kod_private.kod_promo_city(text),kod_private.kod_attach_campaign(uuid,text),kod_private.kod_signup_campaign(),kod_private.kod_campaign_conversion() from public,anon,authenticated;
notify pgrst,'reload schema';
commit;

begin;

alter table public.kod_subscription_orders
 add column valid_from timestamptz,
 add column club_tier text generated always as (
   case months when 1 then 'bronze' when 3 then 'silver' else 'gold' end
 ) stored;
-- Older receipts recorded the end of a term. Prefer the previous receipt end or the
-- payment time when either exactly reproduces the original Dubai calendar calculation.
with history as (
 select id,months,paid_at,valid_until,lag(valid_until) over(partition by user_id order by valid_until,paid_at,id) as prior_end
 from public.kod_subscription_orders where status='paid'
)
update public.kod_subscription_orders o set valid_from=case
 when h.prior_end>=h.paid_at and ((h.prior_end at time zone 'Asia/Dubai')+make_interval(months=>h.months::int)) at time zone 'Asia/Dubai'=h.valid_until then h.prior_end
 when ((h.paid_at at time zone 'Asia/Dubai')+make_interval(months=>h.months::int)) at time zone 'Asia/Dubai'=h.valid_until then h.paid_at
 else greatest(h.paid_at,((h.valid_until at time zone 'Asia/Dubai')-make_interval(months=>h.months::int)) at time zone 'Asia/Dubai') end
from history h where o.id=h.id;
alter table public.kod_subscription_orders add constraint kod_paid_window check (
 status<>'paid' or (valid_from is not null and valid_until is not null and valid_until>valid_from));
create index kod_paid_terms on public.kod_subscription_orders(user_id,valid_until) where status='paid';
grant select (valid_from,club_tier) on public.kod_subscription_orders to authenticated;

alter table public.kod_restaurants
 add column silver_extra smallint not null default 0 check(silver_extra between 0 and 70),
 add column gold_extra smallint not null default 0 check(gold_extra between silver_extra and 70);

create function kod_private.kod_club_level(p_member uuid,p_at timestamptz) returns text
language sql stable security invoker set search_path='' as $$
 select coalesce((select o.club_tier from public.kod_subscription_orders o where o.user_id=m.user_id and o.status='paid'
  and o.valid_from<=p_at and o.valid_until>p_at order by o.valid_from desc,o.paid_at desc limit 1),'bronze')
 from public.kod_memberships m where m.user_id=p_member and m.status='active' and m.expires_at>p_at
$$;
create function kod_private.kod_club_discount(p_level text,p_base integer,p_silver integer,p_gold integer) returns integer
language sql immutable security invoker set search_path='' as $$
 select case when p_level is null or coalesce(p_base,0)<=0 then 0 else least(70,p_base+
  case p_level when 'gold' then p_gold when 'silver' then p_silver else 0 end) end
$$;
create function kod_private.kod_set_club_rates(p_branch uuid,p_online integer,p_counter integer,p_silver integer,p_gold integer) returns void
language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not(kod_private.kod_is_developer() or
   (coalesce(kod_private.kod_role(),'')='merchant' and kod_private.kod_owns_restaurant(p_branch))) then raise exception 'branch_required';end if;
 if not coalesce(p_online between 0 and 70 and p_counter between 0 and 70 and p_silver between 0 and 70
   and p_gold between p_silver and 70 and greatest(p_online,p_counter)+p_gold<=70,false) then raise exception 'invalid_club_rates';end if;
 update public.kod_restaurants set percent=p_online,instore_percent=p_counter,silver_extra=p_silver,gold_extra=p_gold
  where id=p_branch and approved and not is_demo;
 if not found then raise exception 'branch_required';end if;
end $$;
create function public.kod_set_club_rates(p_branch uuid,p_online integer,p_counter integer,p_silver integer,p_gold integer) returns void
language sql security invoker set search_path='' as $$select kod_private.kod_set_club_rates(p_branch,p_online,p_counter,p_silver,p_gold)$$;
revoke all on function kod_private.kod_club_level(uuid,timestamptz),kod_private.kod_club_discount(text,integer,integer,integer),
 kod_private.kod_set_club_rates(uuid,integer,integer,integer,integer),public.kod_set_club_rates(uuid,integer,integer,integer,integer) from public,anon,authenticated;
grant execute on function kod_private.kod_set_club_rates(uuid,integer,integer,integer,integer),public.kod_set_club_rates(uuid,integer,integer,integer,integer) to authenticated;

create or replace function public.kod_settle_subscription(p_id uuid,p_rail text,p_checkout text,p_payment text,p_product text,p_currency text,p_fils integer)
returns void language plpgsql security invoker set search_path='' as $$
declare
  item public.kod_subscription_orders%rowtype; member public.kod_memberships%rowtype;
  moment timestamptz:=clock_timestamp(); starts timestamptz; ends timestamptz;
begin
  select * into item from public.kod_subscription_orders where id=p_id for update;
  if not found or item.rail is distinct from p_rail or item.amount_fils is distinct from p_fils
    or upper(p_currency) is distinct from 'AED' or item.product_ref is distinct from p_product
    or nullif(p_payment,'') is null or item.checkout_ref is null
    or (p_checkout is not null and item.checkout_ref<>p_checkout)
    or (p_rail='stripe' and p_checkout is null) then raise exception 'payment_mismatch'; end if;
  if item.status='paid' then
    if item.transaction_ref<>p_payment then raise exception 'transaction_mismatch'; end if;
    return;
  end if;
  insert into public.kod_memberships(user_id) values(item.user_id) on conflict(user_id) do nothing;
  select * into strict member from public.kod_memberships where user_id=item.user_id for update;
  starts:=case when member.status='active' and member.expires_at>moment then member.expires_at else moment end;
  ends:=((starts at time zone 'Asia/Dubai')+make_interval(months=>item.months)) at time zone 'Asia/Dubai';
  update public.kod_subscription_orders set status='paid',transaction_ref=p_payment,paid_at=moment,valid_from=starts,valid_until=ends,checkout_url=null
    where id=item.id;
  update public.kod_memberships set status='active',expires_at=ends,activation_requested_at=null where user_id=item.user_id;
end $$;

create or replace function kod_private.kod_member_card(p_request boolean) returns jsonb
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); serial text; holder text; m public.kod_memberships%rowtype;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('customer','developer') then raise exception 'member_required'; end if;
 select * into m from public.kod_memberships where user_id=actor for update;
 if not found then
  insert into public.kod_memberships(user_id) values(actor) on conflict(user_id) do nothing;
  select * into strict m from public.kod_memberships where user_id=actor for update;
 end if;
 if p_request and (m.status<>'active' or m.expires_at is null or m.expires_at<=now()) and m.activation_requested_at is null then
  update public.kod_memberships set activation_requested_at=now() where user_id=actor returning * into m;
 end if;
 select card_number into serial from kod_private.kod_member_cards where user_id=actor;
 while serial is null loop
  insert into kod_private.kod_member_cards(user_id,card_number)
  select actor,lpad((('x'||right(replace(gen_random_uuid()::text,'-',''),15))::bit(60)::bigint % 9999999999999999 + 1)::text,16,'0')
  on conflict do nothing returning card_number into serial;
  if serial is null then select card_number into serial from kod_private.kod_member_cards where user_id=actor; end if;
 end loop;
 select nullif(trim(full_name),'') into holder from public.kod_profiles where id=actor;
 return jsonb_build_object('number',serial,'name',coalesce(holder,'عضو توفير'),'status',m.status,'expires_at',m.expires_at,'requested_at',m.activation_requested_at,
   'tier',kod_private.kod_club_level(actor,now()),'periods',coalesce((select jsonb_agg(
      jsonb_build_object('tier',club_tier,'starts',valid_from,'ends',valid_until) order by valid_from)
     from public.kod_subscription_orders where user_id=actor and status='paid' and valid_until>now()),'[]'::jsonb));
end $$;

create or replace function kod_private.kod_place_order(
 p_restaurant_id uuid,p_lines jsonb,p_fulfillment text,p_customer_name text,p_contact_phone text,
 p_delivery_address text,p_notes text,p_request_id uuid
) returns public.kod_orders language plpgsql security definer set search_path=''
as $$declare
 v_uid uuid:=auth.uid(); v_r public.kod_restaurants; v_item public.kod_menu_items;
 v_order public.kod_orders; v_line jsonb; v_items jsonb:='[]'; v_seen uuid[]:='{}';
 v_item_id uuid; v_qty integer; v_sub integer:=0; v_discount integer:=0; v_fee integer:=0;
 v_percent integer:=0; v_fingerprint text;
begin
 if v_uid is null then raise exception 'authentication_required'; end if;
 if coalesce(kod_private.kod_role(),'') not in ('customer','merchant','developer') then raise exception 'customer_account_required'; end if;
 if p_request_id is null then raise exception 'request_id_required'; end if;
 if p_fulfillment not in('delivery','pickup') or p_fulfillment is null then raise exception 'invalid_fulfillment'; end if;
 if char_length(trim(p_customer_name)) not between 1 and 60 or p_customer_name is null
 or p_contact_phone is null or p_contact_phone !~ '^\+[1-9][0-9]{7,14}$'
 or coalesce(char_length(p_delivery_address),0)>300 or coalesce(char_length(p_notes),0)>300
 or (p_fulfillment='delivery' and coalesce(char_length(trim(p_delivery_address)),0)<5)
 then raise exception 'invalid_contact_details'; end if;
 if p_lines is null or jsonb_typeof(p_lines)<>'array' or jsonb_array_length(p_lines) not between 1 and 20
 then raise exception 'invalid_lines'; end if;
 v_fingerprint:=encode(sha256(convert_to(jsonb_build_object('r',p_restaurant_id,'l',p_lines,'f',p_fulfillment,'n',p_customer_name,'p',p_contact_phone,'a',p_delivery_address,'notes',p_notes)::text,'UTF8')),'hex');
 perform pg_advisory_xact_lock(hashtextextended(v_uid::text||p_request_id::text,0));
 select * into v_order from public.kod_orders where customer_id=v_uid and request_id=p_request_id;
 if found then
  if v_order.request_fingerprint<>v_fingerprint then raise exception 'idempotency_conflict'; end if;
  return v_order;
 end if;
 if not exists(select 1 from public.kod_platform_settings where id=1 and ordering_enabled) then raise exception 'ordering_not_enabled'; end if;
 select * into v_r from public.kod_restaurants where id=p_restaurant_id for update;
 if not found or not v_r.approved or not v_r.is_open or v_r.is_demo then raise exception 'restaurant_unavailable'; end if;
 for v_line in select value from jsonb_array_elements(p_lines) loop
  if jsonb_typeof(v_line)<>'object' or coalesce(v_line->>'quantity','') !~ '^[1-9][0-9]?$'
  then raise exception 'invalid_quantity'; end if;
  v_qty:=(v_line->>'quantity')::integer;
  if v_qty not between 1 and 20 then raise exception 'invalid_quantity'; end if;
  v_item_id:=(v_line->>'item_id')::uuid;
  if v_item_id is null or v_item_id=any(v_seen) then raise exception 'duplicate_or_missing_item'; end if;
  v_seen:=array_append(v_seen,v_item_id);
  select * into v_item from public.kod_menu_items where id=v_item_id and restaurant_id=p_restaurant_id for share;
  if not found or not v_item.is_available then raise exception 'item_unavailable'; end if;
  v_sub:=v_sub+v_item.price_cents*v_qty;
  if v_sub>200000 then raise exception 'order_limit_exceeded'; end if;
  v_items:=v_items||jsonb_build_array(jsonb_build_object('item_id',v_item.id,'name',v_item.name,'quantity',v_qty,'unit_price_cents',v_item.price_cents));
 end loop;
 if v_sub<v_r.minimum_order_cents then raise exception 'minimum_order_not_met'; end if;
 v_percent:=kod_private.kod_club_discount(kod_private.kod_club_level(v_uid,now()),v_r.percent,v_r.silver_extra,v_r.gold_extra);
 v_discount:=round(v_sub::numeric*v_percent/100)::integer;
 v_fee:=case when p_fulfillment='delivery' then v_r.delivery_fee_cents else 0 end;
 insert into public.kod_orders(customer_id,restaurant_id,restaurant_name,request_id,request_fingerprint,customer_name,contact_phone,delivery_address,notes,fulfillment,items,subtotal_cents,discount_cents,delivery_fee_cents,total_cents,events)
 values(v_uid,v_r.id,v_r.name,p_request_id,v_fingerprint,trim(p_customer_name),p_contact_phone,
 case when p_fulfillment='delivery' then trim(p_delivery_address) else '' end,coalesce(p_notes,''),p_fulfillment,v_items,v_sub,v_discount,v_fee,v_sub-v_discount+v_fee,jsonb_build_array(jsonb_build_object('status','pending','at',now())))
 returning * into v_order;
 return v_order;
end$$;

create or replace function kod_private.kod_instore_bill(p_restaurant_id uuid,p_card_number text,p_bill_cents integer,p_invoice text,p_request_id uuid,p_expected_percent integer) returns jsonb
language plpgsql security definer set search_path='' as $$
declare
 branch public.kod_restaurants%rowtype; member_id uuid; membership public.kod_memberships%rowtype; receipt public.kod_instore_receipts%rowtype;
 reference text:=upper(trim(p_invoice)); business_date date:=(now() at time zone 'Asia/Dubai')::date; saving integer; effective integer; level text; result jsonb;
begin
 if auth.uid() is null or not (kod_private.kod_is_developer() or (coalesce(kod_private.kod_role(),'')='merchant' and kod_private.kod_owns_restaurant(p_restaurant_id))) then raise exception 'branch_required'; end if;
 if p_bill_cents is null or p_bill_cents not between 1 and 99999999 or reference is null or char_length(reference) not between 1 and 48 or reference ~ '[[:cntrl:]]' then raise exception 'invalid_invoice'; end if;
 if p_card_number is null or p_card_number !~ '^[0-9]{16}$' then raise exception 'card_unavailable'; end if;
 select user_id into member_id from kod_private.kod_member_cards where card_number=p_card_number;
 if not found then raise exception 'card_unavailable'; end if;
 if p_request_id is not null then
  perform pg_advisory_xact_lock(hashtextextended(p_request_id::text,0));
  select * into receipt from public.kod_instore_receipts where request_id=p_request_id;
  if found then
   if receipt.restaurant_id<>p_restaurant_id or receipt.customer_id<>member_id or receipt.bill_cents<>p_bill_cents or receipt.invoice_ref<>reference then raise exception 'request_mismatch'; end if;
   return jsonb_build_object('id',receipt.id,'restaurant_name',receipt.restaurant_name,'invoice_ref',receipt.invoice_ref,'bill_cents',receipt.bill_cents,'percent',receipt.percent,'discount_cents',receipt.discount_cents,'net_cents',receipt.net_cents);
  end if;
 end if;
 select * into branch from public.kod_restaurants where id=p_restaurant_id for share;
 if not found or not branch.approved or branch.is_demo or branch.instore_percent=0 then raise exception 'branch_unavailable'; end if;
 select * into membership from public.kod_memberships where user_id=member_id for share;
 if not found or membership.status<>'active' or membership.expires_at is null or membership.expires_at<=clock_timestamp() then raise exception 'card_unavailable'; end if;
 if exists(select 1 from public.kod_instore_receipts where restaurant_id=p_restaurant_id and business_day=business_date and invoice_ref=reference) then raise exception 'invoice_already_used'; end if;
 level:=kod_private.kod_club_level(member_id,clock_timestamp());
 if level is null then raise exception 'card_unavailable';end if;
 effective:=kod_private.kod_club_discount(level,branch.instore_percent,branch.silver_extra,branch.gold_extra);
 saving:=round(p_bill_cents::numeric*effective/100);
 result:=jsonb_build_object('restaurant_name',branch.name,'invoice_ref',reference,'bill_cents',p_bill_cents,'percent',effective,'discount_cents',saving,'net_cents',p_bill_cents-saving);
 if p_request_id is null then return result; end if;
 if p_expected_percent is distinct from effective then raise exception 'quote_changed'; end if;
 insert into public.kod_instore_receipts(request_id,customer_id,restaurant_id,restaurant_name,business_day,invoice_ref,bill_cents,percent,discount_cents)
 values(p_request_id,member_id,branch.id,branch.name,business_date,reference,p_bill_cents,effective,saving)
 on conflict (restaurant_id,business_day,invoice_ref) do nothing returning * into receipt;
 if not found then raise exception 'invoice_already_used'; end if;
 return result||jsonb_build_object('id',receipt.id);
end $$;
notify pgrst,'reload schema';
commit;

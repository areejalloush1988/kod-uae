begin;
create table kod_private.kod_manual_payments (
 reference_key text primary key, invoice_id uuid not null unique, purpose text not null check(purpose in('restaurant','member'))
);
alter table kod_private.kod_manual_payments enable row level security;
revoke all on kod_private.kod_manual_payments from public,anon,authenticated;
create function kod_private.kod_invoice_details_ok(note text,url text) returns boolean language sql immutable set search_path='' as $$
 select (length(note) between 4 and 500 or (length(note)<=500 and url<>'')) and length(url)<=1000 and
  (url='' or url ~ '^https://[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}([/?#][^[:space:]]*)?$')
$$;
revoke all on function kod_private.kod_invoice_details_ok(text,text) from public,anon,authenticated;

create table kod_private.kod_featured_pricing (
 id boolean primary key default true check(id),
 price_fils integer not null default 14900 check(price_fils between 100 and 9999900)
);
insert into kod_private.kod_featured_pricing default values;
create table kod_private.kod_featured_bookings (
 id uuid primary key default gen_random_uuid(), branch_id uuid not null references public.kod_restaurants(id),
 applicant uuid not null references auth.users(id), request_id uuid not null, unique(applicant,request_id),
 amount_fils integer not null check(amount_fils between 100 and 9999900), days smallint not null default 30 check(days=30),
 status text not null default 'requested' check(status in('requested','invoiced','paid','cancelled','declined')),
 requested_at timestamptz not null default clock_timestamp(), invoiced_at timestamptz, paid_at timestamptz,
 payment_note text, payment_url text, payment_reference text, review_note text,
 starts_at timestamptz, ends_at timestamptz,
 check(status<>'invoiced' or invoiced_at is not null),
 check(status<>'paid' or (paid_at is not null and starts_at is not null and ends_at>starts_at and payment_reference is not null))
);
create unique index kod_featured_open_request on kod_private.kod_featured_bookings(branch_id) where status in('requested','invoiced');
create unique index kod_featured_payment_reference on kod_private.kod_featured_bookings(upper(payment_reference)) where payment_reference is not null;
create index kod_featured_windows on kod_private.kod_featured_bookings(branch_id,ends_at) where status='paid';
create table kod_private.kod_featured_opens (
 booking_id uuid not null references kod_private.kod_featured_bookings(id) on delete cascade,
 member_id uuid not null references auth.users(id) on delete cascade, primary key(booking_id,member_id)
);
alter table kod_private.kod_featured_pricing enable row level security;
alter table kod_private.kod_featured_bookings enable row level security;
alter table kod_private.kod_featured_opens enable row level security;
revoke all on kod_private.kod_featured_pricing,kod_private.kod_featured_bookings,kod_private.kod_featured_opens from public,anon,authenticated;

create function kod_private.kod_featured_public() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('price_fils',(select price_fils from kod_private.kod_featured_pricing where id),'days',30,
  'restaurants',coalesce((select jsonb_agg(jsonb_build_object(
    'booking',b.id,'id',r.id,'name',r.name,'city',r.city,'category',r.category,'photo',r.photo,
    'branch_address',r.branch_address,'public_phone',r.public_phone,'public_whatsapp',r.public_whatsapp,
    'percent',r.percent,'instore_percent',r.instore_percent,'silver_extra',r.silver_extra,'gold_extra',r.gold_extra,
    'approved',true,'is_demo',false,'is_open',r.is_open,'delivery_fee_cents',r.delivery_fee_cents,'minimum_order_cents',r.minimum_order_cents,'ends',b.ends_at)
    order by md5(r.id::text||((now() at time zone 'Asia/Dubai')::date)::text),r.id)
   from kod_private.kod_featured_bookings b join public.kod_restaurants r on r.id=b.branch_id
   where b.status='paid' and b.starts_at<=now() and b.ends_at>now() and r.approved and not r.is_demo),'[]'::jsonb))
$$;
create function kod_private.kod_featured_desk() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare actor uuid:=auth.uid(); is_owner boolean:=kod_private.kod_is_developer();
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('developer','merchant') then raise exception 'merchant_required';end if;
 return jsonb_build_object('bookings',coalesce((select jsonb_agg(jsonb_build_object(
  'id',b.id,'branch',r.id,'name',r.name,'city',r.city,'approved',r.approved and not r.is_demo,
  'state',b.status,'amount_fils',b.amount_fils,'days',b.days,'asked',b.requested_at,'invoiced',b.invoiced_at,'paid',b.paid_at,
  'starts',b.starts_at,'ends',b.ends_at,'payment_note',b.payment_note,'payment_url',b.payment_url,'reference',b.payment_reference,'review_note',b.review_note,
  'opens',(select count(*) from kod_private.kod_featured_opens o where o.booking_id=b.id))
  order by b.requested_at desc,b.id)
  from kod_private.kod_featured_bookings b join public.kod_restaurants r on r.id=b.branch_id
  where is_owner or (r.owner_id=actor and b.applicant=actor)),'[]'::jsonb));
end $$;
create function kod_private.kod_featured_request(p_branch uuid,p_request uuid,p_expected_fils integer) returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); branch public.kod_restaurants%rowtype; old kod_private.kod_featured_bookings%rowtype; price integer; result uuid;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('developer','merchant') or p_request is null then raise exception 'merchant_required';end if;
 select * into branch from public.kod_restaurants where id=p_branch and approved and not is_demo for update;
 if not found or not(kod_private.kod_is_developer() or actor=branch.owner_id) then raise exception 'branch_required';end if;
 select * into old from kod_private.kod_featured_bookings where applicant=branch.owner_id and request_id=p_request;
 if found then
   if old.branch_id<>p_branch or old.amount_fils is distinct from p_expected_fils then raise exception 'request_mismatch';end if;
   return old.id;
 end if;
 select * into old from kod_private.kod_featured_bookings where branch_id=p_branch and status in('requested','invoiced');
 if found then return old.id;end if;
 select price_fils into strict price from kod_private.kod_featured_pricing where id for share;
 if price is distinct from p_expected_fils then raise exception 'price_changed';end if;
 insert into kod_private.kod_featured_bookings(branch_id,applicant,request_id,amount_fils) values(p_branch,branch.owner_id,p_request,price) returning id into result;
 return result;
end $$;
create function kod_private.kod_featured_price(p_fils integer) returns integer language plpgsql security definer set search_path='' as $$
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if not coalesce(p_fils between 100 and 9999900,false) then raise exception 'invalid_amount';end if;
 update kod_private.kod_featured_pricing set price_fils=p_fils where id;
 return p_fils;
end $$;
create function kod_private.kod_featured_invoice(p_id uuid,p_note text,p_url text) returns void language plpgsql security definer set search_path='' as $$
declare row kod_private.kod_featured_bookings%rowtype; note text:=trim(coalesce(p_note,'')); url text:=trim(coalesce(p_url,''));
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if not kod_private.kod_invoice_details_ok(note,url) then raise exception 'invalid_invoice';end if;
 select * into row from kod_private.kod_featured_bookings where id=p_id for update;
 if not found or row.status not in('requested','invoiced') then raise exception 'booking_changed';end if;
 if not exists(select from public.kod_restaurants r where r.id=row.branch_id and r.owner_id=row.applicant and r.approved and not r.is_demo) then raise exception 'branch_required';end if;
 update kod_private.kod_featured_bookings set status='invoiced',payment_note=nullif(note,''),payment_url=nullif(url,''),invoiced_at=coalesce(invoiced_at,clock_timestamp()) where id=p_id;
end $$;
create function kod_private.kod_featured_settle(p_id uuid,p_fils integer,p_reference text) returns jsonb language plpgsql security definer set search_path='' as $$
declare row kod_private.kod_featured_bookings%rowtype; branch uuid; start_time timestamptz; stop_time timestamptz; paid_time timestamptz:=clock_timestamp(); ref text:=trim(coalesce(p_reference,''));
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if length(ref) not between 3 and 100 or ref ~ '[[:cntrl:]]' then raise exception 'invalid_reference';end if;
 select branch_id into branch from kod_private.kod_featured_bookings where id=p_id;
 if branch is null then raise exception 'booking_changed';end if;
 perform 1 from public.kod_restaurants where id=branch and approved and not is_demo for update;
 if not found then raise exception 'branch_required';end if;
 select * into strict row from kod_private.kod_featured_bookings where id=p_id for update;
 if not exists(select from public.kod_restaurants r where r.id=branch and r.owner_id=row.applicant) then raise exception 'branch_required';end if;
 if row.amount_fils is distinct from p_fils then raise exception 'amount_mismatch';end if;
 if row.status='paid' and upper(row.payment_reference)=upper(ref) then return jsonb_build_object('starts',row.starts_at,'ends',row.ends_at);end if;
 if row.status<>'invoiced' then raise exception 'booking_changed';end if;
 select greatest(paid_time,max(ends_at)) into start_time from kod_private.kod_featured_bookings where branch_id=branch and status='paid';
 stop_time:=start_time+make_interval(days=>row.days);
 insert into kod_private.kod_manual_payments values(upper(ref),p_id,'restaurant');
 update kod_private.kod_featured_bookings set status='paid',paid_at=paid_time,payment_reference=ref,starts_at=start_time,ends_at=stop_time where id=p_id;
 return jsonb_build_object('starts',start_time,'ends',stop_time);
exception when unique_violation then raise exception 'duplicate_reference';
end $$;
create function kod_private.kod_featured_close(p_id uuid,p_reason text) returns void language plpgsql security definer set search_path='' as $$
declare row kod_private.kod_featured_bookings%rowtype; admin boolean:=kod_private.kod_is_developer(); actor uuid:=auth.uid(); target text;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('merchant','developer') then raise exception 'merchant_required';end if;
 select * into row from kod_private.kod_featured_bookings where id=p_id for update;
 if not found or not(admin or (row.applicant=actor and kod_private.kod_owns_restaurant(row.branch_id))) then raise exception 'branch_required';end if;
 target:=case when admin then 'declined' else 'cancelled' end;
 if row.status=target then return;end if;
 if row.status not in('requested','invoiced') or (row.status='invoiced' and not admin) then raise exception 'booking_changed';end if;
 if admin and coalesce(length(trim(p_reason)),0) not between 2 and 220 then raise exception 'reason_required';end if;
 update kod_private.kod_featured_bookings set status=target,review_note=case when admin then trim(p_reason) end where id=p_id;
end $$;
create function kod_private.kod_featured_open(p_booking uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or kod_private.kod_role() is distinct from 'customer' then return;end if;
 insert into kod_private.kod_featured_opens(booking_id,member_id) select b.id,auth.uid() from kod_private.kod_featured_bookings b
 join public.kod_restaurants r on r.id=b.branch_id where b.id=p_booking and b.status='paid' and b.starts_at<=now() and b.ends_at>now()
 and r.approved and not r.is_demo and r.owner_id<>auth.uid() on conflict do nothing;
end $$;

create function public.kod_featured_public() returns jsonb language sql stable security invoker set search_path='' as $$select kod_private.kod_featured_public()$$;
create function public.kod_featured_desk() returns jsonb language sql stable security invoker set search_path='' as $$select kod_private.kod_featured_desk()$$;
create function public.kod_featured_request(p_branch uuid,p_request uuid,p_expected_fils integer) returns uuid language sql security invoker set search_path='' as $$select kod_private.kod_featured_request(p_branch,p_request,p_expected_fils)$$;
create function public.kod_featured_price(p_fils integer) returns integer language sql security invoker set search_path='' as $$select kod_private.kod_featured_price(p_fils)$$;
create function public.kod_featured_invoice(p_id uuid,p_note text,p_url text) returns void language sql security invoker set search_path='' as $$select kod_private.kod_featured_invoice(p_id,p_note,p_url)$$;
create function public.kod_featured_settle(p_id uuid,p_fils integer,p_reference text) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_featured_settle(p_id,p_fils,p_reference)$$;
create function public.kod_featured_close(p_id uuid,p_reason text) returns void language sql security invoker set search_path='' as $$select kod_private.kod_featured_close(p_id,p_reason)$$;
create function public.kod_featured_open(p_booking uuid) returns void language sql security invoker set search_path='' as $$select kod_private.kod_featured_open(p_booking)$$;
do $grants$
declare sig text; ns text;
begin
 foreach sig in array array['kod_featured_public()','kod_featured_desk()','kod_featured_request(uuid,uuid,integer)','kod_featured_price(integer)','kod_featured_invoice(uuid,text,text)','kod_featured_settle(uuid,integer,text)','kod_featured_close(uuid,text)','kod_featured_open(uuid)'] loop
  foreach ns in array array['public','kod_private'] loop
   execute format('revoke all on function %I.%s from public,anon,authenticated',ns,sig);
   execute format('grant execute on function %I.%s to authenticated',ns,sig);
   if sig='kod_featured_public()' then execute format('grant execute on function %I.%s to anon',ns,sig);end if;
  end loop;
 end loop;
end $grants$;
notify pgrst,'reload schema';
commit;

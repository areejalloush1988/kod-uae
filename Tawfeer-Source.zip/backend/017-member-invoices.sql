begin;
alter table public.kod_subscription_orders drop constraint kod_subscription_orders_rail_check,
 add constraint kod_subscription_orders_rail_check check(rail in('stripe','etisalat','du','invoice'));
create table kod_private.kod_member_invoices (
 id uuid primary key default gen_random_uuid(),member_id uuid not null references auth.users(id) on delete cascade,
 request_id uuid not null,unique(member_id,request_id),months smallint not null check(months in(1,3,6,12)),
 amount_fils integer not null check(amount_fils>0),status text not null default 'requested' check(status in('requested','invoiced','paid','cancelled','declined')),
 requested_at timestamptz not null default clock_timestamp(),invoiced_at timestamptz,paid_at timestamptz,
 payment_note text,payment_url text,payment_reference text,review_note text,
 paid_order uuid unique references public.kod_subscription_orders(id),check((status='paid')=(paid_order is not null))
);
create unique index kod_open_member_invoice on kod_private.kod_member_invoices(member_id,months) where status in('requested','invoiced');
alter table kod_private.kod_member_invoices enable row level security;
revoke all on kod_private.kod_member_invoices from public,anon,authenticated;
create function kod_private.kod_member_invoice_request(p_months integer,p_request uuid,p_expected_fils integer) returns uuid
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); amount integer:=case p_months when 1 then 6900 when 3 then 18900 when 6 then 35900 when 12 then 59900 end;
 row kod_private.kod_member_invoices%rowtype; result uuid;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('customer','developer') then raise exception 'member_required';end if;
 if p_request is null or amount is null or amount is distinct from p_expected_fils then raise exception 'invalid_amount';end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,35123));
 select * into row from kod_private.kod_member_invoices where member_id=actor and request_id=p_request;
 if found then
  if row.months<>p_months then raise exception 'request_mismatch';end if;
  return row.id;
 end if;
 select id into result from kod_private.kod_member_invoices where member_id=actor and months=p_months and status in('requested','invoiced');
 if result is not null then return result;end if;
 insert into kod_private.kod_member_invoices(member_id,request_id,months,amount_fils) values(actor,p_request,p_months,amount) returning id into result;
 return result;
end $$;
create function kod_private.kod_member_invoice_desk() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare actor uuid:=auth.uid(); admin boolean:=kod_private.kod_is_developer();
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('customer','developer') then raise exception 'member_required';end if;
 return jsonb_build_object('invoices',coalesce((select jsonb_agg(jsonb_build_object('id',b.id,'name',coalesce(nullif(p.full_name,''),'عضو توفير'),
   'mine',b.member_id=actor,'months',b.months,'amount_fils',b.amount_fils,'state',b.status,'asked',b.requested_at,'invoiced',b.invoiced_at,
   'note',b.payment_note,'url',b.payment_url,'review_note',b.review_note,'starts',o.valid_from,'ends',o.valid_until)
   order by b.requested_at desc,b.id) from kod_private.kod_member_invoices b join public.kod_profiles p on p.id=b.member_id
   left join public.kod_subscription_orders o on o.id=b.paid_order where b.member_id=actor or admin),'[]'::jsonb));
end $$;
create function kod_private.kod_member_invoice_update(p_id uuid,p_action text,p_note text,p_url text,p_fils integer,p_reference text) returns void
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); admin boolean:=kod_private.kod_is_developer(); b kod_private.kod_member_invoices%rowtype;
 note text:=trim(coalesce(p_note,''));url text:=trim(coalesce(p_url,''));ref text:=trim(coalesce(p_reference,''));o uuid; target text;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in('customer','developer') then raise exception 'member_required';end if;
 if not admin and p_action is distinct from 'close' then raise exception 'operator_required';end if;
 select * into b from kod_private.kod_member_invoices where id=p_id and (admin or member_id=actor) for update;
 if not found then raise exception 'booking_changed';end if;
 if p_action='invoice' then
  if b.status not in('requested','invoiced') then raise exception 'booking_changed';end if;
  if not kod_private.kod_invoice_details_ok(note,url) then raise exception 'invalid_invoice';end if;
  update kod_private.kod_member_invoices set status='invoiced',payment_note=nullif(note,''),payment_url=nullif(url,''),invoiced_at=coalesce(invoiced_at,clock_timestamp()) where id=p_id;
 elsif p_action='settle' then
  if p_fils is distinct from b.amount_fils then raise exception 'amount_mismatch';end if;
  if length(ref) not between 3 and 100 or ref ~ '[[:cntrl:]]' then raise exception 'invalid_reference';end if;
  if b.status='paid' and upper(b.payment_reference)=upper(ref) then return;end if;
  if b.status<>'invoiced' then raise exception 'booking_changed';end if;
  insert into kod_private.kod_manual_payments values(upper(ref),p_id,'member');
  insert into public.kod_subscription_orders(user_id,request_id,months,amount_fils,rail,checkout_ref)
   values(b.member_id,b.id,b.months,b.amount_fils,'invoice','KOD-INV-'||b.id) returning id into o;
  perform public.kod_settle_subscription(o,'invoice','KOD-INV-'||b.id,'KOD-INV-'||b.id,'','AED',b.amount_fils);
  update kod_private.kod_member_invoices set status='paid',paid_at=clock_timestamp(),paid_order=o,payment_reference=ref where id=p_id;
 elsif p_action='close' then
  target:=case when admin then 'declined' else 'cancelled' end;
  if b.status=target then return;end if;
  if b.status not in('requested','invoiced') or (not admin and b.status='invoiced') then raise exception 'booking_changed';end if;
  if admin and length(note) not between 2 and 220 then raise exception 'reason_required';end if;
  update kod_private.kod_member_invoices set status=target,review_note=case when admin then note end where id=p_id;
 else raise exception 'invalid_request';end if;
exception when unique_violation then raise exception 'duplicate_reference';
end $$;
create function public.kod_member_invoice_request(p_months integer,p_request uuid,p_expected_fils integer) returns uuid language sql security invoker set search_path='' as $$select kod_private.kod_member_invoice_request(p_months,p_request,p_expected_fils)$$;
create function public.kod_member_invoice_desk() returns jsonb language sql stable security invoker set search_path='' as $$select kod_private.kod_member_invoice_desk()$$;
create function public.kod_member_invoice_update(p_id uuid,p_action text,p_note text,p_url text,p_fils integer,p_reference text) returns void language sql security invoker set search_path='' as $$select kod_private.kod_member_invoice_update(p_id,p_action,p_note,p_url,p_fils,p_reference)$$;
do $grants$
declare sig text;ns text;
begin
 foreach sig in array array['kod_member_invoice_request(integer,uuid,integer)','kod_member_invoice_desk()','kod_member_invoice_update(uuid,text,text,text,integer,text)'] loop
  foreach ns in array array['public','kod_private'] loop
   execute format('revoke all on function %I.%s from public,anon,authenticated',ns,sig);
   execute format('grant execute on function %I.%s to authenticated',ns,sig);
  end loop;
 end loop;
end $grants$;
notify pgrst,'reload schema';
commit;

begin;

alter table kod_private.kod_referral_program
 add cash_started timestamptz not null default now();
alter table kod_private.kod_referrals alter column days drop not null;
alter table kod_private.kod_referrals
 add cash_offer boolean not null default false,
 add cash_state text check(cash_state in ('review','available','requested','paid','void')),
 add reviewed_at timestamptz, add requested_at timestamptz, add paid_out_at timestamptz,
 add payout_reference text, add refund_reference text,
 add constraint kod_referral_unit check ((cash_offer and days is null and applied_at is null) or (not cash_offer and days is not null and cash_state is null)),
 add constraint kod_cash_state_requires_payment check (not cash_offer or ((paid_order is not null)=(cash_state is not null)));
create index kod_cash_review_queue on kod_private.kod_referrals(earned_at desc,paid_order desc) where cash_offer and paid_order is not null;

create or replace function kod_private.kod_invite_offer(p_code text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare cfg kod_private.kod_referral_program%rowtype; info jsonb; payload text;
begin
 select * into strict cfg from kod_private.kod_referral_program where id;
 info:=jsonb_build_object('cash_fils',2500);
 if p_code is null then return info;end if;
 if p_code !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then return info||'{"valid":false}'::jsonb;end if;
 if not exists(select from kod_private.kod_referral_links where code=p_code::uuid) then return info||'{"valid":false}'::jsonb;end if;
 payload:='cash25.'||p_code||'.'||floor(extract(epoch from clock_timestamp())*1000)::bigint;
 return info||jsonb_build_object('valid',true,'ticket',payload||'.'||encode(extensions.hmac(payload,cfg.signing_key,'sha256'),'hex'));
end $$;

-- Honor already issued day offers. The new, separately signed ticket has no client-supplied amount.
create or replace function kod_private.kod_attach_invite(p_user uuid,p_ticket text) returns boolean
language plpgsql security definer set search_path='' as $$
declare cfg kod_private.kod_referral_program%rowtype; parts text[]; payload text; signature text; sponsor uuid; signed_at timestamptz; born timestamptz; bonus integer; cash boolean;
begin
 if p_ticket is null or length(p_ticket)>140 then return false;end if;
 select * into strict cfg from kod_private.kod_referral_program where id;
 cash:=left(p_ticket,7)='cash25.';
 if cash then
  parts:=regexp_match(p_ticket,'^cash25\.([0-9a-f-]{36})\.([0-9]{13})\.([0-9a-f]{64})$');
  if parts is null then return false;end if;
  payload:='cash25.'||parts[1]||'.'||parts[2];signature:=parts[3];
 else
  parts:=regexp_match(p_ticket,'^([0-9a-f-]{36})\.([0-9]{13})\.([1-9][0-9]{0,2})\.([0-9a-f]{64})$');
  if parts is null or parts[3]::integer>365 then return false;end if;
  bonus:=parts[3]::integer;payload:=parts[1]||'.'||parts[2]||'.'||parts[3];signature:=parts[4];
 end if;
 if signature<>encode(extensions.hmac(payload,cfg.signing_key,'sha256'),'hex') then return false;end if;
 signed_at:=to_timestamp(parts[2]::bigint/1000.0);
 if not cash and signed_at>cfg.cash_started then return false;end if;
 select user_id into sponsor from kod_private.kod_referral_links where code=parts[1]::uuid;
 if sponsor is null or sponsor=p_user then return false;end if;
 select u.created_at into born from auth.users u join public.kod_profiles p on p.id=u.id join kod_private.kod_account_roles r on r.user_id=u.id
  where u.id=p_user and r.role='customer' and p.requested_account_type='customer';
 if born is null or born<signed_at or born>signed_at+interval '7 days' or signed_at>clock_timestamp() then return false;end if;
 perform 1 from public.kod_memberships where user_id=p_user for update;
 if exists(select from public.kod_subscription_orders where user_id=p_user and status='paid') then return false;end if;
 insert into kod_private.kod_referrals(invitee,inviter,days,cash_offer) values(p_user,sponsor,bonus,cash) on conflict(invitee) do nothing;
 return exists(select from kod_private.kod_referrals where invitee=p_user and inviter=sponsor);
end $$;

create or replace function kod_private.kod_reward_first_subscription() returns trigger
language plpgsql security definer set search_path='' as $$
declare invite kod_private.kod_referrals%rowtype; moment timestamptz:=clock_timestamp();
begin
 select * into invite from kod_private.kod_referrals where invitee=new.user_id for update;
 if not found or invite.paid_order is not null or new.amount_fils<=0 then return new;end if;
 if invite.cash_offer then
  update kod_private.kod_referrals set paid_order=new.id,earned_at=moment,cash_state='review' where invitee=new.user_id;
 else
  update kod_private.kod_referrals set paid_order=new.id,earned_at=moment where invitee=new.user_id;
  update public.kod_memberships set status='active',expires_at=case when status='active' then greatest(expires_at,moment) else moment end where user_id=invite.inviter and status<>'cancelled';
 end if;
 return new;
end $$;
create or replace function kod_private.kod_apply_referral_days() returns trigger
language plpgsql security definer set search_path='' as $$
declare extra integer;moment timestamptz:=clock_timestamp();
begin
 if new.status='active' then
  with earned as (update kod_private.kod_referrals set applied_at=moment where inviter=new.user_id and not cash_offer and earned_at is not null and applied_at is null returning days) select sum(days)::integer into extra from earned;
  if extra is not null then new.expires_at:=greatest(coalesce(new.expires_at,moment),moment)+make_interval(days=>extra);end if;
 end if;return new;
end $$;

create or replace function kod_private.kod_referral_home() returns jsonb language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();code_value uuid;result jsonb;
begin
 if actor is null or coalesce(kod_private.kod_role(),'') not in ('customer','developer') then raise exception 'member_required';end if;
 insert into public.kod_memberships(user_id) values(actor) on conflict do nothing;
 insert into kod_private.kod_referral_links(user_id) values(actor) on conflict do nothing;
 select code into strict code_value from kod_private.kod_referral_links where user_id=actor;
 select jsonb_build_object('code',code_value,'joined',count(*),'paid',count(paid_order),'earned_days',coalesce(sum(days) filter(where earned_at is not null),0),
 'applied_days',coalesce(sum(days) filter(where applied_at is not null),0),'review_fils',2500*count(*) filter(where cash_state='review'),
 'available_fils',2500*count(*) filter(where cash_state='available'),'requested_fils',2500*count(*) filter(where cash_state='requested'),
 'paid_fils',2500*count(*) filter(where cash_state='paid'),'void_fils',2500*count(*) filter(where cash_state='void')) into result from kod_private.kod_referrals where inviter=actor;
 return result||kod_private.kod_invite_offer(null);
end $$;

create function kod_private.kod_cash_review_page(p_before timestamptz,p_order uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if (p_before is null)<>(p_order is null) then raise exception 'invalid_cursor';end if;
 return (with page as (select r.*,p.full_name,coalesce(case when u.phone_confirmed_at is not null then nullif(u.phone,'') end,case when u.email_confirmed_at is not null then u.email end) as contact,o.amount_fils,o.rail,o.transaction_ref
  from kod_private.kod_referrals r join auth.users u on u.id=r.inviter join public.kod_profiles p on p.id=u.id join public.kod_subscription_orders o on o.id=r.paid_order
  where r.cash_offer and r.paid_order is not null and (p_before is null or (r.earned_at,r.paid_order)<(p_before,p_order)) order by r.earned_at desc,r.paid_order desc limit 26),
 shown as (select * from page order by earned_at desc,paid_order desc limit 25)
 select jsonb_build_object('more',(select count(*)>25 from page),'rows',coalesce(jsonb_agg(jsonb_build_object('order_id',paid_order,'name',full_name,'contact',contact,'state',cash_state,'earned_at',earned_at,'amount_fils',2500,'order_fils',amount_fils,'rail',rail,'payment_ref',transaction_ref,'payout_ref',payout_reference) order by earned_at desc,paid_order desc),'[]'::jsonb)) from shown);
end $$;
create function public.kod_cash_review_page(p_before timestamptz,p_order uuid) returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_cash_review_page(p_before,p_order)$$;
create or replace function kod_private.kod_referral_admin(p_days integer default null) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if p_days is not null then raise exception 'cash_program_active';end if;
 return kod_private.kod_cash_review_page(null,null)||jsonb_build_object('cash_fils',2500,'due_fils',(select count(*)*2500 from kod_private.kod_referrals where cash_state in ('review','available','requested')));
end $$;

create function kod_private.kod_request_reward_cash() returns integer language plpgsql security definer set search_path='' as $$
declare n integer;begin
 if auth.uid() is null then raise exception 'member_required';end if;
 update kod_private.kod_referrals set cash_state='requested',requested_at=now() where inviter=auth.uid() and cash_state='available';get diagnostics n=row_count;return n;
end $$;
create function kod_private.kod_review_reward_cash(p_order uuid,p_action text,p_reference text,p_verified boolean) returns void language plpgsql security definer set search_path='' as $$
declare r kod_private.kod_referrals%rowtype;ref text:=nullif(trim(p_reference),'');begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 select * into r from kod_private.kod_referrals where paid_order=p_order and cash_offer for update;
 if not found or p_verified is not true then raise exception 'review_required';end if;
 if p_action='approve' and r.cash_state='review' and exists(select from public.kod_subscription_orders where id=p_order and status='paid') then
  update kod_private.kod_referrals set cash_state='available',reviewed_at=now() where invitee=r.invitee;
 elsif p_action='pay' and r.cash_state='requested' and length(ref) between 3 and 120 then
  update kod_private.kod_referrals set cash_state='paid',paid_out_at=now(),payout_reference=ref where invitee=r.invitee;
 elsif p_action='refund' and r.cash_state in('review','available','requested') and length(ref) between 3 and 120 then
  update kod_private.kod_referrals set cash_state='void',refund_reference=ref where invitee=r.invitee;
 elsif (p_action='pay' and r.cash_state='paid' and ref=r.payout_reference) or (p_action='approve' and r.reviewed_at is not null) or (p_action='refund' and r.cash_state='void' and ref=r.refund_reference) then return;
 else raise exception 'reward_state_changed';end if;
end $$;
create function public.kod_request_reward_cash() returns integer language sql security invoker set search_path='' as $$select kod_private.kod_request_reward_cash()$$;
create function public.kod_review_reward_cash(p_order uuid,p_action text,p_reference text,p_verified boolean) returns void language sql security invoker set search_path='' as $$select kod_private.kod_review_reward_cash(p_order,p_action,p_reference,p_verified)$$;
do $$declare ns text;sig text;begin foreach ns in array array['kod_private','public'] loop foreach sig in array array['kod_request_reward_cash()','kod_review_reward_cash(uuid,text,text,boolean)','kod_cash_review_page(timestamptz,uuid)'] loop execute format('revoke all on function %I.%s from public, anon, authenticated',ns,sig);execute format('grant execute on function %I.%s to authenticated',ns,sig);end loop;end loop;end $$;
notify pgrst,'reload schema';
commit;

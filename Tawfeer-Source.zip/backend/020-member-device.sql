begin;
-- Issued cards, wallet passes and printed numbers identify a member. Only a linked browser can authorize a benefit.
create table kod_private.kod_member_devices (
 user_id uuid primary key references auth.users(id) on delete cascade, device_id uuid not null, signing_secret bytea not null check(length(signing_secret)=32), linked_at timestamptz not null default now());
create table kod_private.kod_device_transfers (
 user_id uuid primary key references auth.users(id) on delete cascade, device_id uuid not null, signing_secret bytea not null check(length(signing_secret)=32),requested_at timestamptz not null default now());
create table kod_private.kod_device_challenges (
 nonce uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,device_id uuid not null,session_id uuid not null,
 purpose text not null check(purpose in ('order','bill','decline')),target uuid not null,expires_at timestamptz not null,approved_at timestamptz,unique(user_id,session_id,purpose,target));
create table kod_private.kod_bill_approvals (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade, restaurant_id uuid not null references public.kod_restaurants(id) on delete cascade,
 business_day date not null,invoice_ref text not null,bill_cents integer not null,percent integer not null,expires_at timestamptz not null, approved_at timestamptz,finished_at timestamptz,presence_hash bytea,attempts smallint not null default 0,
 unique(user_id,restaurant_id,business_day,invoice_ref));
create index kod_bill_member_pending on kod_private.kod_bill_approvals(user_id,expires_at desc) where finished_at is null;
alter table kod_private.kod_member_devices enable row level security;alter table kod_private.kod_device_transfers enable row level security;
alter table kod_private.kod_device_challenges enable row level security;alter table kod_private.kod_bill_approvals enable row level security;
revoke all on kod_private.kod_member_devices,kod_private.kod_device_transfers,kod_private.kod_device_challenges,kod_private.kod_bill_approvals from public,anon,authenticated;

create function kod_private.kod_device_session() returns uuid language plpgsql stable security definer set search_path='' as $$
declare session_key uuid:=nullif(auth.jwt()->>'session_id','')::uuid;begin
 if auth.uid() is null or not exists(select from auth.sessions s where s.user_id=auth.uid() and s.id=session_key and (s.not_after is null or s.not_after>now())) then raise exception 'authentication_required';end if;
 return session_key;
end $$;
create function kod_private.kod_device_status() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare actor uuid:=auth.uid();begin
 perform kod_private.kod_device_session();
 if coalesce(kod_private.kod_role(),'') not in ('customer','developer') then raise exception 'member_required';end if;
 return jsonb_build_object('device',(select device_id from kod_private.kod_member_devices where user_id=actor),'replacement',(select device_id from kod_private.kod_device_transfers where user_id=actor and requested_at>now()-interval '7 days'),
 'bills',coalesce((select jsonb_agg(jsonb_build_object('id',a.id,'restaurant_name',r.name,'invoice_ref',a.invoice_ref,'expires_at',a.expires_at,'bill_cents',a.bill_cents,'percent',a.percent,'discount_cents',round(a.bill_cents::numeric*a.percent/100),'net_cents',a.bill_cents-round(a.bill_cents::numeric*a.percent/100),'approved',a.approved_at is not null) order by a.expires_at desc)
 from kod_private.kod_bill_approvals a join public.kod_restaurants r on r.id=a.restaurant_id where a.user_id=actor and a.finished_at is null and a.expires_at>clock_timestamp()),'[]'::jsonb));
end $$;
create function kod_private.kod_link_device(p_device uuid,p_secret text,p_replace boolean) returns text language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();bound uuid;begin
 perform kod_private.kod_device_session();
 if coalesce(kod_private.kod_role(),'') not in ('customer','developer') or not exists(select from auth.users where id=actor and (email_confirmed_at is not null or phone_confirmed_at is not null)) then raise exception 'member_required';end if;
 if p_device is null or p_secret is null or p_secret !~ '^[0-9a-f]{64}$' then raise exception 'invalid_device';end if;
 perform pg_advisory_xact_lock(hashtextextended('device:'||actor::text,0));
 select device_id into bound from kod_private.kod_member_devices where user_id=actor;
 if bound is null then
  insert into kod_private.kod_member_devices(user_id,device_id,signing_secret) values(actor,p_device,decode(p_secret,'hex'));return 'linked';
 elsif bound=p_device then return 'linked';
 elsif p_replace is not true then raise exception 'other_device';end if;
 insert into kod_private.kod_device_transfers(user_id,device_id,signing_secret) values(actor,p_device,decode(p_secret,'hex'))
 on conflict(user_id) do update set device_id=excluded.device_id,signing_secret=excluded.signing_secret,requested_at=now() where kod_private.kod_device_transfers.requested_at<=now()-interval '7 days';
 if not exists(select from kod_private.kod_device_transfers where user_id=actor and device_id=p_device) then raise exception 'transfer_pending';end if;
 return 'pending';
end $$;
create function kod_private.kod_device_requests() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 return coalesce((select jsonb_agg(jsonb_build_object('user',t.user_id,'device',t.device_id,'name',p.full_name,'contact',coalesce(case when u.phone_confirmed_at is not null then nullif(u.phone,'') end,case when u.email_confirmed_at is not null then u.email end)) order by t.requested_at)
 from kod_private.kod_device_transfers t join auth.users u on u.id=t.user_id join public.kod_profiles p on p.id=t.user_id where t.requested_at>now()-interval '7 days'),'[]'::jsonb);
end $$;
create function kod_private.kod_review_device(p_user uuid,p_device uuid,p_approve boolean,p_verified boolean) returns void language plpgsql security definer set search_path='' as $$
declare replacement kod_private.kod_device_transfers%rowtype;begin
 if not kod_private.kod_is_developer() then raise exception 'operator_required';end if;
 if p_approve is null or (p_approve and p_verified is not true) then raise exception 'review_required'; end if;
 perform pg_advisory_xact_lock(hashtextextended('device:'||p_user::text,0));
 delete from kod_private.kod_device_transfers where user_id=p_user and device_id=p_device and requested_at>now()-interval '7 days' returning * into replacement;
 if not found then raise exception 'request_changed';end if;
 if p_approve then
  update kod_private.kod_member_devices set device_id=replacement.device_id,signing_secret=replacement.signing_secret,linked_at=now() where user_id=p_user;
  delete from kod_private.kod_device_challenges where user_id=p_user;
  update kod_private.kod_bill_approvals set approved_at=null,presence_hash=null,attempts=0 where user_id=p_user and finished_at is null and expires_at>clock_timestamp();
 end if;
end $$;

create function kod_private.kod_device_challenge(p_device uuid,p_purpose text,p_target uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();sid uuid:=kod_private.kod_device_session();value uuid;begin
 if p_target is null or p_purpose is null or p_purpose not in ('order','bill','decline') then raise exception 'invalid_request';end if;
 perform 1 from kod_private.kod_member_devices where user_id=actor and device_id=p_device for share;
 if not found then raise exception 'other_device';end if;
 if p_purpose<>'order' and not exists(select from kod_private.kod_bill_approvals where id=p_target and user_id=actor and finished_at is null and expires_at>clock_timestamp()) then raise exception 'bill_expired';end if;
 delete from kod_private.kod_device_challenges where user_id=actor and expires_at<=clock_timestamp();
 if (select count(*) from kod_private.kod_device_challenges where user_id=actor)>=64 then raise exception 'too_many_requests';end if;
 insert into kod_private.kod_device_challenges(user_id,device_id,session_id,purpose,target,expires_at) values(actor,p_device,sid,p_purpose,p_target,clock_timestamp()+interval '90 seconds')
 on conflict(user_id,session_id,purpose,target) do update set nonce=excluded.nonce,device_id=excluded.device_id,expires_at=excluded.expires_at,approved_at=null returning nonce into value;
 return value;
end $$;
create function kod_private.kod_device_prove(p_nonce uuid,p_signature text) returns text language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();sid uuid:=kod_private.kod_device_session();proof kod_private.kod_device_challenges%rowtype;secret bytea;expected bytea;code text;begin
 select signing_secret into secret from kod_private.kod_member_devices where user_id=actor for share;
 select c.* into proof from kod_private.kod_device_challenges c join kod_private.kod_member_devices d on d.user_id=c.user_id and d.device_id=c.device_id where c.nonce=p_nonce and c.user_id=actor and c.session_id=sid and c.expires_at>clock_timestamp() for update of c;
 if not found or p_signature is null or p_signature !~ '^[0-9a-f]{64}$' then raise exception 'device_proof_required';end if;
 expected:=extensions.hmac(convert_to('tawfeer-v1|'||proof.nonce||'|'||proof.purpose||'|'||proof.target,'UTF8'),secret,'sha256');
 if sha256(expected)<>sha256(decode(p_signature,'hex')) then raise exception 'device_proof_required';end if;
 if proof.purpose='order' then update kod_private.kod_device_challenges set approved_at=clock_timestamp() where nonce=p_nonce;
 else
  if proof.purpose='bill' then
   code:=lpad(((('x'||substr(encode(extensions.hmac(convert_to('presence|'||proof.target,'UTF8'),secret,'sha256'),'hex'),1,8))::bit(32)::bigint)%1000000)::text,6,'0');
  end if;
  update kod_private.kod_bill_approvals set presence_hash=case when code is not null then sha256(convert_to(code,'UTF8')) end,approved_at=case when proof.purpose='bill' then clock_timestamp() end,finished_at=case when proof.purpose='decline' then clock_timestamp() end where id=proof.target and user_id=actor and expires_at>clock_timestamp() and finished_at is null;
  if not found then raise exception 'bill_expired';end if;
  delete from kod_private.kod_device_challenges where nonce=p_nonce;
 end if;return code;
end $$;
create function kod_private.kod_guard_order_discount() returns trigger language plpgsql security definer set search_path='' as $$
declare sid uuid:=kod_private.kod_device_session();begin
 if auth.uid() is distinct from new.customer_id then raise exception 'device_proof_required';end if;
 perform 1 from kod_private.kod_member_devices where user_id=new.customer_id for share;
 delete from kod_private.kod_device_challenges c using kod_private.kod_member_devices d where c.user_id=new.customer_id and c.session_id=sid and c.device_id=d.device_id and d.user_id=c.user_id and c.purpose='order' and c.target=new.request_id and c.approved_at is not null and c.expires_at>clock_timestamp();
 if not found then raise exception 'device_proof_required';end if;return new;
end $$;
create trigger kod_order_member_device before insert on public.kod_orders for each row when(new.discount_cents>0) execute function kod_private.kod_guard_order_discount();

create function kod_private.kod_checked_instore_bill(p_restaurant_id uuid,p_card_number text,p_bill_cents integer,p_invoice text,p_request_id uuid,p_expected_percent integer,p_code text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare
 branch public.kod_restaurants%rowtype; member_id uuid; membership public.kod_memberships%rowtype; receipt public.kod_instore_receipts%rowtype;
 reference text:=upper(trim(p_invoice)); business_date date:=(now() at time zone 'Asia/Dubai')::date; saving integer; effective integer; level text; result jsonb; approval kod_private.kod_bill_approvals%rowtype;
begin
 if auth.uid() is null or not (kod_private.kod_is_developer() or (coalesce(kod_private.kod_role(),'')='merchant' and kod_private.kod_owns_restaurant(p_restaurant_id))) then raise exception 'branch_required'; end if;
 if p_bill_cents is null or p_bill_cents not between 1 and 99999999 or reference is null or char_length(reference) not between 1 and 48 or reference ~ '[[:cntrl:]]' then raise exception 'invalid_invoice'; end if;
 if p_card_number is null or p_card_number !~ '^[0-9]{16}$' then raise exception 'card_unavailable'; end if;
 select user_id into member_id from kod_private.kod_member_cards where card_number=p_card_number;
 if not found then raise exception 'card_unavailable'; end if;
 if p_request_id is not null then
  perform pg_advisory_xact_lock(hashtextextended(p_request_id::text,0));
  select * into receipt from public.kod_instore_receipts where request_id=p_request_id;
  if found then
   if receipt.restaurant_id<>p_restaurant_id or receipt.customer_id<>member_id or receipt.bill_cents<>p_bill_cents or receipt.invoice_ref<>reference then raise exception 'request_mismatch'; end if;
   return jsonb_build_object('id',receipt.id,'restaurant_name',receipt.restaurant_name,'invoice_ref',receipt.invoice_ref,'bill_cents',receipt.bill_cents,'percent',receipt.percent,'discount_cents',receipt.discount_cents,'net_cents',receipt.net_cents);
  end if;
 end if;
 select * into branch from public.kod_restaurants where id=p_restaurant_id for share;
 if not found or not branch.approved or branch.is_demo or branch.instore_percent=0 then raise exception 'branch_unavailable'; end if;
 select * into membership from public.kod_memberships where user_id=member_id for share;
 if not found or membership.status<>'active' or membership.expires_at is null or membership.expires_at<=clock_timestamp() then raise exception 'card_unavailable'; end if;
 if exists(select 1 from public.kod_instore_receipts where restaurant_id=p_restaurant_id and business_day=business_date and invoice_ref=reference) then raise exception 'invoice_already_used'; end if;
 level:=kod_private.kod_club_level(member_id,clock_timestamp());
 if level is null then raise exception 'card_unavailable';end if;
 effective:=kod_private.kod_club_discount(level,branch.instore_percent,branch.silver_extra,branch.gold_extra);
 saving:=round(p_bill_cents::numeric*effective/100);
 result:=jsonb_build_object('restaurant_name',branch.name,'invoice_ref',reference,'bill_cents',p_bill_cents,'percent',effective,'discount_cents',saving,'net_cents',p_bill_cents-saving);
 if p_request_id is null then
  delete from kod_private.kod_bill_approvals where user_id=member_id and expires_at<now()-interval '1 day';
  insert into kod_private.kod_bill_approvals(user_id,restaurant_id,business_day,invoice_ref,bill_cents,percent,expires_at)
  values(member_id,branch.id,business_date,reference,p_bill_cents,effective,clock_timestamp()+interval '3 minutes')
  on conflict(user_id,restaurant_id,business_day,invoice_ref) do update set id=excluded.id,bill_cents=excluded.bill_cents,percent=excluded.percent,expires_at=excluded.expires_at,approved_at=null,finished_at=null,presence_hash=null,attempts=0
  where kod_private.kod_bill_approvals.expires_at<=clock_timestamp() or kod_private.kod_bill_approvals.finished_at is not null or kod_private.kod_bill_approvals.bill_cents<>excluded.bill_cents or kod_private.kod_bill_approvals.percent<>excluded.percent;
  select * into strict approval from kod_private.kod_bill_approvals where user_id=member_id and restaurant_id=branch.id and business_day=business_date and invoice_ref=reference;
  return result||jsonb_build_object('approval_id',approval.id,'approved',approval.approved_at is not null,'expires_at',approval.expires_at);
 end if;
 if p_expected_percent is distinct from effective then raise exception 'quote_changed'; end if;
 perform 1 from kod_private.kod_member_devices where user_id=member_id for share;
 select * into approval from kod_private.kod_bill_approvals where user_id=member_id and restaurant_id=branch.id and business_day=business_date and invoice_ref=reference and bill_cents=p_bill_cents and percent=effective for update;
 if not found or approval.approved_at is null then raise exception 'member_approval_required';end if;
 if approval.finished_at is not null or approval.expires_at<=clock_timestamp() then raise exception 'bill_expired';end if;
 if p_code is null or p_code !~ '^[0-9]{6}$' then raise exception 'presence_required';end if;
 if approval.presence_hash is distinct from sha256(convert_to(p_code,'UTF8')) then
  update kod_private.kod_bill_approvals set attempts=attempts+1,expires_at=case when attempts>=4 then clock_timestamp() else expires_at end where id=approval.id;
  return jsonb_build_object('error',case when approval.attempts>=4 then 'bill_expired' else 'presence_required' end);
 end if;
 update kod_private.kod_bill_approvals set finished_at=clock_timestamp(),presence_hash=null where id=approval.id;
 insert into public.kod_instore_receipts(request_id,customer_id,restaurant_id,restaurant_name,business_day,invoice_ref,bill_cents,percent,discount_cents)
 values(p_request_id,member_id,branch.id,branch.name,business_date,reference,p_bill_cents,effective,saving)
 on conflict (restaurant_id,business_day,invoice_ref) do nothing returning * into receipt;
 if not found then raise exception 'invoice_already_used'; end if;
 return result||jsonb_build_object('id',receipt.id);
end $$;

-- Old scans can identify the card and preview a bill. A new receipt needs the live six-digit code.
create or replace function kod_private.kod_instore_bill(p_restaurant_id uuid,p_card_number text,p_bill_cents integer,p_invoice text,p_request_id uuid,p_expected_percent integer) returns jsonb language sql security definer set search_path='' as $$
 select kod_private.kod_checked_instore_bill(p_restaurant_id,p_card_number,p_bill_cents,p_invoice,p_request_id,p_expected_percent,null)$$;
create function public.kod_confirm_present_bill(p_restaurant_id uuid,p_card_number text,p_bill_cents integer,p_invoice text,p_request_id uuid,p_expected_percent integer,p_code text) returns jsonb language sql security invoker set search_path='' as $$
 select kod_private.kod_checked_instore_bill(p_restaurant_id,p_card_number,p_bill_cents,p_invoice,p_request_id,p_expected_percent,p_code)$$;
revoke all on function kod_private.kod_checked_instore_bill(uuid,text,integer,text,uuid,integer,text),public.kod_confirm_present_bill(uuid,text,integer,text,uuid,integer,text) from public,anon,authenticated;
grant execute on function kod_private.kod_checked_instore_bill(uuid,text,integer,text,uuid,integer,text),public.kod_confirm_present_bill(uuid,text,integer,text,uuid,integer,text) to authenticated;
revoke all on function kod_private.kod_device_session(),kod_private.kod_guard_order_discount() from public,anon,authenticated;
create function public.kod_device_status() returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_device_status()$$;
revoke all on function public.kod_device_status(),kod_private.kod_device_status() from public,anon,authenticated;
grant execute on function public.kod_device_status(),kod_private.kod_device_status() to authenticated;
create function public.kod_link_device(p_device uuid,p_secret text,p_replace boolean) returns text language sql security invoker set search_path='' as $$select kod_private.kod_link_device(p_device,p_secret,p_replace)$$;
revoke all on function public.kod_link_device(uuid,text,boolean),kod_private.kod_link_device(uuid,text,boolean) from public,anon,authenticated;
grant execute on function public.kod_link_device(uuid,text,boolean),kod_private.kod_link_device(uuid,text,boolean) to authenticated;
create function public.kod_device_requests() returns jsonb language sql security invoker set search_path='' as $$select kod_private.kod_device_requests()$$;
revoke all on function public.kod_device_requests(),kod_private.kod_device_requests() from public,anon,authenticated;
grant execute on function public.kod_device_requests(),kod_private.kod_device_requests() to authenticated;
create function public.kod_review_device(p_user uuid,p_device uuid,p_approve boolean,p_verified boolean) returns void language sql security invoker set search_path='' as $$select kod_private.kod_review_device(p_user,p_device,p_approve,p_verified)$$;
revoke all on function public.kod_review_device(uuid,uuid,boolean,boolean),kod_private.kod_review_device(uuid,uuid,boolean,boolean) from public,anon,authenticated;
grant execute on function public.kod_review_device(uuid,uuid,boolean,boolean),kod_private.kod_review_device(uuid,uuid,boolean,boolean) to authenticated;
create function public.kod_device_challenge(p_device uuid,p_purpose text,p_target uuid) returns uuid language sql security invoker set search_path='' as $$select kod_private.kod_device_challenge(p_device,p_purpose,p_target)$$;
revoke all on function public.kod_device_challenge(uuid,text,uuid),kod_private.kod_device_challenge(uuid,text,uuid) from public,anon,authenticated;
grant execute on function public.kod_device_challenge(uuid,text,uuid),kod_private.kod_device_challenge(uuid,text,uuid) to authenticated;
create function public.kod_device_prove(p_nonce uuid,p_signature text) returns text language sql security invoker set search_path='' as $$select kod_private.kod_device_prove(p_nonce,p_signature)$$;
revoke all on function public.kod_device_prove(uuid,text),kod_private.kod_device_prove(uuid,text) from public,anon,authenticated;
grant execute on function public.kod_device_prove(uuid,text),kod_private.kod_device_prove(uuid,text) to authenticated;
notify pgrst,'reload schema';
commit;

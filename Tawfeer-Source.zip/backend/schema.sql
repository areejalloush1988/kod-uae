-- KOD accounts and ordering schema. Apply only to the selected KOD project.
-- Live ordering remains disabled until real partners and operating terms are ready.
begin;
create schema if not exists kod_private;
revoke all on schema kod_private from public;

create table public.kod_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '' check(char_length(full_name)<=80),
 requested_account_type text not null default 'customer' check(requested_account_type in('customer','merchant')),
 account_role text not null default 'customer' check(account_role in('customer','merchant','developer')),
 created_at timestamptz not null default now()
);
create table kod_private.kod_account_roles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 role text not null check(role in('customer','merchant','developer')),
 created_at timestamptz not null default now()
);
create table public.kod_platform_settings (
 id integer primary key check(id=1), ordering_enabled boolean not null default false,
 currency text not null default 'AED' check(currency='AED')
);
insert into public.kod_platform_settings(id) values(1);
create table public.kod_restaurants (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id),
 name text not null check(char_length(name) between 2 and 80), en text not null default '',
 city text not null check(city in('دبي','أبوظبي','الشارقة','عجمان','رأس الخيمة','الفجيرة','أم القيوين')),
 photo text not null default 'nandos', category text not null default 'food' check(category in('food','coffee')),
 percent integer not null default 0 check(percent between 0 and 70),
 delivery_fee_cents integer not null default 0 check(delivery_fee_cents between 0 and 5000),
 minimum_order_cents integer not null default 1000 check(minimum_order_cents between 1000 and 50000),
 approved boolean not null default false, is_open boolean not null default false,
 is_demo boolean not null default false, created_at timestamptz not null default now()
);
create index kod_restaurants_owner_idx on public.kod_restaurants(owner_id);
create table public.kod_menu_items (
 id uuid primary key default gen_random_uuid(), restaurant_id uuid not null references public.kod_restaurants(id) on delete cascade,
 name text not null check(char_length(name) between 1 and 100), category text not null default 'المنيو' check(char_length(category)<=50),
 description text not null default '' check(char_length(description)<=400),
 price_cents integer not null check(price_cents between 100 and 200000),
 is_available boolean not null default true, created_at timestamptz not null default now()
);
create index kod_menu_restaurant_idx on public.kod_menu_items(restaurant_id);
create table public.kod_memberships (
 user_id uuid primary key references auth.users(id) on delete cascade,
 status text not null default 'inactive' check(status in('inactive','active','cancelled')),
 expires_at timestamptz, created_at timestamptz not null default now()
);
create table public.kod_favorites (
 user_id uuid not null references auth.users(id) on delete cascade,
 offer_key text not null check(char_length(offer_key) between 1 and 80),
 primary key(user_id,offer_key)
);
create table public.kod_orders (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references auth.users(id),
 restaurant_id uuid not null references public.kod_restaurants(id), restaurant_name text not null,
 request_id uuid not null, request_fingerprint text not null,
 customer_name text not null check(char_length(customer_name) between 1 and 60),
 contact_phone text not null check(contact_phone ~ '^\+[1-9][0-9]{7,14}$'),
 delivery_address text not null default '' check(char_length(delivery_address)<=300),
 notes text not null default '' check(char_length(notes)<=300),
 fulfillment text not null check(fulfillment in('delivery','pickup')),
 status text not null default 'pending' check(status in('pending','accepted','preparing','out_for_delivery','ready_for_pickup','delivered','cancelled','rejected')),
 items jsonb not null check(jsonb_typeof(items)='array'),
 subtotal_cents integer not null check(subtotal_cents between 100 and 200000),
 discount_cents integer not null check(discount_cents>=0 and discount_cents<=subtotal_cents),
 delivery_fee_cents integer not null check(delivery_fee_cents between 0 and 5000),
 total_cents integer not null check(total_cents=subtotal_cents-discount_cents+delivery_fee_cents),
 events jsonb not null check(jsonb_typeof(events)='array'),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 unique(customer_id,request_id)
);
create index kod_orders_restaurant_created_idx on public.kod_orders(restaurant_id,created_at desc);
create index kod_orders_customer_created_idx on public.kod_orders(customer_id,created_at desc);

create function kod_private.kod_role() returns text language sql stable security definer set search_path=''
as $$select r.role from kod_private.kod_account_roles r where r.user_id=(select auth.uid())$$;
create function kod_private.kod_is_developer() returns boolean language sql stable security definer set search_path=''
as $$select coalesce((select kod_private.kod_role())='developer',false)$$;
create function kod_private.kod_owns_restaurant(p_id uuid) returns boolean language sql stable security definer set search_path=''
as $$select exists(select 1 from public.kod_restaurants r where r.id=p_id and r.owner_id=(select auth.uid()))$$;

create function kod_private.kod_new_user() returns trigger language plpgsql security definer set search_path=''
as $$begin
 insert into public.kod_profiles(id,full_name,requested_account_type)
 values(new.id,left(coalesce(new.raw_user_meta_data->>'full_name',''),80),
 case when new.raw_user_meta_data->>'requested_account_type'='merchant' then 'merchant' else 'customer' end);
 insert into kod_private.kod_account_roles(user_id,role) values(new.id,'customer');
 insert into public.kod_memberships(user_id) values(new.id);
 return new;
end$$;
create trigger kod_new_user after insert on auth.users for each row execute function kod_private.kod_new_user();

-- A trusted administrator provisions a confirmed operator by user ID in the private role table.
alter table public.kod_profiles enable row level security;
alter table kod_private.kod_account_roles enable row level security;
alter table public.kod_platform_settings enable row level security;
alter table public.kod_restaurants enable row level security;
alter table public.kod_menu_items enable row level security;
alter table public.kod_memberships enable row level security;
alter table public.kod_favorites enable row level security;
alter table public.kod_orders enable row level security;

create policy kod_profiles_read on public.kod_profiles for select to authenticated
 using(id=(select auth.uid()) or (select kod_private.kod_is_developer()));
create policy kod_profiles_name_update on public.kod_profiles for update to authenticated
 using(id=(select auth.uid())) with check(id=(select auth.uid()));
create policy kod_settings_read on public.kod_platform_settings for select to anon,authenticated using(true);
create policy kod_restaurants_read on public.kod_restaurants for select to anon,authenticated
 using(approved or owner_id=(select auth.uid()) or (select kod_private.kod_is_developer()));
create policy kod_restaurant_apply on public.kod_restaurants for insert to authenticated
 with check(owner_id=(select auth.uid()) and not approved and not is_open and not is_demo and percent=0);
create policy kod_menu_read on public.kod_menu_items for select to anon,authenticated
 using(exists(select 1 from public.kod_restaurants r where r.id=restaurant_id and (r.approved or r.owner_id=(select auth.uid()) or (select kod_private.kod_is_developer()))));
create policy kod_menu_insert on public.kod_menu_items for insert to authenticated
 with check(kod_private.kod_owns_restaurant(restaurant_id) and (select kod_private.kod_role())='merchant');
create policy kod_menu_update on public.kod_menu_items for update to authenticated
 using(kod_private.kod_owns_restaurant(restaurant_id) and (select kod_private.kod_role())='merchant')
 with check(kod_private.kod_owns_restaurant(restaurant_id) and (select kod_private.kod_role())='merchant');
create policy kod_membership_read on public.kod_memberships for select to authenticated
 using(user_id=(select auth.uid()) or (select kod_private.kod_is_developer()));
create policy kod_favorites_read on public.kod_favorites for select to authenticated using(user_id=(select auth.uid()));
create policy kod_favorites_insert on public.kod_favorites for insert to authenticated with check(user_id=(select auth.uid()));
create policy kod_favorites_delete on public.kod_favorites for delete to authenticated using(user_id=(select auth.uid()));
create policy kod_orders_read on public.kod_orders for select to authenticated
 using(customer_id=(select auth.uid()) or kod_private.kod_owns_restaurant(restaurant_id) or (select kod_private.kod_is_developer()));

-- Immutable client-side prices/roles/status: no direct writes to orders, roles or membership.
revoke all on public.kod_profiles,public.kod_platform_settings,public.kod_restaurants,public.kod_menu_items,
 public.kod_memberships,public.kod_favorites,public.kod_orders from public,anon,authenticated;
revoke all on kod_private.kod_account_roles from public,anon,authenticated;
grant select on public.kod_platform_settings,public.kod_restaurants,public.kod_menu_items to anon,authenticated;
grant select on public.kod_profiles,public.kod_memberships,public.kod_favorites,public.kod_orders to authenticated;
grant update(full_name) on public.kod_profiles to authenticated;
grant insert(owner_id,name,city,delivery_fee_cents,minimum_order_cents,is_demo,approved,is_open) on public.kod_restaurants to authenticated;
grant insert(restaurant_id,name,category,description,price_cents,is_available),update(name,category,description,price_cents,is_available) on public.kod_menu_items to authenticated;
grant insert,delete on public.kod_favorites to authenticated;

create function public.kod_my_role() returns text language sql stable security invoker set search_path=''
as $$select coalesce(kod_private.kod_role(),'customer')$$;

create function kod_private.kod_place_order(
 p_restaurant_id uuid,p_lines jsonb,p_fulfillment text,p_customer_name text,p_contact_phone text,
 p_delivery_address text,p_notes text,p_request_id uuid
) returns public.kod_orders language plpgsql security definer set search_path=''
as $$declare
 v_uid uuid:=auth.uid(); v_r public.kod_restaurants; v_item public.kod_menu_items;
 v_order public.kod_orders; v_line jsonb; v_items jsonb:='[]'; v_seen uuid[]:='{}';
 v_item_id uuid; v_qty integer; v_sub integer:=0; v_discount integer:=0; v_fee integer:=0;
 v_percent integer:=0; v_fingerprint text;
begin
 if v_uid is null then raise exception 'authentication_required'; end if;
 if coalesce(kod_private.kod_role(),'')<>'customer' then raise exception 'customer_account_required'; end if;
 if p_request_id is null then raise exception 'request_id_required'; end if;
 if p_fulfillment not in('delivery','pickup') or p_fulfillment is null then raise exception 'invalid_fulfillment'; end if;
 if char_length(trim(p_customer_name)) not between 1 and 60 or p_customer_name is null
 or p_contact_phone is null or p_contact_phone !~ '^\+[1-9][0-9]{7,14}$'
 or coalesce(char_length(p_delivery_address),0)>300 or coalesce(char_length(p_notes),0)>300
 or (p_fulfillment='delivery' and coalesce(char_length(trim(p_delivery_address)),0)<5)
 then raise exception 'invalid_contact_details'; end if;
 if p_lines is null or jsonb_typeof(p_lines)<>'array' or jsonb_array_length(p_lines) not between 1 and 20
 then raise exception 'invalid_lines'; end if;
 v_fingerprint:=encode(sha256(convert_to(jsonb_build_object('r',p_restaurant_id,'l',p_lines,'f',p_fulfillment,'n',p_customer_name,'p',p_contact_phone,'a',p_delivery_address,'notes',p_notes)::text,'UTF8')),'hex');
 perform pg_advisory_xact_lock(hashtextextended(v_uid::text||p_request_id::text,0));
 select * into v_order from public.kod_orders where customer_id=v_uid and request_id=p_request_id;
 if found then
  if v_order.request_fingerprint<>v_fingerprint then raise exception 'idempotency_conflict'; end if;
  return v_order;
 end if;
 if not exists(select 1 from public.kod_platform_settings where id=1 and ordering_enabled) then raise exception 'ordering_not_enabled'; end if;
 select * into v_r from public.kod_restaurants where id=p_restaurant_id for update;
 if not found or not v_r.approved or not v_r.is_open or v_r.is_demo then raise exception 'restaurant_unavailable'; end if;
 for v_line in select value from jsonb_array_elements(p_lines) loop
  if jsonb_typeof(v_line)<>'object' or coalesce(v_line->>'quantity','') !~ '^[1-9][0-9]?$'
  then raise exception 'invalid_quantity'; end if;
  v_qty:=(v_line->>'quantity')::integer;
  if v_qty not between 1 and 20 then raise exception 'invalid_quantity'; end if;
  v_item_id:=(v_line->>'item_id')::uuid;
  if v_item_id is null or v_item_id=any(v_seen) then raise exception 'duplicate_or_missing_item'; end if;
  v_seen:=array_append(v_seen,v_item_id);
  select * into v_item from public.kod_menu_items where id=v_item_id and restaurant_id=p_restaurant_id for share;
  if not found or not v_item.is_available then raise exception 'item_unavailable'; end if;
  v_sub:=v_sub+v_item.price_cents*v_qty;
  if v_sub>200000 then raise exception 'order_limit_exceeded'; end if;
  v_items:=v_items||jsonb_build_array(jsonb_build_object('item_id',v_item.id,'name',v_item.name,'quantity',v_qty,'unit_price_cents',v_item.price_cents));
 end loop;
 if v_sub<v_r.minimum_order_cents then raise exception 'minimum_order_not_met'; end if;
 if exists(select 1 from public.kod_memberships where user_id=v_uid and status='active' and expires_at>now()) then v_percent:=v_r.percent; end if;
 v_discount:=round(v_sub::numeric*v_percent/100)::integer;
 v_fee:=case when p_fulfillment='delivery' then v_r.delivery_fee_cents else 0 end;
 insert into public.kod_orders(customer_id,restaurant_id,restaurant_name,request_id,request_fingerprint,customer_name,contact_phone,delivery_address,notes,fulfillment,items,subtotal_cents,discount_cents,delivery_fee_cents,total_cents,events)
 values(v_uid,v_r.id,v_r.name,p_request_id,v_fingerprint,trim(p_customer_name),p_contact_phone,
 case when p_fulfillment='delivery' then trim(p_delivery_address) else '' end,coalesce(p_notes,''),p_fulfillment,v_items,v_sub,v_discount,v_fee,v_sub-v_discount+v_fee,jsonb_build_array(jsonb_build_object('status','pending','at',now())))
 returning * into v_order;
 return v_order;
end$$;
create function public.kod_place_order(p_restaurant_id uuid,p_lines jsonb,p_fulfillment text,p_customer_name text,p_contact_phone text,p_delivery_address text,p_notes text,p_request_id uuid)
returns public.kod_orders language sql security invoker set search_path=''
as $$select kod_private.kod_place_order(p_restaurant_id,p_lines,p_fulfillment,p_customer_name,p_contact_phone,p_delivery_address,p_notes,p_request_id)$$;

create function kod_private.kod_transition_order(p_order_id uuid,p_next text) returns public.kod_orders
language plpgsql security definer set search_path=''
as $$declare v_uid uuid:=auth.uid();v_order public.kod_orders;v_allowed boolean:=false;
begin
 if v_uid is null then raise exception 'authentication_required'; end if;
 select * into v_order from public.kod_orders where id=p_order_id for update;
 if not found then raise exception 'order_not_found'; end if;
 if v_order.customer_id=v_uid and p_next='cancelled' then v_allowed:=v_order.status='pending';
 elsif kod_private.kod_is_developer() or (kod_private.kod_role()='merchant' and kod_private.kod_owns_restaurant(v_order.restaurant_id)) then
  v_allowed:=case v_order.status
   when 'pending' then p_next in('accepted','rejected')
   when 'accepted' then p_next='preparing'
   when 'preparing' then (p_next='out_for_delivery' and v_order.fulfillment='delivery') or (p_next='ready_for_pickup' and v_order.fulfillment='pickup')
   when 'out_for_delivery' then p_next='delivered'
   when 'ready_for_pickup' then p_next='delivered'
   else false end;
 end if;
 if not coalesce(v_allowed,false) then raise exception 'transition_not_allowed'; end if;
 update public.kod_orders set status=p_next,updated_at=now(),events=events||jsonb_build_array(jsonb_build_object('status',p_next,'at',now())) where id=p_order_id returning * into v_order;
 return v_order;
end$$;
create function public.kod_transition_order(p_order_id uuid,p_next text) returns public.kod_orders
language sql security invoker set search_path='' as $$select kod_private.kod_transition_order(p_order_id,p_next)$$;

create function kod_private.kod_review_restaurant(p_restaurant_id uuid,p_approved boolean) returns void
language plpgsql security definer set search_path=''
as $$declare v_r public.kod_restaurants;begin
 if auth.uid() is null or not kod_private.kod_is_developer() then raise exception 'developer_required'; end if;
 if p_approved is null then raise exception 'approval_required'; end if;
 select * into v_r from public.kod_restaurants where id=p_restaurant_id for update;
 if not found then raise exception 'restaurant_not_found'; end if;
 update public.kod_restaurants set approved=p_approved,is_open=false where id=p_restaurant_id;
 if p_approved then
  insert into kod_private.kod_account_roles(user_id,role) values(v_r.owner_id,'merchant')
  on conflict(user_id) do update set role=case when kod_private.kod_account_roles.role='developer' then 'developer' else 'merchant' end;
  update public.kod_profiles set account_role=(select role from kod_private.kod_account_roles where user_id=v_r.owner_id) where id=v_r.owner_id;
 end if;
end$$;
create function public.kod_review_restaurant(p_restaurant_id uuid,p_approved boolean) returns void
language sql security invoker set search_path='' as $$select kod_private.kod_review_restaurant(p_restaurant_id,p_approved)$$;

create function kod_private.kod_set_restaurant_open(p_restaurant_id uuid,p_open boolean) returns void
language plpgsql security definer set search_path=''
as $$begin
 if auth.uid() is null or coalesce(kod_private.kod_role(),'')<>'merchant' or not kod_private.kod_owns_restaurant(p_restaurant_id) then raise exception 'merchant_required'; end if;
 if p_open is null then raise exception 'open_state_required'; end if;
 update public.kod_restaurants set is_open=p_open where id=p_restaurant_id and approved and not is_demo;
 if not found then raise exception 'restaurant_not_approved'; end if;
end$$;
create function public.kod_set_restaurant_open(p_restaurant_id uuid,p_open boolean) returns void
language sql security invoker set search_path='' as $$select kod_private.kod_set_restaurant_open(p_restaurant_id,p_open)$$;

-- Default function EXECUTE on PUBLIC must be explicitly removed, including triggers.
revoke all on all functions in schema kod_private from public,anon,authenticated;
grant usage on schema kod_private to anon,authenticated;
grant execute on function kod_private.kod_role(),kod_private.kod_is_developer(),kod_private.kod_owns_restaurant(uuid) to anon,authenticated;
grant execute on function kod_private.kod_place_order(uuid,jsonb,text,text,text,text,text,uuid),kod_private.kod_transition_order(uuid,text),kod_private.kod_review_restaurant(uuid,boolean),kod_private.kod_set_restaurant_open(uuid,boolean) to authenticated;
revoke all on function public.kod_my_role(),public.kod_place_order(uuid,jsonb,text,text,text,text,text,uuid),public.kod_transition_order(uuid,text),public.kod_review_restaurant(uuid,boolean),public.kod_set_restaurant_open(uuid,boolean) from public,anon,authenticated;
grant execute on function public.kod_my_role(),public.kod_place_order(uuid,jsonb,text,text,text,text,text,uuid),public.kod_transition_order(uuid,text),public.kod_review_restaurant(uuid,boolean),public.kod_set_restaurant_open(uuid,boolean) to authenticated;
do $$begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime')
 and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='kod_orders') then
  alter publication supabase_realtime add table public.kod_orders;
 end if;
end$$;
commit;

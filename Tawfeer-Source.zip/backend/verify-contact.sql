-- Exercise tenant visibility with disposable fixtures; nothing is committed.
begin;
do $test$
declare
 owner_user uuid:=gen_random_uuid(); other_user uuid:=gen_random_uuid();
 branch uuid:=gen_random_uuid(); affected integer;
begin
 insert into auth.users(id,raw_user_meta_data,raw_app_meta_data)
 values (owner_user,'{}','{}'),(other_user,'{}','{}');
 insert into public.kod_restaurants(id,owner_id,name,city)
 values (branch,owner_user,'Contact check','دبي');
 perform set_config('request.jwt.claim.sub',owner_user::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('role','authenticated','sub',owner_user)::text,true);
 execute 'set local role authenticated';
 update public.kod_restaurants set public_phone='+97140000000',public_whatsapp=null,branch_address='Test location' where id=branch;
 get diagnostics affected=row_count;
 if affected<>1 then raise exception 'Cannot update own business contact';end if;
 if has_column_privilege('authenticated','public.kod_restaurants','approved','UPDATE') then raise exception 'Excessive grant';end if;
 execute 'reset role';
 update public.kod_restaurants set approved=true where id=branch;
 perform set_config('request.jwt.claim.sub',other_user::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('role','authenticated','sub',other_user)::text,true);
 execute 'set local role authenticated';
 update public.kod_restaurants set public_phone='+97140000001' where id=branch;
 get diagnostics affected=row_count;
 if affected<>0 then raise exception 'Another user edited the number';end if;
 execute 'reset role';
 perform set_config('request.jwt.claim.sub','',true);
 perform set_config('request.jwt.claims','{"role":"anon"}',true);
 execute 'set local role anon';
 if not exists(select 1 from public.kod_restaurants where id=branch and public_phone='+97140000000' and public_whatsapp is null) then
  raise exception 'Published restaurant phone missing';
 end if;
 if has_column_privilege('anon','public.kod_restaurants','public_phone','UPDATE') then raise exception 'Anonymous edit grant';end if;
 execute 'reset role';
end
$test$;
rollback;
select 'passed — contact updates isolated, published contacts readable, all fixtures rolled back' as kod_contact_checks;

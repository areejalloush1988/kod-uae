-- Synthetic identities and payments, all rolled back. No gateway is contacted.
begin;
do $qa$
declare
 owner_id uuid:=gen_random_uuid(); owner_session uuid:=gen_random_uuid(); sponsor uuid:=gen_random_uuid(); friend uuid:=gen_random_uuid();
 creator uuid:=gen_random_uuid(); stranger uuid:=gen_random_uuid(); employee uuid:=gen_random_uuid(); fake_friend uuid:=gen_random_uuid();
 campaign uuid:=gen_random_uuid(); company uuid:=gen_random_uuid(); branch uuid:=gen_random_uuid(); branch_campaign uuid;
 batch uuid:=gen_random_uuid(); seat uuid; other_seat uuid; app_id uuid; code text; ticket text; c_ticket text; info jsonb; sale jsonb;
 baseline timestamptz:=clock_timestamp()+interval '15 days'; after_first timestamptz;
begin
 insert into auth.users(id,email,email_confirmed_at,created_at,raw_user_meta_data,raw_app_meta_data)
 select u,'kod-promo-'||u||'@example.invalid',clock_timestamp(),clock_timestamp()-interval '1 day','{}','{}'
 from unnest(array[owner_id,sponsor,creator,stranger,employee]) u;
 update kod_private.kod_account_roles set role='developer' where user_id=owner_id;
 insert into kod_private.kod_operator_security(user_id,email,direct_login_from) select id,email,now()-interval '1 hour' from auth.users where id=owner_id;
 insert into auth.sessions(id,user_id,created_at,updated_at) values(owner_session,owner_id,now(),now());
 update public.kod_memberships set status='active',expires_at=baseline where user_id=sponsor;
 perform set_config('request.jwt.claim.sub',sponsor::text,true);
 execute 'set local role authenticated';
 info:=public.kod_referral_home();code:=info->>'code';
 if coalesce(length(code),0)<>36 or info->>'joined'<>'0' or public.kod_referral_home()->>'code'<>code then raise exception 'unstable referral link';end if;
 ticket:=public.kod_invite_offer(code)->>'ticket';
 if ticket is null or public.kod_invite_offer('bogus')->>'valid'<>'false' or public.kod_accept_invite(ticket) then raise exception 'invalid/self invite';end if;
 begin perform public.kod_referral_admin(91);raise exception 'customer updated rate';exception when raise_exception then if sqlerrm<>'operator_required' then raise;end if;end;
 begin perform 1 from kod_private.kod_referrals;raise exception 'private referral ledger exposed';exception when insufficient_privilege then null;end;
 perform set_config('request.jwt.claim.sub',creator::text,true);
 app_id:=public.kod_partner_apply('creator','KOD Test Creator','qa@example.invalid','دبي',null);
 if public.kod_accept_invite(ticket) then raise exception 'old account claimed invitation';end if;
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',owner_id,'role','authenticated','session_id',owner_session,'amr',jsonb_build_array(jsonb_build_object('method','password','timestamp',extract(epoch from now())::bigint)))::text,true);
 if public.kod_referral_admin(11)->>'days'<>'11' then raise exception 'rate not saved';end if;
 campaign:=public.kod_create_campaign('creator','Test Creator','دبي',10,app_id,campaign);
 if public.kod_create_campaign('creator','Test Creator','دبي',10,app_id,gen_random_uuid())<>campaign then raise exception 'duplicate campaign';end if;
 company:=public.kod_create_campaign('corporate','QA Company','',0,null,company);
 if public.kod_company_batch(company,batch,2,15)<>2 or public.kod_company_batch(company,batch,2,15)<>2 or jsonb_array_length(public.kod_company_codes(company))<>2 then raise exception 'batch duplicated';end if;
 seat:=(public.kod_company_codes(company)->0->>'token')::uuid;other_seat:=(public.kod_company_codes(company)->1->>'token')::uuid;
 perform set_config('request.jwt.claim.sub',stranger::text,true);
 if jsonb_array_length(public.kod_marketing_desk()->'requests')<>0 or jsonb_array_length(public.kod_marketing_desk()->'campaigns')<>0 then raise exception 'campaign data leaked';end if;
 begin perform public.kod_company_codes(company);raise exception 'corporate seat codes leaked';exception when raise_exception then if sqlerrm<>'operator_required' then raise;end if;end;
 execute 'reset role';execute 'set local role anon';
 c_ticket:=public.kod_campaign_offer(campaign)->>'ticket';if c_ticket is null then raise exception 'campaign landing';end if;
 begin perform public.kod_referral_home();raise exception 'anonymous access to member account';exception when insufficient_privilege then null;end;
 execute 'reset role';
 insert into auth.users(id,email,created_at,raw_user_meta_data,raw_app_meta_data) values
 (friend,friend||'@example.invalid',clock_timestamp(),jsonb_build_object('kod_invite_ticket',ticket,'kod_campaign_ticket',c_ticket),'{}'),
 (fake_friend,fake_friend||'@example.invalid',clock_timestamp(),jsonb_build_object('kod_invite_ticket',ticket||'z','kod_campaign_ticket',c_ticket||'z'),'{}');
 if (select count(*) from kod_private.kod_referrals where invitee=friend and inviter=sponsor and days=7 and paid_order is null)<>1 or exists(select from kod_private.kod_referrals where invitee=fake_friend) or exists(select from kod_private.kod_campaign_members where member_id=fake_friend) then raise exception 'new signup attribution/signature validation';end if;
 if (select count(*) from kod_private.kod_campaign_members where member_id=friend and campaign_id=campaign and paid_order is null)<>1 then raise exception 'campaign not attached';end if;
 perform set_config('request.jwt.claim.sub',friend::text,true);execute 'set local role authenticated';
 if not public.kod_accept_invite(ticket) or not public.kod_accept_campaign(c_ticket) then raise exception 'provider retry';end if;
 execute 'reset role';execute 'set local role service_role';
 sale:=public.kod_prepare_subscription(friend,gen_random_uuid(),1,'stripe','');
 perform public.kod_attach_checkout((sale->>'id')::uuid,(sale->>'lease')::uuid,'qa-'||friend,'https://checkout.stripe.com/fixture',now()+interval '1 day');
 perform public.kod_settle_subscription((sale->>'id')::uuid,'stripe','qa-'||friend,'payment-'||friend,'','AED',6900);
 perform public.kod_settle_subscription((sale->>'id')::uuid,'stripe','qa-'||friend,'payment-'||friend,'','AED',6900);
 sale:=public.kod_prepare_subscription(friend,gen_random_uuid(),3,'stripe','');
 perform public.kod_attach_checkout((sale->>'id')::uuid,(sale->>'lease')::uuid,'renew-'||friend,'https://checkout.stripe.com/fixture',now()+interval '1 day');
 perform public.kod_settle_subscription((sale->>'id')::uuid,'stripe','renew-'||friend,'renewal-'||friend,'','AED',18900);
 execute 'reset role';execute 'set local role authenticated';
 perform set_config('request.jwt.claim.sub',sponsor::text,true);
 info:=public.kod_referral_home();
 if info->>'joined'<>'1' or info->>'paid'<>'1' or info->>'earned_days'<>'7' or info->>'applied_days'<>'7' or info->>'days'<>'11' then raise exception 'wrong referral totals: %',info;end if;
 if (select expires_at from public.kod_memberships where user_id=sponsor) is distinct from baseline+interval '7 days' then raise exception 'wrong extension';end if;
 perform set_config('request.jwt.claim.sub',creator::text,true);info:=public.kod_marketing_desk();
 if jsonb_array_length(info->'campaigns')<>1 or info->'campaigns'->0->>'commission_fils'<>'690' or info->'campaigns'->0->>'paid'<>'1' then raise exception 'creator attribution/commission/privacy';end if;
 perform set_config('request.jwt.claim.sub',employee::text,true);
 if public.kod_claim_seat(seat)<>15 then raise exception 'seat rejected';end if;
 select expires_at into after_first from public.kod_memberships where user_id=employee;
 perform public.kod_claim_seat(seat);
 if (select expires_at from public.kod_memberships where user_id=employee) is distinct from after_first or after_first<now()+interval '14 days' then raise exception 'employee validity';end if;
 begin perform public.kod_claim_seat(other_seat);raise exception 'employee used 2 seats';exception when raise_exception then if sqlerrm<>'already_used' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',stranger::text,true);
 begin perform public.kod_claim_seat(seat);raise exception 'second account used same seat';exception when raise_exception then if sqlerrm<>'invalid_seat' then raise;end if;end;
 execute 'reset role';
 insert into public.kod_restaurants(id,owner_id,name,city,approved,is_demo,instore_percent) values(branch,creator,'Test Branch','دبي',false,false,0);
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 begin perform public.kod_branch_campaign(branch);raise exception 'unapproved restaurant';exception when raise_exception then if sqlerrm<>'branch_required' then raise;end if;end;
 update public.kod_restaurants set approved=true,instore_percent=10 where id=branch;
 branch_campaign:=public.kod_branch_campaign(branch);
 if public.kod_branch_campaign(branch)<>branch_campaign or public.kod_campaign_offer(branch_campaign)->>'valid'<>'true' then raise exception 'restaurant QR';end if;
 update public.kod_restaurants set instore_percent=0 where id=branch;
 if public.kod_campaign_offer(branch_campaign)->>'valid'<>'false' then raise exception 'withdrawn branch link';end if;
end $qa$;
rollback;
select 'Passed signup attribution, first settled payment, single reward, privacy, creator commission, company seats and branch QR' as result;

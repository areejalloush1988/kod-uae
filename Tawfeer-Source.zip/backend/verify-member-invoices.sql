-- Test identities and payment references are discarded together. No external gateway or account is used.
begin;
do $test$
declare
 owner_id uuid:=gen_random_uuid();sid uuid:=gen_random_uuid();buyer uuid:=gen_random_uuid();friend uuid:=gen_random_uuid();
 seller uuid:=gen_random_uuid();branch uuid:=gen_random_uuid();nonce uuid:=gen_random_uuid();ref text:='QA-'||nonce;
 bill uuid;cancelled uuid;ad uuid;ticket text;info jsonb;ends timestamptz;bonus integer;
begin
 insert into auth.users(id,email,email_confirmed_at,created_at,raw_user_meta_data,raw_app_meta_data)
 select u,u||'@example.invalid',now(),now()-interval '1 day','{}','{}' from unnest(array[owner_id,friend,seller]) u;
 update kod_private.kod_account_roles set role='developer' where user_id=owner_id;
 update kod_private.kod_account_roles set role='merchant' where user_id=seller;
 insert into kod_private.kod_operator_security(user_id,email,direct_login_from) select id,email,now()-interval '1 hour' from auth.users where id=owner_id;
 insert into auth.sessions(id,user_id,created_at,updated_at) values(sid,owner_id,now(),now());
 insert into public.kod_restaurants(id,owner_id,name,city,approved) values(branch,seller,'Invoice Test','دبي',true);
 perform set_config('request.jwt.claim.sub',friend::text,true);
 execute 'set local role authenticated';
 info:=public.kod_referral_home();bonus:=(info->>'cash_fils')::int;ticket:=public.kod_invite_offer(info->>'code')->>'ticket';
 execute 'reset role';
 insert into auth.users(id,email,created_at,email_confirmed_at,raw_user_meta_data,raw_app_meta_data)
 values(buyer,buyer||'@example.invalid',clock_timestamp(),clock_timestamp(),jsonb_build_object('kod_invite_ticket',ticket),'{}');
 execute 'set local role anon';
 begin perform public.kod_member_invoice_desk();raise exception 'anonymous ledger';exception when insufficient_privilege then null;end;
 execute 'reset role';execute 'set local role authenticated';
 perform set_config('request.jwt.claim.sub',buyer::text,true);
 begin perform public.kod_member_invoice_request(3,nonce,100);raise exception 'incorrect quote';exception when raise_exception then if sqlerrm<>'invalid_amount' then raise;end if;end;
 bill:=public.kod_member_invoice_request(3,nonce,18900);
 if bill<>public.kod_member_invoice_request(3,gen_random_uuid(),18900) or bill<>public.kod_member_invoice_request(3,nonce,18900) then raise exception 'duplicate invoice';end if;
 cancelled:=public.kod_member_invoice_request(1,gen_random_uuid(),6900);
 perform public.kod_member_invoice_update(cancelled,'close','','',null,'');
 begin perform public.kod_member_invoice_update(bill,'settle','','',18900,ref);raise exception 'member self-activated';exception when raise_exception then if sqlerrm<>'operator_required' then raise;end if;end;
 if exists(select from public.kod_subscription_orders where user_id=buyer) then raise exception 'unpaid invoice created a purchase';end if;
 perform set_config('request.jwt.claim.sub',friend::text,true);
 if jsonb_array_length(public.kod_member_invoice_desk()->'invoices')<>0 then raise exception 'another customer saw invoice';end if;
 perform set_config('request.jwt.claim.sub',seller::text,true);
 begin perform public.kod_member_invoice_desk();raise exception 'merchant accessed member invoices';exception when raise_exception then if sqlerrm<>'member_required' then raise;end if;end;
 ad:=public.kod_featured_request(branch,gen_random_uuid(),(public.kod_featured_public()->>'price_fils')::integer);
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',owner_id,'role','authenticated','session_id',sid,'amr',jsonb_build_array(jsonb_build_object('method','password','timestamp',extract(epoch from now())::bigint)))::text,true);
 begin perform public.kod_member_invoice_update(bill,'invoice','','http://insecure.example',null,'');raise exception 'insecure invoice url';exception when raise_exception then if sqlerrm<>'invalid_invoice' then raise;end if;end;
 perform public.kod_member_invoice_update(bill,'invoice','Fixture instructions','',null,'');
 begin perform public.kod_member_invoice_update(bill,'settle','','',6900,ref);raise exception 'accepted wrong amount';exception when raise_exception then if sqlerrm<>'amount_mismatch' then raise;end if;end;
 perform public.kod_member_invoice_update(bill,'settle','','',18900,ref);
 perform public.kod_member_invoice_update(bill,'settle','','',18900,ref);
 perform public.kod_featured_invoice(ad,'Fixture ad instructions','');
 begin perform public.kod_featured_settle(ad,(public.kod_featured_public()->>'price_fils')::integer,lower(ref));raise exception 'reused same reference across products';exception when raise_exception then if sqlerrm<>'duplicate_reference' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',buyer::text,true);
 if (select count(*) from public.kod_subscription_orders where user_id=buyer and rail='invoice' and status='paid' and club_tier='silver' and amount_fils=18900 and valid_until=valid_from+interval '3 months')<>1 then raise exception 'wrong member entitlement or repeated settlement';end if;
 if not exists(select from jsonb_array_elements(public.kod_member_invoice_desk()->'invoices') e where e->>'id'=bill::text and e->>'state'='paid' and (e->>'mine')::boolean) then raise exception 'missing member paid receipt';end if;
 perform set_config('request.jwt.claim.sub',friend::text,true);
 info:=public.kod_referral_home();
 if info->>'paid'<>'1' or (info->>'review_fils')::integer<>bonus or info->>'earned_days'<>'0' then raise exception 'wrong first paid referral reward';end if;
execute 'reset role';select paid_order into nonce from kod_private.kod_referrals where invitee=buyer;
 execute 'set local role authenticated';perform set_config('request.jwt.claim.sub',owner_id::text,true);
 perform public.kod_review_reward_cash(nonce,'approve','',true);
 perform set_config('request.jwt.claim.sub',friend::text,true);
 if public.kod_request_reward_cash()<>1 or public.kod_request_reward_cash()<>0 then raise exception 'cash request duplicated';end if;
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 perform public.kod_review_reward_cash(nonce,'pay',ref,true);perform public.kod_review_reward_cash(nonce,'pay',ref,true);
 perform set_config('request.jwt.claim.sub',friend::text,true);
 if public.kod_referral_home()->>'paid_fils'<>'2500' then raise exception 'paid cash ledger';end if;
end $test$;
rollback;
select 'Passed member invoice isolation, payment confirmation, exact tier, referral, retries and shared reference protection' as result;

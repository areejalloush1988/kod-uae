-- Synthetic users and receipts exist only within this rolled-back transaction.
begin;
do $test$
declare
 presence_code text;member_sid uuid:=gen_random_uuid();device uuid:=gen_random_uuid();nonce uuid;secret bytea:=extensions.gen_random_bytes(32);
 customer uuid:=gen_random_uuid(); other_customer uuid:=gen_random_uuid(); merchant uuid:=gen_random_uuid();
 other_merchant uuid:=gen_random_uuid(); operator_id uuid:=gen_random_uuid(); sid uuid:=gen_random_uuid();
 branch uuid:=gen_random_uuid(); req uuid:=gen_random_uuid(); card jsonb; receipt jsonb; quote jsonb; serial text; operator_serial text; claim jsonb;
begin
 insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data,raw_app_meta_data)
 select u,'kod-card-'||u||'@example.invalid',now(),'{}','{}' from unnest(array[customer,other_customer,merchant,other_merchant,operator_id]) u;
 update kod_private.kod_account_roles set role='merchant' where user_id in(merchant,other_merchant);
 update kod_private.kod_account_roles set role='developer' where user_id=operator_id;
 insert into kod_private.kod_operator_security(user_id,email,direct_login_from) select id,email,now()-interval '1 minute' from auth.users where id=operator_id;
 -- A legacy operator may not yet have a membership row.
 delete from public.kod_memberships where user_id=operator_id;
 insert into auth.sessions(id,user_id,created_at,updated_at) values(sid,operator_id,now(),now());
 insert into auth.sessions(id,user_id,created_at,updated_at) values(member_sid,customer,now(),now());
 insert into public.kod_restaurants(id,owner_id,name,city,approved) values(branch,merchant,'KOD Card Test','دبي',true);
 perform set_config('request.jwt.claim.sub',customer::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',customer,'role','authenticated')::text,true);
 execute 'set local role authenticated';
 card:=public.kod_member_card(true);serial:=card->>'number';
 if serial !~ '^[0-9]{16}$' or card->>'status'<>'inactive' or card->>'requested_at' is null or (public.kod_member_card(false)->>'number')<>serial then raise exception 'Card issue, stable number or activation request failed';end if;
 begin perform public.kod_set_member_access(customer,true,current_date+7);raise exception 'customer activated membership';exception when raise_exception then if sqlerrm<>'operator_required' then raise;end if;end;
 begin perform public.kod_instore_bill(branch,serial,12000,'A-12');raise exception 'customer acted as cashier';exception when raise_exception then if sqlerrm<>'branch_required' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',merchant::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',merchant,'role','authenticated')::text,true);
 begin perform public.kod_instore_bill(branch,serial,12000,'A-12');raise exception 'unenrolled branch accepted';exception when raise_exception then if sqlerrm<>'branch_unavailable' then raise;end if;end;
 begin perform public.kod_member_card(false);raise exception 'merchant issued personal card';exception when raise_exception then if sqlerrm<>'member_required' then raise;end if;end;
 perform public.kod_set_instore_rate(branch,20);
 begin perform public.kod_instore_bill(branch,serial,12000,'A-12');raise exception 'inactive card accepted';exception when raise_exception then if sqlerrm<>'card_unavailable' then raise;end if;end;
 claim:=jsonb_build_object('sub',operator_id,'role','authenticated','session_id',sid,'amr',jsonb_build_array(jsonb_build_object('method','password','timestamp',floor(extract(epoch from now())))));
 perform set_config('request.jwt.claim.sub',operator_id::text,true); perform set_config('request.jwt.claims',claim::text,true);
 perform set_config('request.jwt.claims',(claim-'session_id')::text,true);
 begin perform public.kod_member_card(false);raise exception 'unverified operator issued personal card';exception when raise_exception then if sqlerrm<>'member_required' then raise;end if;end;
 perform set_config('request.jwt.claims',claim::text,true);
 card:=public.kod_member_card(false);operator_serial:=card->>'number';
 if operator_serial is null or operator_serial !~ '^[0-9]{16}$' or operator_serial=serial or card->>'status'<>'inactive' or card->>'requested_at' is not null or public.kod_member_card(false)->>'number'<>operator_serial then raise exception 'Operator personal card or initial status failed';end if;
 begin perform public.kod_set_member_access(merchant,true,current_date+7);raise exception 'a merchant was activated';exception when raise_exception then if sqlerrm<>'member_required' then raise;end if;end;
 perform public.kod_set_member_access(operator_id,true,current_date+7);
 if public.kod_member_card(false)->>'status'<>'active' then raise exception 'Manual operator card activation failed';end if;
 perform public.kod_set_member_access(customer,true,current_date+7);
 perform set_config('request.jwt.claim.sub',merchant::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',merchant,'role','authenticated')::text,true);
 quote:=public.kod_instore_bill(branch,serial,12000,'A-12');
 if (quote->>'net_cents')::int<>9600 or (quote->>'discount_cents')::int<>2400 or (select count(id) from public.kod_instore_receipts where restaurant_id=branch)<>0 then raise exception 'Preview calculation or side effect';end if;
 begin perform public.kod_instore_bill(branch,serial,12000,'A-12',req,30);raise exception 'changed quote accepted';exception when raise_exception then if sqlerrm<>'quote_changed' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',customer::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',customer,'role','authenticated','session_id',member_sid)::text,true);
 perform public.kod_link_device(device,encode(secret,'hex'),false);
 nonce:=public.kod_device_challenge(device,'bill',(quote->>'approval_id')::uuid);
 presence_code:=public.kod_device_prove(nonce,encode(extensions.hmac(convert_to('tawfeer-v1|'||nonce||'|bill|'||(quote->>'approval_id'),'UTF8'),secret,'sha256'),'hex'));
 perform set_config('request.jwt.claim.sub',merchant::text,true);perform set_config('request.jwt.claims',jsonb_build_object('sub',merchant,'role','authenticated')::text,true);
 receipt:=public.kod_confirm_present_bill(branch,serial,12000,'A-12',req,20,presence_code);
 if receipt->>'id' is null or public.kod_instore_bill(branch,serial,12000,'A-12',req,20)<>receipt then raise exception 'Receipt retry failed';end if;
 begin perform public.kod_instore_bill(branch,serial,12000,' a-12 ',gen_random_uuid(),20);raise exception 'duplicate invoice accepted';exception when raise_exception then if sqlerrm<>'invoice_already_used' then raise;end if;end;
 if (select count(id) from public.kod_instore_receipts where restaurant_id=branch)<>1 then raise exception 'Invalid receipt count';end if;
 perform set_config('request.jwt.claim.sub',other_merchant::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',other_merchant,'role','authenticated')::text,true);
 if exists(select id from public.kod_instore_receipts where restaurant_id=branch) then raise exception 'Receipt visible to another branch';end if;
 begin perform public.kod_set_instore_rate(branch,50);raise exception 'another merchant configured branch';exception when raise_exception then if sqlerrm<>'branch_required' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',other_customer::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',other_customer,'role','authenticated')::text,true);
 if public.kod_member_card(false)->>'number'=serial or exists(select id from public.kod_instore_receipts where restaurant_id=branch) then raise exception 'Member isolation failed';end if;
 perform set_config('request.jwt.claim.sub',customer::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',customer,'role','authenticated')::text,true);
 if not exists(select id from public.kod_instore_receipts where id=(receipt->>'id')::uuid) then raise exception 'Member cannot read receipt';end if;
 execute 'reset role';update public.kod_memberships set expires_at=now()-interval '1 day' where user_id=customer;
 perform set_config('request.jwt.claim.sub',merchant::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',merchant,'role','authenticated')::text,true);
 execute 'set local role authenticated';
 begin perform public.kod_instore_bill(branch,serial,12000,'A-13');raise exception 'Expired card accepted';exception when raise_exception then if sqlerrm<>'card_unavailable' then raise;end if;end;
 execute 'reset role';
 if has_function_privilege('anon','public.kod_instore_bill(uuid,text,integer,text,uuid,integer)','EXECUTE') or has_table_privilege('authenticated','kod_private.kod_member_cards','SELECT') or has_table_privilege('authenticated','public.kod_instore_receipts','INSERT') then raise exception 'Unexpected public permission';end if;
end
$test$;
rollback;
select 'passed: verified operator and customer cards, legacy row, explicit activation, branch enrollment, invoice 120/24/96, duplicate protection, expiration and account isolation; fixtures rolled back' as card_checks;

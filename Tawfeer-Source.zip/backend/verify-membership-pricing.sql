-- Synthetic accounts and listed prices exist only in this rolled-back transaction.
begin;
do $test$
declare
 owner_id uuid:=gen_random_uuid(); sid uuid:=gen_random_uuid(); buyer uuid:=gen_random_uuid();
 other_buyer uuid:=gen_random_uuid(); seller uuid:=gen_random_uuid(); nonce uuid:=gen_random_uuid();
 checkout uuid:=gen_random_uuid(); bronze_checkout uuid:=gen_random_uuid(); bill uuid; batch jsonb; item record;
 forbidden jsonb:='[{"tier":"gold","months":1,"previous_fils":null,"amount_fils":8750}]';
 original integer; result jsonb; entitlement timestamptz;
begin
 update public.kod_membership_prices set amount_fils=legacy_fils;
 update public.kod_billing_availability set methods='{"stripe":[1,3,6,12],"etisalat":[1],"du":[1]}',checked_at=now() where id=1;
 insert into auth.users(id,email,email_confirmed_at,created_at,raw_user_meta_data,raw_app_meta_data)
 select u,u||'@example.invalid',now(),now()-interval '1 day','{}','{}' from unnest(array[owner_id,buyer,other_buyer,seller]) u;
 update kod_private.kod_account_roles set role='developer' where user_id=owner_id;
 update kod_private.kod_account_roles set role='merchant' where user_id=seller;
 insert into kod_private.kod_operator_security(user_id,email,direct_login_from) select id,email,now()-interval '1 hour' from auth.users where id=owner_id;
 insert into auth.sessions(id,user_id,created_at,updated_at) values(sid,owner_id,now(),now());
 execute 'set local role anon';
 result:=public.kod_membership_catalog();
 if jsonb_array_length(result)<>12 or (select count(*) from jsonb_array_elements(result) r where r->'amount_fils'='null')<>8 then raise exception 'initial catalogue';end if;
 begin perform public.kod_set_membership_prices(forbidden);raise exception 'anonymous edit';exception when insufficient_privilege then null;end;
 execute 'reset role';execute 'set local role authenticated';
 perform set_config('request.jwt.claim.sub',buyer::text,true);
 begin update public.kod_membership_prices set amount_fils=1;raise exception 'direct update';exception when insufficient_privilege then null;end;
 begin perform public.kod_set_membership_prices(forbidden);raise exception 'member edit';exception when raise_exception then if sqlerrm<>'operator_required' then raise;end if;end;
 begin perform public.kod_request_plan_invoice('gold',1,nonce,8750);raise exception 'unpriced invoice';exception when raise_exception then if sqlerrm<>'price_unset' then raise;end if;end;
 begin perform public.kod_reserve_membership_checkout('gold',1,'stripe',8750,checkout);raise exception 'unpriced checkout';exception when raise_exception then if sqlerrm<>'price_unset' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',seller::text,true);
 begin perform public.kod_set_membership_prices(forbidden);raise exception 'merchant edit';exception when raise_exception then if sqlerrm<>'operator_required' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 begin perform public.kod_set_membership_prices(forbidden);raise exception 'unverified operator edit';exception when raise_exception then if sqlerrm<>'operator_required' then raise;end if;end;
 perform set_config('request.jwt.claims',jsonb_build_object('sub',owner_id,'role','authenticated','session_id',sid,'amr',jsonb_build_array(jsonb_build_object('method','password','timestamp',extract(epoch from now())::bigint)))::text,true);
 select jsonb_agg(jsonb_build_object('tier',tier,'months',months,'previous_fils',amount_fils,'amount_fils',
   (case tier when 'bronze' then 2000 when 'silver' then 4000 else 8000 end)+months*100+75)) into batch from public.kod_membership_prices;
 result:=public.kod_set_membership_prices(batch);
 if (select count(distinct r->>'amount_fils') from jsonb_array_elements(result) r)<>12 then raise exception 'not independently priced';end if;
 begin perform public.kod_set_membership_prices('[{"tier":"bronze","months":1,"previous_fils":2175,"amount_fils":1},{"tier":"silver","months":1,"previous_fils":null,"amount_fils":2}]');
  raise exception 'stale patch accepted';exception when raise_exception then if sqlerrm<>'price_conflict' then raise;end if;end;
 if (select amount_fils from public.kod_membership_prices where tier='bronze' and months=1)<>2175 then raise exception 'partial write';end if;
 perform set_config('request.jwt.claim.sub',buyer::text,true);
 begin perform public.kod_member_invoice_request(1,gen_random_uuid(),6900);raise exception 'old client quote';exception when raise_exception then if sqlerrm<>'price_changed' then raise;end if;end;
 begin perform public.kod_request_plan_invoice('gold',1,nonce,1);raise exception 'stale buyer quote';exception when raise_exception then if sqlerrm<>'price_changed' then raise;end if;end;
 for item in select tier,months,amount_fils from public.kod_membership_prices loop
  perform public.kod_request_plan_invoice(item.tier,item.months,case when item.tier='gold' and item.months=1 then nonce else gen_random_uuid() end,item.amount_fils);
 end loop;
 original:=8175;bill:=public.kod_request_plan_invoice('gold',1,nonce,original);
 if jsonb_array_length(public.kod_member_invoice_desk()->'invoices')<>12 then raise exception 'missing invoice combination';end if;
 if public.kod_reserve_membership_checkout('gold',1,'stripe',original,checkout)<>checkout or public.kod_reserve_membership_checkout('gold',1,'stripe',original,gen_random_uuid())<>checkout then raise exception 'checkout retry';end if;
 perform public.kod_reserve_membership_checkout('bronze',1,'stripe',2175,bronze_checkout);
 begin perform public.kod_reserve_membership_checkout('bronze',1,'stripe',2175,checkout);raise exception 'nonce reused for another tier';exception when raise_exception then if sqlerrm<>'request_mismatch' then raise;end if;end;
 begin perform public.kod_reserve_membership_checkout('gold',1,'du',original,gen_random_uuid());raise exception 'unsupported carrier product';exception when raise_exception then if sqlerrm<>'method_unavailable' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',other_buyer::text,true);
 if jsonb_array_length(public.kod_member_invoice_desk()->'invoices')<>0 then raise exception 'customer isolation';end if;
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 perform public.kod_set_membership_prices('[{"tier":"gold","months":1,"previous_fils":8175,"amount_fils":9136}]');
 perform set_config('request.jwt.claim.sub',buyer::text,true);
 if bill<>public.kod_request_plan_invoice('gold',1,nonce,original) then raise exception 'invoice snapshot lost';end if;
 begin perform public.kod_request_plan_invoice('gold',1,gen_random_uuid(),9136);raise exception 'second open repriced invoice';exception when raise_exception then if sqlerrm<>'invoice_open' then raise;end if;end;
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 perform public.kod_set_membership_prices('[{"tier":"gold","months":1,"previous_fils":9136,"amount_fils":null}]');
 perform public.kod_member_invoice_update(bill,'invoice','QA instructions','',null,'');
 perform public.kod_member_invoice_update(bill,'settle','','',original,'QA-'||nonce);
 perform public.kod_member_invoice_update(bill,'settle','','',original,'QA-'||nonce);
 execute 'reset role';execute 'set local role service_role';
 result:=public.kod_prepare_subscription(buyer,checkout,1,'stripe','');
 if result->>'state'<>'new' or (result->>'amount')::integer<>original then raise exception 'hosted checkout discarded its quote';end if;
 result:=public.kod_prepare_subscription(buyer,bronze_checkout,1,'stripe','');
 if (result->>'amount')::integer<>2175 then raise exception 'other tier checkout used wrong amount';end if;
 begin perform public.kod_prepare_subscription(buyer,gen_random_uuid(),1,'stripe','');raise exception 'legacy gateway used outdated quote';exception when raise_exception then if sqlerrm<>'price_changed' then raise;end if;end;
 execute 'reset role';
 select valid_from into strict entitlement from public.kod_subscription_orders where user_id=buyer and status='paid' and rail='invoice'
  and club_tier='gold' and months=1 and amount_fils=original and valid_until=valid_from+interval '1 month';
 if kod_private.kod_club_level(buyer,entitlement+interval '1 second') is distinct from 'gold' then raise exception 'wrong monthly gold benefit';end if;
 if (select amount_fils from public.kod_membership_prices where tier='gold' and months=1) is not null then raise exception 'clearing a price failed';end if;
end $test$;
rollback;
select 'Passed all 12 prices, owner-only edits, invoice snapshots, tier benefits and isolated hosted checkouts' as result;

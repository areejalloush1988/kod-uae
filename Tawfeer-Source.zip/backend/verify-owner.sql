-- Password, recovery-only, expired and customer sessions. The transaction rolls back every fixture.
begin;
do $checks$
declare
  op uuid:=gen_random_uuid(); customer uuid:=gen_random_uuid(); second_customer uuid:=gen_random_uuid();
  sid uuid:=gen_random_uuid(); another_device uuid:=gen_random_uuid(); client_session uuid:=gen_random_uuid();
  restaurant uuid:=gen_random_uuid(); item uuid:=gen_random_uuid(); claims jsonb; denied boolean:=false;
begin
  insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data,raw_app_meta_data) values
    (op,'kod-owner-'||op||'@example.invalid',now(),'{}','{}'),
    (customer,'kod-customer-'||customer||'@example.invalid',now(),'{"role":"developer"}','{}'),
    (second_customer,'kod-second-'||second_customer||'@example.invalid',now(),'{}','{}');
  update kod_private.kod_account_roles set role='developer' where user_id=op;
  insert into kod_private.kod_operator_security(user_id,email,direct_login_from)
    select id,email,now()-interval '1 minute' from auth.users where id=op;
  insert into auth.sessions(id,user_id,created_at,updated_at) values
    (sid,op,now(),now()),(another_device,op,now(),now()),(client_session,customer,now(),now());
  insert into public.kod_favorites(user_id,offer_key) values(customer,'venue:qa-customer'),(second_customer,'venue:qa-second');
  insert into public.kod_restaurants(id,owner_id,name,city,approved) values(restaurant,second_customer,'KOD QA Venue','دبي',true);

  claims=jsonb_build_object('sub',op,'role','authenticated','session_id',sid,'amr',
     jsonb_build_array(jsonb_build_object('method','password','timestamp',floor(extract(epoch from now())))));
  perform set_config('request.jwt.claim.sub',op::text,true);
  perform set_config('request.jwt.claims',claims::text,true);
  execute 'set local role authenticated';
  if public.kod_my_role()<>'developer' or (select count(*) from public.kod_operator_directory() where user_id in(customer,second_customer))<>2 then raise exception 'owner first device missing data'; end if;
  perform set_config('request.jwt.claims',jsonb_set(claims,'{session_id}',to_jsonb(another_device))::text,true);
  if public.kod_my_role()<>'developer' or (select count(*) from public.kod_favorites where user_id in(customer,second_customer))<>2 then raise exception 'second device missing data'; end if;
  insert into public.kod_menu_items(restaurant_id,name,category,price_cents) values(restaurant,'QA Dish','QA',1000) returning id into item;
  update public.kod_menu_items set is_available=false where id=item;
  if not exists(select 1 from public.kod_menu_items where id=item and not is_available) then raise exception 'owner menu control missing'; end if;
  perform public.kod_set_restaurant_open(restaurant,true);
  if not exists(select 1 from public.kod_restaurants where id=restaurant and is_open) then raise exception 'owner restaurant control missing'; end if;

  perform set_config('request.jwt.claims',jsonb_set(claims,'{amr,0,method}','"otp"')::text,true);
  if public.kod_my_role()<>'developer_locked' then raise exception 'recovery-only session granted admin'; end if;
  perform set_config('request.jwt.claims',jsonb_set(claims,'{amr,0,timestamp}',to_jsonb(0))::text,true);
  if public.kod_my_role()<>'developer_locked' then raise exception 'old unprivileged session granted admin'; end if;
  perform set_config('request.jwt.claims',jsonb_set(claims,'{session_id}',to_jsonb(gen_random_uuid()))::text,true);
  if public.kod_my_role()<>'developer_locked' then raise exception 'missing session granted admin'; end if;

  perform set_config('request.jwt.claim.sub',customer::text,true);
  perform set_config('request.jwt.claims',(claims||jsonb_build_object('sub',customer,'session_id',client_session))::text,true);
  if public.kod_my_role()<>'customer' or exists(select 1 from public.kod_favorites where user_id=second_customer) then raise exception 'customer privacy failure'; end if;
  begin perform public.kod_operator_directory();exception when insufficient_privilege then denied:=true;end;
  if not denied then raise exception 'customer directory not restricted'; end if;
  update public.kod_menu_items set is_available=true where id=item;
  if found then raise exception 'customer changed another menu'; end if;
  execute 'reset role';
end
$checks$;
rollback;
select true as direct_login_and_dashboard_checks_passed;

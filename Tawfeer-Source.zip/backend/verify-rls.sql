-- Transactional integration checks. Synthetic auth rows have no credentials.
-- The inner subtransaction rolls back every fixture on both success and failure.
create temporary table if not exists kod_qa_context(message text);
create or replace function pg_temp.kod_run_checks() returns jsonb
language plpgsql security invoker as $test$
declare
 a uuid:='10000000-0000-4000-8000-000000000001'; b uuid:='10000000-0000-4000-8000-000000000002';
 m1 uuid:='10000000-0000-4000-8000-000000000003'; m2 uuid:='10000000-0000-4000-8000-000000000004';
 dev uuid:='10000000-0000-4000-8000-000000000005'; operator_session uuid:=gen_random_uuid();
 r1 uuid:='20000000-0000-4000-8000-000000000001'; r2 uuid:='20000000-0000-4000-8000-000000000002';
 i1 uuid:='30000000-0000-4000-8000-000000000001'; i2 uuid:='30000000-0000-4000-8000-000000000002'; i3 uuid:='30000000-0000-4000-8000-000000000003';
 request_id uuid:=gen_random_uuid(); order_id uuid; pickup_id uuid; cancelled_id uuid;
 lines jsonb; out_order public.kod_orders; cases text[]:='{}'; denied boolean; rows_affected integer;
 report jsonb; baseline_auth bigint; baseline_ordering boolean;
begin
 select count(*) into baseline_auth from auth.users;
 select ordering_enabled into baseline_ordering from public.kod_platform_settings where id=1;
 if exists(select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname in('public','kod_private') and c.relname like 'kod_%' and c.relkind='r' and not c.relrowsecurity) then raise exception 'QA: missing RLS'; end if;
 if has_table_privilege('authenticated','public.kod_orders','INSERT') or has_table_privilege('authenticated','public.kod_orders','UPDATE') or has_table_privilege('authenticated','kod_private.kod_account_roles','SELECT') then raise exception 'QA: excessive direct grants'; end if;
 if has_column_privilege('authenticated','public.kod_profiles','account_role','UPDATE') then raise exception 'QA: role column writable'; end if;
 cases:=array_append(cases,'RLS and minimum table grants');
 begin
  insert into auth.users(id,raw_user_meta_data,raw_app_meta_data) values
   (a,'{"full_name":"QA Customer A","role":"developer","account_role":"developer"}','{}'),
   (b,'{"full_name":"QA Customer B","requested_account_type":"merchant"}','{}'),
   (m1,'{"full_name":"QA Merchant One"}','{}'),(m2,'{"full_name":"QA Merchant Two"}','{}'),(dev,'{"full_name":"QA Operator"}','{}');
  if (select role from kod_private.kod_account_roles where user_id=a)<>'customer' or (select role from kod_private.kod_account_roles where user_id=b)<>'customer' then raise exception 'QA: metadata escalation'; end if;
  cases:=array_append(cases,'Signup metadata cannot choose privileges');
  update kod_private.kod_account_roles set role='developer' where user_id=dev;
  update public.kod_profiles set account_role='developer' where id=dev;
  update auth.users set email='kod-qa-operator@example.invalid',email_confirmed_at=now() where id=dev;
  insert into auth.sessions(id,user_id,created_at,updated_at) values(operator_session,dev,now(),now());
  insert into kod_private.kod_operator_security(user_id,email) values(dev,'kod-qa-operator@example.invalid');
  insert into kod_private.kod_operator_sessions(session_id,user_id,unlocked_until) values(operator_session,dev,now()+interval '1 hour');
  insert into public.kod_restaurants(id,owner_id,name,city,percent,delivery_fee_cents,minimum_order_cents) values
   (r1,m1,'QA Restaurant One','دبي',25,700,2500),(r2,m2,'QA Restaurant Two','أبوظبي',20,500,2500);
  update public.kod_platform_settings set ordering_enabled=true where id=1;
  perform set_config('request.jwt.claim.sub',dev::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',dev,'role','authenticated','session_id',operator_session)::text,true);
  execute 'set local role authenticated';
  perform public.kod_review_restaurant(r1,true); perform public.kod_review_restaurant(r2,true);
  if public.kod_my_role()<>'developer' then raise exception 'QA: operator role lookup'; end if;
  cases:=array_append(cases,'Verified operator can approve restaurant accounts');
  execute 'reset role';
  if (select role from kod_private.kod_account_roles where user_id=m1)<>'merchant' then raise exception 'QA: approved merchant binding'; end if;
  insert into public.kod_menu_items(id,restaurant_id,name,price_cents,is_available) values
   (i1,r1,'QA Meal',3500,true),(i2,r1,'QA Unavailable',1000,false),(i3,r2,'QA Other Menu',1000,true);
  update public.kod_memberships set status='active',expires_at=now()+interval '30 days' where user_id=a;
  perform set_config('request.jwt.claim.sub',m1::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',m1,'role','authenticated')::text,true);
  execute 'set local role authenticated';perform public.kod_set_restaurant_open(r1,true);execute 'reset role';
  perform set_config('request.jwt.claim.sub',m2::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',m2,'role','authenticated')::text,true);
  execute 'set local role authenticated';perform public.kod_set_restaurant_open(r2,true);execute 'reset role';
  perform set_config('request.jwt.claim.sub',a::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',a,'role','authenticated')::text,true);
  execute 'set local role authenticated';
  if public.kod_my_role()<>'customer' or (select count(*) from public.kod_profiles)<>1 then raise exception 'QA: customer profile isolation'; end if;
  denied:=false;begin update public.kod_profiles set account_role='developer' where id=a;exception when insufficient_privilege then denied:=true;end;
  if not denied then raise exception 'QA: customer altered role';end if;
  denied:=false;begin perform public.kod_review_restaurant(r1,true);exception when others then if sqlerrm<>'developer_required' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: customer approved restaurant';end if;
  cases:=array_append(cases,'Customer profile isolation and privilege escalation rejection');
  lines:=jsonb_build_array(jsonb_build_object('item_id',i1,'quantity',2,'price_cents',1));
  out_order:=public.kod_place_order(r1,lines,'delivery','QA Guest','+971500000001','QA synthetic address','',request_id);
  order_id:=out_order.id;
  if out_order.subtotal_cents<>7000 or out_order.discount_cents<>1750 or out_order.delivery_fee_cents<>700 or out_order.total_cents<>5950 then raise exception 'QA: authoritative pricing';end if;
  cases:=array_append(cases,'Server prices ignore forged client price; total 59.50 AED');
  out_order:=public.kod_place_order(r1,lines,'delivery','QA Guest','+971500000001','QA synthetic address','',request_id);
  if out_order.id<>order_id or (select count(*) from public.kod_orders)<>1 then raise exception 'QA: duplicate order';end if;
  denied:=false;begin perform public.kod_place_order(r1,jsonb_build_array(jsonb_build_object('item_id',i1,'quantity',1)),'delivery','QA Guest','+971500000001','QA synthetic address','',request_id);exception when others then if sqlerrm<>'idempotency_conflict' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: reused key accepted different content';end if;
  cases:=array_append(cases,'Idempotency and changed-content conflict');
  denied:=false;begin perform public.kod_place_order(r1,jsonb_build_array(jsonb_build_object('item_id',i2,'quantity',3)),'delivery','QA Guest','+971500000001','QA synthetic address','',gen_random_uuid());exception when others then if sqlerrm<>'item_unavailable' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: unavailable item accepted';end if;
  denied:=false;begin perform public.kod_place_order(r1,jsonb_build_array(jsonb_build_object('item_id',i3,'quantity',3)),'delivery','QA Guest','+971500000001','QA synthetic address','',gen_random_uuid());exception when others then if sqlerrm<>'item_unavailable' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: foreign menu item accepted';end if;
  denied:=false;begin perform public.kod_place_order(r1,jsonb_build_array(jsonb_build_object('item_id',i1,'quantity',1),jsonb_build_object('item_id',i1,'quantity',1)),'delivery','QA Guest','+971500000001','QA synthetic address','',gen_random_uuid());exception when others then if sqlerrm<>'duplicate_or_missing_item' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: duplicate line accepted';end if;
  denied:=false;begin perform public.kod_place_order(r1,jsonb_build_array(jsonb_build_object('item_id',i1,'quantity',21)),'delivery','QA Guest','+971500000001','QA synthetic address','',gen_random_uuid());exception when others then if sqlerrm<>'invalid_quantity' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: invalid quantity accepted';end if;
  denied:=false;begin perform public.kod_place_order(r2,jsonb_build_array(jsonb_build_object('item_id',i3,'quantity',1)),'pickup','QA Guest','+971500000001','','',gen_random_uuid());exception when others then if sqlerrm<>'minimum_order_not_met' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: minimum order bypassed';end if;
  cases:=array_append(cases,'Availability, foreign items, duplicates, quantities and minimum order');
  perform set_config('request.jwt.claim.sub',b::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',b,'role','authenticated')::text,true);
  if (select count(*) from public.kod_orders)<>0 then raise exception 'QA: customer read another order';end if;
  denied:=false;begin perform public.kod_transition_order(order_id,'cancelled');exception when others then if sqlerrm<>'transition_not_allowed' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: foreign customer cancelled order';end if;
  cases:=array_append(cases,'Cross-customer order read and cancellation isolation');
  perform set_config('request.jwt.claim.sub',m2::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',m2,'role','authenticated')::text,true);
  if (select count(*) from public.kod_orders)<>0 then raise exception 'QA: other merchant read order';end if;
  denied:=false;begin perform public.kod_transition_order(order_id,'accepted');exception when others then if sqlerrm<>'transition_not_allowed' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: other merchant accepted order';end if;
  update public.kod_menu_items set is_available=false where id=i1;get diagnostics rows_affected=row_count;
  if rows_affected<>0 then raise exception 'QA: merchant changed foreign menu';end if;
  cases:=array_append(cases,'Cross-merchant order and menu isolation');
  perform set_config('request.jwt.claim.sub',m1::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',m1,'role','authenticated')::text,true);
  if (select count(*) from public.kod_orders)<>1 then raise exception 'QA: owner cannot read order';end if;
  denied:=false;begin perform public.kod_transition_order(order_id,'preparing');exception when others then if sqlerrm<>'transition_not_allowed' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: skipped acceptance';end if;
  perform public.kod_transition_order(order_id,'accepted');perform public.kod_transition_order(order_id,'preparing');
  denied:=false;begin perform public.kod_transition_order(order_id,'ready_for_pickup');exception when others then if sqlerrm<>'transition_not_allowed' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: delivery used pickup state';end if;
  perform public.kod_transition_order(order_id,'out_for_delivery');out_order:=public.kod_transition_order(order_id,'delivered');
  if jsonb_array_length(out_order.events)<>5 then raise exception 'QA: incomplete delivery timeline';end if;
  cases:=array_append(cases,'Merchant state machine and delivery timeline');
  perform set_config('request.jwt.claim.sub',a::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',a,'role','authenticated')::text,true);
  denied:=false;begin perform public.kod_transition_order(order_id,'cancelled');exception when others then if sqlerrm<>'transition_not_allowed' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: delivered order cancelled';end if;
  out_order:=public.kod_place_order(r1,jsonb_build_array(jsonb_build_object('item_id',i1,'quantity',1)),'pickup','QA Guest','+971500000001','','',gen_random_uuid());pickup_id:=out_order.id;
  if out_order.delivery_fee_cents<>0 or out_order.total_cents<>2625 then raise exception 'QA: pickup pricing';end if;
  out_order:=public.kod_place_order(r1,jsonb_build_array(jsonb_build_object('item_id',i1,'quantity',1)),'pickup','QA Guest','+971500000001','','',gen_random_uuid());cancelled_id:=out_order.id;
  out_order:=public.kod_transition_order(cancelled_id,'cancelled');if out_order.status<>'cancelled' then raise exception 'QA: pending cancellation';end if;
  cases:=array_append(cases,'Pickup price and customer cancellation constraints');
  perform set_config('request.jwt.claim.sub',m1::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',m1,'role','authenticated')::text,true);
  perform public.kod_transition_order(pickup_id,'accepted');perform public.kod_transition_order(pickup_id,'preparing');perform public.kod_transition_order(pickup_id,'ready_for_pickup');perform public.kod_transition_order(pickup_id,'delivered');
  perform public.kod_set_restaurant_open(r1,false);
  perform set_config('request.jwt.claim.sub',a::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',a,'role','authenticated')::text,true);
  denied:=false;begin perform public.kod_place_order(r1,lines,'delivery','QA Guest','+971500000001','QA synthetic address','',gen_random_uuid());exception when others then if sqlerrm<>'restaurant_unavailable' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: closed restaurant accepted order';end if;
  cases:=array_append(cases,'Pickup fulfillment and closed-restaurant rejection');
  execute 'reset role';update public.kod_platform_settings set ordering_enabled=false where id=1;
  execute 'set local role authenticated';
  denied:=false;begin perform public.kod_place_order(r2,jsonb_build_array(jsonb_build_object('item_id',i3,'quantity',3)),'pickup','QA Guest','+971500000001','','',gen_random_uuid());exception when others then if sqlerrm<>'ordering_not_enabled' then raise;end if;denied:=true;end;
  if not denied then raise exception 'QA: ordering gate bypass';end if;
  execute 'reset role';perform set_config('request.jwt.claim.sub','',true);perform set_config('request.jwt.claims','{"role":"anon"}',true);execute 'set local role anon';
  if (select count(*) from public.kod_restaurants where id in(r1,r2))<>2 then raise exception 'QA: approved restaurant public read';end if;
  denied:=false;begin perform public.kod_my_role();exception when insufficient_privilege then denied:=true;end;
  if not denied then raise exception 'QA: anon called account RPC';end if;
  cases:=array_append(cases,'Ordering gate and anonymous RPC restriction');
  execute 'reset role';perform set_config('request.jwt.claim.sub',dev::text,true);perform set_config('request.jwt.claims',jsonb_build_object('sub',dev,'role','authenticated','session_id',operator_session)::text,true);execute 'set local role authenticated';
  if (select count(*) from public.kod_orders where id in(order_id,pickup_id,cancelled_id))<>3 or (select count(*) from public.kod_profiles where id in(a,b,m1,m2,dev))<>5 then raise exception 'QA: developer visibility';end if;
  cases:=array_append(cases,'Operator oversight visibility');
  execute 'reset role';
  update public.kod_platform_settings set ordering_enabled=true where id=1;
  update public.kod_restaurants set is_open=true where id=r1;
  execute 'set local role authenticated';
  request_id:=gen_random_uuid();
  denied:=false;
  begin
   perform public.kod_checkout_order(r1,lines,'pickup','QA Operator','+971500000001','','',request_id,6000);
  exception when others then
   if sqlerrm<>'price_changed' then raise; end if;
   denied:=true;
  end;
  if not denied or (select count(*) from public.kod_orders where customer_id=dev)>0 then
   raise exception 'QA: unconfirmed price produced an order';
  end if;
  out_order:=public.kod_checkout_order(r1,lines,'pickup','QA Operator','+971500000001','','',request_id,7000);
  if out_order.customer_id<>dev or out_order.total_cents<>7000 then raise exception 'QA: native developer purchase';end if;
  order_id:=out_order.id;
  out_order:=public.kod_checkout_order(r1,lines,'pickup','QA Operator','+971500000001','','',request_id,7000);
  if out_order.id<>order_id then raise exception 'QA: duplicate checkout';end if;
  perform public.kod_transition_order(order_id,'cancelled');
  cases:=array_append(cases,'Changed quotes roll back, same-basket retry is idempotent and the operator purchases as self');
  perform set_config('request.jwt.claim.sub',m2::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',m2,'role','authenticated')::text,true);
  if exists(select 1 from public.kod_orders where id=order_id) then raise exception 'QA: other merchant could see buyer'; end if;
  out_order:=public.kod_checkout_order(r1,lines,'delivery','QA Merchant','+971500000002','QA test address','',gen_random_uuid(),7700);
  if out_order.customer_id<>m2 or out_order.delivery_fee_cents<>700 then raise exception 'QA: merchant purchases for self';end if;
  cases:=array_append(cases,'Merchant can buy for self while other restaurants remain isolated');

  report:=jsonb_build_object('passed',true,'check_groups',cardinality(cases),'cases',to_jsonb(cases));
  raise exception using errcode='ZK001',message='rollback_qa_fixtures';
 exception when sqlstate 'ZK001' then null;
 end;
 if (select count(*) from auth.users)<>baseline_auth or exists(select 1 from public.kod_restaurants where id in(r1,r2)) or (select ordering_enabled from public.kod_platform_settings where id=1) is distinct from baseline_ordering then raise exception 'QA: fixtures not rolled back';end if;
 return report||jsonb_build_object('fixtures_rolled_back',true,'real_credentials_created',false);
end
$test$;
select pg_temp.kod_run_checks() as kod_backend_qa;

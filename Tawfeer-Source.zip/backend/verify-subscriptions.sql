-- Disposable KOD billing checks. No gateway is contacted.
begin;
do $test$
declare
  u uuid:=gen_random_uuid(); v uuid:=gen_random_uuid(); req uuid:=gen_random_uuid();
  a jsonb; b jsonb; paid_until timestamptz; id_a uuid; id_b uuid; term integer; expected integer;
begin
  insert into auth.users(id,email,raw_user_meta_data,raw_app_meta_data)
    select id,'kod-test-'||id||'@example.invalid','{}','{}' from unnest(array[u,v]) id;
  execute 'set local role service_role';
  foreach term in array array[1,3,6,12] loop
    expected:=case term when 1 then 6900 when 3 then 18900 when 6 then 35900 when 12 then 59900 end;
    b:=public.kod_prepare_subscription(v,gen_random_uuid(),term,'etisalat','101');
    if (b->>'amount')::integer<>expected then raise exception 'invalid term price';end if;
  end loop;
  a:=public.kod_prepare_subscription(u,req,1,'stripe','');id_a:=(a->>'id')::uuid;
  b:=public.kod_prepare_subscription(u,gen_random_uuid(),1,'stripe','');
  if b->>'state'<>'starting' or b->>'id'<>a->>'id' then raise exception 'concurrent reservation failed';end if;
  if not public.kod_attach_checkout(id_a,(a->>'lease')::uuid,'cs_fixture','https://checkout.stripe.com/fixture',now()+interval '24 hours') then raise exception 'attach failed';end if;
  if public.kod_prepare_subscription(u,req,1,'stripe','')->>'state'<>'ready' then raise exception 'retry failed';end if;
  begin
    perform public.kod_settle_subscription(id_a,'stripe','cs_fixture','pi_fixture','','AED',100);
    raise exception 'unexpected amount accepted';
  exception when raise_exception then if sqlerrm<>'payment_mismatch' then raise;end if;end;
  if (select status from public.kod_memberships where user_id=u)='active' then raise exception 'activated before confirmation';end if;
  perform public.kod_settle_subscription(id_a,'stripe','cs_fixture','pi_fixture','','AED',6900);
  select expires_at into paid_until from public.kod_memberships where user_id=u;
  perform public.kod_settle_subscription(id_a,'stripe','cs_fixture','pi_fixture','','AED',6900);
  if paid_until is null or (select expires_at from public.kod_memberships where user_id=u)<>paid_until then raise exception 'duplicate extension';end if;
  b:=public.kod_prepare_subscription(u,gen_random_uuid(),3,'du','202');id_b:=(b->>'id')::uuid;
  perform public.kod_attach_checkout(id_b,(b->>'lease')::uuid,'apaya_fixture','https://checkout.apaya.io/fixture',now()+interval '30 minutes');
  begin
    perform public.kod_settle_subscription(id_b,'etisalat',null,'carrier_fixture','202','AED',18900);
    raise exception 'wrong carrier accepted';
  exception when raise_exception then if sqlerrm<>'payment_mismatch' then raise;end if;end;
  perform public.kod_settle_subscription(id_b,'du','apaya_fixture','carrier_fixture','202','AED',18900);
  if (select expires_at from public.kod_memberships where user_id=u)<>paid_until+interval '3 months' then raise exception 'remaining membership not preserved';end if;
  execute 'reset role';
  if has_function_privilege('authenticated','public.kod_settle_subscription(uuid,text,text,text,text,text,integer)','execute')
    or has_table_privilege('authenticated','public.kod_subscription_orders','UPDATE') or has_column_privilege('authenticated','public.kod_subscription_orders','checkout_url','SELECT')
    or has_column_privilege('anon','public.kod_subscription_orders','id','SELECT') then raise exception 'unexpected checkout permission';end if;
  perform set_config('request.jwt.claim.sub',v::text,true);
  perform set_config('request.jwt.claims',jsonb_build_object('sub',v,'role','authenticated')::text,true);
  execute 'set local role authenticated';
  if exists(select id from public.kod_subscription_orders where id=id_a) or (select count(id) from public.kod_subscription_orders where user_id=v)<>4 then raise exception 'account isolation failed';end if;
  execute 'reset role';
end $test$;
rollback;
select 'passed: four prices, retry, amount, signed-handler-only settlement, repeat delivery, carrier match, renewal and private receipts' as billing_checks;

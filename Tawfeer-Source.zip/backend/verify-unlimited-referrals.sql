-- More than twenty independent paid friends earn one cash reward each. All records roll back.
begin;
do $test$
declare sponsor uuid:=gen_random_uuid();friend uuid;ticket text;sale jsonb;summary jsonb;i integer;
begin
 insert into auth.users(id,email,email_confirmed_at,created_at,raw_user_meta_data,raw_app_meta_data) values(sponsor,sponsor||'@example.invalid',now(),now()-interval '1 day','{}','{}');
 perform set_config('request.jwt.claim.sub',sponsor::text,true);
 execute 'set local role authenticated';ticket:=public.kod_invite_offer(public.kod_referral_home()->>'code')->>'ticket';execute 'reset role';
 for i in 1..21 loop
  friend:=gen_random_uuid();insert into auth.users(id,email,email_confirmed_at,created_at,raw_user_meta_data,raw_app_meta_data) values(friend,friend||'@example.invalid',now(),clock_timestamp(),jsonb_build_object('kod_invite_ticket',ticket),'{}');
  execute 'set local role service_role';sale:=public.kod_prepare_subscription(friend,gen_random_uuid(),1,'stripe','');
  perform public.kod_attach_checkout((sale->>'id')::uuid,(sale->>'lease')::uuid,'qa-'||friend,'https://checkout.stripe.com/fixture',now()+interval '1 day');
  perform public.kod_settle_subscription((sale->>'id')::uuid,'stripe','qa-'||friend,'fixture-'||friend,'','AED',6900);
  execute 'reset role';
 end loop;
 execute 'set local role authenticated';summary:=public.kod_referral_home();
 if summary->>'paid' is distinct from '21' or summary->>'review_fils' is distinct from '52500' or summary->>'earned_days' is distinct from '0' then raise exception 'unlimited referral regression';end if;
 execute 'reset role';
end $test$;
rollback;

"""Build the four-language application, PWA metadata and self-contained guide/offline copy."""
import html
import json
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parent
CODES=('en','ur','fa')
RTL={'ar','ur','fa'}
def js(obj):
    return json.dumps(obj,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
def compile_copy(source):
    return subprocess.run(['node','--expose-internals',str(ROOT/'localize-build.cjs')],input=source,text=True,capture_output=True,check=False)
def compile_checked(source):
    result=compile_copy(source)
    if result.returncode: raise RuntimeError(result.stderr[:1500])
    return result.stdout
class PageCopy(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.keys=set()
        self.omit=None
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style','svg'): self.omit=tag
        if not self.omit:
            for k,v in attrs:
                if v and k in ('alt','aria-label','title','placeholder','content','data-copy-source'):self.keys.add(v.strip())
    def handle_endtag(self,tag):
        if tag==self.omit:self.omit=None
    def handle_data(self,data):
        if not self.omit and data.strip():self.keys.add(data.strip())
def catalogs():
    result={code:json.loads((ROOT/'locales'/f'{code}.json').read_text()) for code in CODES}
    keys=set(result['en']['messages'])
    for code,d in result.items():
        if d['language']!=code or set(d['messages'])!=keys:raise ValueError('Mismatched locale '+code)
        for key,v in d['messages'].items():
            if not isinstance(v,str) or not v.strip() or any(c in v for c in '<>'):raise ValueError((code,key,v))
    return result
def resources(tables):
    return '<script type="application/json" id="tawfeer-language-data">'+js(tables)+'</script>\n<script id="tawfeer-language">'+(ROOT/'language.js').read_text()+'</script>'
def check_static_keys(page,table):
    parser=PageCopy();parser.feed(page)
    autonyms={'العربية','اردو','فارسی','English'}
    missing={key for key in parser.keys if re.search('[\u0621-\u064a]',key) and key not in table and key not in autonyms}
    if missing:raise ValueError('Missing static translations: '+repr(sorted(missing)))
def build_application(page):
    locales=catalogs()
    tables={c:d['messages'] for c,d in locales.items()}
    check_static_keys(page,tables['en'])
    named={key:v for key,v in locales['en'].get('formats',{}).items()}
    ar_form={k:v['source'] for k,v in named.items()}
    for c,d in locales.items():
        for k,v in d.get('formats',{}).items():tables[c][v['source']]=v['translation']
    fn='const localePatterns='+js(ar_form)+';\nfunction localeMessage(key,values){const pattern=localeCopy(localePatterns[key]);return pattern.replace(/\\{([a-zA-Z]+)\\}/g,(_,name)=>String(values[name]??""));}\n'
    page=page.replace('/* Tawfeer message formatter */\n/* End Tawfeer message formatter */','/* Tawfeer message formatter */\n'+fn+'/* End Tawfeer message formatter */')
    start=page.rindex('<script>')+len('<script>');end=page.index('</script>',start)
    page=page[:start]+compile_checked(page[start:end])+page[end:]
    page=page.replace('<!-- Tawfeer locale resources --><!-- End Tawfeer locale resources -->','<!-- Tawfeer locale resources -->\n'+resources(tables)+'\n<!-- End Tawfeer locale resources -->')
    install=compile_checked((ROOT/'install-view.js').read_text())
    (ROOT/'tawfeer-install.js').write_text("(() => {\nconst localeCopy = key => globalThis.TawfeerLanguage?.text(key) ?? key;\n"+install+'\n})();\n')
    return page
def build_static(page,locales,picker):
    # Only original static copy from this specific document is needed while offline.
    check_static_keys(page,locales['en']['messages'])
    keys=PageCopy();keys.feed(page)
    keys.keys.add('اللغة')
    tables={c:{key:d['messages'][key] for key in keys.keys if key in d['messages']} for c,d in locales.items()}
    # Sort to make repeated builds byte-for-byte reproducible.
    tables={c:dict(sorted(vals.items())) for c,vals in tables.items()}
    page=page.replace('</head>',resources(tables)+'<style>'+(ROOT/'language.css').read_text()+'</style></head>')
    page=page.replace('<body>', '<body data-language-links>')
    if '<nav aria-label="تصفح توفير">' in page: page=page.replace('<nav aria-label="تصفح توفير">','<nav aria-label="تصفح توفير">'+picker)
    else:page=page.replace('</main>',picker+'</main>')
    return page.replace('</body>','<script id="tawfeer-static-copy">TawfeerLanguage.applyStatic(document);</script></body>')
def build_documents():
    locales=catalogs()
    tag=re.search(r'<label class="locale-picker">.*?</label>',(ROOT/'app-shell.html').read_text(),re.S)[0]
    for guide in sorted(ROOT.glob('city-*.html')):
        guide.write_text(build_static(guide.read_text(),locales,tag))
    offline=ROOT/'offline.html'
    offline.write_text(build_static(offline.read_text(),locales,tag))
    manifest=json.loads((ROOT/'manifest.webmanifest').read_text())
    for c,d in locales.items():
        target=dict(manifest,lang=c,dir='rtl' if c in RTL else 'ltr')
        for field in ('name','short_name','description'):target[field]=d['messages'][manifest[field]]
        (ROOT/f'manifest-{c}.webmanifest').write_text(json.dumps(target,ensure_ascii=False,indent=2)+'\n')

"""Refresh the editable Tawfeer components in the standalone GitHub Pages document."""
import base64
from collections import Counter
from hashlib import sha256
from xml.etree import ElementTree
import json
from pathlib import Path
import re
import runpy
localize = runpy.run_path(str(Path(__file__).resolve().with_name("build-locales.py")))

root = Path(__file__).resolve().parent
index = root / "index.html"
page = (root / "app-shell.html").read_text()

def replace_section(source, start, end, content):
    before, rest = source.split(start, 1)
    _, after = rest.split(end, 1)
    return before + start + content + end + after

logo_svg = (root / "tawfeer-brand.svg").read_text().strip()
logo = ElementTree.fromstring(logo_svg)
width = float(logo.attrib["viewBox"].split()[2])
paths = [{"fill": child.attrib["fill"], "d": child.attrib["d"]} for child in logo]
art = "const tawfeerLogoArt=" + json.dumps({"width": width, "paths": paths}, separators=(",", ":")) + ";\n"
art += (root / "tawfeer-logo-art.js").read_text()

offline_file = root / "offline.html"
offline = replace_section((root / "offline-template.html").read_text(), "<!-- Tawfeer logo -->", "<!-- End Tawfeer logo -->", logo_svg)
offline_file.write_text(offline)
font_dir = root / "assets" / "fonts"
font_styles = (font_dir / "cairo.css").read_text()
for subset in ("arabic", "latin-ext", "latin"):
    font = font_dir / f"cairo-{subset}.woff2"
    encoded = base64.b64encode(font.read_bytes()).decode("ascii")
    font_styles = font_styles.replace(f"url({font.name})", f"url(data:font/woff2;base64,{encoded})")
font_license = (font_dir / "OFL.txt").read_text()
styles = "/* Cairo\n" + font_license + "\n*/\n" + font_styles
styles += "\n" + (root / "base-layout.css").read_text() + "\n" + (root / "workspace-v6.css").read_text()
styles += "\n/* Campaign styles */\n" + (root / "campaign.css").read_text().rstrip()
styles += "\n" + (root / "dining.css").read_text().rstrip() + "\n" + (root / "ordering.css").read_text().rstrip() + "\n" + (root / "membership-card.css").read_text().rstrip() + "\n" + (root / "subscriptions.css").read_text().rstrip()
styles += "\n" + (root / "marketing.css").read_text() + "\n" + (root / "club-tiers.css").read_text()
styles += "\n" + (root / "tawfeer.css").read_text() + "\n" + (root/"language.css").read_text()
page = replace_section(page, "<style>", "</style>", "\n" + styles + "\n")
catalog = json.loads((root / "dining-catalog.json").read_text())
for branch in catalog["branches"]:
    branch["nativeName"] = branch["name"]
geo = json.loads((root / "uae-dining.json").read_text())
fields = geo["fields"]
meta = {"asOf": geo["asOf"], "count": len(geo["rows"])}
for name, key in [("cities", "emirate"), ("types", "type")]:
    meta[name] = Counter(row[fields.index(key)] for row in geo["rows"])
city_index, type_index = fields.index("emirate"), fields.index("type")
meta["cityTypes"] = {city: Counter() for city in meta["cities"]}
for row in geo["rows"]:
    meta["cityTypes"][row[city_index]][row[type_index]] += 1
images = json.loads((root / "image-sources.json").read_text())
credits = [{k: image[k] for k in ("id","alt","url","photographer") if k in image}
           for image in images if "photographer" in image or image.get("usage") == "generated_illustrative_cover"]
constants = {"DINING_BRANCHES": catalog["branches"], "PUBLIC_DEALS": catalog["deals"], "DINING_META": meta, "DINING_IMAGES": credits}
definitions = [f"const {key}=" + json.dumps(value, ensure_ascii=False, separators=(",",":")).replace("<","\\u003c") + ";" for key,value in constants.items()]
page = replace_section(page, "/* KOD dining data */", "/* End dining data */", "\n" + "\n".join(definitions) + "\n")
page = replace_section(
    page, "/* KOD discovery components */", "/* End discovery components */",
    "\n" + (root / "dining-directory.js").read_text().rstrip() + "\n" + (root / "discover.js").read_text().rstrip() + "\n",
)
workspace_marker = "/* KOD accounts and ordering. Public configuration contains no secret keys. */"
workspace = (root / "workspace-v6.js").read_text()
if not workspace.startswith(workspace_marker):
    raise ValueError("The account workspace marker is missing")
page = replace_section(page, workspace_marker, "function accountSettingsView()",
                       workspace.removeprefix(workspace_marker) + "\n" + (root / "merchant-workspace.js").read_text() + "\n" + (root / "merchant-menu.js").read_text() + "\n" + re.sub(r'(?m)^export ', '', (root / "backend/functions/kod-wallet-pass/member-appearance.js").read_text()) + "\n" + (root / "direct-order.js").read_text() + "\n" + (root / "ordering.js").read_text() + "\n" + (root / "owner-console.js").read_text() + "\n" + (root / "account-auth.js").read_text() + "\n" + art + "\n" + (root / "membership-art.js").read_text() + "\n" + (root / "card-wallet.js").read_text() + "\n" + (root / "member-device.js").read_text() + "\n" + (root / "referral-cash.js").read_text() + "\n" + (root / "membership-card.js").read_text() + "\n" + (root / "subscriptions.js").read_text() + "\n" + (root / "savings-share-art.js").read_text() + "\n" + (root / "marketing.js").read_text() + "\n" + (root / "marketing-partners.js").read_text() + "\n" + (root / "member-tiers.js").read_text() + "\n" + (root / "featured-restaurants.js").read_text() + "\n" + (root / "member-invoices.js").read_text() + "\n" + (root / "membership-pricing.js").read_text() + "\n")

vendor = root / "assets" / "vendor"
sdk = (vendor / "supabase-2.119.0.js").read_text()
license_text = (vendor / "supabase-LICENSE.txt").read_text()
qr = (vendor / "qrcode-generator-2.0.4.js").read_text()
qr_license = (vendor / "qrcode-generator-LICENSE.txt").read_text()
sdk = re.sub(r"(?i)</script", lambda _: "<" + chr(92) + "/script", sdk)
page = replace_section(page, "<!-- KOD auth SDK -->", "<!-- End auth SDK -->",
                       '\n<script id="kod-auth-sdk">\n/* ' + license_text + ' */\n' + sdk + '\n</script>\n<script id="kod-qr">\n/* ' + qr_license + ' */\n' + qr + '\n</script>\n')

photo_line = re.compile(r"^const PHOTOS=(\{[^\n]*\});$", re.MULTILINE)
photos = json.loads(photo_line.search(page)[1])
for asset in sorted((root / "assets").glob("offer-*.jpg")):
    photos[asset.stem.removeprefix("offer-")] = "data:image/jpeg;base64," + base64.b64encode(asset.read_bytes()).decode()
for asset in sorted((root / "assets").glob("kod-*.webp")):
    key = asset.stem.removeprefix("kod-")
    photos[key] = "data:image/webp;base64," + base64.b64encode(asset.read_bytes()).decode()
page = photo_line.sub(lambda _: "const PHOTOS=" + json.dumps(photos, separators=(",", ":")) + ";", page)
page = localize["build_application"](page)
if index.read_text() != page:
    index.write_text(page)
runpy.run_path(str(root / "build-city-guides.py"), run_name="__main__")

localize["build_documents"]()
worker_file = root / "sw.js"
revision = sha256(offline_file.read_bytes()).hexdigest()[:12]
worker_file.write_text(re.sub(r"const cacheName = prefix \+ '[a-z0-9]+';", f"const cacheName = prefix + '{revision}';", worker_file.read_text()))


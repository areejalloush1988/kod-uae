// Published restaurants keep their own ordering channels. These local basket
// lines never go to the merchant-dashboard RPC without a registered venue ID.
const DIRECT_METHODS={delivery:'توصيل',pickup:'استلام من الفرع',dinein:'داخل المطعم',arrange:'بالاتفاق مع الفرع'};
const directVenues=new Map(),directItems=new Map();
for(const entry of [...DINING_BRANCHES,...PUBLIC_DEALS]){
  if(!entry.direct)continue;
  const offer=Boolean(entry.restaurant),contact=entry.direct;
  const id=(offer?'offer:':'branch:')+entry.id;
  const lines=contact.items||[{key:'offer',name:entry.title,cents:contact.cents}];
  const menu=lines.map(line=>({id:id+'/'+line.key,restaurant_id:id,name:line.name,price_cents:line.cents,is_available:true}));
  const r={id,name:entry.restaurant||entry.name,city:entry.emirate,area:entry.branch||entry.area,photo:contact.photo||entry.photo,
    direct:true,contact,methods:contact.methods,entry,offer,menu};
  directVenues.set(id,r);
  for(const item of menu)directItems.set(item.id,item);
}
function availableDirect(r){return Boolean(r?.direct&&(!r.entry.endDate||r.entry.endDate>=todayInUae()));}
function fulfillmentMethods(r){return r?.direct?r.methods:['delivery','pickup'];}
function displayPrice(item){return Number.isInteger(item?.price_cents)?money(item.price_cents):'السعر يؤكّده الفرع';}
function publicContacts(r){
  if(r.direct)return r.contact;
  return {phone:r.public_phone,whatsapp:r.public_whatsapp};
}
function dialLink(phone){
  return /^\+[1-9][0-9]{7,14}$/.test(phone||'')?'tel:'+phone:'';
}
function waLink(number,text=''){
  if(!dialLink(number))return '';
  return 'https://wa.me/'+number.slice(1)+(text?'?text='+encodeURIComponent(text):'');
}
function emailLink(email,subject='',body=''){
  if(!email||!/^[-a-z0-9.%+_]+@[-a-z0-9.]+\.[a-z]{2,}$/i.test(email))return '';
  return 'mailto:'+email+(subject?'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body):'');
}
function contactLink(url,body,cls='',newWindow=false){
  return url?'<a class="'+cls+'" href="'+esc(url)+'"'+(newWindow?' target="_blank" rel="noopener noreferrer"':'')+'>'+body+'</a>':'';
}
function branchContactBlock(r){
  const c=publicContacts(r);
  const choices=[
    contactLink(dialLink(c.phone),icon('phone')+' <bdi dir="ltr">'+esc(c.phone)+'</bdi>','direct-contact'),
    contactLink(waLink(c.whatsapp),icon('chat')+' واتساب الفرع','direct-contact',true),
    contactLink(emailLink(c.email),'بريد الفرع','direct-contact')
  ].join('');
  if(!choices)return r.is_demo?'':'<p class="direct-hint">يؤكّد المطعم طلبات توفير من لوحة الفرع.</p>';
  return '<div class="direct-contact-list" aria-label="التواصل مع المطعم">'+choices+'</div>';
}
function branchOrderAction(p,cls=''){
  if(!p?.official||!directVenues.has('branch:'+p.id))return '';
  return '<button type="button" class="'+cls+'" data-restaurant-info="branch:'+esc(p.id)+'" aria-label="'+localeMessage('order.viewDirectoryBranch',{name:displayText(p.name),area:displayText(p.area)})+'">عرض وطلب '+icon('arrow')+'</button>';
}
function showRestaurantOrder(id){
  const r=venueForOrder(id);
  if(!r||r.direct&&!availableDirect(r)){toast('انتهت مدة هذا العرض.');return;}
  const items=menuForOrder(r.id).filter(item=>item.is_available),entry=r.entry||{},isOffer=r.offer;
  const location=[r.area||r.branch_address,placeLabel(r.city)].filter(Boolean).join('، ');
  let picker='';
  if(items.length>1){
    picker='<label for="direct-item">اختر '+(isOffer?'القائمة':'الصنف')+'</label><select id="direct-item" name="menu_item_id">'+items.map(m=>'<option value="'+esc(m.id)+'">'+displayText(m.name)+' · '+displayPrice(m)+'</option>').join('')+'</select>';
  }else if(items.length){
    const item=items[0],sameOffer=isOffer&&item.name===entry.title;
    const label=sameOffer?'سعر العرض':displayText(item.name);
    const value=sameOffer&&!Number.isInteger(item.price_cents)?'يؤكّده الفرع':displayPrice(item);
    picker='<input type="hidden" name="menu_item_id" value="'+esc(item.id)+'"><div class="direct-single"><strong>'+label+'</strong><span>'+value+'</span></div>';
  }
  const terms=isOffer?'<div class="direct-offer"><h3>'+displayText(entry.title)+'</h3><p>'+icon('clock')+' '+displayText(entry.schedule)+'</p><p>'+displayText(entry.terms)+'</p>'+
    (entry.endDate?'<small>حتى <bdi>'+esc(entry.endDate)+'</bdi></small>':'')+'</div>':'';
  const more=r.direct?'<details class="direct-more"><summary>معلومات الفرع والمصدر</summary><div>'+
    linkOut(entry.direct.contactUrl||entry.url,'موقع الفرع')+((entry.direct.menuUrl||entry.menuUrl)?linkOut(entry.direct.menuUrl||entry.menuUrl,'المنيو الرسمي'):'')+
    (isOffer?linkOut(entry.url,'شروط العرض'):'')+linkOut(mapsUrl({name:r.name,en:entry.en,area:r.area,emirate:r.city}),'موقع الفرع على الخريطة')+'</div></details>':'';
  showModal('<div class="direct-modal"><div class="direct-cover">'+photo(FEATURED_MENUS[entry.id]?.photo||venuePhoto(r))+'</div><div class="direct-body">'+
    '<h2 id="modal-title">'+displayText(r.name)+'</h2><p class="direct-location">'+icon('pin')+' '+displayText(location)+'</p>'+
    branchContactBlock(r)+(r.approved&&!r.is_demo&&r.instore_percent>0?'<p class="direct-hint">خصومات توفير عند الكاشير · '+clubRateComparison(r,'counter')+'</p>':'')+terms+'<form class="direct-add-form" id="direct-add-form" data-venue="'+esc(r.id)+'">'+picker+
    '<button type="submit" class="btn full direct-add" '+(!canOrderAt(r)||!items.length?'disabled':'')+'>'+icon('bag')+' '+(items.length?'إضافة إلى السلة':'المنيو غير متاح حالياً')+'</button></form>'+more+'</div></div>');
}
function directCard(r){
  const p=r.entry;
  return '<article class="order-tile direct-tile"><div class="order-tile-photo">'+photo(r.photo)+'</div><div class="order-tile-info">'+
    '<span>'+displayText(placeLabel(r.city))+' · '+displayText(placeCuisines(officialByKey.get('venue:'+p.id)))+'</span><h3>'+displayText(r.name)+'</h3><p>'+displayText(r.area)+'</p>'+
    '<button class="order-tile-action" data-restaurant-info="'+esc(r.id)+'" aria-label="'+localeMessage('order.viewDirectBranch',{name:displayText(r.name),area:displayText(r.area)})+'">عرض وطلب '+icon('arrow')+'</button></div></article>';
}
function directOrderSummary(r){
  const items=menuForOrder(r.id);
  const selected=cart.lines.map(line=>({item:items.find(i=>i.id===line.itemId),quantity:line.quantity}));
  const valid=availableDirect(r)&&r.methods.includes(cart.method)&&selected.length>0&&selected.every(({item,quantity})=>item?.is_available&&Number.isInteger(quantity)&&quantity>=1&&quantity<=20);
  const priced=selected.every(({item})=>Number.isInteger(item?.price_cents));
  const total=priced?selected.reduce((sum,{item,quantity})=>sum+item.price_cents*quantity,0):null;
  const amount=priced?money(total):'يؤكّده الفرع';
  const intro=r.offer?localeMessage('direct.confirmOffer',{restaurant:r.name,area:r.area,city:placeLabel(r.city)}):localeMessage('direct.orderItems',{restaurant:r.name,area:r.area,city:placeLabel(r.city)});
  const text=[intro,DIRECT_METHODS[cart.method],
    ...selected.map(({item,quantity})=>(item?.name||'صنف غير متاح')+' × '+quantity+
      (Number.isInteger(item?.price_cents)?' — '+money(item.price_cents*quantity):'')),
    priced?'قيمة الأصناف حسب المنيو '+amount:'يرجى تأكيد السعر.',
    cart.method==='delivery'?'يرجى تأكيد التوفّر ورسوم التوصيل.':'يرجى تأكيد التوفّر.'].join('\n');
  return {valid,amount,priced,text};
}
function directCartView(r){
  const s=directOrderSummary(r),c=r.contact,isBooking=r.offer&&cart.method==='dinein',items=menuForOrder(r.id);
  const whatsapp=waLink(c.whatsapp,s.text),call=dialLink(c.phone);
  const action=whatsapp?contactLink(whatsapp,icon('chat')+' '+(isBooking?'اطلب الحجز عبر واتساب الفرع':'أرسل الطلب عبر واتساب الفرع'),'btn full direct-submit',true):
    contactLink(call,icon('phone')+' '+(isBooking?'اتصل بالفرع لتأكيد العرض':'اتصل بالفرع لتأكيد الطلب'),'btn full direct-submit');
  const tip=whatsapp?'يفتح واتساب وفيه تفاصيل سلّتك. اضغط إرسال، والفرع يؤكّد لك الطلب.':'اتصل بالرقم المعلن وأكّد الأصناف مع الفرع. فيك تنسخ تفاصيل سلّتك.';
  const buttons=r.methods.length>1?'<div class="method-switch fulfillment">'+r.methods.map(method=>'<button data-fulfillment="'+method+'" class="'+(cart.method===method?'active':'')+'" aria-pressed="'+(cart.method===method)+'">'+DIRECT_METHODS[method]+'</button>').join('')+'</div>':
    '<p class="direct-method">'+icon('store')+' '+DIRECT_METHODS[cart.method]+'</p>';
  return '<header class="order-page-head"><div><h1>سلّتك</h1><p>'+displayText(r.name)+' · '+displayText(r.area)+'، '+displayText(placeLabel(r.city))+'</p></div></header>'+
    '<div class="checkout-layout"><section class="box"><h2>'+ (r.offer?'تفاصيل العرض':'الأصناف')+'</h2>'+buttons+cart.lines.map(l=>cartLine(l,items)).join('')+
    '<button class="text-button" data-restaurant-info="'+esc(r.id)+'">العودة إلى '+(r.offer?'الإعلان':'منيو الفرع')+'</button></section>'+
    '<aside class="box checkout-summary order-checkout direct-checkout"><h2>تأكيد الطلب مع المطعم</h2><div class="checkout-total"><span>قيمة الأصناف</span><strong>'+s.amount+'</strong></div>'+
    (cart.method==='delivery'?'<p class="order-payment">يحدّد الفرع رسوم التوصيل حسب العنوان.</p>':'')+
    (s.valid?'<p class="order-payment">'+tip+'</p>'+action+
      '<div class="direct-alternatives"><button class="text-button" data-copy-direct>نسخ تفاصيل الطلب</button>'+
      (c.email?contactLink(emailLink(c.email,'طلب من '+r.name,s.text),'مراسلة الفرع بالبريد','text-button'):'')+
      (whatsapp?contactLink(call,'اتصال بالفرع','text-button'):'')+'</div>':
      '<p role="alert">تغيّر توفّر أحد الأصناف أو انتهى العرض. راجع السلة قبل التواصل.</p>')+'</aside></div>';
}
function branchPhone(value){
  let number=latinDigits(value||'').replace(/[\s()-]/g,'');
  if(/^0[2-4679]\d{7}$/.test(number))number='+971'+number.slice(1);
  return normalizedPhone(number);
}
function contactFields(r={}){
  return '<div class="field"><label>عنوان الفرع<input name="branch_address" maxlength="200" required value="'+esc(r.branch_address||'')+'" placeholder="المنطقة، الشارع أو المركز التجاري"></label></div>'+
    '<div class="field"><label>هاتف الفرع المعلن<input name="public_phone" type="tel" dir="ltr" required value="'+esc(r.public_phone||'')+'"></label></div>'+
    '<div class="field"><label>واتساب الفرع (اختياري)<input name="public_whatsapp" type="tel" dir="ltr" value="'+esc(r.public_whatsapp||'')+'"></label></div>'+
    '<p class="small">تظهر بيانات التواصل هذه للعملاء في إعلان الفرع.</p>';
}
function contactPayload(form){
  const f=form.elements,phone=branchPhone(f.public_phone.value),wa=branchPhone(f.public_whatsapp.value),address=f.branch_address.value.trim();
  if(!phone||f.public_whatsapp.value.trim()&&!wa||!address)throw Error('invalid_business_contact');
  return {public_phone:phone,public_whatsapp:wa||null,branch_address:address};
}
function editContactPanel(r){
  if(!r||previewRole)return '';
  return '<form class="box contact-edit" data-contact-edit="'+esc(r.id)+'"><h3>التواصل مع '+displayText(r.name)+'</h3>'+contactFields(r)+'<button class="btn" type="submit">حفظ بيانات الفرع</button><p role="status"></p></form>';
}
document.addEventListener('click',async e=>{
  const button=e.target.closest('button');if(!button)return;
  if(button.dataset.restaurantInfo){showRestaurantOrder(button.dataset.restaurantInfo);return;}
  if(button.hasAttribute('data-copy-direct')){
    const r=venueForOrder(cart?.restaurantId);if(!r?.direct)return;
    const s=directOrderSummary(r);if(!s.valid)return;
    try{await navigator.clipboard.writeText(s.text);toast('تم نسخ تفاصيل الطلب.');}
    catch{showModal('<div class="modal-body"><h2 id="modal-title">تفاصيل الطلب</h2><textarea id="direct-copy-text" rows="7" readonly>'+esc(s.text)+'</textarea></div>');document.getElementById('direct-copy-text').select();}
  }
});
document.addEventListener('submit',async e=>{
  const form=e.target;
  if(form.id==='direct-add-form'){
    e.preventDefault();const r=venueForOrder(form.dataset.venue),id=form.elements.namedItem('menu_item_id')?.value;
    if(!r||!canOrderAt(r)||!menuForOrder(r.id).some(m=>m.id===id&&m.is_available))return toast('الصنف غير متاح.');
    addCartItem(id,false,true);
  }else if(form.dataset.contactEdit){
    e.preventDefault();
    if(!appIdentity||previewRole)return;
    const submit=form.querySelector('[type=submit]'),status=form.querySelector('[role=status]'),epoch=workspaceEpoch;
    submit.disabled=true;
    try{
      const fields=contactPayload(form),client=await getKodClient();
      if(epoch!==workspaceEpoch)return;
      const {data,error}=await client.from('kod_restaurants').update(fields).eq('id',form.dataset.contactEdit).select('id').single();
      if(error||!data)throw error||Error('not_updated');
      await refreshLiveWorkspace();if(epoch===workspaceEpoch){render('merchant');toast('تم حفظ بيانات التواصل.');}
    }catch(error){status.textContent=error?.message==='invalid_business_contact'?'راجع عنوان الفرع ورقم التواصل.':'تعذّر حفظ التغيير.';}
    finally{submit.disabled=false;}
  }
});

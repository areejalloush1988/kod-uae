const FEATURED_MENUS = {
  'grand-beirut-galleria-lunch': {title:'غداء لبناني',location:'في جزيرة المارية',photo:'lebanese-table',perPerson:true},
  'pizzaexpress-jlt-wednesday': {title:'صنفان بسعر واحد',location:'في أبراج بحيرات جميرا'},
  'refuel-creek-coffee-pastry': {title:'قهوة وكرواسون',location:'في ألوفت دبي كريك'},
  'sea-breeze-rak-indian-lunch': {title:'غداء هندي',location:'في ميناء العرب',perPerson:true},
  'dai-pai-dong-rosewood-lunch': {title:'غداء كانتوني',location:'في روزوود أبوظبي'}
};
let storyIndex=0, showDemoDeals=false;
const photoAlt = key=>DINING_IMAGES.find(i=>i.id===key)?.alt||'صورة توضيحية للطعام';
function photo(key,cls='',priority=false) {
  return '<img class="'+cls+'" src="'+(PHOTOS[key]||PHOTOS.feast)+'" alt="'+displayText(photoAlt(key))+'" '+
    (priority?'fetchpriority="high"':'loading="lazy"')+' decoding="async">';
}
function isDiningFavorite(id) {
  return typeof id==='string'&&id.length<=80&&(/^(venue|deal):[a-z0-9-]+$/.test(id)||/^osm:[nwr]\d+$/.test(id)||OFFERS.some(o=>o.id===id));
}
function heart(key,name) {
  const on=state.favorites.includes(key), label=(on?'إزالة من المفضلة':'حفظ في المفضلة')+' · '+name;
  return '<button class="dining-heart'+(on?' saved':'')+'" data-favorite="'+esc(key)+'" data-favorite-name="'+displayText(name)+'" aria-label="'+displayText(label)+'" aria-pressed="'+on+'">'+icon('heart')+'</button>';
}
function updateHearts() {
  document.querySelectorAll('[data-favorite]').forEach(b=>{
    const on=state.favorites.includes(b.dataset.favorite);
    b.classList.toggle('saved',on); b.setAttribute('aria-pressed',String(on));
    b.setAttribute('aria-label',(on?'إزالة من المفضلة':'حفظ في المفضلة')+' · '+b.dataset.favoriteName);
  });
}
function navHtml(mobile) {
  const cardLabel=appIdentity?.role==='merchant'&&!previewRole?'بطاقة العضوية':'بطاقتي';
  const extra={rewards:{name:'دعواتي ومكافآتي',short:'مكافآتي',icon:'ticket'},marketing:{name:'التسويق والشراكات',short:'الشراكات',icon:'store'},subscriptions:{name:'باقات الاشتراك',short:'الاشتراكات',icon:'ticket'},food:{name:'اطلب الآن',short:'اطلب الآن',icon:'food'},directory:{name:'دليل الأماكن',short:'الدليل',icon:'pin'},deals:{name:'عروض المطاعم',short:'العروض',icon:'ticket'},membership:{name:cardLabel,short:cardLabel==='بطاقتي'?cardLabel:'البطاقة',icon:'card'}};
  function item(id) {
    const row=extra[id]||NAV.find(n=>n.id===id);
    const selected=id===current||(id==='food'&&['menu','cart'].includes(current))||(mobile&&id==='membership'&&current==='subscriptions')||(id==='orders'&&current==='receipt')||(id==='account'&&!isLiveOperator()&&['auth','register','dashboard','merchant','developer'].includes(current));
    return '<button data-go="'+id+'" class="'+(selected?'active':'')+'"'+(selected?' aria-current="page"':'')+'>'+icon(row.icon)+'<span>'+row[mobile?'short':'name']+'</span></button>';
  }
  if(isLiveOperator())extra.developer={name:'لوحات التحكم',short:'الإدارة',icon:'grid'};
  if(mobile)return ['discover','food','membership','orders','deals',isLiveOperator()?'developer':'account'].map(item).join('');
  return '<div class="rail-group"><span class="rail-heading">استكشف</span>'+['discover','food','deals','directory'].map(item).join('')+
    '</div><div class="rail-group"><span class="rail-heading">مساحتي</span>'+(isLiveOperator()?['favorites','orders','membership','subscriptions','rewards','marketing','developer','account']:['favorites','orders','membership','subscriptions','rewards','marketing','account']).map(item).join('')+'</div>';
}
function featuredDeals() {
  const eligible=activeDeals().filter(d=>state.city==='all'||d.emirate===state.city);
  const curated=Object.keys(FEATURED_MENUS).map(id=>eligible.find(d=>d.id===id)).filter(Boolean);
  return curated.concat(eligible.filter(d=>!FEATURED_MENUS[d.id])).slice(0,3);
}
function storyContent(deal) {
  if(!deal) {
    const area=state.city==='all'?'الإمارات':displayText(placeLabel(state.city));
    return '<div class="feature-photo">'+photo('feast','',true)+'</div><div class="feature-copy"><p class="feature-origin">'+icon('pin')+area+'</p>'+
      '<h1 id="cover-title">دليل المطاعم<span>في '+area+'</span></h1><button class="feature-action" data-directory-open="all">تصفّح الأماكن '+icon('arrow')+'</button></div>';
  }
  const editorial=FEATURED_MENUS[deal.id]||{title:deal.title,location:deal.branch};
  return '<div class="feature-photo">'+photo(editorial.photo||deal.photo,'',true)+'</div>'+
    '<div class="feature-copy"><p class="feature-origin"><span class="feature-rule"></span>'+displayText(deal.restaurant)+'<i></i>'+displayText(placeLabel(deal.emirate))+'</p>'+
    '<h1 id="cover-title">'+displayText(editorial.title)+'<span>'+displayText(editorial.location)+'</span></h1>'+
    '<div class="feature-meta"><strong>'+displayText(deal.priceLabel)+(editorial.perPerson?' <small>للشخص</small>':'')+'</strong><span>'+displayText(deal.schedule)+'</span></div>'+
    '<button class="feature-action" data-public-deal="'+esc(deal.id)+'">تفاصيل العرض '+icon('arrow')+'</button></div>';
}
function storyCount(count) {return localeMessage('discover.storyPosition',{index:number(storyIndex+1),total:number(count)});}
function changeStory(step) {
  const box=document.getElementById('lead-story'),deals=featuredDeals();
  if(!box||deals.length<2)return;
  storyIndex=(storyIndex+step+deals.length)%deals.length;
  box.innerHTML=storyContent(deals[storyIndex]);
  document.getElementById('story-count').textContent=storyCount(deals.length);
}
function campaignCover() {
  const deals=featuredDeals();
  if(storyIndex>=deals.length)storyIndex=0;
  const controls=deals.length>1?'<div class="feature-controls" role="group" aria-label="تصفّح العروض المختارة">'+
    '<button data-story-step="-1" aria-label="العرض السابق">'+icon('arrow')+'</button><span id="story-count">'+storyCount(deals.length)+'</span>'+
    '<button data-story-step="1" aria-label="العرض التالي">'+icon('arrow')+'</button></div>':'';
  return '<section class="dining-feature" aria-label="اختيارات توفير"><div class="feature-frame" id="lead-story" aria-live="polite">'+
    storyContent(deals[storyIndex])+ '</div>'+controls+'</section>';
}
function cuisineShelf() {
  return '<section class="cuisine-shelf" aria-labelledby="cuisine-title"><div class="shelf-heading"><h2 id="cuisine-title">اختر المطبخ</h2>'+
    '<button class="section-link" data-directory-open="all">كل المطابخ '+icon('arrow')+'</button></div><div class="cuisine-options">'+
    CUISINES.slice(0,10).map(c=>'<button data-cuisine="'+c[0]+'"><span>'+photo(c[2],'cuisine-photo')+'</span><strong>'+c[1]+'</strong></button>').join('')+'</div></section>';
}
function typeShelf() {
  const counts=state.city==='all'?DINING_META.types:DINING_META.cityTypes[state.city];
  return '<div class="venue-types" role="group" aria-label="الدليل حسب نوع المكان">'+Object.entries(VENUE_TYPES).map(([id,t])=>
    '<button class="type-'+id+'" data-directory-open="'+id+'"><span class="venue-icon">'+icon(t.icon)+'</span><span class="venue-label"><strong>'+
    (id==='cafe'?'مقاهي':t.label)+'</strong><small>'+number(counts?.[id]||0)+' في الدليل</small></span><span class="type-arrow">'+icon('arrow')+'</span></button>').join('')+'</div>';
}
function todayInUae() {
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Dubai',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
  const field=key=>parts.find(p=>p.type===key).value;
  return field('year')+'-'+field('month')+'-'+field('day');
}
function activeDeals(day=todayInUae()) {return PUBLIC_DEALS.filter(d=>!d.endDate||d.endDate>=day);}
function dealCard(d) {
  return '<article class="dining-deal"><div class="deal-image"><button data-public-deal="'+d.id+'" aria-label="تفاصيل '+displayText(d.restaurant)+'">'+photo(d.photo)+'</button>'+
    '<b class="price-flag">'+icon('ticket')+displayText(d.priceLabel)+'</b>'+heart('deal:'+d.id,d.restaurant)+'</div>'+
    '<button class="deal-copy" data-public-deal="'+d.id+'"><small>'+displayText(d.restaurant)+'</small><h3>'+displayText(d.title)+'</h3>'+
    '<span class="deal-place">'+icon('pin')+displayText(placeLabel(d.emirate))+' · '+displayText(d.branch)+'</span><span class="deal-hours">'+icon('clock')+displayText(d.schedule)+'</span><span class="open-deal">عرض وطلب '+icon('arrow')+'</span></button></article>';
}
function publicDealDetails(id) {
  const d=activeDeals().find(o=>o.id===id);if(!d){toast('انتهت مدة العرض المنشورة.');return;}
  showRestaurantOrder('offer:'+d.id);
}
function homeDeals() {
  const all=activeDeals().filter(d=>state.city==='all'||d.emirate===state.city);
  const list=all.slice(0,3);
  return '<section class="published-shelf"><div class="shelf-heading"><h2>عروض المطاعم والمقاهي</h2>'+
    '<button class="section-link" data-published-deals>كل العروض '+icon('arrow')+'</button></div>'+
    (list.length?'<div class="market-card-grid home-offers">'+list.map(dealCard).join('')+'</div>':'<div class="no-local-deals"><p>لا توجد عروض منشورة في هذه الإمارة حالياً.</p><button class="section-link" data-deals-all-cities>عروض كل الإمارات '+icon('arrow')+'</button></div>')+'</section>';
}
function offerCard(o) {
  return '<article class="dining-deal"><div class="deal-image"><button data-offer="'+o.id+'" aria-label="تفاصيل '+displayText(o.name)+'">'+photograph(o)+'</button>'+
    '<b class="price-flag">'+number(o.percent)+'% · تجريبي</b>'+heart(o.id,o.name)+'</div>'+
    '<button class="deal-copy" data-offer="'+o.id+'"><small>'+displayText(o.name)+' · '+displayText(placeLabel(o.city))+'</small><h3>'+displayText(o.title)+'</h3>'+
    '<span>توفير تجريبي '+number(Math.round(o.base*o.percent)/100)+' د.إ على فاتورة '+number(o.base)+' د.إ</span></button>'+
    '<button class="demo-menu" data-menu="'+o.id+'">'+icon('food')+' جرّب المنيو والطلب</button></article>';
}
function dealsPage() {
  const list=(showDemoDeals?OFFERS:activeDeals()).filter(o=>state.city==='all'||(o.emirate||o.city)===state.city);
  return '<section class="deals-page"><div class="market-heading"><div><h1>عروض المطاعم والمقاهي</h1><p>'+
    (showDemoDeals?'نماذج لتجربة العضوية والتوفير والطلب.':'اضغط على الإعلان لعرض معلومات الفرع وإضافة العرض إلى السلة.')+'</p></div></div>'+
    '<div class="type-tabs" role="group" aria-label="نوع العرض"><button data-offer-mode="published" aria-pressed="'+!showDemoDeals+'">من المطاعم</button>'+
    '<button data-offer-mode="demo" aria-pressed="'+showDemoDeals+'">تجربة عضوية توفير</button></div>'+
    (list.length?'<div class="market-card-grid">'+list.map(showDemoDeals?offerCard:dealCard).join('')+'</div>':
      '<div class="empty"><h3>لا توجد عروض في هذه الإمارة حالياً</h3><p>يمكنك تصفّح الأماكن المدرجة أو اختيار إمارة أخرى.</p>'+
      '<button class="btn" data-directory-open="all">دليل الأماكن</button><button class="text-button" data-deals-all-cities>عروض كل الإمارات</button></div>')+'</section>';
}
function cityShelf() {
  return '<section class="city-board"><div class="city-heading">'+icon('pin')+'<h2>اكتشف حسب الإمارة</h2></div><div class="city-options">'+
    CITIES.slice(1).map(c=>'<button data-dining-city="'+c+'"><strong>'+displayText(placeLabel(c))+'</strong><span>'+number(DINING_META.cities[c])+' مكان</span>'+icon('arrow')+'</button>').join('')+'</div></section>';
}
function featuredBranches() {
  const list=officialPlaces.filter(p=>state.city==='all'||p.emirate===state.city).slice(0,4);
  return '<section class="official-shelf"><div class="shelf-heading"><h2>فروع من الدليل</h2>'+
    '<button class="section-link" data-official-list>كل الفروع '+icon('arrow')+'</button></div><div class="place-list">'+list.map(placeRow).join('')+'</div></section>';
}
let homeTab = 'ads';
function homeTabs() {
  function tab(id, label, glyph) {
    const selected = homeTab === id;
    return '<button type="button" role="tab" id="home-tab-'+id+'" aria-controls="home-panel-'+id+'" aria-selected="'+selected+'" tabindex="'+(selected?'0':'-1')+'" data-home-tab="'+id+'">'+icon(glyph)+label+'</button>';
  }
  function panel(id, content) {
    return '<div role="tabpanel" id="home-panel-'+id+'" aria-labelledby="home-tab-'+id+'"'+(homeTab===id?'':' hidden')+'>'+content+'</div>';
  }
  return '<div class="home-tabs" role="tablist" aria-label="الرئيسية">'+tab('ads','إعلانات المطاعم','store')+tab('order','اطلب الآن','food')+'</div>'+
    panel('ads','<div id="featured-home-rail" class="home-ads">'+featuredRail()+'</div>')+panel('order',orderHero());
}
function selectHomeTab(button) {
  homeTab = button.dataset.homeTab;
  for (const tab of button.parentElement.querySelectorAll('[data-home-tab]')) {
    const selected = tab === button;
    tab.setAttribute('aria-selected',String(selected));
    tab.tabIndex = selected ? 0 : -1;
    document.getElementById(tab.getAttribute('aria-controls')).hidden = !selected;
  }
  button.focus();
}
document.addEventListener('click',event=>{
  const tab=event.target.closest('[data-home-tab]');
  if (tab) selectHomeTab(tab);
});
document.addEventListener('keydown',event=>{
  const tab=event.target.closest('[data-home-tab]');
  if (!tab || !['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
  const tabs=[...tab.parentElement.querySelectorAll('[data-home-tab]')];
  const target=event.key==='Home'?tabs[0]:event.key==='End'?tabs[tabs.length-1]:tabs.find(button=>button!==tab);
  event.preventDefault();
  selectHomeTab(target);
});
function discover() {
  return '<div class="market-home"><div class="home-spotlight">'+homeTabs()+'</div><div class="featured-home-body"><button class="sub-home-link" data-go="subscriptions">'+icon('ticket')+' باقات الاشتراك '+icon('arrow')+'</button>'+marketingHomeLink()+'</div>'+orderHighlights()+homeDeals()+cuisineShelf()+typeShelf()+featuredBranches()+cityShelf()+
    '<div class="market-links"><button data-go="favorites">'+icon('heart')+' المفضلة</button><button data-go="orders">'+icon('bag')+' طلباتي</button>'+
    '<button data-go="membership">'+icon('card')+' عضوية توفير</button><button data-go="partner">'+icon('store')+' انضم بمطعمك أو مقهاك</button><button data-go="marketing">'+icon('store')+' التسويق والشراكات</button></div>'+attribution()+'</div>';
}
function favorites() {
  return '<section class="dining-favorites"><div class="market-heading"><div><h1>المفضلة</h1><p>مطاعمك ومقاهيك وعروضك المحفوظة</p></div></div><div id="favorites-content"></div></section>';
}
function updateDiningFavorites() {
  const el=document.getElementById('favorites-content');if(!el)return;
  const keys=state.favorites,city=state.city;
  const ps=keys.map(getPlace).filter(p=>p&&(city==='all'||p.emirate===city));
  const deals=activeDeals().filter(d=>keys.includes('deal:'+d.id)&&(city==='all'||d.emirate===city));
  const demos=OFFERS.filter(o=>keys.includes(o.id)&&(city==='all'||o.city===city));
  const waiting=keys.some(k=>k.startsWith('osm:'))&&mapStatus!=='ready';
  const pending=waiting?mapStatus==='error'?'<p>تعذّر تحميل الأماكن المحفوظة من الخريطة. <button class="text-button" data-directory-retry>أعد المحاولة</button></p>':'<p role="status">يجري تحميل الأماكن المحفوظة…</p>':'';
  el.innerHTML=(deals.length?'<h2>عروض المطاعم</h2><div class="market-card-grid">'+deals.map(dealCard).join('')+'</div>':'')+
    (ps.length?'<h2>الأماكن المحفوظة</h2><div class="place-list">'+ps.map(placeRow).join('')+'</div>':'')+
    (demos.length?'<h2>نماذج العضوية</h2><div class="market-card-grid">'+demos.map(offerCard).join('')+'</div>':'')+pending;
  if(!el.innerHTML)el.innerHTML='<div class="empty">'+icon('heart')+'<h3>المفضلة فارغة</h3><p>اضغط على القلب في بطاقة المكان أو العرض ليظهر هنا.</p><button class="btn" data-directory-open="all">تصفّح الدليل</button></div>';
}
function refreshDiningPage() {
  if(current==='directory'){
    updateDirectory();
    if(mapStatus==='idle'&&directory.source==='map')loadMapPlaces();
  }else if(current==='dashboard'&&isLiveOperator()&&ownerCustomerId&&mapStatus==='idle'&&liveWorkspace.favorites.some(f=>f.user_id===ownerCustomerId&&f.offer_key.startsWith('osm:'))){
    loadMapPlaces();
  }else if(current==='favorites'){
    updateDiningFavorites();
    if(mapStatus==='idle'&&state.favorites.some(k=>k.startsWith('osm:')))loadMapPlaces();
  }
}
function diningFavoriteChanged() {
  if(current==='favorites')updateDiningFavorites();
  else updateHearts();
}
function showSources() {
  const credits=DINING_IMAGES.map(i=>linkOut(i.url,i.photographer)).join('');
  showModal('<div class="modal-body"><h2 id="modal-title">مصادر الدليل والصور</h2><p class="description">دليل الخريطة يضم أماكن مسمّاة في بيانات OpenStreetMap بتاريخ '+
    displayText(DINING_META.asOf)+'. التغطية مجتمعية وقد تتغيّر الفروع أو تغيب بعض المطاعم. يُعرض نوع المطبخ عندما تذكره البيانات.</p>'+attribution()+
    '<p class="description">الفروع المختارة وعروض المطاعم مرتبطة بمصادرها الرسمية داخل البطاقة. الإدراج في الدليل لا يعني وجود خصم أو شراكة مع توفير.</p>'+
    '<details class="faq"><summary>مصوّرو صور المطابخ والأطباق</summary><div class="source-list">'+credits+'</div></details>'+
    '<details class="faq"><summary>صور نماذج عضوية توفير</summary><div class="source-list">'+OFFERS.map(o=>linkOut(o.source,o.name)).join('')+'</div></details></div>');
}
document.addEventListener('click',event=>{
  const b=event.target.closest('button');if(!b)return;
  if(b.dataset.storyStep){changeStory(Number(b.dataset.storyStep));return;}
  if(b.dataset.directoryOpen){openDirectory({type:b.dataset.directoryOpen});return;}
  if(b.dataset.cuisine){openDirectory({cuisine:b.dataset.cuisine});return;}
  if(b.dataset.diningCity){openDirectory({city:b.dataset.diningCity});return;}
  if(b.hasAttribute('data-official-list')){openDirectory({source:'official'});return;}
  if(b.hasAttribute('data-directory-reset')){openDirectory({city:'all',source:directory.source});return;}
  if(b.hasAttribute('data-directory-retry')){loadMapPlaces();return;}
  if(b.hasAttribute('data-more-places')){directory.limit+=24;updateDirectory();return;}
  if(b.dataset.listType){directory.type=b.dataset.listType;directory.limit=24;updateDirectory();return;}
  if(b.dataset.listSource){directory.source=b.dataset.listSource;directory.limit=24;updateDirectory();if(directory.source==='map'&&mapStatus==='idle')loadMapPlaces();return;}
  if(b.dataset.place){placeDetails(b.dataset.place);return;}
  if(b.dataset.publicDeal){publicDealDetails(b.dataset.publicDeal);return;}
  if(b.dataset.offerMode){showDemoDeals=b.dataset.offerMode==='demo';render('deals');return;}
  if(b.hasAttribute('data-deals-all-cities')){state.city='all';persist();showDemoDeals=false;navigate('deals');return;}
  if(b.hasAttribute('data-published-deals')){showDemoDeals=false;navigate('deals');}
});
let storyTouch=null;
document.addEventListener('touchstart',event=>{
  const t=event.touches[0];storyTouch=event.touches.length===1&&event.target.closest('#lead-story')&&!event.target.closest('button')?{x:t.clientX,y:t.clientY}:null;
},{passive:true});
document.addEventListener('touchend',event=>{
  if(!storyTouch)return;
  const t=event.changedTouches[0],dx=t.clientX-storyTouch.x,dy=t.clientY-storyTouch.y;storyTouch=null;
  if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.4)changeStory(dx>0?1:-1);
},{passive:true});
document.addEventListener('touchcancel',()=>{storyTouch=null;},{passive:true});

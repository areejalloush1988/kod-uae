# UAE dining directory

`uae-dining.json` is a derived open database. It contains 8,611 named dining locations in the seven UAE emirates from the OpenStreetMap snapshot of 17 November 2026 at 00:10:36 UTC. A listing identifies a community-mapped place. It carries no offer, partnership, current opening-hours guarantee or ordering capability.

**© OpenStreetMap contributors.** [Attribution and copyright](https://www.openstreetmap.org/copyright). The directory is available under the [Open Database License 1.0](https://opendatacommons.org/licenses/odbl/1-0/), also supplied as `../DATA-LICENSE.txt`. The derivative is the standalone downloadable JSON. Separately maintained merchant/offer records are outside this database.

## Records

Read the field order from the JSON's `fields` array. Each row holds an OSM object reference (`n` for node, `w` for way, `r` for relation), display name, optional Arabic and English variants, venue type, emirate in Arabic, source cuisine tags separated by semicolons, latitude, longitude and an optional mapped suburb, district, street or city. Treat names/addresses as plain untrusted text. OSM IDs open on www.openstreetmap.org at /node/NUMBER, /way/NUMBER or /relation/NUMBER. Coordinates represent a node or an on-surface point of an area.

Every record has exactly one assigned emirate and a non-generic local, translated or brand name. The pipeline spatially tests the location against the seven OSM emirate polygons, including their enclaves. It omits ambiguous border points. It includes mapped restaurants, fast-food restaurants, cafés and cafeterias. A dedicated cafeteria tag or an explicit English/Arabic cafeteria name identifies the cafeteria category. Private or inactive entries marked as such are skipped. Near-coincident markers with a matching name are deduplicated conservatively, while distinct named branches are retained. A venue with no source cuisine has an empty cuisine field. Names and location coverage depend on local mapping.

## Rebuild

The builder uses Python 3 and GDAL 3.10+ with its Python bindings, OSM driver and GEOS support. Download the UAE extract, the atomic sequence timestamp, its checksum and the full Abu Dhabi relation from the same data source. The country extract can clip that relation at the international perimeter. Relation 3766481 was version 62, last edited 28 September 2026 at the time of this build. The other six emirate boundaries come directly from the same country PBF.

```sh
curl --fail --location --output united_arab_emirates.osm.pbf https://download.openstreetmap.fr/extracts/asia/united_arab_emirates-latest.osm.pbf
curl --fail --location --output united_arab_emirates.osm.pbf.md5 https://download.openstreetmap.fr/extracts/asia/united_arab_emirates.osm.pbf.md5
curl --fail --location --output united_arab_emirates.state.txt https://download.openstreetmap.fr/extracts/asia/united_arab_emirates.state.txt
md5sum --check united_arab_emirates.osm.pbf.md5
curl --fail --location --output abu-dhabi.osm https://api.openstreetmap.org/api/0.6/relation/3766481/full
python3 build_directory.py united_arab_emirates.osm.pbf abu-dhabi.osm --out ../uae-dining.json --as-of "$(sed -n 's/^timestamp=\([0-9-]*\)T.*/\1/p' united_arab_emirates.state.txt)"
```

The 17 November 2026 source PBF has SHA-256 `a8fed95fd066d5cd31221dc8813321c0225a267bbbdaab8f3d34c5bc0be9b7ba`. The provider's rolling URLs and the canonical boundary can change after publication.

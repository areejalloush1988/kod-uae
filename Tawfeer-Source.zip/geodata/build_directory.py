"""Extract named UAE restaurants, cafés and cafeterias from public OpenStreetMap inputs."""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import re
import unicodedata

from osgeo import gdal, ogr

gdal.UseExceptions()
ROOT = Path(__file__).resolve().parent
SOURCE = "https://download.openstreetmap.fr/extracts/asia/united_arab_emirates-latest.osm.pbf"
OSM_CREDIT = "© OpenStreetMap contributors"
LICENSE = "https://opendatacommons.org/licenses/odbl/1-0/"
EMIRATES = {
    "AE-AZ": "أبوظبي", "AE-DU": "دبي", "AE-SH": "الشارقة", "AE-AJ": "عجمان",
    "AE-UQ": "أم القيوين", "AE-RK": "رأس الخيمة", "AE-FU": "الفجيرة",
}
FIELDS = ["id", "name", "nameAr", "nameEn", "type", "emirate", "cuisine", "lat", "lon", "area"]
AMENITIES = "amenity IN ('restaurant','fast_food','cafe','cafeteria')"
GENERIC_NAMES = {
    "restaurant", "restaurants", "fastfood", "fastfoodrestaurant", "cafeteria", "cafetaria",
    "cafe", "café", "coffee", "coffeeshop", "coffeeshops", "cafeandrestaurant", "food",
    "مطعم", "مطاعم", "مقهى", "مقهي", "كافيه", "كافتيريا", "كافتريا", "كافيتريا", "كافيتيريا",
    "تجربة", "test", "unknown", "unnamed", "noname",
    "foodcourt", "foodhall", "canteen", "buffet", "staffcafeteria", "staffcanteen",
    "thecafe", "المقهى", "المطعم", "indianrestaurant", "chineserestaurant",
    "مطعم هندي", "مطعم صيني", "مطعم عربي", "shawarma", "شاورما",
}
CAFETERIA = re.compile(r"caf[ée]t[aei]r[ií]?a|cafeter[iy]|cafetari|cafet[eé]r[ií]|ك[اأ]ف[ي]?ت[ي]?ر[ي]?[ايه]", re.I)


def text(value):
    if not value:
        return ""
    return " ".join("".join(c for c in str(value) if not unicodedata.category(c).startswith("C")).split()).strip()


def name_key(name):
    return "".join(c for c in unicodedata.normalize("NFKD", name).casefold() if c.isalnum())


BLOCKED_NAMES = {name_key(s) for s in GENERIC_NAMES}


def open_osm(path):
    return gdal.OpenEx(str(path), gdal.OF_VECTOR, allowed_drivers=["OSM"],
                       open_options=["CONFIG_FILE=" + str(ROOT / "osm-dining.ini")])


def boundaries(pbf, abu_dhabi):
    geometry = {}
    relation_ids = {}
    for path in [pbf, abu_dhabi]:
        ds = open_osm(path)
        ds.ExecuteSQL("SET interest_layers = multipolygons")
        layer = ds.GetLayerByName("multipolygons")
        layer.SetAttributeFilter("boundary = 'administrative' AND admin_level = '4'")
        for feat in layer:
            code = feat.GetField("ISO3166-2")
            if code not in EMIRATES or code in geometry:
                continue
            shape = feat.GetGeometryRef().Clone()
            if not shape.IsValid():
                shape = shape.MakeValid()
            geometry[code] = shape
            relation_ids[code] = feat.GetField("osm_id")
        if len(geometry) == len(EMIRATES):
            break
    missing = set(EMIRATES) - set(geometry)
    if missing:
        raise ValueError("Missing geographic emirate boundaries: " + ", ".join(sorted(missing)))
    return geometry, {k: v.CreatePreparedGeometry() for k, v in geometry.items()}, relation_ids


def cuisine_tags(value):
    tags = [t.strip().lower().replace(" ", "_") for t in re.split(r"[;,]", value or "")]
    return ";".join(dict.fromkeys(t for t in tags if t and t not in {"n/a", "none", "yes", "no", "unknown"}))


def dedicated(row, nearby):
    """Keep real branches; merge area/point representations or virtually coincident same-name markers."""
    def level_matches(other):
        return not row["level"] or not other["level"] or row["level"] == other["level"]

    lat = row["lat"]
    lon = row["lon"]
    for other in nearby:
        same_name = bool(row["keys"] & other["keys"])
        if not same_name or not level_matches(other) or row["emirate"] != other["emirate"]:
            continue
        different_geometry = (row["id"][0] == "n") != (other["id"][0] == "n")
        distance = math.hypot((lat - other["lat"]) * 111320,
                              (lon - other["lon"]) * 111320 * math.cos(math.radians(lat)))
        if distance <= (22 if different_geometry else 4):
            return False
    return True


def build(pbf, abu_dhabi):
    shapes, prepared, relation_ids = boundaries(pbf, abu_dhabi)
    envelopes = {code: shape.GetEnvelope() for code, shape in shapes.items()}
    rows = []
    stats = collections.Counter()
    ds = open_osm(pbf)
    for layername in ("points", "multipolygons"):
        if layername != "points":
            ds = open_osm(pbf)  # each OSM read is sequential
        ds.ExecuteSQL("SET interest_layers = " + layername)
        layer = ds.GetLayerByName(layername)
        layer.SetAttributeFilter(AMENITIES)
        for feat in layer:
            stats["mapped_dining_features"] += 1
            names = [text(feat.GetField(field)) for field in ("name", "name_ar", "name_en", "brand")]
            if not any(name_key(n) and name_key(n) not in BLOCKED_NAMES for n in names):
                stats["unnamed_or_generic"] += 1
                continue
            if str(feat.GetField("access") or "").lower() in {"no", "private", "employees"} or any(
                    str(feat.GetField(f) or "").lower() == "yes" for f in ("disused", "abandoned", "construction")):
                stats["private_or_inactive"] += 1
                continue
            geom = feat.GetGeometryRef()
            point = geom if layername == "points" else geom.PointOnSurface()
            if not point or point.IsEmpty():
                stats["no_position"] += 1
                continue
            lon, lat = point.GetX(), point.GetY()
            codes = [code for code, (west, east, south, north) in envelopes.items()
                     if west <= lon <= east and south <= lat <= north and prepared[code].Intersects(point)]
            if len(codes) != 1:
                stats["outside_or_ambiguous_emirate"] += 1
                continue
            name, ar, en, brand = names
            name = next(n for n in names if name_key(n) and name_key(n) not in BLOCKED_NAMES)
            kind = feat.GetField("amenity")
            if kind == "cafeteria" or CAFETERIA.search(" ".join(names)):
                kind = "cafeteria"
            elif kind == "fast_food":
                kind = "restaurant"
            osm_id = feat.GetField("osm_id")
            if layername == "points":
                ident = "n" + osm_id
            else:
                ident = "r" + osm_id if osm_id else "w" + feat.GetField("osm_way_id")
            area = next((v for f in ("addr_suburb", "addr_district", "addr_street", "addr_city")
                         if (v := text(feat.GetField(f)))), "")
            rows.append(dict(id=ident, name=name, nameAr=ar, nameEn=en, type=kind, emirate=EMIRATES[codes[0]],
                             cuisine=cuisine_tags(feat.GetField("cuisine")), lat=round(lat, 6), lon=round(lon, 6), area=area,
                             keys={k for n in (name, ar, en) if (k := name_key(n)) and k not in BLOCKED_NAMES},
                             level=text(feat.GetField("level"))))
    # Place the most informative record first when two representations of the same place exist.
    rows.sort(key=lambda r: (-sum(bool(r[k]) for k in ("area", "nameAr", "nameEn", "cuisine")), r["id"]))
    grids = collections.defaultdict(list)
    output = []
    for row in rows:
        ix, iy = int(row["lat"] * 1000), int(row["lon"] * 1000)
        adjacent = (other for x in range(ix-1,ix+2) for y in range(iy-1,iy+2) for other in grids[x,y])
        if not dedicated(row, adjacent):
            stats["same_site_duplicate"] += 1
            continue
        grids[ix, iy].append(row)
        output.append([row[k] for k in FIELDS])
    output.sort(key=lambda r: (r[5],r[1].casefold(),r[0]))
    return output, stats, relation_ids


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pbf", type=Path)
    parser.add_argument("abu_dhabi_boundary", type=Path,
                        help="Complete OSM relation 3766481 in .osm XML, for country extracts that clip its geometry.")
    parser.add_argument("--as-of", required=True, help="UTC snapshot day from the OSM extract's .state.txt")
    parser.add_argument("--out", type=Path, default=ROOT / "uae-dining.json")
    args = parser.parse_args()
    rows, stats, relation_ids = build(args.pbf, args.abu_dhabi_boundary)
    output = dict(schema=1, asOf=args.as_of, source=SOURCE, credit=OSM_CREDIT,
                  copyright="https://www.openstreetmap.org/copyright", license=LICENSE,
                  fields=FIELDS, rows=rows)
    args.out.write_text(json.dumps(output, ensure_ascii=False, separators=(",", ":"))+"\n",encoding="utf-8")
    print("Rows:",len(rows),"bytes:",args.out.stat().st_size)
    print("Types:",dict(collections.Counter(r[4] for r in rows)))
    print("Emirates:",dict(collections.Counter(r[5] for r in rows)))
    print("Tagged cuisine:",sum(bool(r[6]) for r in rows))
    print("Filtering:",dict(stats))
    print("Boundary relations:",relation_ids)
    print("Input SHA256:",hashlib.sha256(args.pbf.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()

/* Only the public Tawfeer web application is served. This script requests no account data. */
var TAWFEER_SITE = 'https://sites.google.com/view/tawfeer-uae/app';

function doGet(event) {
  var direct = ScriptApp.getService().getUrl();
  var setup = JSON.stringify({direct: direct, site: TAWFEER_SITE, query: (event && event.parameter) || {}});
  var safeSetup = setup.replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');
  var page = tawfeerHostHtml_().replace('__TAWFEER_SETTINGS__', function () { return safeSetup; })
       .replace('__TAWFEER_PACKED_DATA__', function () { return tawfeerPackage_(); });
  return HtmlService.createHtmlOutput(page).setTitle('توفير')
    .addMetaTag('viewport','width=device-width, initial-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getPublicDocument() {
  return Utilities.ungzip(Utilities.newBlob(Utilities.base64Decode(tawfeerPackage_()),'application/gzip')).getDataAsString('UTF-8');
}

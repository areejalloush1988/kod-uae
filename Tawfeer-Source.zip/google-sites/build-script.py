"""Build the Google Sites embed and the versioned Apps Script deployment."""
import argparse
import base64
import gzip
from html import escape
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent


def host_template():
    vendor = ROOT.parent / 'assets' / 'vendor'
    license_text = (vendor / 'fflate-LICENSE.txt').read_text().strip()
    fallback = (vendor / 'fflate-0.8.2.js').read_text()
    fallback = re.sub(r'(?i)</script', lambda _: r'<\/script', fallback)
    return (ROOT / 'host.html').read_text().replace(
        '__TAWFEER_GZIP_FALLBACK__', f'/* {license_text} */\n{fallback}'
    )


def build(public_html, output, embed_output=None, direct_url=None):
    payload = base64.b64encode(
        gzip.compress(public_html.read_bytes(), compresslevel=9, mtime=0)
    ).decode('ascii')
    template = host_template()
    base = (ROOT / 'Code.gs').read_text()
    parts = [json.dumps(payload[i:i+4096]) for i in range(0, len(payload), 4096)]
    shell = json.dumps(template, ensure_ascii=False)
    output.write_text(
        base + '\nfunction tawfeerHostHtml_(){return ' + shell + ';}\n'
        + 'function tawfeerPackage_(){return [\n' + ',\n'.join(parts) + '\n].join("");}\n'
    )
    if embed_output:
        location = urlsplit(direct_url)
        if location.scheme != 'https' or location.hostname != 'script.google.com':
            raise ValueError('Use the HTTPS Apps Script deployment URL for the embed')
        site = re.search(r"var TAWFEER_SITE = '([^']+)';", base)[1]
        settings = json.dumps({'direct': direct_url, 'site': site, 'query': {}})
        embed_output.write_text(template.replace('__TAWFEER_SETTINGS__', settings)
                                .replace('__TAWFEER_FALLBACK_URL__', escape(direct_url, quote=True))
                                .replace('__TAWFEER_PACKED_DATA__', payload))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('public_html', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--embed-output', type=Path)
    parser.add_argument('--direct-url')
    args = parser.parse_args()
    if args.embed_output and not args.direct_url:
        parser.error('--embed-output requires --direct-url')
    build(args.public_html, args.output, args.embed_output, args.direct_url)

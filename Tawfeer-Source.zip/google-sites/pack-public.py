"""Bundle the published public Tawfeer client into one document for its Google host."""
import argparse
import base64
import json
import re
from pathlib import Path

SCRIPT = re.compile(r"(<script\b[^>]*>)(.*?)(</script>)", re.I | re.S)
STYLE = re.compile(r"<style\b[^>]*>.*?</style>", re.I | re.S)
SINGLE_SCRIPT = r"<script\b[^>]*>.*?</script>"


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError("Expected exactly one occurrence of " + old[:105])
    return source.replace(old, new, 1)


def inline_json(value):
    return (json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            .replace("<", r"\u003c").replace(">", r"\u003e")
            .replace("\u2028", r"\u2028").replace("\u2029", r"\u2029"))


def image_url(root, name):
    return "data:image/png;base64," + base64.b64encode((root/name).read_bytes()).decode()


def adapt_routing(source):
    # Only first-party scripts are passed here. A locally scoped variable named
    # location in the order view is ordinary customer text and never has a URL property.
    source = re.sub(r"(?<![\w.])(?:window\.)?location\.(?=href\b|hash\b|search\b|pathname\b|protocol\b|origin\b|assign\b|replace\b)",
                    "window.TawfeerGoogle.location.", source)
    return re.sub(r"(?<![\w.])(?:window\.)?history\.replaceState\b",
                  "window.TawfeerGoogle.history.replaceState", source)


def app_script(source):
    config_match = re.search(r"const KOD_CONFIG=(\{[^\n]+?\});", source)
    if not config_match:
        raise ValueError("Cannot locate the published app configuration")
    config = json.loads(config_match[1])
    for prop in ("publicAppUrl", "publicSiteUrl", "oauthReturnUrl"):
        config.pop(prop, None)
    new_config = ("const KOD_CONFIG=Object.assign(" + inline_json(config) +
                  ",{publicAppUrl:window.TawfeerGoogle.directUrl,"
                  "publicSiteUrl:window.TawfeerGoogle.siteUrl,"
                  "oauthReturnUrl:window.TawfeerGoogle.directUrl});")
    source = source[:config_match.start()] + new_config + source[config_match.end():]
    source, changed = re.subn(r"const response=await fetch\('\./uae-dining\.json\?v='.*?const rows=indexMapData\(await response\.json\(\)\);",
                              "const rows=indexMapData(JSON.parse(document.getElementById('tawfeer-directory-data').textContent));",
                              source, flags=re.S)
    if changed != 1:
        raise ValueError("Cannot identify the public directory loader")
    source = replace_once(source, r'href=\"./uae-dining.json\" download',
                          r'href=\""+window.TawfeerGoogleAssets.directory()+"\" download=\"uae-dining.json\"')
    source = replace_once(source, r'href=\"./DATA-LICENSE.txt\" target=\"_blank\"',
                          r'href=\""+window.TawfeerGoogleAssets.license()+"\" download=\"DATA-LICENSE.txt\"')
    source = replace_once(source, """'<a href="./city-'+slug+'.html">'""",
                          """'<a href="'+esc(window.TawfeerGoogleAssets.guide(slug))+'">'""")
    # The provider SDK sees the srcdoc frame's browser URL. Complete only
    # the provider callbacks explicitly supplied by the public Google endpoint.
    source=replace_once(source, "  const sessionCallback=params.has('access_token'),isRecovery=params.get('type')==='recovery';", """  const callbackSearch=new URLSearchParams(window.TawfeerGoogle.location.search);
  const authorizationCode=callbackSearch.get('code');
  const sessionCallback=params.has('access_token')||Boolean(authorizationCode),isRecovery=params.get('type')==='recovery';""")
    source=replace_once(source,"    const c=await getKodClient();\n    if(custom){","""    const c=await getKodClient();
    if(sessionCallback){
      callbackSearch.delete('code');
      const clean=callbackSearch.toString();
      window.TawfeerGoogle.history.replaceState(null,'',window.TawfeerGoogle.location.pathname+(clean?'?'+clean:'')+'#auth');
      const result=authorizationCode ? await c.auth.exchangeCodeForSession(authorizationCode) :
        await c.auth.setSession({access_token:params.get('access_token'),refresh_token:params.get('refresh_token')});
      if(result.error||!result.data?.session)throw result.error||Error('otp_expired');
      if(isRecovery||result.data.redirectType==='PASSWORD_RECOVERY'){
        switchScope(result.data.user.id,sessionId(result.data.session));recoveryUser=result.data.user.id;
      }
    }
    if(custom){""")
    return adapt_routing(source)


def installer(root, logo):
    source = (root/"tawfeer-install.js").read_text()
    start = source.index("    const body = external")
    stop = source.index("    showModal(", start)
    source = source[:start]+"""    const body='<h3>'+heading+'</h3><ol>'+steps.map(step=>'<li>'+step+'</li>').join('')+
      '</ol><a class="btn" target="_blank" rel="noopener" href="'+window.TawfeerGoogle.siteUrl+'">'+localeCopy("فتح رابط توفير")+'</a>';
"""+source[stop:]
    # The Google page is the bookmark target. Installing its ancestor's worker
    # from inside an embedded document is neither supported nor necessary.
    registration = re.compile(r"  if \(!external && 'serviceWorker' in navigator\) \{.*?\n  \}\n", re.S)
    source, count = registration.subn("", source)
    if count != 1:
        raise ValueError("Cannot identify the standalone service-worker setup")
    return adapt_routing(source).replace('./tawfeer-logo.png',logo)


def guides(root, logo):
    templates, styles = {}, []
    for path in sorted(root.glob("city-*.html")):
        text=path.read_text()
        css=STYLE.findall(text)
        if not styles:
            styles=css
        elif styles != css:
            raise ValueError(f"Unexpected variation in guide styling at {path.name}")
        body = re.search(r"(<body\b[^>]*>)(.*?)(</body>)",text,re.I | re.S)
        title = re.search(r"<title>(.*?)</title>",text,re.I | re.S)
        if not body or not title:
            raise ValueError(f"Missing content in {path.name}")
        markup = re.sub(SINGLE_SCRIPT,"",body[2],flags=re.I|re.S)
        templates[path.stem.removeprefix('city-')] = [title[1],markup.replace('./tawfeer-logo.png',logo)]
    if len(templates)!=7:
        raise ValueError("Expected the seven city guides in the public release")
    return {"styles":"".join(styles),"pages":templates}


BOOT = r"""<script>
window.TawfeerGoogle = window.TawfeerGoogle || parent.TawfeerGoogle;
(() => {
  const host=window.TawfeerGoogle;
  const address=(params={})=>{
    const url=new URL(host.directUrl);
    const language=window.TawfeerLanguage?.code;
    if(language && language!=='ar')url.searchParams.set('lang',language);
    for(const [key,value] of Object.entries(params))url.searchParams.set(key,value);
    return url;
  };
  let directoryUrl,licenseUrl;
  window.TawfeerGoogleAssets={
    guide:slug=>address({guide:slug}).href,
    directory:()=>directoryUrl ||= URL.createObjectURL(new Blob([document.getElementById('tawfeer-directory-data').textContent],{type:'application/json'})),
    license:()=>licenseUrl ||= URL.createObjectURL(new Blob([JSON.parse(document.getElementById('tawfeer-license-data').textContent)],{type:'text/plain;charset=utf-8'}))
  };
  document.addEventListener('click',e=>{
    const anchor=e.target.closest?.('a[href]');
    if(!anchor || anchor.target==='_blank' || e.defaultPrevented || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey)return;
    const target=new URL(anchor.href);
    const direct=new URL(host.directUrl);
    if(target.origin===direct.origin && target.pathname===direct.pathname){
      e.preventDefault(); host.location.assign(target.href);
    }
  });
})();
</script>"""

GUIDE_JS = r"""
(() => {
  const host=window.TawfeerGoogle, current=new URL(host.location.href), slug=current.searchParams.get('guide');
  if(!slug)return;
  const {styles,pages}=JSON.parse(document.getElementById('tawfeer-guide-data').textContent);
  if(!Object.hasOwn(pages,slug))return;
  const child=document.createElement('iframe');
  child.title=window.TawfeerLanguage.text(pages[slug][0]);
  child.style.cssText='position:fixed;inset:0;width:100%;height:100%;border:0;z-index:2147483647;background:white';
  child.addEventListener('load',()=>{
    const doc=child.contentDocument;
    const code=window.TawfeerLanguage.code;
    doc.documentElement.lang=code;doc.documentElement.dir=code==='en'?'ltr':'rtl';
    doc.title=child.title;
    for(const anchor of doc.querySelectorAll('a[href^="."]')){
      const raw=anchor.getAttribute('href');
      const url=new URL(host.directUrl);
      const guide=raw.match(/^\.\/city-([a-z-]+)\.html$/);
      if(guide)url.searchParams.set('guide',guide[1]);
      else if(raw!=='./'){
        const source=new URL(raw,'https://app.invalid/');
        url.search=source.search;url.hash=source.hash;
      }
      if(code!=='ar')url.searchParams.set('lang',code);
      anchor.href=url.href;anchor.addEventListener('click',e=>{if(e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault();host.location.assign(url.href);});
    }
    for(const external of doc.querySelectorAll('a[href]')){
      if(!external.href.startsWith(host.directUrl)){external.target='_blank';external.rel='noopener noreferrer';}
    }
    window.TawfeerLanguage.applyStatic(doc);
    doc.addEventListener('change',e=>{
      if(!e.target.matches('[data-language-picker]'))return;
      const next=e.target.value;
      if(!['ar','en','ur','fa'].includes(next))return;
      try{localStorage.setItem('tawfeer-language-v1',next)}catch{}
      current.searchParams.set('lang',next);host.location.assign(current.href);
    });
  },{once:true});
  child.srcdoc='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+styles+'</head><body>'+pages[slug][1]+'</body></html>';
  document.body.append(child);document.documentElement.style.overflow='hidden';
})();
"""


def build(root):
    page=(root/'index.html').read_text()
    logo=image_url(root,'tawfeer-logo.png')
    page=re.sub(r'<link\b[^>]*\brel="manifest"[^>]*>','',page,count=1,flags=re.I)
    page,n=re.subn(r'(<meta\b[^>]*property="og:image"[^>]*content=")[^"]+(")',lambda m:m[1]+image_url(root,'tawfeer-icon-512.png')+m[2],page,count=1)
    if n!=1:raise ValueError("Missing site image")
    for filename in ('tawfeer-logo.png','tawfeer-apple.png','tawfeer-icon-192.png'):
        page=page.replace('./'+filename,image_url(root,filename))
    def script(match):
        tag,body,end=match.groups()
        if 'id="tawfeer-public-address"' in tag:
            # The previous publisher needs this redirect. An embedded Google
            # document already runs at the official entry and has its own host.
            return ''
        if 'id="tawfeer-language"' in tag:
            body=adapt_routing(body)
        elif 'src="./tawfeer-install.js"' in tag:
            # The web install tag was deferred. Append its contents after the
            # main script so its DOM queries and translated helpers are ready.
            return ''
        elif tag=='<script>' and 'const KOD_CONFIG=' in body:body=app_script(body)
        return tag+body+end
    page=SCRIPT.sub(script,page)
    page=replace_once(page,'<head>','<head>'+BOOT)
    assets={'tawfeer-directory-data':json.loads((root/'uae-dining.json').read_text()),
            'tawfeer-license-data':(root/'DATA-LICENSE.txt').read_text(),'tawfeer-guide-data':guides(root,logo)}
    embedded=''.join('<script type="application/json" id="'+name+'">'+inline_json(v)+'</script>' for name,v in assets.items())
    page=replace_once(page,'</head>',embedded+'</head>')
    page=replace_once(page,'</body>','<script id="tawfeer-google-install">'+installer(root,logo)+'</script><script id="tawfeer-google-guide">'+GUIDE_JS+'</script></body>')
    if re.search(r'https?://[^/\s"<>]+\.github\.io/|\bdeveloperEmail\b',page,re.I):
        raise ValueError('A previous publishing URL or operator contact remains in the bundle')
    return page


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path,help='compiled Tawfeer project')
    parser.add_argument('output',type=Path,help='path to the public HTML')
    args=parser.parse_args()
    args.output.write_text(build(args.root))

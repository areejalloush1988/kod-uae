// Read only the app's own copy catalog. Customer names, notes and orders never enter a translation service.
(() => {
  'use strict';
  const data = JSON.parse(document.getElementById('tawfeer-language-data').textContent);
  const supported = ['ar','en','ur','fa'];
  const address = new URL(location.href);
  const requested = address.searchParams.get('lang');
  let remembered;
  try { remembered = localStorage.getItem('tawfeer-language-v1'); } catch {}
  const valid = value => supported.includes(value);
  const code = valid(requested) ? requested : valid(remembered) ? remembered : 'ar';
  function remember(value) {
    try { localStorage.setItem('tawfeer-language-v1',value); } catch {}
  }
  if (valid(requested)) remember(code);
  document.documentElement.lang = code;
  document.documentElement.dir = code === 'en' ? 'ltr' : 'rtl';
  const table = data[code] || {};
  const text = source => typeof source === 'string' && Object.hasOwn(table,source) ? table[source] : source;
  function localText(value) {
    const source = value.trim();
    return source && text(source) !== source ? value.replace(source, () => text(source)) : value;
  }
  function withLanguage(link) {
    const url = new URL(link,location.href);
    if (url.origin === location.origin && (code !== 'ar' || valid(requested))) url.searchParams.set('lang',code);
    return url.href;
  }
  function applyStatic(root) {
    const nodes = root.createTreeWalker(root.documentElement,NodeFilter.SHOW_TEXT);
    for (let n=nodes.nextNode(); n; n=nodes.nextNode()) {
      if (!n.parentElement || n.parentElement.closest('script,style,svg,textarea,[data-language-picker]')) continue;
      const contextual = n.parentElement.getAttribute('data-copy-source');
      const value = contextual && code!=='ar' ? n.nodeValue.replace(n.nodeValue.trim(),()=>text(contextual)) : localText(n.nodeValue);
      if (value !== n.nodeValue) n.nodeValue = value;
    }
    for (const el of root.querySelectorAll('[aria-label],[alt],[title],[placeholder],meta[content]')) {
      for (const attr of ['aria-label','alt','title','placeholder','content']) {
        if (el.hasAttribute(attr)) {
          const source = el.getAttribute(attr), value = localText(source);
          if (value !== source) el.setAttribute(attr,value);
        }
      }
    }
    for (const picker of root.querySelectorAll('[data-language-picker]')) picker.value = code;
    if (root.body.hasAttribute('data-language-links')) {
      for (const link of root.querySelectorAll('a[href]')) {
        if (!link.getAttribute('href').startsWith('.')) continue;
        link.href = withLanguage(link.href);
      }
    }
    const manifest = root.querySelector('link[rel="manifest"]');
    if (manifest && code !== 'ar') manifest.href = './manifest-' + code + '.webmanifest';
    const meta = root.querySelector('meta[property="og:locale"]');
    if (meta) meta.content = {ar:'ar_AE',en:'en_AE',ur:'ur_PK',fa:'fa_IR'}[code];
    const schema = root.querySelector('script[type="application/ld+json"]');
    if (schema) {
      const item = JSON.parse(schema.textContent);
      item.inLanguage = code;
      for (const prop of ['name','description']) if (item[prop]) item[prop] = text(item[prop]);
      if (item.spatialCoverage) item.spatialCoverage.name = text(item.spatialCoverage.name);
      if (item.isPartOf) item.isPartOf.name = text(item.isPartOf.name);
      schema.textContent = JSON.stringify(item);
    }
  }
  // Browser messages normally follow the device language, which may differ from the selected app language.
  const validationFields = new WeakSet();
  function validationText(field) {
    const v=field.validity;
    let source;
    if(v.valueMissing) source = field.type==='checkbox' ? 'اختر هذا المربّع للمتابعة.' : field.tagName==='SELECT'||field.type==='radio' ? 'اختر أحد الخيارات.' : 'هذا الحقل مطلوب.';
    else if(v.typeMismatch) source = field.type==='email' ? 'أدخل عنوان بريد إلكتروني صحيحاً.' : 'أدخل رابطاً صحيحاً.';
    else if(v.badInput) source='أدخل رقماً صحيحاً لهذا الحقل.';
    else if(v.patternMismatch) source='أدخل القيمة بالصيغة المطلوبة.';
    else if(v.rangeUnderflow) source='يجب ألا تقلّ القيمة عن {min}.';
    else if(v.rangeOverflow) source='يجب ألا تتجاوز القيمة {max}.';
    else if(v.tooShort) source='أدخل {min} أحرف على الأقل.';
    else if(v.tooLong) source='لا تدخل أكثر من {max} حرفاً.';
    else if(v.stepMismatch) source='اختر قيمة تتوافق مع مقدار الزيادة المسموح به.';
    else source='تحقّق من القيمة المدخلة.';
    return text(source).replace('{min}',v.tooShort?field.minLength:field.min).replace('{max}',v.tooLong?field.maxLength:field.max);
  }
  function clearValidation(event) {
    const field=event.target;
    if(validationFields.delete(field)) field.setCustomValidity('');
  }
  document.addEventListener('invalid', event => {
    const field=event.target;
    if(typeof field.setCustomValidity!=='function' || (field.validity.customError && !validationFields.has(field))) return;
    if(validationFields.has(field))field.setCustomValidity('');
    field.setCustomValidity(validationText(field));
    validationFields.add(field);
  },true);
  document.addEventListener('input',clearValidation,true);
  document.addEventListener('change',clearValidation,true);
  document.addEventListener('change', event => {
    if (!event.target.matches('[data-language-picker]')) return;
    const next = event.target.value;
    if (!valid(next) || next === code) return;
    remember(next);
    const url = new URL(location.href);
    url.searchParams.set('lang',next);
    location.assign(url.href);
  });
  globalThis.TawfeerLanguage = Object.freeze({code,text,place:text,withLanguage,applyStatic});
})();

// Compile authored JavaScript copy to catalog lookups without touching dynamic customer data,
// persisted city keys, search aliases, selectors, URLs or code. Node's bundled Acorn is the
// offline fallback when the project's build environment has no standalone Acorn package.
const fs = require('node:fs');
const path = require('node:path');
let acorn;
try { acorn = require('acorn'); }
catch { acorn = require('internal/deps/acorn/acorn/dist/acorn'); }
const root = __dirname;
const table = JSON.parse(fs.readFileSync(path.join(root,'locales','en.json'))).messages;
const hasArabic = s => /[\u0621-\u064a\u066e-\u06d3]/u.test(s);
const spans = /[\p{L}\p{M}\p{N}\t \u00a0.,:!؟?،؛;·…–—•©%٪/+()«»’‘&\-|\u200c\u200d]+/gu;
const reserved = new Set(['CITIES','CITY_EN','PROMO_AREAS','DINING_META','bridgeNames','KOD_CONFIG','localePatterns','cuisineLabels']);
const keepFields = new Set(['city','emirate','nativeName','search','url','en','id','status','key','raw','type','photo','category','endDate']);
function quote(s){return JSON.stringify(s).replaceAll('<','\\u003c');}
function compile(source) {
  const replacements=[];
  const parsed=acorn.parse(source,{ecmaVersion:'latest',sourceType:'script'});
  function walk(n) {
    if (!n || typeof n!=='object') return;
    if ((n.type==='FunctionDeclaration' && ['norm','latinDigits','localeMessage','localeCopy','placeLabel'].includes(n.id.name)) ||
        (n.type==='VariableDeclarator' && reserved.has(n.id.name))) return;
    if (n.type==='CallExpression' && ['localeCopy','placeLabel'].includes(n.callee.name)) return;
    if (n.type==='Property' && !n.computed) {
      const key=n.key.name??n.key.value;
      if (!keepFields.has(key)) walk(n.value);
      return;
    }
    if (n.type==='Literal' && typeof n.value==='string' && hasArabic(n.value)) {
      const pieces=[];
      let cursor=0;
      for (const m of n.value.matchAll(spans)) {
        const key=m[0].trim();
        if (!hasArabic(key)) continue;
        if (!Object.hasOwn(table,key)) throw Error('Missing translation: '+key);
        const first=m.index+m[0].indexOf(key);
        if (first>cursor) pieces.push(quote(n.value.slice(cursor,first)));
        pieces.push('localeCopy('+quote(key)+')');
        cursor=first+key.length;
      }
      if (pieces.length) {
        if (cursor<n.value.length) pieces.push(quote(n.value.slice(cursor)));
        replacements.push([n.start,n.end,'('+pieces.join('+')+')']);
      }
      return;
    }
    if (n.type==='TemplateElement' && hasArabic(n.value.cooked||'')) throw Error('Use a named localized message for template literal: '+n.value.cooked);
    for (const child of Object.values(n)) {
      if (Array.isArray(child)) child.forEach(walk);
      else if (child && typeof child==='object') walk(child);
    }
  }
  walk(parsed);
  let tail=source.length;const chunks=[];
  for(const [start,end,value] of replacements.reverse()) {
    chunks.push(source.slice(end,tail),value); tail=start;
  }
  chunks.push(source.slice(0,tail));
  const translated=chunks.reverse().join('');
  acorn.parse(translated,{ecmaVersion:'latest'});
  return translated;
}
if(require.main===module) process.stdout.write(compile(fs.readFileSync(0,'utf8')));

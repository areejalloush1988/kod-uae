// Promoters see only their own applications and campaign aggregates. Approval requires the verified operator.
let partnerDesk=null,partnerAdmin=null,partnerKey='',partnerJob=null,partnerError=false;
function resetPartnerDesk(){partnerDesk=null;partnerAdmin=null;partnerKey='';partnerJob=null;partnerError=false;}
function promoCitySelect(chosen=''){
  return '<label class="field">الإمارة<select name="city"><option value="">كل الإمارات</option>'+Object.values(PROMO_AREAS).map(c=>'<option value="'+esc(c)+'"'+(c===chosen?' selected':'')+' >'+displayText(placeLabel(c))+'</option>').join('')+'</select></label>';
}
function promoInteger(label,name,value,min,max){return '<label class="field">'+label+'<input type="number" lang="en" dir="ltr" name="'+name+'" step="1" min="'+min+'" max="'+max+'" value="'+value+'" required></label>';}
function submitPromo(label){return '<button class="btn" type="submit">'+label+'</button><p role="status" aria-live="polite"></p>';}
function partnerApplication(){
  if(!appIdentity||previewRole||appIdentity.role==='developer_locked')return '<button class="btn light" data-card-login="marketing">دخول لتقديم طلب شراكة</button>';
  return '<form class="promo-form" data-promo-form="apply"><div class="promo-inputs"><label class="field">نوع الشراكة<select name="kind" data-application-kind><option value="creator">صانع محتوى</option><option value="corporate">عضوية للموظفين</option></select></label>'+promoCitySelect()+'</div><label class="field">اسم الشركة أو القناة<input name="label" maxlength="80" minlength="2" required></label><label class="field">بريد التواصل<input type="email" name="contact" dir="ltr" maxlength="150" required></label><div data-seat-field hidden>'+promoInteger('عدد الموظفين','seats','1',1,100000)+'</div>'+submitPromo('إرسال طلب الشراكة')+'</form>';
}
function ownerPromoTools(){
  if(!isLiveOperator()||!partnerAdmin)return '';
  return cashAdminPanel()+
    '<section class="promo-box"><h2>إنشاء رابط حملة</h2><p>استخدم رابطاً لكل منطقة أو مجموعة أو شريك لتعرف أي حملة جابت اشتراكات مدفوعة.</p><form class="promo-form" data-promo-form="campaign"><div class="promo-inputs"><label class="field">القناة<select name="kind" data-campaign-kind>'+['community','area','creator','corporate'].map(k=>'<option value="'+k+'">'+PROMO_KINDS[k]+'</option>').join('')+'</select></label>'+promoCitySelect()+'</div><label class="field">اسم الحملة<input name="label" maxlength="80" minlength="2" required placeholder="مثلاً مجموعة مطاعم دبي"></label><div data-commission-field hidden>'+promoInteger('عمولة أول اشتراك مدفوع (%)','percent','0',0,100)+'</div>'+submitPromo('إنشاء رابط الحملة')+'</form></section>';
}
function branchPromoTools(){
  if(previewRole||(!isLiveOperator()&&appIdentity?.role!=='merchant'))return '';
  const eligible=cardPartners().filter(b=>isLiveOperator()||b.owner_id===appIdentity.id);
  return '<section class="promo-box"><h2>رمز الاشتراك عند الكاشير</h2><p>لكل فرع مشارك رمز QR خاص فيه. المسح بيفتح صفحة الاشتراك وبيحسب التسجيلات اللي جابها الفرع.</p>'+(eligible.length?'<form class="promo-form" data-promo-form="branch"><label class="field">الفرع<select name="branch">'+eligible.map(b=>'<option value="'+esc(b.id)+'">'+displayText(b.name)+'</option>').join('')+'</select></label>'+submitPromo('تجهيز رمز الفرع')+'</form>':'<p>بتظهر الفروع هون بعد اعتمادها وتفعيل خصم الكاشير.</p><button class="text-button" data-go="partner">تسجيل فرع</button>')+'</section>';
}
function applicationList(rows){
  if(!rows?.length)return '';
  return '<section class="promo-box"><h2>طلبات الشراكة</h2>'+rows.map(r=>'<article class="promo-row"><strong>'+displayText(r.name)+'</strong><p>'+esc(PROMO_KINDS[r.kind]||'')+' · '+esc(placeLabel(r.city)||'كل الإمارات')+' · '+(r.status==='approved'?'معتمد':'قيد المراجعة')+(r.seats?' · '+number(r.seats)+' موظف':'')+'</p>'+(isLiveOperator()&&r.status==='pending'?'<p><bdi>'+esc(r.contact)+'</bdi></p><form class="promo-form" data-promo-form="approve" data-request="'+esc(r.id)+'">'+(r.kind==='creator'?promoInteger('العمولة المتفق عليها (%)','percent',0,0,100):'')+submitPromo('اعتماد وإصدار رابط')+'</form>':'')+'</article>').join('')+'</section>';
}
function campaignList(rows){
  if(!rows?.length)return '';
  return '<section class="promo-box"><h2>روابط الحملات ونتائجها</h2>'+rows.map(c=>{
    const url=promoHref('campaign',c.id);
    const commissions=c.kind==='creator'?'<p>العمولة المتفق عليها '+number(c.commission_percent)+'% · العمولة المحتسبة '+money(c.commission_fils)+'</p>':'';
    const seats=c.kind==='corporate'?'<p>المقاعد المفعّلة '+number(c.used)+' من '+number(c.seats)+'</p>'+(isLiveOperator()?'<details><summary>إصدار مقاعد موظفين</summary><form class="promo-form" data-promo-form="seats" data-campaign="'+esc(c.id)+'"><div class="promo-inputs">'+promoInteger('عدد المقاعد','seats',1,1,1000)+promoInteger('أيام كل مقعد','days',30,1,365)+'</div><label class="promo-check"><input type="checkbox" required> تم اعتماد اتفاق الشركة وعدد المقاعد</label>'+submitPromo('إصدار روابط الموظفين')+'</form></details>':'')+(c.seats>c.used?'<button class="text-button" data-export-seats="'+esc(c.id)+'">تنزيل روابط المقاعد المتاحة</button>':''):'';
    return '<article class="promo-row"><span class="promo-small">'+esc(PROMO_KINDS[c.kind])+' · '+esc(placeLabel(c.city)||'كل الإمارات')+'</span><h3>'+displayText(c.label)+'</h3><p>التسجيلات '+number(c.joined)+' · الاشتراكات المدفوعة '+number(c.paid)+'</p>'+commissions+promoShareTools(url,'اكتشف عضوية توفير للمطاعم والمقاهي'+(c.city?' في '+placeLabel(c.city):' في الإمارات')+'.')+'<button class="text-button" data-export-poster="'+esc(c.id)+'">تحميل ملصق QR للطباعة</button>'+seats+'</article>';
  }).join('')+'</section>';
}
function marketingPrivate(){
  if(!appIdentity||previewRole||appIdentity.role==='developer_locked')return '';
  if(partnerError)return '<div class="promo-note" role="status">تعذّر تحميل الحملات. <button class="text-button" data-reload-partners>إعادة المحاولة</button></div>';
  if(!partnerDesk)return '<p role="status">جارٍ تحميل بيانات حسابك…</p>';
  return ownerPromoTools()+branchPromoTools()+applicationList(partnerDesk.requests)+campaignList(partnerDesk.campaigns);
}
function marketingPage(){
  return '<div class="promo-page"><header class="order-page-head"><div><h1>التسويق والشراكات</h1><p>روابط الاشتراك للمطاعم وصنّاع المحتوى، وعضويات فرق العمل.</p></div><button class="btn light" data-go="rewards">دعواتي ومكافآتي</button></header>'+ownerWorkspaceNav('marketing')+featuredMerchantLink()+'<div class="promo-stack" id="partner-workspace">'+marketingPrivate()+'</div>'+
    '<section class="promo-box"><h2>انضم كشريك</h2><p>صنّاع المحتوى بيحصلوا على رابط لتتبّع الاشتراكات والعمولة المتفق عليها. والشركات فيها تطلب مقاعد خاصة لموظفيها.</p>'+partnerApplication()+'</section>'+
    '<section class="promo-box"><h2>شارك دليل إمارتك</h2><p>اختر إمارة وأرسل دليل المطاعم والمقاهي إلى مجموعتك.</p><label class="field">الإمارة<select id="promo-local-guide">'+Object.entries(PROMO_AREAS).map(([slug,c])=>'<option value="'+slug+'" >'+displayText(placeLabel(c))+'</option>').join('')+'</select></label><div id="promo-local-share">'+localGuideShare('dubai')+'</div>'+promoAreaLinks()+'</section></div>';
}
async function beginPartnerPage(force=false){
  if(!appIdentity||previewRole||appIdentity.role==='developer_locked')return;
  const id=appIdentity.id,key=workspaceEpoch+'|'+id,epoch=workspaceEpoch;
  if(!force&&(partnerKey===key||partnerJob===key))return;
  partnerJob=key;
  try{
    const [desk,admin]=await Promise.all([cardRpc('kod_marketing_desk',{}),isLiveOperator()?cardRpc('kod_referral_admin',{p_days:null}):null]);
    if(workspaceEpoch!==epoch||id!==appIdentity?.id||previewRole)return;
    partnerDesk=desk;partnerAdmin=admin;partnerError=false;
  }catch{if(workspaceEpoch===epoch)partnerError=true;}
  finally{if(workspaceEpoch===epoch&&partnerJob===key){partnerJob=null;partnerKey=key;const el=document.getElementById('partner-workspace');if(current==='marketing'&&el)el.innerHTML=marketingPrivate();}}
}
function posterBlob(c){
  const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=1350;
  const g=canvas.getContext('2d');if(!g)throw Error();
  g.fillStyle='#ffffff';g.fillRect(0,0,1080,1350);
  g.fillStyle='#f7e6ed';g.fillRect(0,0,1080,285);g.fillStyle='#800028';g.fillRect(0,273,1080,12);g.fillStyle='#000000';g.textAlign='center';g.direction=localeDirection;
  drawTawfeerLogo(g,375,58,330);
  g.font='600 43px Cairo, sans-serif';g.fillText('عضوية المطاعم والمقاهي',540,222);
  g.fillStyle='#000000';g.font='800 52px Cairo, sans-serif';g.fillText(c.label,540,410,920);
  const qr=memberArtQr(promoHref('campaign',c.id)),step=Math.floor(630/qr.modules),side=step*qr.modules,left=Math.round((1080-side)/2);
  g.fillStyle='#000000';for(const [x,y,w] of qr.runs)g.fillRect(left+x*step,465+y*step,w*step,step);
  g.fillStyle='#000000';g.font='800 48px Cairo, sans-serif';g.fillText('امسح الرمز للاشتراك',540,1195);
  g.fillStyle='#000000';g.font='600 33px Cairo, sans-serif';g.fillText(c.city||'الإمارات العربية المتحدة',540,1275);
  return new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error()),'image/png'));
}
function promoFormRequest(f){return f.dataset.nonce||(f.dataset.nonce=crypto.randomUUID());}
document.addEventListener('change',e=>{
  if(e.target.hasAttribute?.('data-application-kind'))e.target.form.querySelector('[data-seat-field]').hidden=e.target.value!=='corporate';
  if(e.target.hasAttribute?.('data-campaign-kind'))e.target.form.querySelector('[data-commission-field]').hidden=e.target.value!=='creator';
});
document.addEventListener('submit',async e=>{
  const f=e.target,k=f.dataset?.promoForm;if(!k)return;e.preventDefault();
  if(!appIdentity||previewRole||f.dataset.busy==='true')return;
  const epoch=workspaceEpoch,btn=f.querySelector('[type=submit]'),msg=f.querySelector('[role=status]'),v=f.elements;
  f.dataset.busy='true';btn.disabled=true;msg.textContent='جارٍ الحفظ…';
  try{
    if(k==='apply')await cardRpc('kod_partner_apply',{p_kind:v.kind.value,p_name:v.label.value.trim(),p_contact:v.contact.value.trim(),p_city:v.city.value,p_seats:v.kind.value==='corporate'?Number(v.seats.value):null});
    else if(k==='branch')await cardRpc('kod_branch_campaign',{p_branch:v.branch.value});
    else if(k==='campaign'||k==='approve'){
      const lead=k==='approve'?partnerDesk.requests.find(r=>r.id===f.dataset.request):null;
      if(k==='approve'&&!lead)throw Error();
      const kind=lead?.kind||v.kind.value;
      await cardRpc('kod_create_campaign',{p_kind:kind,p_label:lead?.name||v.label.value.trim(),p_city:lead?lead.city:v.city.value,p_percent:kind==='creator'?Number(v.percent.value):0,p_request:lead?.id||null,p_nonce:promoFormRequest(f)});
    }else if(k==='seats')await cardRpc('kod_company_batch',{p_campaign:f.dataset.campaign,p_batch:promoFormRequest(f),p_seats:Number(v.seats.value),p_days:Number(v.days.value)});
    else return;
    if(epoch!==workspaceEpoch)return;
    f.reset();delete f.dataset.nonce;
    const done=k==='apply'?'تم استلام طلب الشراكة.':k==='seats'?'تم إصدار روابط الموظفين.':'تم الحفظ.';
    msg.textContent=done;toast(done);await beginPartnerPage(true);
  }catch{if(epoch===workspaceEpoch)msg.textContent='تعذّر الحفظ. تحقّق من البيانات والاتصال ثم أعد المحاولة.';}
  finally{btn.disabled=false;delete f.dataset.busy;}
});
document.addEventListener('click',async e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.hasAttribute('data-reload-partners')){beginPartnerPage(true);return;}
  const c=partnerDesk?.campaigns?.find(c=>c.id===(b.dataset.exportPoster||b.dataset.exportSeats));
  if(!c||previewRole||!appIdentity)return;
  const epoch=workspaceEpoch;b.disabled=true;
  try{
    if(b.dataset.exportPoster){await document.fonts?.ready;const png=await posterBlob(c);if(epoch===workspaceEpoch)saveCardFile(png,'Tawfeer-QR-'+c.id.slice(0,8)+'.png');}
    else if(b.dataset.exportSeats){const rows=await cardRpc('kod_company_codes',{p_campaign:c.id});if(epoch!==workspaceEpoch)return;
      if(!rows.length){toast('كل المقاعد مستخدمة.');return;}
      const csv=['رابط الموظف,أيام العضوية',...rows.map(s=>promoHref('seat',s.token)+','+Number(s.days))].join('\r\n');
      saveCardFile(new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'}),'Tawfeer-Employee-Seats.csv');
    }
  }catch{if(epoch===workspaceEpoch)toast('تعذّر تجهيز الملف. أعد المحاولة.');}finally{b.disabled=false;}
});

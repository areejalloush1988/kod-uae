// The non-exportable key stays in this browser. Its random identifier alone cannot approve a discount.
let memberKeyDatabase,deviceView=null,deviceViewOwner='',deviceQueue=null,deviceError='',deviceReadVersion=0;
const memberBillCodes=new Map();
function clearDeviceView(){deviceView=null;deviceViewOwner='';deviceQueue=null;deviceError='';deviceReadVersion++;memberBillCodes.clear();}
function memberKeys(){
  if(!memberKeyDatabase){
    memberKeyDatabase=new Promise((resolve,reject)=>{
      const open=indexedDB.open('tawfeer-member-devices',1);
      open.onupgradeneeded=()=>open.result.createObjectStore('members');
      open.onsuccess=()=>{const db=open.result;db.onversionchange=()=>{db.close();memberKeyDatabase=null;};resolve(db);};
      open.onerror=()=>reject(Error('device_storage'));
    }).catch(()=>{memberKeyDatabase=null;throw Error('device_storage');});
  }
  return memberKeyDatabase;
}
async function deviceRecord(uid,record,previousId){
  const db=await memberKeys();return new Promise((resolve,reject)=>{
    const tx=db.transaction('members',record?'readwrite':'readonly'),store=tx.objectStore('members');
    const req=store.get(uid);let conflict=false;
    if(record)req.onsuccess=()=>{
      const current=req.result;
      if((current?.id||null)!==previousId || (current?.createdAt&&current.createdAt>Date.now()-20000)){conflict=true;tx.abort();return;}
      store.put(record,uid);
    };
    tx.oncomplete=()=>resolve(record||req.result||null);
    tx.onerror=tx.onabort=()=>reject(Error(conflict?'device_busy':'device_storage'));
  });
}
function deviceHex(bytes){return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');}
function deviceMessage(e){
  return ({device_storage:'يتعذّر حفظ جهاز العضوية في هذا المتصفح. افتح التطبيق في متصفح عادي مع السماح بتخزين بياناته.',other_device:'افتح «بطاقتي» على جهازك المعتمد واربطه قبل استخدام الخصم.',device_proof_required:'افتح «بطاقتي» على جهازك المعتمد واربطه قبل استخدام الخصم.',transfer_pending:'طلب نقل الجهاز بانتظار مراجعة إدارة توفير.',bill_expired:'انتهت مهلة الموافقة. اطلب من الكاشير إرسال الطلب مجدداً.'})[e?.message]||'تعذّر تنفيذ الطلب. حدّث الصفحة وحاول مجدداً.';
}
async function linkMemberBrowser(replace){
  const uid=appIdentity?.id,epoch=workspaceEpoch;
  if(!uid||previewRole)return;
  const info=await cardRpc('kod_device_status',{}),saved=await deviceRecord(uid);
  if(saved&&(saved.id===info.device||saved.id===info.replacement))return;
  if(info.device&&!replace)throw Error('other_device');
  if(info.replacement)throw Error('transfer_pending');
  if(!crypto.subtle)throw Error('device_storage');
  const bytes=crypto.getRandomValues(new Uint8Array(32)),id=crypto.randomUUID();
  const key=await crypto.subtle.importKey('raw',bytes,{name:'HMAC',hash:'SHA-256'},false,['sign']);
  try{
    // The server never binds a browser that could not durably store its key.
    await deviceRecord(uid,{id,key,createdAt:Date.now()},saved?.id||null);if(epoch!==workspaceEpoch||appIdentity?.id!==uid)return;
    await cardRpc('kod_link_device',{p_device:id,p_secret:deviceHex(bytes),p_replace:replace});
  }finally{bytes.fill(0);}
}
async function approveMemberUse(purpose,target){
  const uid=appIdentity?.id,epoch=workspaceEpoch;if(!uid||previewRole)throw Error('device_proof_required');
  const record=await deviceRecord(uid);if(!record)throw Error('device_proof_required');
  const nonce=await cardRpc('kod_device_challenge',{p_device:record.id,p_purpose:purpose,p_target:target});
  const signature=await crypto.subtle.sign('HMAC',record.key,new TextEncoder().encode(['tawfeer-v1',nonce,purpose,target].join('|')));
  if(epoch!==workspaceEpoch||appIdentity?.id!==uid)throw Error('authentication_required');
  return cardRpc('kod_device_prove',{p_nonce:nonce,p_signature:deviceHex(signature)});
}
function approvedMemberBill(b){
  const cached=memberBillCodes.get(b.id);
  if(cached&&cached.until>Date.now())return '<p>رمز تأكيد الفاتورة</p><strong class="presence-code" dir="ltr">'+esc(cached.code)+'</strong><p>أبرز هذا الرمز للكاشير من جهازك المعتمد. يصلح لهذه الفاتورة فقط.</p>';
  return '<button class="btn" data-device-action="bill" data-bill="'+esc(b.id)+'">عرض رمز التأكيد</button>';
}
function devicePanel(){
  const v=deviceViewOwner===appIdentity?.id?deviceView:null;
  let body='';
  if(v){
    if(!v.device)body='<button class="btn" type="button" data-device-action="link">ربط هذا الجهاز</button>';
    else if(v.here)body='<strong>هذا هو جهاز العضوية المعتمد.</strong>';
    else body='<p>العضوية مرتبطة بجهاز آخر.</p>'+(v.replacement?'<p>طلب نقل الجهاز بانتظار مراجعة إدارة توفير.</p>':'<button class="btn light" type="button" data-device-action="replace">طلب نقل العضوية إلى هذا الجهاز</button>');
    if(v.here)body+='<h3>طلبات الموافقة على الخصم</h3>'+(v.bills.length?v.bills.map(b=>'<article>'+summaryOfBill(b)+(b.approved?approvedMemberBill(b):'<button class="btn" data-device-action="bill" data-bill="'+esc(b.id)+'">الموافقة على خصم هذه الفاتورة</button> <button class="text-button" data-device-action="decline" data-bill="'+esc(b.id)+'">رفض الفاتورة</button>')+'</article>').join(''):'<p>لا توجد فواتير بانتظار موافقتك.</p>');
  }
  return '<section class="box member-protection" id="member-protection"><h2>حماية العضوية</h2><p>تُستخدم خصومات عضويتك من جهاز واحد. عند الكاشير، راجع الفاتورة ووافق عليها من جهازك المعتمد.</p>'+body+'<button class="text-button" data-device-action="refresh">تحديث طلبات الخصم</button><p role="status">'+esc(deviceError)+'</p></section>';
}
function deviceDesk(){
  return '<section class="box member-protection" id="member-devices-admin"><h2>طلبات تغيير جهاز العضوية</h2>'+(deviceQueue===null?'':deviceQueue.length?deviceQueue.map(row=>'<form data-device-review="'+esc(row.user)+'" data-device="'+esc(row.device)+'"><strong>'+displayText(row.name||'حساب توفير')+'</strong> <bdi>'+displayText(row.contact||'لا توجد وسيلة تواصل موثقة متاحة.')+'</bdi><label><input type="checkbox" name="verified"> تحققت من هوية صاحب العضوية عبر وسيلة التواصل المسجلة</label><button class="btn" value="approve">اعتماد الجهاز الجديد</button> <button class="text-button" value="deny">رفض طلب النقل</button><p role="status"></p></form>').join(''):'<p>لا توجد طلبات تغيير جهاز معلّقة.</p>')+'<button class="text-button" data-device-action="refresh">تحديث</button><p role="status">'+esc(deviceError)+'</p></section>';
}
async function loadDevicePanel(){
  const admin=current==='dashboard'&&isLiveOperator(),member=current==='membership'&&!previewRole&&hasPersonalCard(appIdentity?.role);
  if(!admin&&!member)return;
  const id=admin?'member-devices-admin':'member-protection',uid=appIdentity.id,epoch=workspaceEpoch,version=++deviceReadVersion;
  if(!document.getElementById(id))return;
  try{
    if(admin){const rows=await cardRpc('kod_device_requests',{});if(version!==deviceReadVersion||epoch!==workspaceEpoch)return;deviceQueue=rows;}
    else{const [info,record]=await Promise.all([cardRpc('kod_device_status',{}),deviceRecord(uid)]);
      if(version!==deviceReadVersion||epoch!==workspaceEpoch)return;deviceView={...info,here:Boolean(record&&record.id===info.device)};deviceViewOwner=uid;}
    deviceError='';
  }catch(err){if(version!==deviceReadVersion||epoch!==workspaceEpoch)return;deviceError=deviceMessage(err);}
  const zone=document.getElementById(id);if(zone&&epoch===workspaceEpoch&&version===deviceReadVersion)zone.outerHTML=admin?deviceDesk():devicePanel();
}
document.addEventListener('click',async e=>{
  const button=e.target.closest?.('[data-device-action]');if(!button||button.disabled||previewRole||!appIdentity)return;
  const action=button.dataset.deviceAction,epoch=workspaceEpoch;button.disabled=true;
  try{
    if(action==='link'||action==='replace')await linkMemberBrowser(action==='replace');
    if(action==='bill'||action==='decline'){const id=button.dataset.bill;const code=await approveMemberUse(action,id);if(epoch===workspaceEpoch&&action==='bill'&&/^\d{6}$/.test(code))memberBillCodes.set(id,{code,until:Date.parse(deviceView?.bills.find(b=>b.id===id)?.expires_at)||Date.now()+90000});}
    if(epoch===workspaceEpoch)await loadDevicePanel();
  }catch(err){if(epoch===workspaceEpoch){const node=button.closest('section')?.querySelector('[role="status"]');if(node)node.textContent=deviceMessage(err);}}
  finally{button.disabled=false;}
});
document.addEventListener('submit',async e=>{
  const form=e.target;if(!form.dataset.deviceReview||!isLiveOperator())return;e.preventDefault();
  const approved=e.submitter?.value==='approve',verified=form.elements.verified.checked;
  if(approved&&!verified){form.elements.verified.focus();form.querySelector('[role="status"]').textContent='تحققت من هوية صاحب العضوية عبر وسيلة التواصل المسجلة';return;}
  const epoch=workspaceEpoch;try{await cardRpc('kod_review_device',{p_user:form.dataset.deviceReview,p_device:form.dataset.device,p_approve:approved,p_verified:verified});if(epoch===workspaceEpoch)await loadDevicePanel();}
  catch(err){if(epoch===workspaceEpoch)form.querySelector('[role="status"]').textContent=deviceMessage(err);}
});

const CLUB_TIERS={
  bronze:{name:'البرونزية',benefit:'خصم العضوية الأساسي في الفروع المشاركة.'},
  silver:{name:'الفضية',benefit:'الخصم الأساسي مع زيادة الفئة الفضية في الفروع التي تقدّمها.'},
  gold:{name:'الذهبية',benefit:'أعلى خصم عضوية يقدّمه الفرع.'}
};
function legacyTierForMonths(months){return Number(months)===1?'bronze':Number(months)===3?'silver':'gold';}
function receiptTier(row){return Object.hasOwn(CLUB_TIERS,row.club_tier)?row.club_tier:legacyTierForMonths(row.months);}
function activeClubTier(card,at=Date.now()){return cardEntitlement(card,at).tier;}
function clubDiscount(base,branch,tier){
  if(!tier||!base)return 0;
  const extra=tier==='gold'?branch.gold_extra:tier==='silver'?branch.silver_extra:0;
  return Math.min(70,Number(base)+Number(extra||0));
}
function clubChoiceSwitch(route){
  if(restaurantShell())return '';
  return '<nav class="club-switch" aria-label="نوع الاشتراك">'+[['subscriptions','عضويات الزبائن'],['featured','اشتراك المطاعم']].map(([id,name])=>'<button type="button" data-go="'+id+'" aria-pressed="'+(id===route)+'">'+name+'</button>').join('')+'</nav>';
}
function clubTierBadge(tier){
  if(!Object.hasOwn(CLUB_TIERS,tier))return '';
  return '<span class="club-tier-badge" data-tier="'+tier+'">العضوية '+CLUB_TIERS[tier].name+'</span>';
}
function clubStarts(iso){return new Date(iso).toLocaleDateString(UI_LOCALE,{timeZone:'Asia/Dubai',day:'numeric',month:'short',year:'numeric'});}
function clubRateComparison(r,channel){
  const base=channel==='online'?r.percent:r.instore_percent;
  if(!base)return '';
  return Object.entries(CLUB_TIERS).map(([key,t])=>t.name+' '+number(clubDiscount(base,r,key))+'%').join(' · ');
}
function clubBranchOffers(){
  const selected=chosenTier;
  const rows=(liveWorkspace.restaurants||[]).filter(r=>r.approved&&!r.is_demo&&(r.instore_percent>0||r.percent>0)&&(state.city==='all'||r.city===state.city));
  if(!rows.length)return '';
  return '<details class="box club-branch-offers"><summary>'+localeMessage('membership.discountsAtBranches',{tier:CLUB_TIERS[selected].name})+'</summary>'+rows.map(r=>'<p><strong>'+displayText(r.name)+' · '+displayText(placeLabel(r.city))+'</strong><br>'+[r.instore_percent>0?'عند الكاشير '+number(clubDiscount(r.instore_percent,r,selected))+'%':'',r.percent>0?'على طلبات توفير '+number(clubDiscount(r.percent,r,selected))+'%':''].filter(Boolean).join(' · ')+'</p>').join('')+'</details>';
}
function clubRateSettings(r){
  if(!r?.approved||r.is_demo||previewRole)return '';
  const fields=[['rate','خصم البرونزية عند الكاشير (%)',r.instore_percent],['online','خصم البرونزية على طلبات توفير (%)',r.percent],['silver','زيادة الفضية (نقاط مئوية)',r.silver_extra],['gold','زيادة الذهبية (نقاط مئوية)',r.gold_extra]];
  return '<form class="box card-admin-form featured-form" data-card-rate data-branch="'+esc(r.id)+'"><h3>خصومات العضويات · '+displayText(r.name)+'</h3>'+
    '<p>حدّد خصم كل طريقة شراء. وضع 0 للخصم الأساسي يوقفه لهذه الطريقة. مثلاً خصم أساسي 10% مع زيادة 5 نقاط يعطي خصماً قدره 15%.</p>'+
    fields.map(([key,title,val])=>'<label class="field">'+title+'<input type="number" dir="ltr" lang="en" name="'+key+'" min="0" max="70" step="1" value="'+Number(val||0)+'" required></label>').join('')+
    '<p>زيادة الذهبية تساوي زيادة الفضية أو تفوقها. الحد الأعلى للخصم النهائي 70%.</p><button class="btn">حفظ خصومات الفرع</button><p role="status"></p></form>';
}

let membershipCatalog=null,priceListAt=0,priceListJob=null,priceListError=false,priceListRevision=0;
let priceEdits=new Map(),priceEditorNote='',priceEditorBusy=false;
function clearPriceEditor(){priceEdits.clear();priceEditorNote='';priceEditorBusy=false;}
function catalogEntry(tier,months){return membershipCatalog?.find(r=>r.tier===tier&&r.months===months);}
function applyCatalog(rows){
  if(!Array.isArray(rows)||rows.length!==12||!Object.keys(CLUB_TIERS).every(tier=>SUBSCRIPTION_TERMS.every(term=>rows.some(r=>
    r.tier===tier&&r.months===term.months&&typeof r.carrier_allowed==='boolean'&&(r.amount_fils===null||(Number.isInteger(r.amount_fils)&&r.amount_fils>0&&r.amount_fils<=9999999))))))throw Error('invalid_prices');
  membershipCatalog=rows;priceListError=false;priceListAt=Date.now();
}
function redrawPriceList(){
  if(current==='subscriptions')redrawSubscriptions();
  if(current==='pricing'&&isLiveOperator()){
    const body=document.getElementById('plan-prices-body');
    if(body&&!body.contains?.(document.activeElement))body.innerHTML=priceEditorBody();
  }
  if(current==='rewards'){
    const amounts=document.getElementById('promo-amounts');if(amounts)amounts.innerHTML=shareAmountsView();
  }
}
async function loadMembershipCatalog(force=false){
  if(priceListJob)return priceListJob;
  if(!force&&Date.now()-priceListAt<60000)return;
  const revision=priceListRevision;
  const job=(async()=>{
    try{const rows=await publicPromoRpc('kod_membership_catalog',{});if(revision===priceListRevision)applyCatalog(rows);}
    catch{if(revision===priceListRevision){priceListError=true;priceListAt=0;}}
    if(revision===priceListRevision)redrawPriceList();
  })();
  priceListJob=job;try{await job;}finally{if(priceListJob===job)priceListJob=null;}
}
function priceEditorBody(){
  if(!isLiveOperator())return '';
  if(!membershipCatalog)return priceListError?'<p role="status">تعذّر تحميل الأسعار.</p><button class="btn light" data-price-reload>إعادة المحاولة</button>':'<p role="status">جارٍ تحميل الأسعار…</p>';
  const fields=Object.entries(CLUB_TIERS).map(([tier,meta])=>'<fieldset class="club-price-row" data-tier="'+tier+'"><legend>'+meta.name+'</legend>'+
    SUBSCRIPTION_TERMS.map(term=>{
      const row=catalogEntry(tier,term.months),draft=priceEdits.get(tier+'/'+term.months);
      const original=draft?draft.original:row.amount_fils;
      const value=draft?draft.value:row.amount_fils===null?'':String(row.amount_fils/100);
      return '<label><span>'+term.label+'</span><input class="price-input" type="text" inputmode="decimal" dir="ltr" lang="en" maxlength="12" autocomplete="off" aria-label="'+meta.name+' · '+term.label+' بالدرهم" data-price-tier="'+tier+'" data-price-months="'+term.months+'" data-original="'+(original??'')+'" value="'+esc(value)+'" placeholder="—"></label>';
    }).join('')+'</fieldset>').join('');
  return '<form class="box club-price-editor" id="membership-price-form"><p>الأسعار بالدرهم لكل فئة ومدة. اترك الخانة فارغة لإيقاف الطلبات الجديدة لهذا الخيار. الفواتير الصادرة تحتفظ بسعرها.</p>'+fields+
   '<div class="club-price-actions"><button class="btn" type="submit" '+(priceEditorBusy?'disabled':'')+'>حفظ أسعار العضويات</button><button class="btn light" type="button" data-price-reload>تحميل الأسعار المحفوظة</button><p role="status" aria-live="polite">'+esc(priceEditorNote||(priceListError?'تعذّر تحديث الأسعار.':'') )+'</p></div></form>';
}
function membershipPricingPage(){
  const title='<header class="order-page-head"><div><h1>أسعار العضويات</h1></div></header>';
  if(!isLiveOperator())return '<div class="subscriptions">'+title+'<section class="box"><p>إدارة الأسعار متاحة من حساب المطوّر.</p>'+
    (!appIdentity||appIdentity.role==='developer_locked'?'<button class="btn" data-card-login="pricing">تسجيل دخول المطوّر</button>':'')+'</section></div>';
  return '<div class="subscriptions">'+title+ownerWorkspaceNav('pricing')+'<div id="plan-prices-body">'+priceEditorBody()+'</div></div>';
}
function parseMemberPrice(text){
  const amount=latinDigits(String(text)).trim().replace('٫','.');
  if(!amount)return null;
  if(!/^\d{1,5}(?:\.\d{1,2})?$/.test(amount))return NaN;
  const [whole,fraction='']=amount.split('.');
  const fils=Number(whole)*100+Number(fraction.padEnd(2,'0'));
  return fils>0?fils:NaN;
}
document.addEventListener('input',e=>{
  const input=e.target,tier=input.dataset?.priceTier;
  if(!tier||!isLiveOperator()||current!=='pricing')return;
  input.setCustomValidity('');
  const original=input.dataset.original===''?null:Number(input.dataset.original),months=Number(input.dataset.priceMonths),key=tier+'/'+months;
  if(parseMemberPrice(input.value)===original)priceEdits.delete(key);
  else priceEdits.set(key,{tier,months,original,value:input.value});
});
document.addEventListener('click',async e=>{
  const button=e.target.closest('button');if(!button?.hasAttribute('data-price-reload')||!isLiveOperator()||priceEditorBusy)return;
  clearPriceEditor();await loadMembershipCatalog(true);
  const panel=document.getElementById('plan-prices-body');if(current==='pricing'&&isLiveOperator()&&panel)panel.innerHTML=priceEditorBody();
});
document.addEventListener('submit',async e=>{
  const form=e.target;if(form.id!=='membership-price-form')return;e.preventDefault();
  if(!isLiveOperator()||priceEditorBusy)return;
  const status=form.querySelector('[role=status]'),changes=[];
  for(const input of form.querySelectorAll('[data-price-tier]')){
    const amount=parseMemberPrice(input.value),original=input.dataset.original===''?null:Number(input.dataset.original);
    if(Number.isNaN(amount)){input.setCustomValidity('أدخل سعراً موجباً بالدرهم حتى منزلتين عشريتين، أو اترك الخانة فارغة.');input.reportValidity();return;}
    if(amount!==original)changes.push({tier:input.dataset.priceTier,months:Number(input.dataset.priceMonths),previous_fils:original,amount_fils:amount});
  }
  if(!changes.length){status.textContent='الأسعار مطابقة للمحفوظة.';return;}
  const epoch=workspaceEpoch,submit=form.querySelector('[type=submit]');priceEditorBusy=true;submit.disabled=true;status.textContent='جارٍ حفظ الأسعار…';
  for(const input of form.querySelectorAll('input'))input.readOnly=true;
  try{
    const result=await cardRpc('kod_set_membership_prices',{p_changes:changes});
    if(epoch!==workspaceEpoch||!isLiveOperator())return;
    priceListRevision++;applyCatalog(result);priceEdits.clear();priceEditorNote='تم حفظ الأسعار. تظهر الأسعار الجديدة عند اختيار العضوية والمدة.';
    if(current==='pricing'){const body=document.getElementById('plan-prices-body');priceEditorBusy=false;if(body)body.innerHTML=priceEditorBody();}else redrawPriceList();
    toast('تم حفظ أسعار العضويات.');
  }catch(error){
    if(epoch!==workspaceEpoch)return;
    priceEditorNote=error.message==='price_conflict'?'تغيّر سعر من جهاز آخر. اضغط «تحميل الأسعار المحفوظة» وراجع التعديل.':'تعذّر حفظ الأسعار. تحقق من الاتصال وأعد المحاولة.';
    status.textContent=priceEditorNote;
  }finally{if(epoch===workspaceEpoch){priceEditorBusy=false;submit.disabled=false;for(const input of form.querySelectorAll('input'))input.readOnly=false;}}
});

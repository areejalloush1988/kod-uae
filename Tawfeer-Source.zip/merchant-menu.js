const menuCsvColumns=['name','category','price','description'];
const menuCsvHeaders={
  ar:['اسم الصنف','القسم','السعر','الوصف'], en:menuCsvColumns,
  ur:['نام','زمرہ','قیمت','تفصیل'], fa:['نام غذا','دسته','قیمت','توضیحات']
};

function csvFields(text) {
  const source=text.replace(/^\uFEFF/,'').replace(/\r\n?/g,'\n');
  const separator=source.split('\n',1)[0].includes(';') ? ';' : ',';
  const rows=[];let row=[],field='',quoted=false,closed=false;
  function addRow(){
    row.push(field.trim());
    if(row.some(cell=>cell!==''))rows.push(row);
    row=[];field='';closed=false;
  }
  for(let i=0;i<source.length;i++){
    const ch=source[i];
    if(quoted){
      if(ch!=='"')field+=ch;
      else if(source[i+1]==='"'){field+='"';i++;}
      else{quoted=false;closed=true;}
    }else if(ch===separator){row.push(field.trim());field='';closed=false;}
    else if(ch==='\n')addRow();
    else if(ch==='"'&&!field&&!closed)quoted=true;
    else if(ch==='"'||(closed&&ch.trim()))throw Error('csv');
    else field+=ch;
  }
  if(quoted)throw Error('csv');
  addRow();
  return rows;
}
function menuPrice(value){
  const s=latinDigits(String(value)).trim().replace('٫','.').replace(',','.');
  if(!/^\d{1,4}(?:\.\d{1,2})?$/.test(s))return null;
  const cents=Math.round(Number(s)*100);
  return cents>=100 && cents<=200000 ? cents : null;
}
function menuItemKey(item){return JSON.stringify([item.name,item.category].map(s=>s.trim().normalize('NFC').toLowerCase()));}
function parseMenuCsv(text){
  const [head,...rows]=csvFields(text);
  if(!head || !rows.length || rows.length>200)throw Error('csv');
  const cols=head.map(label=>menuCsvColumns.find((key,i)=>Object.values(menuCsvHeaders).some(headers=>headers[i]===label.toLowerCase())));
  if(cols.some(c=>!c)||new Set(cols).size!==cols.length||!['name','category','price'].every(k=>cols.includes(k)))throw Error('csv');
  return rows.map((line,i)=>{
    const record=Object.fromEntries(cols.map((k,j)=>[k,line[j]||'']));
    const price=menuPrice(record.price),description=record.description||'';
    if(line.length!==head.length||!record.name||!record.category||record.name.length>100||record.category.length>50||description.length>400||price===null)throw Error('row-'+(i+2));
    return {name:record.name,category:record.category,description,price_cents:price,is_available:true};
  });
}
function menuToAdd(rows,existing){
  const known=new Set(existing.map(menuItemKey));
  return rows.filter(row=>{
    const key=menuItemKey(row);
    if(known.has(key))return false;
    known.add(key);return true;
  });
}
function merchantCsvForm(branch){
  const file=merchantImport?.branch===branch.id?merchantImport:null;
  const existing=menus().filter(m=>m.restaurant_id===branch.id);
  const count=file?menuToAdd(file.rows,existing).length:0;
  return '<form id="merchant-csv" data-branch="'+esc(branch.id)+'"><h3>رفع ملف المنيو</h3><p>نزّل النموذج، عبّئ الأصناف والأسعار بالدرهم، ثم ارفع ملف CSV.</p>'+
    '<button type="button" class="text-button" data-menu-template>تنزيل نموذج المنيو</button><div class="field"><label for="menu-file">ملف المنيو</label><input id="menu-file" type="file" accept=".csv,text/csv"></div>'+
    (file?'<p>'+localeMessage('merchant.importCount',{count:number(count),total:number(file.rows.length)})+'</p>':'')+
    '<button class="merchant-primary" type="submit"'+(!count?' disabled':'')+'>تأكيد إضافة الأصناف</button><p role="status" aria-live="polite"></p></form>';
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-menu-template]');if(!b)return;
  const blob=new Blob(['\ufeff'+(menuCsvHeaders[APP_LANGUAGE]||menuCsvColumns).join(',')+'\r\n'],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob),link=document.createElement('a');
  link.href=url;link.download='Tawfeer-Menu.csv';document.body.appendChild(link);link.click();link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
});
document.addEventListener('change',async e=>{
  if(e.target.id!=='menu-file')return;
  const input=e.target,file=input.files[0],form=input.form,branch=selectMerchantBranch(ownMerchantBranches());
  if(!menuWritable(branch)||form.dataset.branch!==branch.id)return;
  const epoch=workspaceEpoch;merchantImport=null;form.querySelector('[type="submit"]').disabled=true;
  if(!file)return;
  try{
    if(file.size>1024*1024)throw Error('csv');
    const rows=parseMenuCsv(await file.text());
    if(epoch!==workspaceEpoch||!form.isConnected||input.files[0]!==file)return;
    merchantImport={branch:branch.id,rows};render('merchant');
    document.querySelector('#merchant-csv [type="submit"]')?.focus();
  }catch(err){
    if(!form.isConnected||input.files[0]!==file)return;
    form.querySelector('[role="status"]').textContent=err.message.startsWith('row-')?localeMessage('merchant.badRow',{row:err.message.slice(4)}):'تعذّرت قراءة الملف. استخدم نموذج CSV وأضف من صنف واحد إلى 200 صنف.';
  }
});
async function reloadMerchantMenu(form,epoch,message){
  try{if(!previewRole)await refreshLiveWorkspace();}
  catch{if(epoch===workspaceEpoch)toast('تم الحفظ. أعد تحديث اللوحة لعرض آخر التغييرات.');return;}
  if(epoch!==workspaceEpoch)return;
  if(form.isConnected && current==='merchant')render('merchant');
  toast(message);
}
document.addEventListener('submit',async e=>{
  const form=e.target;if(form.id!=='merchant-csv')return;
  e.preventDefault();
  const branch=selectMerchantBranch(ownMerchantBranches()),batch=merchantImport;
  if(!batch||!menuWritable(branch)||batch.branch!==branch.id||form.dataset.branch!==branch.id||form.dataset.busy==='true')return;
  const feedback=form.querySelector('[role="status"]'),submit=form.querySelector('[type="submit"]'),epoch=workspaceEpoch;
  form.dataset.busy='true';submit.disabled=true;
  try{
    let existing=menus().filter(m=>m.restaurant_id===branch.id),client;
    if(!previewRole){
      client=await getKodClient();
      const result=await allWorkspaceRows(()=>client.from('kod_menu_items').select('id,name,category').eq('restaurant_id',branch.id).order('id'),epoch);
      if(result.error)throw result.error;
      existing=result.data;
    }
    if(epoch!==workspaceEpoch||!form.isConnected)return;
    const incoming=menuToAdd(batch.rows,existing).map(row=>({...row,restaurant_id:branch.id}));
    if(incoming.length){
      if(previewRole)previewMenus.push(...incoming.map(row=>({...row,id:'demo-item-'+crypto.randomUUID()})));
      else{const result=await client.from('kod_menu_items').insert(incoming);if(result.error)throw result.error;}
    }
    if(epoch!==workspaceEpoch)return;
    merchantImport=null;
    await reloadMerchantMenu(form,epoch,localeMessage('merchant.savedItems',{count:number(incoming.length)}));
  }catch{
    if(epoch===workspaceEpoch)feedback.textContent='تعذّر حفظ المنيو. تحقّق من الاتصال وأعد المحاولة.';
  }finally{delete form.dataset.busy;submit.disabled=!merchantImport;}
});

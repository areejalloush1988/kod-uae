// Portal intent selects a workspace. Database roles and ownership still authorize every write.
const merchantPortalUrl = new URLSearchParams(location.search).get('portal') === 'restaurant';
let merchantEntry = merchantPortalUrl || ['#merchant','#partner'].includes(location.hash);
let merchantBranchId = '', merchantEditId = '', merchantImport = null;
const merchantSections = [
  ['overview','لوحة المطعم','home'], ['settings','الفروع والانضمام','store'],
  ['menu','إدارة المنيو','food'], ['orders','طلبات المطعم','bag']
];

function ownMerchantBranches() {
  if(previewRole==='merchant') return previewRestaurants.filter(r=>r.id==='shakeshack');
  if(!appIdentity || previewRole) return [];
  return liveWorkspace.restaurants.filter(r=>r.owner_id===appIdentity.id && !r.is_demo);
}
function merchantAccount() {
  if(previewRole) return previewRole==='merchant';
  if(appIdentity?.role==='merchant') return true;
  if(appIdentity?.role!=='customer') return false;
  return appIdentity.requestedType==='merchant' || liveWorkspace.profiles.some(p=>p.id===appIdentity.id && p.requested_account_type==='merchant') || ownMerchantBranches().length>0;
}
function restaurantShell() {
  return merchantAccount() || (merchantEntry && !previewRole && (!appIdentity || appIdentity.role==='customer'));
}
function merchantRoute(route) {
  if(!restaurantShell()) return route;
  if(['merchant','featured','cashier','account','auth','register','forgot','phone-code','reset-key','reset-password','change-password'].includes(route)) return route;
  return 'merchant';
}
function merchantAuth(route) {
  merchantEntry=true;
  authAccountType='merchant';
  navigate(route);
}
function merchantNav(mobile) {
  if(!appIdentity && !previewRole) return '<button data-go="merchant" class="active">'+icon('store')+'<span>بوابة المطاعم</span></button>';
  const links=merchantSections.map(([key,label,glyph])=>[key,label,glyph,'data-merchant-tab',current==='merchant' && merchantTab===key]);
  links.push(['featured','اشتراك المطعم','ticket','data-go',current==='featured']);
  if(!mobile) {
    if(currentRole()==='merchant')links.push(['cashier','خصم عند الكاشير','wallet','data-go',current==='cashier']);
    links.push(['account','إعدادات الحساب','user','data-go',current==='account']);
  }
  return links.map(([id,label,glyph,attr,selected])=>'<button '+attr+'="'+id+'"'+(selected?' class="active" aria-current="page"':'')+'>'+icon(glyph)+'<span>'+label+'</span></button>').join('');
}
function merchantEntryView() {
  return '<section class="merchant-entry"><div class="merchant-entry-intro"><div><h1>بوابة المطاعم</h1><p>انضم إلى توفير، أضف منيو فروعك وتابع طلبات زبائنك من لوحة واحدة.</p>'+
    '<div class="merchant-actions"><button class="merchant-primary" data-preview-role="merchant">معاينة لوحة المطعم</button><button class="merchant-secondary" data-merchant-auth="auth">دخول صاحب المطعم</button><button class="merchant-secondary" data-merchant-auth="register">إنشاء حساب مطعم</button></div></div>'+
    '<div class="merchant-entry-photo" aria-hidden="true">'+photo('lebanese-table','',true)+'</div></div>'+
    '<div class="merchant-entry-steps"><div>'+icon('store')+'<h2>سجّل فرعك</h2><p>أرسل بيانات الفرع وتابع حالة الاعتماد.</p></div>'+
    '<div>'+icon('food')+'<h2>أضف المنيو</h2><p>أضف الأصناف والأسعار أو ارفع ملف المنيو بعد اعتماد الفرع.</p></div>'+
    '<div>'+icon('ticket')+'<h2>اشتراك المطعم</h2><p>اختر الفرع واطلب ظهوره في إعلانات المطاعم.</p></div></div>'+
    '<button class="text-button" data-merchant-exit="home">العودة إلى تطبيق العملاء</button></section>';
}
function selectMerchantBranch(branches) {
  return branches.find(r=>r.id===merchantBranchId) || branches.find(r=>r.approved) || branches[0];
}
function menuWritable(branch) {
  return currentRole()==='merchant' && Boolean(branch?.approved) && ownMerchantBranches().some(r=>r.id===branch.id);
}
function merchantBranchSelect(own,branch) {
  if(!branch)return '';
  if(own.length===1)return '<p class="merchant-branch-line">'+icon('pin')+displayText(branch.name)+' · '+displayText(placeLabel(branch.city))+'</p>';
  return '<label class="merchant-branch-line">'+icon('pin')+' الفرع<select id="merchant-branch">'+own.map(r=>'<option value="'+esc(r.id)+'"'+(branch.id===r.id?' selected':'')+'>'+displayText(r.name)+' · '+displayText(placeLabel(r.city))+'</option>').join('')+'</select></label>';
}
function merchantLink(section,label) {
  return '<button class="merchant-secondary" data-merchant-tab="'+section+'">'+label+'</button>';
}
function merchantBranchState(branch) {
  return branch.approved?'فرع معتمد':'بانتظار اعتماد الإدارة';
}
function merchantOverview(branch) {
  const overview='<section class="merchant-start"><div>'+icon('store')+'<h2>'+(!branch?'ابدأ بتسجيل فرعك':merchantBranchState(branch))+'</h2><p>'+
    (!branch?'أضف عنوان الفرع وبيانات التواصل لتقديم طلب الانضمام.':branch.approved?'تقدر تدير منيو الفرع وتتابع طلباته من هون.':'استلمنا بيانات الفرع. بعد الاعتماد بتقدر تنشر المنيو وتطلب اشتراك المطعم.')+
    '</p></div>'+(branch?merchantLink('settings','بيانات الفرع'):merchantLink('settings','تسجيل الفرع'))+'</section>';
  if(!branch?.approved)return overview;
  const items=menus().filter(m=>m.restaurant_id===branch.id),pending=orders().filter(o=>o.restaurant_id===branch.id&&o.status==='pending');
  return overview+'<div class="merchant-shortcuts"><button data-merchant-tab="menu">'+icon('food')+'<strong>إدارة المنيو</strong><span>'+localeMessage('merchant.itemCount',{count:number(items.length)})+'</span></button>'+
    '<button data-merchant-tab="orders">'+icon('bag')+'<strong>طلبات المطعم</strong><span>'+localeMessage('merchant.pendingOrders',{count:number(pending.length)})+'</span></button>'+
    '<button data-go="featured">'+icon('ticket')+'<strong>اشتراك المطعم</strong><span>الإعلانات والفواتير</span></button></div>'+deskLink();
}
function merchantBranches(own,branch) {
  if(!branch)return onboardingView();
  const operation=menuWritable(branch)?'<div class="settings-row"><span>استقبال الطلبات</span><button class="availability '+(branch.is_open?'available':'')+'" data-toggle-restaurant="'+esc(branch.id)+'">'+(branch.is_open?'مفتوح للطلبات':'متوقف مؤقتاً')+'</button></div>':'';
  return '<section class="box merchant-settings"><h2>بيانات الفرع</h2><div class="settings-row"><span>اسم المطعم</span><strong>'+displayText(branch.name)+'</strong></div>'+
    '<div class="settings-row"><span>حالة طلب الانضمام</span><strong>'+merchantBranchState(branch)+'</strong></div>'+operation+
    (branch.approved?'<div class="settings-row"><span>رسوم التوصيل</span><strong>'+money(branch.delivery_fee_cents)+'</strong></div>':'')+'</section>'+
    editContactPanel(branch)+(menuWritable(branch)?ratePanel(branch):'')+
    (!previewRole?'<details class="merchant-add-branch"><summary>إضافة فرع آخر</summary>'+onboardingView()+'</details>':'');
}
function merchantMenu(branch) {
  if(!menuWritable(branch))return '<section class="box merchant-hold"><h2>إدارة المنيو</h2><p>تقدر تضيف الأصناف والأسعار بعد اعتماد الفرع.</p>'+merchantLink('settings',branch?'متابعة طلب الانضمام':'تسجيل الفرع')+'</section>';
  const items=menus().filter(m=>m.restaurant_id===branch.id);
  const edit=items.find(m=>m.id===merchantEditId);
  return '<section class="box merchant-menu"><div class="section-head"><h2>أصناف المنيو</h2><strong>'+number(items.length)+'</strong></div>'+
    (items.length?'<ul class="merchant-items">'+items.map(m=>'<li><div><strong>'+displayText(m.name)+'</strong><small>'+displayText(m.category)+' · '+money(m.price_cents)+'</small></div><button class="text-button" data-merchant-edit="'+esc(m.id)+'">تعديل</button>'+
      '<button class="availability '+(m.is_available?'available':'')+'" data-toggle-item="'+esc(m.id)+'">'+(m.is_available?'متاح':'غير متاح')+'</button></li>').join('')+'</ul>':'<p>المنيو فارغ. أضف أول صنف أو ارفع ملفاً.</p>')+
    '</section><div class="merchant-menu-tools"><section class="box">'+menuCreateForm([branch],edit)+'</section><section class="box">'+merchantCsvForm(branch)+'</section></div>';
}
function merchantOrders(branch) {
  if(!branch?.approved)return '<section class="box"><h2>طلبات المطعم</h2><p>تظهر الطلبات هنا بعد اعتماد الفرع وفتح استقبال الطلبات.</p>'+merchantLink('settings','بيانات الفرع')+'</section>';
  const items=orders().filter(o=>o.restaurant_id===branch.id);
  if(!items.length)return '<section class="box"><h2>طلبات المطعم</h2><p>لا توجد طلبات لهذا الفرع حالياً.</p>'+merchantLink('settings','إعدادات المطعم')+'</section>';
  return '<div class="merchant-board">'+Object.keys(ORDER_LABELS).map(status=>{
    const list=items.filter(o=>o.status===status);
    return list.length?'<section class="board-column"><h3>'+ORDER_LABELS[status]+' <span>'+number(list.length)+'</span></h3>'+list.map(o=>orderCard(o,true)).join('')+'</section>':'';
  }).join('')+'</div>';
}
function merchantDashboard() {
  if(isLiveOperator())return ownerRestaurantsView();
  if(!appIdentity && !previewRole)return merchantEntryView();
  if(!restaurantShell())return accessView('merchant');
  const own=ownMerchantBranches(),branch=selectMerchantBranch(own);
  const heading=workspaceHeader('لوحة المطعم','إدارة الفروع والمنيو واشتراك مطعمك.');
  const body=merchantTab==='menu'?merchantMenu(branch):merchantTab==='settings'?merchantBranches(own,branch):merchantTab==='orders'?merchantOrders(branch):merchantOverview(branch);
  const returnToApp=!merchantAccount()?'<button class="text-button" data-merchant-exit="home">العودة إلى تطبيق العملاء</button>':'';
  return '<div class="merchant-dashboard">'+heading+returnToApp+merchantBranchSelect(own,branch)+workspaceTabs('merchant',merchantSections,merchantTab)+
    (orderDataStatus==='error'&&!previewRole?'<p class="inline-notice" role="status">تعذّر تحديث بيانات الفروع. <button class="text-button" data-merchant-refresh>إعادة المحاولة</button></p>':'')+body+'</div>';
}
document.addEventListener('click',async event=>{
  const b=event.target.closest('button');if(!b)return;
  if(b.dataset.merchantAuth){merchantAuth(b.dataset.merchantAuth);return;}
  if(b.hasAttribute('data-merchant-refresh')){
    b.disabled=true;
    try{await refreshLiveWorkspace();}catch{}finally{if(current==='merchant')render('merchant');}
  }
  if(b.hasAttribute('data-merchant-edit')){
    merchantEditId=b.dataset.merchantEdit;
    render('merchant');
    document.getElementById('new-item-name')?.focus();
  }
});
document.addEventListener('change',event=>{
  if(event.target.id!=='merchant-branch')return;
  merchantBranchId=event.target.value;merchantEditId='';merchantImport=null;render('merchant');
});
document.addEventListener('click',event=>{
  if(event.target.closest('[data-google-entry]') && restaurantShell())writePromo('tawfeer-merchant-oauth-until',Date.now()+30*60*1000);
  const exit=event.target.closest('[data-merchant-exit]');
  if(exit&&!previewRole&&!merchantAccount()){
    merchantEntry=false;authAccountType='customer';writePromo('tawfeer-merchant-oauth-until',null);
    navigate(exit.dataset.merchantExit==='register'?'register':'discover');
  }
});

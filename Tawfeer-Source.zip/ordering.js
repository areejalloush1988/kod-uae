const PRACTICE_VENUE = {id:'kod-order-demo',name:'مطبخ توفير التجريبي',is_demo:true,is_open:true,approved:true,percent:0,minimum_order_cents:0,delivery_fee_cents:700,photo:'grill'};
const PRACTICE_MENU = [
  ['grill','شيش طاووق','دجاج مشوي مع الخبز والثوم','أطباق رئيسية',3400],
  ['indian','برياني دجاج','أرز بسمتي بالدجاج والبهارات','أطباق رئيسية',2900],
  ['italian','بيتزا مارغريتا','طماطم وموزاريلا وريحان','أطباق رئيسية',3200],
  ['shawarma','ساندويتش شاورما','شاورما دجاج مع المخلل','ساندويتشات',1600],
  ['cafe','لاتيه ساخن','إسبريسو مع الحليب','مشروبات',1800],
  ['karak','شاي كرك','شاي بالحليب والهيل','مشروبات',600]
].map(([photo,name,description,category,price_cents])=>({id:'sample-'+photo,restaurant_id:PRACTICE_VENUE.id,name,description,category,price_cents,photo,is_available:true}));
let orderContact={},lastReceipt=null,guestCheckout=null,orderDataStatus='loading';
try{activeRestaurant=sessionStorage.getItem('kod-menu')||activeRestaurant;}catch{}
function venueForOrder(id){return id===PRACTICE_VENUE.id?PRACTICE_VENUE:directVenues.get(id)||restaurants().find(r=>r.id===id)||featuredBranchById(id);}
function menuForOrder(id){return id===PRACTICE_VENUE.id?PRACTICE_MENU:directVenues.get(id)?.menu||menus().filter(m=>m.restaurant_id===id);}
function itemForOrder(id){return directItems.get(id)||PRACTICE_MENU.find(m=>m.id===id)||menus().find(m=>m.id===id);}
function canOrderAt(r){if(r?.direct)return availableDirect(r);return Boolean(r?.approved&&r.is_open&&(r===PRACTICE_VENUE||previewRole||(!r.is_demo&&liveWorkspace.settings.ordering_enabled)));}
function canCancelOwn(o){return previewRole?previewRole==='customer':Boolean(appIdentity&&appIdentity.id===o.customer_id);}
function orderCount(){return cart?.lines?.reduce((total,line)=>total+line.quantity,0)||0;}
function venuePhoto(r){return r.photo||({coffee:'cafe',cafe:'cafe',cafeteria:'karak'}[r.category])||'feast';}
function liveVenues(){
  return restaurants().filter(r=>canOrderAt(r)&&menuForOrder(r.id).some(i=>i.is_available)&&(state.city==='all'||state.city===r.city));
}
function orderingBranches(){
  const rows=[...directVenues.values()].filter(r=>!r.offer&&(state.city==='all'||state.city===r.city));
  return rows.sort((a,b)=>Number(Boolean(b.contact.whatsapp))-Number(Boolean(a.contact.whatsapp)));
}
function orderHero(){
  return '<section class="order-hero"><div class="order-hero-image">'+photo('lebanese-table','',true)+'</div><div class="order-hero-copy">'+
    '<h1>'+localeMessage('order.hungryToday',{lineBreak:'<br><em>'})+'</em></h1><p>اختر المطعم واطلب من منيو الفرع.</p><div class="order-hero-actions">'+
    '<button class="order-primary" data-go="food">'+icon('food')+' اطلب الآن</button><button class="order-secondary" data-go="membership">'+icon('wallet')+' بطاقة عضويتي</button></div></div></section>';
}
function nativeTile(r){
  return '<article class="order-tile direct-tile"><div class="order-tile-photo">'+photo(venuePhoto(r))+'</div><div class="order-tile-info"><span>'+displayText(placeLabel(r.city||''))+' · '+(r.is_demo?'تجربة':'الطلب داخل توفير')+'</span><h3>'+displayText(r.name)+'</h3><p>الحد الأدنى '+money(r.minimum_order_cents)+' · توصيل '+money(r.delivery_fee_cents)+'</p><button class="order-tile-action" data-restaurant-info="'+esc(r.id)+'" aria-label="'+localeMessage('order.viewVenue',{name:displayText(r.name)})+'">عرض وطلب '+icon('arrow')+'</button></div></article>';
}
function sampleLink(){
  return '<button class="order-sample" data-menu="'+PRACTICE_VENUE.id+'"><span class="order-sample-icon">'+icon('bag')+'</span><span><strong>جرّب الطلب داخل توفير</strong><small>منيو وسلّة وتأكيد طلب تجريبي</small></span>'+icon('arrow')+'</button>';
}
function orderHighlights(){
  const native=liveVenues(),branches=orderingBranches();
  const cards=[...native.slice(0,3).map(nativeTile),...branches.slice(0,Math.max(0,3-native.length)).map(directCard)];
  return '<section class="order-home-shelf"><div class="shelf-heading"><h2>من وين بدك تطلب؟</h2><button class="section-link" data-go="food">كل المطاعم للطلب '+icon('arrow')+'</button></div>'+
    (cards.length?'<div class="order-tiles">'+cards.join('')+'</div>':'<p>ما في فروع للطلب ضمن الإمارة المحددة حالياً. <button class="text-button" data-order-all>اعرض كل الإمارات</button></p>')+sampleLink()+'</section>';
}
function foodView(){
  const native=liveVenues(),branches=orderingBranches();
  const cards=native.map(nativeTile).concat(branches.map(directCard));
  return '<div class="order-store"><header class="order-page-head"><div><h1>اطلب من المطعم</h1><p>افتح إعلان الفرع، اختر الصنف وأضفه إلى سلّتك.</p></div><button class="order-cart-pill" data-go="cart">'+icon('bag')+' سلّتي <b>'+orderCount()+'</b></button></header>'+
    (cards.length?'<div class="order-tiles">'+cards.join('')+'</div>':'<div class="empty"><p>ما في فرع للطلب بهالإمارة حالياً.</p><button class="btn" data-order-all>اعرض كل الإمارات</button></div>')+
    (orderDataStatus==='error'?'<button class="text-button" data-order-refresh>أعد تحميل الفروع المسجّلة</button>':'')+
    sampleLink()+'<button class="text-button" data-go="partner">'+icon('store')+' سجّل مطعمك لاستقبال الطلبات</button></div>';
}
function menuView(){
  const r=venueForOrder(activeRestaurant);if(!r||r.direct)return foodView();
  const items=menuForOrder(r.id),sample=r.is_demo,ready=canOrderAt(r);
  const count=cart?.restaurantId===r.id?orderCount():0;
  return '<button class="order-back" data-go="food">'+icon('arrow')+' مطاعم للطلب</button><section class="order-menu-head"><div><h1>'+displayText(r.name)+'</h1><p>'+(sample?'منيو بأسعار توضيحية. الطلب التجريبي ما بينرسل لأي مطعم.':displayText(placeLabel(r.city))+' · '+(ready?'يستقبل الطلبات':'الفرع لا يستقبل طلبات حالياً'))+'</p><p class="order-fees">توصيل '+money(r.delivery_fee_cents)+' <i>·</i> استلام من المطعم مجاناً</p></div>'+photo(venuePhoto(r))+'</section>'+
    '<div class="menu-layout"><section class="box order-menu-list">'+[...new Set(items.map(m=>m.category))].map(category=>
      '<h2>'+displayText(category)+'</h2>'+items.filter(m=>m.category===category).map(m=>{
        const quantity=cart?.lines.find(l=>l.itemId===m.id)?.quantity||0;
        return '<article class="order-dish">'+(m.photo?photo(m.photo):'')+'<div><h3>'+displayText(m.name)+'</h3><p>'+displayText(m.description||'')+'</p><strong>'+money(m.price_cents)+'</strong></div><button class="dish-add" data-add-item="'+esc(m.id)+'" aria-label="'+localeMessage('cart.addNamedItem',{item:displayText(m.name)})+'" '+(!m.is_available||!ready?'disabled':'')+'>'+(!m.is_available?'غير متاح':quantity?'إضافة + ('+quantity+')':'إضافة +')+'</button></article>';
      }).join('')).join('')+(!items.length?'<p>لا توجد أصناف على المنيو حالياً.</p>':'')+'</section><aside class="box cart-mini"><h3>'+icon('bag')+' سلّتي</h3><p>'+(count?number(count)+' في السلة':'اختر أول صنف من المنيو')+'</p><button class="btn full" data-go="cart">راجع السلة</button></aside></div>';
}
function cartQuote(r){
  const member=liveWorkspace.memberships.find(m=>m.user_id===appIdentity?.id);
  const tier=r.is_demo?(state.membership?'bronze':null):activeClubTier(liveWorkspace.card||member);
  return quoteCart(cart.lines,menuForOrder(r.id),clubDiscount(r.percent,r,tier),r.delivery_fee_cents,cart.method);
}
function summaryRows(q,method){
  return '<div><span>الأصناف</span><strong>'+money(q.subtotal_cents)+'</strong></div>'+(q.discount_cents?'<div class="discount-row"><span>خصم العضوية</span><strong>− '+money(q.discount_cents)+'</strong></div>':'')+
    '<div><span>'+(method==='pickup'?'الاستلام من المطعم':'رسوم التوصيل')+'</span><strong>'+money(q.delivery_fee_cents)+'</strong></div><div class="checkout-total"><span>الإجمالي</span><strong>'+money(q.total_cents)+'</strong></div>';
}
function cartLine(line,items){
  const item=items.find(i=>i.id===line.itemId),name=displayText(item?.name||'صنف لم يعد متوفراً');
  return '<div class="cart-line"><div><strong>'+name+'</strong><p>'+(item?.is_available?displayPrice(item)+(Number.isInteger(item.price_cents)?' للصنف':''):'غير متاح')+'</p></div><div class="quantity">'+
    '<button data-cart-qty="'+esc(line.itemId)+'" data-delta="-1" aria-label="'+localeMessage('cart.decreaseNamedQuantity',{item:name})+'">−</button><span>'+number(line.quantity)+'</span><button data-cart-qty="'+esc(line.itemId)+'" data-delta="1" aria-label="'+localeMessage('cart.increaseNamedQuantity',{item:name})+'" '+(!item?.is_available||line.quantity>=20?'disabled':'')+'>+</button></div><strong>'+(Number.isInteger(item?.price_cents)?money(item.price_cents*line.quantity):'—')+'</strong></div>';
}
function checkoutFields(r){
  if(r.is_demo)return '<p class="inline-notice">هذا طلب تجريبي. ما في داعي تدخل بياناتك أو تدفع أي مبلغ.</p><input type="hidden" name="notes" value="">';
  if(!appIdentity)return '';
  const val=(key,fallback='')=>esc(orderContact[key]??fallback);
  return '<div class="field"><label for="order-name">الاسم على الطلب</label><input id="order-name" name="customer_name" autocomplete="name" maxlength="60" value="'+val('customer_name',appIdentity.name)+'" required></div>'+
    '<div class="field"><label for="order-phone">رقم الموبايل</label><input id="order-phone" name="contact_phone" type="tel" autocomplete="tel" dir="ltr" placeholder="05X XXX XXXX" value="'+val('contact_phone',appIdentity.phone)+'" required></div>'+
    (cart.method==='delivery'?'<div class="field"><label for="order-address">عنوان التوصيل</label><input id="order-address" name="delivery_address" autocomplete="street-address" minlength="5" maxlength="300" placeholder="المنطقة، المبنى، رقم الشقة" value="'+val('delivery_address')+'" required></div>':'')+
    '<div class="field"><label for="order-notes">ملاحظة للمطعم (اختياري)</label><textarea id="order-notes" name="notes" maxlength="300" rows="2">'+val('notes')+'</textarea></div>';
}
function cartView(){
  if(!cart?.lines?.length)return '<div class="empty order-empty">'+icon('bag')+'<h1>سلّتك فارغة</h1><p>اختر مطعماً وأضف الوجبات من المنيو.</p><button class="btn" data-go="food">اطلب الآن</button></div>';
  const r=venueForOrder(cart.restaurantId);
  if(!r)return '<div class="empty"><h2>منيو المطعم غير متاح</h2><button class="btn" data-go="food">ارجع إلى المطاعم</button></div>';
  if(r.direct)return directCartView(r);
  const items=menuForOrder(r.id);let q,issue='';
  try{q=cartQuote(r);}catch{issue='أزل الأصناف غير المتاحة من السلة للمتابعة.';}
  if(!canOrderAt(r))issue='المطعم لا يستقبل الطلبات حالياً.';
  else if(q&&q.subtotal_cents<r.minimum_order_cents)issue=localeMessage('cart.minimumSubtotal',{amount:money(r.minimum_order_cents)});
  const guest=!appIdentity&&!r.is_demo&&!previewRole;
  return '<button class="order-back" data-menu="'+esc(r.id)+'">'+icon('arrow')+' العودة إلى المنيو</button><header class="order-page-head"><div><h1>راجع طلبك</h1><p>'+displayText(r.name)+'</p></div></header>'+
    '<div class="checkout-layout"><section class="box"><h2>طريقة الاستلام</h2><div class="method-switch fulfillment">'+['delivery','pickup'].map(m=>'<button data-fulfillment="'+m+'" aria-pressed="'+(cart.method===m)+'" class="'+(cart.method===m?'active':'')+'">'+icon(m==='delivery'?'car':'store')+' '+(m==='delivery'?'توصيل':'استلام من المطعم')+'</button>').join('')+'</div>'+
    cart.lines.map(l=>cartLine(l,items)).join('')+'<button class="text-button" data-menu="'+esc(r.id)+'">أضف أصنافاً من المنيو</button></section>'+
    '<aside class="box checkout-summary order-checkout"><h2>ملخص الطلب</h2>'+(q?summaryRows(q,cart.method):'')+
    '<form id="checkout-form" data-expected="'+(q?q.total_cents:'')+'">'+checkoutFields(r)+
    (!r.is_demo?'<p class="order-payment">الدفع للمطعم عند استلام الطلب.</p>':'')+'<p id="checkout-error" class="error" role="alert">'+issue+'</p>'+
    (guest?'<button class="btn full" type="button" data-checkout-login '+(issue?'disabled':'')+'>سجّل الدخول وأكمل الطلب</button>':'<button class="btn full" type="submit" '+(placingOrder||issue?'disabled':'')+'>'+(r.is_demo?'تأكيد طلب تجريبي':'أرسل الطلب للمطعم')+'</button>')+'</form></aside></div>';
}
function clearGuestCheckout(){
  guestCheckout=null;
  try{sessionStorage.removeItem('kod-guest-checkout');}catch{}
}
function basketKey(uid){return 'kod-basket-v1-'+(uid||'guest');}
function saveBasket(){
  if(previewRole)return;
  const key=basketKey(appIdentity?.id);
  try{
    if(!cart?.lines?.length){sessionStorage.removeItem(key);return;}
    const {restaurantId,method,requestId,lines}=cart;
    sessionStorage.setItem(key,JSON.stringify({restaurantId,method,requestId,lines:lines.map(l=>({itemId:l.itemId,quantity:l.quantity})),expires:Date.now()+4*60*60*1000}));
  }catch{}
}
function restoreBasket(uid){
  if(cart||previewRole)return;
  try{
    const saved=JSON.parse(sessionStorage.getItem(basketKey(uid)));
    if(!saved||saved.expires<Date.now()||!fulfillmentMethods(venueForOrder(saved.restaurantId)).includes(saved.method)||!Array.isArray(saved.lines)||!saved.lines.length||saved.lines.length>20)return;
    if(!saved.lines.every(l=>typeof l.itemId==='string'&&Number.isInteger(l.quantity)&&l.quantity>0&&l.quantity<=20)||!venueForOrder(saved.restaurantId))return;
    cart={restaurantId:saved.restaurantId,method:saved.method,requestId:saved.requestId,lines:saved.lines};
  }catch{}
}
function rememberGuestCheckout(){
  if(appIdentity||previewRole||!cart?.lines.length||!canOrderAt(venueForOrder(cart.restaurantId)))return false;
  guestCheckout={expires:Date.now()+30*60*1000,restaurantId:cart.restaurantId,lines:cart.lines.map(l=>({itemId:l.itemId,quantity:l.quantity})),method:cart.method,requestId:cart.requestId};
  try{sessionStorage.setItem('kod-guest-checkout',JSON.stringify(guestCheckout));}catch{}
  return true;
}
function resumeGuestCheckout(){
  if(!appIdentity||appIdentity.role==='developer_locked')return false;
  let draft=guestCheckout;
  if(!draft){try{draft=JSON.parse(sessionStorage.getItem('kod-guest-checkout'));}catch{}}
  clearGuestCheckout();
  if(!draft||draft.expires<Date.now()||!Array.isArray(draft.lines)||!draft.lines.length||draft.lines.length>20||!['delivery','pickup'].includes(draft.method))return false;
  const r=venueForOrder(draft.restaurantId);if(!r||r.is_demo)return false;
  cart={restaurantId:r.id,lines:draft.lines.map(l=>({itemId:l.itemId,quantity:l.quantity})),method:draft.method,requestId:crypto.randomUUID()};activeRestaurant=r.id;saveBasket();
  try{sessionStorage.removeItem(basketKey(null));}catch{}
  return true;
}
function practiceOrderLink(){return lastReceipt?.practice?'<p class="inline-notice"><button class="text-button" data-go="receipt">عرض إيصال الطلب التجريبي</button></p>':'';}
function receiptView(){
  const o=lastReceipt;
  if(!o||(!o.practice&&o.customer_id!==appIdentity?.id))return ordersView();
  const latest=o.practice?o:orders().find(row=>row.id===o.id)||o;
  const label=o.practice?'تجربة مكتملة':ORDER_LABELS[latest.status]||'بانتظار قبول المطعم';
  return '<section class="order-receipt box"><div class="receipt-check">'+icon('check')+'</div><h1>'+(o.practice?'اكتملت تجربة الطلب':'تم إرسال طلبك')+'</h1>'+
    '<p>'+(o.practice?'هذا إيصال تجريبي. ما انبعت طلب للمطعم وما عليك أي مبلغ.':displayText(latest.restaurant_name)+' · '+label)+'</p><div class="receipt-id"><span>رقم الطلب'+(o.practice?' التجريبي':'')+'</span><b dir="ltr">'+displayText(o.practice?o.id:tawfeerReference(o.id))+'</b></div>'+
    '<h2>'+displayText(o.restaurant_name)+'</h2><p>'+o.items.map(i=>displayText(i.name)+' × '+number(i.quantity)).join(' · ')+'</p><div class="checkout-summary">'+summaryRows(o,o.fulfillment)+'</div>'+
    (!o.practice?'<button class="btn full" data-track-order="'+esc(o.id)+'">تابع حالة الطلب</button>':'')+'<button class="'+(o.practice?'btn full':'text-button')+'" data-go="food">العودة إلى المطاعم</button></section>';
}
const ORDER_ERRORS={
  restaurant_unavailable:'توقّف الفرع عن استقبال الطلبات. اختر مطعماً آخر.',
  ordering_not_enabled:'استقبال الطلبات متوقّف حالياً.',item_unavailable:'تغيّر توفّر أحد الأصناف. راجع السلّة قبل التأكيد.',
  price_changed:'تغيّر سعر الطلب. راجع الإجمالي الجديد وأكّد من جديد.',
  minimum_order_not_met:'لم يصل مجموع الأصناف إلى الحد الأدنى للفرع.',
  invalid_contact_details:'راجع الاسم ورقم الموبايل وعنوان التوصيل.',order_limit_exceeded:'تجاوزت قيمة الأصناف الحد المسموح للطلب.',
  authentication_required:'سجّل الدخول لإكمال الطلب.',customer_account_required:'سجّل الدخول بحساب مفعّل لإكمال الطلب.',
  idempotency_conflict:'سبق إرسال نسخة من هذا الطلب. راجع «طلباتي» قبل متابعة الطلب.'
};
async function checkoutSubmit(form){
  if(placingOrder||!cart?.lines?.length)return;
  const r=venueForOrder(cart.restaurantId),err=document.getElementById('checkout-error');
  if(r?.direct)return;
  if(!r||!canOrderAt(r)){err.textContent=ORDER_ERRORS.restaurant_unavailable;return;}
  if(previewRole&&r!==PRACTICE_VENUE)return checkoutPreview(form);
  let q;try{q=cartQuote(r);}catch{err.textContent=ORDER_ERRORS.item_unavailable;return;}
  if(q.subtotal_cents<r.minimum_order_cents){err.textContent=ORDER_ERRORS.minimum_order_not_met;return;}
  const expected=Number(form.dataset.expected);
  if(expected!==q.total_cents){render('cart');document.getElementById('checkout-error').textContent=ORDER_ERRORS.price_changed;return;}
  const practice=r===PRACTICE_VENUE;
  if(!practice&&!appIdentity){if(rememberGuestCheckout())navigate('auth');return;}
  const values=form.elements,phone=practice?'':normalizedPhone(values.contact_phone.value);
  if(!practice&&!phone){err.textContent='أدخل رقم موبايل صحيحاً. يمكنك البدء بـ 05 أو +971.';return;}
  const epoch=workspaceEpoch,button=form.querySelector('[type=submit]'),basket=cart;
  placingOrder=true;button.disabled=true;err.textContent='';
  try{
    let receipt;
    if(practice){
      receipt={practice:true,id:'DEMO-'+crypto.randomUUID().slice(0,8).toUpperCase(),restaurant_name:r.name,fulfillment:basket.method,
        items:basket.lines.map(l=>({name:itemForOrder(l.itemId).name,quantity:l.quantity})),...q};
    }else{
      const c=await getKodClient();if(epoch!==workspaceEpoch||basket!==cart)return;
      const {data,error}=await c.rpc('kod_checkout_order',{
        p_restaurant_id:r.id,p_lines:basket.lines.map(l=>({item_id:l.itemId,quantity:l.quantity})),p_fulfillment:basket.method,
        p_customer_name:values.customer_name.value.trim(),p_contact_phone:phone,p_delivery_address:basket.method==='delivery'?values.delivery_address.value.trim():'',
        p_notes:values.notes.value.trim(),p_request_id:basket.requestId,p_expected_total:expected
      });
      if(error)throw error;
      if(epoch!==workspaceEpoch)return;
      receipt=Array.isArray(data)?data[0]:data;
      if(!receipt?.id||receipt.customer_id!==appIdentity?.id)throw Error('invalid_order_response');
      liveWorkspace.orders=liveWorkspace.orders.filter(o=>o.id!==receipt.id).concat(receipt);
    }
    if(epoch!==workspaceEpoch)return;
    lastReceipt=receipt;cart=null;saveBasket();orderContact={};orderFilter='all';clearGuestCheckout();navigate('receipt');
    if(!practice)refreshLiveWorkspace().catch(()=>{});
  }catch(error){
    if(epoch!==workspaceEpoch)return;
    const message=ORDER_ERRORS[error.message]||'تعذّر التحقّق من الإرسال. راجع «طلباتي» أو أعد المحاولة بنفس السلّة.';
    if(['price_changed','item_unavailable','restaurant_unavailable','minimum_order_not_met','ordering_not_enabled'].includes(error.message)){
      await refreshLiveWorkspace().catch(()=>{});
      if(epoch!==workspaceEpoch)return;
      if(current==='cart'){placingOrder=false;render('cart');}
    }
    const output=document.getElementById('checkout-error');if(output)output.textContent=message;
  }finally{if(epoch===workspaceEpoch){placingOrder=false;button.disabled=false;}}
}
document.addEventListener('input',e=>{
  const field=e.target;
  if(field?.form?.id==='checkout-form'&&appIdentity&&['customer_name','contact_phone','delivery_address','notes'].includes(field.name))orderContact[field.name]=field.value;
});
document.addEventListener('click',e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.hasAttribute('data-checkout-login')){if(rememberGuestCheckout())navigate('auth');}
  if(b.hasAttribute('data-order-all')){state.city='all';persist();navigate('food');}
  if(b.hasAttribute('data-order-refresh')){orderDataStatus='loading';render('food');refreshLiveWorkspace().catch(()=>{orderDataStatus='error';}).finally(()=>{if(current==='food')render('food');});}
});

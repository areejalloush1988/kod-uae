const cashLabels={review:'مكافآت قيد المراجعة',available:'متاح للصرف',requested:'صرف مطلوب',paid:'تم الصرف',void:'مكافأة ملغاة'};
function cashMetrics(rows){return '<div class="promo-metrics">'+rows.map(([value,label])=>'<div><strong>'+value+'</strong><span>'+label+'</span></div>').join('')+'</div>';}
function referralCashView(){
  const personal=hasPersonalCard(appIdentity?.role)&&!previewRole,info=personal?rewardInfo:null;
  let actions='';
  if(previewRole)actions='<p>اخرج من المعاينة لعرض دعوات حسابك.</p>';
  else if(info)actions=promoShareTools(promoHref('invite',info.code),'هاي دعوتي لعضوية توفير لخصومات المطاعم والمقاهي في الإمارات.');
  else if(personal)actions=rewardError?'<button class="btn light" data-reload-rewards>إعادة تحميل رابط الدعوة</button>':'<p role="status">جارٍ تحميل رابطك الشخصي…</p>';
  else if(appIdentity?.role==='merchant')actions='<button class="btn light" data-go="marketing">تسويق فرعي</button>';
  else actions='<button class="btn" data-card-login="rewards">سجّل الدخول للحصول على رابطك</button>';
  const banner='<section class="promo-invite"><div class="promo-invite-copy"><h1>ادعُ صديقاً واكسب 25 درهماً</h1><p>25 درهماً عن أول اشتراك مدفوع لكل صديق جديد. عدد الدعوات مفتوح.</p>'+actions+'</div><div class="promo-days">'+icon('wallet')+'<strong>'+number(25)+'</strong><span>درهم</span></div></section><p>بعد تأكيد الدفعة وانتهاء مهلة الاسترداد، تراجع توفير المكافأة وتتيح طلب صرفها.</p>';
  if(!info)return banner;
  const totals=cashMetrics([[number(info.joined),'أصدقاء سجّلوا'],[number(info.paid),'أصدقاء دفعوا'],...Object.entries(cashLabels).filter(([state])=>state!=='void'||info.void_fils).map(([state,label])=>[money(info[state+'_fils']||0),label])]);
  const previous=info.earned_days?'<p>دعوات سابقة بأيام عضوية'+' · '+number(info.earned_days)+'</p>':'';
  const request=info.available_fils>0?'<button class="btn" data-request-cash>طلب صرف المكافآت المتاحة</button>':'';
  return banner+totals+previous+'<section class="promo-box">'+request+'<button class="text-button" data-reload-rewards>تحديث المكافآت</button><p>تتابع توفير طلب الصرف عبر بيانات التواصل المسجلة في حسابك.</p><p id="cash-feedback" role="status"></p></section>';
}
function cashAdminPanel(){
  const a=partnerAdmin;
  const forms=(a.rows||[]).map(row=>{
    const action=(kind,label,attest,reference)=>'<form class="promo-form" data-cash-review="'+kind+'" data-order="'+esc(row.order_id)+'">'+(reference?'<label class="field">مرجع التحويل أو الاسترداد<input name="reference" minlength="3" maxlength="120" required></label>':'')+'<label><input type="checkbox" name="verified" required> '+attest+'</label><button class="btn light">'+label+'</button><p role="status"></p></form>';
    let operations='';
    if(row.state==='review')operations+=action('approve','اعتماد المكافأة','راجعت الدفعة وتحققت من انتهاء مهلة الاسترداد',false);
    if(row.state==='requested')operations+=action('pay','تسجيل الصرف','تأكدت من هوية العضو وحوّلت المبلغ فعلياً',true);
    if(['review','available','requested'].includes(row.state))operations+='<details><summary>تسجيل الاسترداد</summary>'+action('refund','تسجيل الاسترداد','تحققت من استرداد الدفعة الأصلية',true)+'</details>';
    return '<article class="cash-review"><h3>'+displayText(row.name||'حساب توفير')+' · '+money(row.amount_fils)+'</h3><p>'+cashLabels[row.state]+' · <bdi>'+displayText(row.contact||'لا توجد وسيلة تواصل موثقة متاحة.')+'</bdi></p><p>الدفعة الأصلية'+' · '+money(row.order_fils)+' · <bdi>'+displayText(row.payment_ref||row.order_id)+'</bdi></p>'+(row.payout_ref?'<p>رقم العملية'+' · <bdi>'+displayText(row.payout_ref)+'</bdi></p>':'')+operations+'</article>';
  }).join('');
  return '<section class="promo-box"><h2>مكافآت الدعوات</h2>'+cashMetrics([[money(a.due_fils||0),'إجمالي المكافآت المستحقة']])+(forms||'<p>لا توجد مكافآت بانتظار الإجراء.</p>')+(a.more?'<button class="btn light" data-cash-more>المزيد</button>':'')+'<button class="text-button" data-reload-partners>تحديث المكافآت</button></section>';
}
document.addEventListener('submit',async e=>{
  const f=e.target;if(!f.dataset.cashReview||!isLiveOperator())return;e.preventDefault();const b=e.submitter||f.querySelector('button'),epoch=workspaceEpoch;if(b.disabled)return;b.disabled=true;
  try{await cardRpc('kod_review_reward_cash',{p_order:f.dataset.order,p_action:f.dataset.cashReview,p_reference:f.elements.reference?.value.trim()||'',p_verified:f.elements.verified.checked});if(epoch===workspaceEpoch)await beginPartnerPage(true);}
  catch{if(epoch===workspaceEpoch)f.querySelector('[role="status"]').textContent='تعذّر تحديث المكافأة. راجع حالتها وحاول مجدداً.';}finally{b.disabled=false;}
});
document.addEventListener('click',async e=>{
  const b=e.target.closest?.('button');if(!b||b.disabled||previewRole||!appIdentity)return;const epoch=workspaceEpoch;
  if(b.hasAttribute('data-request-cash')){
    b.disabled=true;try{await cardRpc('kod_request_reward_cash',{});if(epoch===workspaceEpoch){await beginRewardsPage(true);toast('تم تسجيل طلبك.');}}
    catch{if(epoch===workspaceEpoch)toast('تعذّر تحديث المكافأة. راجع حالتها وحاول مجدداً.');}finally{b.disabled=false;}
  }
  if(b.hasAttribute('data-cash-more')&&isLiveOperator()&&partnerAdmin?.more){
    b.disabled=true;const a=partnerAdmin,last=a.rows.at(-1);
    try{const data=await cardRpc('kod_cash_review_page',{p_before:last.earned_at,p_order:last.order_id});if(epoch===workspaceEpoch&&partnerAdmin===a){a.rows.push(...data.rows);a.more=data.more;if(current==='marketing')render(current);}}
    catch{if(epoch===workspaceEpoch)toast('تعذّر تحديث المكافأة. راجع حالتها وحاول مجدداً.');}finally{b.disabled=false;}
  }
});

// Use the source logo geometry directly on exported images and both membership card faces.
function drawTawfeerLogo(context, x, y, width, ink) {
  const scale = width / tawfeerLogoArt.width;
  context.save();
  context.translate(x, y);
  context.scale(scale, scale);
  for (const part of tawfeerLogoArt.paths) {
    context.fillStyle = ink || part.fill;
    context.fill(new Path2D(part.d), 'evenodd');
  }
  context.restore();
}

const cardLogoBox = { x: 51, y: 53, width: 194 };
function cardLogoSvg(ink) {
  const { x, y, width } = cardLogoBox;
  const paths = tawfeerLogoArt.paths.map(part => '<path d="' + part.d + '"/>').join('');
  return '<g transform="translate(' + x + ' ' + y + ') scale(' + (width / tawfeerLogoArt.width) +
    ')" fill="' + ink + '" fill-rule="evenodd">' + paths + '</g>';
}

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const source = name => fs.readFileSync(path.join(root, name), 'utf8');
const base = 'https://example.test/kod-uae/';

function installPage({agent = 'Chrome/120', platform = '', touches = 0, embedded = false, app = false, hash = '', search = ''} = {}) {
  const winEvents = {}, docEvents = {}, registered = [];
  let sheet = '';
  const button = {hidden: true, addEventListener(event, listener) { this[event] = listener; }};
  const native = {hidden: true};
  const window = {
    isSecureContext: true, self: {}, matchMedia: () => ({matches: app}),
    addEventListener: (type, listener) => { winEvents[type] = listener; }
  };
  window.top = embedded ? {} : window.self;
  const document = {
    querySelector(selector) {
      if (selector === '[data-tawfeer-install]') return button;
      if (selector === '[data-tawfeer-native]') return sheet.includes('data-tawfeer-native') ? native : null;
      return sheet && selector === '.tawfeer-install-guide' ? {} : null;
    },
    addEventListener: (type, listener) => { docEvents[type] = listener; }
  };
  const navigator = {userAgent: agent, platform, maxTouchPoints: touches, serviceWorker: {register(url, options) {
    registered.push({url, scope: options.scope}); return Promise.resolve();
  }}};
  vm.runInNewContext(source('tawfeer-install.js'), {window, document, navigator, URLSearchParams,
    location: {protocol: 'https:', hash, search}, KOD_CONFIG: {publicAppUrl: base},
    showModal: markup => { sheet = markup; }, closeModal: () => { sheet = ''; }});
  return {button, winEvents, docEvents, registered, native, get sheet() { return sheet; }};
}

async function verifyInstall() {
  const manifest = JSON.parse(source('manifest.webmanifest'));
  for (const key of ['id', 'scope', 'start_url']) assert.equal(new URL(manifest[key], base).href, base);
  assert.equal(manifest.name, 'توفير');
  assert.equal(manifest.display, 'standalone');
  for (const icon of manifest.icons) {
    const actual = fs.readFileSync(path.join(root, icon.src));
    assert.equal(icon.sizes, actual.readUInt32BE(16) + 'x' + actual.readUInt32BE(20));
  }
  assert(manifest.icons.some(i => i.purpose === 'maskable'));
  const apple = installPage({agent: 'Mozilla/5.0 Macintosh Safari', platform: 'MacIntel', touches: 5, search: '?install=1'});
  assert(apple.sheet.includes('على iPhone وiPad') && apple.sheet.includes('فتح كتطبيق ويب'));
  assert.equal(apple.button.hidden, false);
  assert.equal(installPage({app: true, search: '?install=1'}).button.hidden, true);
  const embed = installPage({embedded: true, search: '?install=1'});
  assert(embed.sheet.includes(base + '?install=1') && embed.registered.length === 0);
  assert.equal(installPage({hash: '#cashier/0123456789012345', search: '?install=1'}).sheet, '');

  const chrome = installPage();
  assert.deepEqual(chrome.registered, [{url: './sw.js', scope: './'}]);
  let prompts = 0;
  chrome.winEvents.beforeinstallprompt({preventDefault() {}, prompt: async () => { prompts++; }, userChoice: Promise.resolve({outcome: 'dismissed'})});
  assert.equal(prompts, 0);
  await chrome.button.click();
  await chrome.button.click();
  assert.equal(prompts, 1);
  assert(chrome.sheet.includes('Chrome'));
  chrome.winEvents.appinstalled();
  assert(chrome.button.hidden && !chrome.sheet);
}

async function verifyWorker() {
  const handlers = {}, writes = [], removed = [], requests = [];
  const offline = base + 'offline.html';
  const cache = {add: async request => {writes.push(request.url);}, match: async key => key === offline ? new Response('offline') : undefined};
  const old = 'tawfeer-offline:/kod-uae/:previous';
  const caches = {open: async () => cache, keys: async () => [old, 'tawfeer-offline:/different/:1', 'other-product'], delete: async key => {removed.push(key);}};
  let network = true;
  const self = {registration: {scope: base}, clients: {claim: async () => {}}, skipWaiting: async () => {},
    addEventListener: (type, listener) => {handlers[type] = listener;}};
  vm.runInNewContext(source('sw.js'), {self, caches, Request, Response, URL, fetch: async req => {
    requests.push(req.url);
    if (!network) throw Error('offline');
    return new Response('network');
  }});
  let pending;
  for (const stage of ['install', 'activate']) { handlers[stage]({waitUntil: p => {pending = p;}}); await pending; }
  assert.deepEqual(writes, [offline]); assert.deepEqual(removed, [old]);
  const load = (url, mode = 'navigate', method = 'GET') => {
    let result;
    handlers.fetch({request: {url, mode, method}, respondWith: response => {result = response;}});
    return result;
  };
  for (const url of [base, base + 'index.html?subscription=test', base + 'city-dubai.html']) {
    assert.equal(await (await load(url)).text(), 'network');
  }
  network = false;
  assert.equal(await (await load(base + '?invite=test')).text(), 'offline');
  assert.equal(load(base + 'api/private'), undefined);
  assert.equal(load('https://external.test/account'), undefined);
  assert.equal(load('https://example.test/other/'), undefined);
  assert.equal(load(base + 'uae-dining.json', 'cors'), undefined);
  assert.equal(load(base, 'navigate', 'POST'), undefined);
  assert.deepEqual(writes, [offline]);
}
Promise.all([verifyInstall(), verifyWorker()]).then(() => console.log('PASS: installability, device guidance, hash isolation, and public-only offline fallback')).catch(e => { console.error(e); process.exitCode = 1; });

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname,'..');
const page = fs.readFileSync(path.join(root,'index.html'),'utf8');
const data = JSON.parse(page.match(/id="tawfeer-language-data">([\s\S]*?)<\/script>/)[1]);
const core = page.split('<script>')[1].split('</script>')[0].replace(/\nrender\(cardRoute\(\)\);[\s\S]*$/,'');
const maps = JSON.parse(fs.readFileSync(path.join(root,'uae-dining.json')));
const qr = fs.readFileSync(path.join(root,'assets/vendor/qrcode-generator-2.0.4.js'),'utf8');
const arabic = /[\u0621-\u064a]/u;
function makeApp(code) {
  const text = value => data[code]?.[value] ?? value;
  const values = new Map();
  const storage = {getItem:key=>values.get(key)??null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};
  const node = {hidden:false,style:{},classList:{toggle(){}},addEventListener(){},setAttribute(){},toggleAttribute(){},focus(){},scrollIntoView(){}};
  const sandbox = {TawfeerLanguage:{code,text,place:text,withLanguage:url=>url},fixture:maps,Intl,URL,URLSearchParams,crypto:require('node:crypto').webcrypto,
    sessionStorage:storage,localStorage:storage,location:{href:'https://app.test/',hash:'',search:''},setTimeout(){},clearTimeout(){},
    document:{getElementById:()=>node,querySelector:()=>null,querySelectorAll:()=>[],createElement:()=>node,addEventListener(){},body:{style:{}}},
    window:{addEventListener(){},scrollTo(){}},console};
  vm.createContext(sandbox);vm.runInContext(qr,sandbox);vm.runInContext(core,sandbox);
  return src=>vm.runInContext(src,sandbox);
}
for(const code of ['en','ur','fa']) {
  const catalog=JSON.parse(fs.readFileSync(path.join(root,'locales',code+'.json')));
  assert.deepEqual(Object.keys(catalog.messages).sort(),Object.keys(JSON.parse(fs.readFileSync(path.join(root,'locales/en.json'))).messages).sort());
  for(const [source,value] of Object.entries(catalog.messages)){
    assert.ok(typeof value==='string'&&value.trim(),source);
    assert.ok(!/[٠-٩۰-۹]/.test(value),code+': '+source);
  }
  for(const {source,translation} of Object.values(catalog.formats))assert.deepEqual((translation.match(/\{\w+\}/g)||[]).sort(),(source.match(/\{\w+\}/g)||[]).sort());
  const run=makeApp(code);
  assert.equal(run('APP_LANGUAGE'),code);
  assert.equal(run('localeDirection'),code==='en'?'ltr':'rtl');
  assert.ok(!/[٠-٩۰-۹]/.test(run('number(12345)')));
  assert.equal(run("CITIES.includes('دبي') && PROMO_AREAS.dubai==='دبي'"),true);
  assert.equal(run("state.city='دبي'; indexMapData(fixture).filter(p=>p.emirate===state.city).length"),maps.rows.filter(x=>x[5]==='دبي').length);
  run("state.city='all'");
  const views=['discover()','foodView()','authView()','authView(true)','forgotView()','resetKeyView()','passwordView()','navHtml(false)','subscriptionPage()','directoryPage()','dealsPage()','favorites()','rewardsPage()','marketingPage()','memberPage()','cashierPage()','featuredPage()','membershipPricingPage()','phoneCodeView()','liveSavingsView()','cartView()'];
  const extra=['merchantDashboard()','developerDashboard()','orderCard(previewOrders[0])','accountSettingsView()'];
  const all=[];
  for(const expr of [...views,...extra]){
    if(expr.startsWith('merchantDashboard'))run("previewRole='merchant'");
    if(expr.startsWith('developerDashboard'))run("previewRole='developer'");
    const fn=expr.split('(')[0];assert.equal(run('typeof '+fn),'function',fn);
    const result=run(expr);
    const visible=String(result).replace(/<script[\s\S]*?<\/script>/gi,'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ');
    if(code==='en') {
      const leftovers=visible.match(/[\u0621-\u064a][\u0600-\u06ff ]{1,48}/g)||[];
      if(leftovers.length) all.push([expr,...leftovers]);
    }
  }
  if(all.length) throw Error(JSON.stringify(all));
  run("authFeatures.phone=true;authFeatures.whatsapp=true;authFeatures.sms=true;authMethod='phone';phoneChallenge={kind:'signup',phone:'+971501234567',channel:'whatsapp'}");
  for(const expr of ['authView(true)','forgotView()']){
    const html=run(expr);
    assert.ok(html.includes(catalog.messages['طريقة إرسال رمز التحقق']));
    assert.ok(html.includes(catalog.messages['رسالة نصية (SMS)']));
    assert.ok(html.includes(catalog.messages['واتساب']));
  }
  assert.ok(run('phoneCodeView()').includes(catalog.messages['أدخل رمز واتساب المرسل إلى']));
  assert.equal(run("displayText('اسم الزبون')"),'اسم الزبون');
  assert.ok(run("localeMessage('cart.addNamedItem',{item:'TEST'})").includes('TEST'));
  if(code==='en'){
    const missing=run('indexMapData(fixture).filter(p=>/[\\u0621-\\u064a]/.test(p.name+" "+p.area)).map(p=>[p.name,p.area])');
    assert.deepEqual(Array.from(missing),[]);
  }
}
console.log('PASS: each locale renders UI, stores canonical emirates, localizes the complete map, preserves customer input, named parameters and Western digits.');

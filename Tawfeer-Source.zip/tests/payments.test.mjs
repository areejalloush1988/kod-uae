import assert from 'node:assert/strict';
const values=new Map([['SUPABASE_URL','https://kod-db.example.invalid'],['SUPABASE_SERVICE_ROLE_KEY','worker-fixture'],['SUPABASE_ANON_KEY','fixture']]);
globalThis.Deno={env:{get:key=>values.get(key)},serve(){}};
const {handle}=await import('../backend/functions/kod-payments/index.ts');
const id='53712486-ac49-44b5-98af-07ee787958e0';
const call=(action,body,token='')=>handle(new Request('https://kod.example.invalid/kod-payments/'+action,{method:'POST',headers:{'Content-Type':'application/json',Authorization:token?'Bearer '+token:''},body:JSON.stringify(body)}));
let methods={stripe:[],du:[],etisalat:[]},due=[],settled=[],stripeForm,carrierForm,amount=6900,checkId=null,paid=false,wrongAmount=false;
globalThis.fetch=async(url,opt)=>{
  if(url.endsWith('/auth/v1/user'))return Response.json({id,email:'fixture@example.invalid'});
  if(url.endsWith('/kod_my_role'))return Response.json('customer');
  if(url.endsWith('/kod_subscription_methods'))return Response.json(methods);
  if(url.endsWith('/kod_billing_availability?id=eq.1')){methods=JSON.parse(opt.body).methods;return new Response(null,{status:204});}
  if(url.endsWith('/kod_claim_payment_checks')){checkId=JSON.parse(opt.body);return Response.json(due);}
  if(url.endsWith('/kod_prepare_subscription'))return Response.json({id,state:'new',amount,lease:id});
  if(url.endsWith('/kod_attach_checkout'))return Response.json(true);
  if(url.endsWith('/kod_settle_subscription')){settled.push(JSON.parse(opt.body));return new Response(null,{status:204});}
  if(url==='https://api.stripe.com/v1/checkout/sessions'){stripeForm=opt.body;return Response.json({livemode:true,currency:'aed',amount_total:amount,id:'cs_live_fixture',url:'https://checkout.stripe.com/c/pay/fixture',expires_at:1950000000});}
  if(url==='https://api.stripe.com/v1/checkout/sessions/cs_live_fixture')return Response.json({id:'cs_live_fixture',status:'complete',object:'checkout.session',livemode:true,mode:'payment',payment_status:paid?'paid':'unpaid',client_reference_id:id,metadata:{kod_subscription:id},currency:'aed',amount_total:wrongAmount?1:amount,payment_intent:'pi_fixture'});
  if(url==='https://api.apaya.io/prod/api/tokens/request'){carrierForm=JSON.parse(opt.body);return Response.json({token:'fixture-token',checkoutUrl:'https://checkout.apaya.io/fixture-token',errorMessage:null});}
  if(url==='https://api.apaya.io/prod/api/tokens/checkstatus')return Response.json({errorMessage:null,tokenTypeId:4,transactions:[{status:'Success',detail:{data:{transactionStatus:'Success',transactionType:'SinglePayment',paymentType:1,currency:'AED',productId:202,providerId:4,merchantId:23,actionedAmount:189,passThrough:id,txId:'sample-tx',checkoutToken:'fixture-token'}}}]});
  throw Error('unhandled fixture destination');
};
const tick=async()=>assert.equal((await call('reconcile',{},'worker-fixture')).status,200);
assert.equal((await call('reconcile',{},'ordinary')).status,403);
assert.equal((await call('check-order',{order_id:id})).status,401);
await tick();assert.deepEqual(methods,{stripe:[],etisalat:[],du:[]});
values.set('KOD_STRIPE_SECRET_KEY','sk_test_fixture');await tick();assert.deepEqual(methods.stripe,[]);
values.set('KOD_STRIPE_SECRET_KEY','rk_live_fixture');await tick();assert.deepEqual(methods.stripe,[1,3,6,12]);
assert.equal((await call('checkout',{rail:'stripe',months:1,request_id:id})).status,401);
assert.equal((await call('checkout',{rail:'stripe',months:1,request_id:id,amount:1},'member')).status,200);
assert.equal(stripeForm.get('mode'),'payment');assert.equal(stripeForm.get('line_items[0][price_data][unit_amount]'),'6900');
due=[{id,rail:'stripe',amount_fils:6900,product_ref:'',checkout_ref:'cs_live_fixture'}];
await tick();assert.equal(settled.length,0);
paid=true;wrongAmount=true;assert.equal((await call('check-order',{order_id:id},'member')).status,503);assert.equal(settled.length,0);assert.deepEqual(checkId,{p_user:id,p_order:id});
wrongAmount=false;await tick();assert.equal(settled[0].p_payment,'pi_fixture');assert.equal(settled[0].p_fils,6900);
due=[];for(const [k,v] of Object.entries({KOD_APAYA_API_KEY:'fixture',KOD_APAYA_USER:'fixture',KOD_APAYA_PASSWORD:'fixture',KOD_APAYA_MERCHANT_ID:'23',KOD_APAYA_TOKEN_URL:'https://api.apaya.io/prod/api/tokens/request',KOD_APAYA_PRODUCTS:'{"du":{"3":"202"},"etisalat":{"1":"101"}}'}))values.set(k,v);
await tick();assert.deepEqual(methods.du,[3]);assert.equal((await call('checkout',{rail:'du',months:12,request_id:id},'member')).status,409);
amount=18900;assert.equal((await call('checkout',{rail:'du',months:3,request_id:id},'member')).status,200);
const params=Object.fromEntries(carrierForm.parameters.map(({key,value})=>[key,value]));assert.equal(params.pt,id);assert.equal(params.chargeAmount,'189');assert.equal(params.defaultProviderId,'4');
due=[{id,rail:'du',checkout_ref:'fixture-token',product_ref:'202',amount_fils:18900}];await tick();assert.equal(settled[1].p_rail,'du');
assert.equal((await call('checkout',{rail:'free',months:1,request_id:id},'member')).status,400);
console.log('PASS: protected checkout and worker, active rails by approved plan, provider-confirmed payment and matching owner, total, currency and operator; no external calls.');

const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
let source=fs.readFileSync(__dirname+'/../index.html','utf8').split('<script>')[1].split('</script>')[0];
source=source.replace(/\nrender\(cardRoute\(\)\);.*?\nif\(backendReady\(\)\).*?;\s*$/s,'');
const handlers={};
const sessionValues=new Map();
const nodes=new Map();
function node(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',style:{},hidden:false,value:'',classList:{toggle(){}},toggleAttribute(){},setAttribute(){},addEventListener(){},scrollIntoView(){},focus(){},select(){}});return nodes.get(id);}
const geoFixture=JSON.parse(fs.readFileSync(__dirname+'/../uae-dining.json','utf8'));
const sandbox={geoFixture,sessionStorage:{getItem:key=>sessionValues.get(key)??null,setItem:(key,value)=>sessionValues.set(key,value),removeItem:key=>sessionValues.delete(key)},console,Intl,Date,Math,Set,Map,JSON,Number,String,Promise,crypto:require('node:crypto').webcrypto,URL,URLSearchParams,localStorage:{getItem:()=>null,setItem(){}},document:{addEventListener:(name,fn)=>(handlers[name]??=[]).push(fn),getElementById:node,querySelectorAll:()=>[],body:{style:{},appendChild(){}},createElement:()=>node('new')},window:{addEventListener(){},scrollTo(){}},location:{hash:''},setTimeout:()=>0,clearTimeout(){}};
sandbox.submitThroughDocument=async form=>{
  const event={target:form,preventDefault(){}};
  for(const handler of handlers.submit)await handler(event);
};
vm.createContext(sandbox);vm.runInContext(fs.readFileSync(__dirname+'/../assets/vendor/qrcode-generator-2.0.4.js','utf8'),sandbox);vm.runInContext(source,sandbox);
vm.runInContext(`
const assert=(b,m)=>{if(!b)throw Error(m)};
const testMenu=[{id:'one',price_cents:3500,is_available:true},{id:'two',price_cents:1000,is_available:true}];
let q=quoteCart([{itemId:'one',quantity:2},{itemId:'two',quantity:1}],testMenu,25,700,'delivery');
assert(q.subtotal_cents===8000&&q.discount_cents===2000&&q.total_cents===6700,'discount and delivery total');
q=quoteCart([{itemId:'one',quantity:1}],testMenu,0,700,'pickup');assert(q.total_cents===3500&&q.delivery_fee_cents===0,'pickup excludes delivery');
for(const lines of [[],[{itemId:'missing',quantity:1}],[{itemId:'one',quantity:0}],[{itemId:'one',quantity:1.5}],[{itemId:'one',quantity:21}],[{itemId:'one',quantity:1},{itemId:'one',quantity:2}]]){let rejected=false;try{quoteCart(lines,testMenu,25,700,'delivery')}catch{rejected=true}assert(rejected,'invalid basket accepted');}
for(const id of ['abcd2345-6789-1234', 'KD-ABCD2345', 'KOD-ABCD2345', 'TAWFEER-ABCD2345']){
  assert(tawfeerReference(id)==='TAWFEER-ABCD2345','retain the order or invoice suffix under the current brand');
}
for(const label of ['عضو كود','KOD member','عضو کود','کوڈ کا رکن']){
  assert(cardPrintedName(label)==='عضو توفير','show the current member label for existing cards');
}
assert(backendReady(),'production backend must be configured');
assert(canRoute('customer','developer')===false&&canRoute('merchant','developer')===false,'developer access gate');
assert(developerDashboard().includes('ادخل بحسابك'),'direct developer route must not open');
assert(authView().includes('data-go="forgot"')&&authView().includes('autocomplete="current-password"'),'login and recovery');
assert(authView(true).includes('maxlength="6"')&&authView(true).includes('inputmode="numeric"')&&!authView(true).includes('name="full_name"'),'email and six digits are sufficient');
assert(pinPattern.test(latinDigits('٠٠١٢٣٤'))&&!pinPattern.test('12345a')&&!pinPattern.test('1234567'),'PIN shape and leading zeros');
assert(normalizedPhone('٠٥٠ ١٢٣ ٤٥٦٧')==='+971501234567'&&normalizedPhone('00971 50 1234567')==='+971501234567'&&!normalizedPhone('a123'),'phone formats');
assert(APP_ROUTES.has('forgot')&&APP_ROUTES.has('reset-key')&&APP_ROUTES.has('reset-password')&&APP_ROUTES.has('change-password'),'password routes');
assert(!authView(true).includes('data-preview-role="developer"')&&!authView().includes('operator-hint'),'guest login always has a password');
appIdentity={id:'pinned-owner',role:'developer_locked'};
assert(authView().includes('name="password"')&&!authView().includes('operator-pin'),'previous owner sessions return to email and password');
appIdentity={id:'pinned-owner',role:'developer'};
liveWorkspace={...freshWorkspace(),profiles:[{id:'client-a',account_role:'customer',full_name:'عميل تجريبي'}],contacts:[{user_id:'client-a',login_email:'example@example.invalid'}],restaurants:[{id:'venue-a',name:'مطعم تجريبي',city:'دبي'}]};
assert(canRoute('developer','dashboard')&&canRoute('developer','merchant')&&canRoute('developer','developer'),'owner reaches all areas');
assert(developerDashboard().includes('لوحة العملاء')&&developerDashboard().includes('لوحة المطاعم'),'owner navigation');
assert(customerDashboard().includes('example@example.invalid'),'owner sees registered customer data');
ownerCustomerId='client-a';assert(customerDashboard().includes('طلبات العميل'),'per-customer account');
for(const tab of ['menu','settings','orders']){merchantTab=tab;assert(merchantDashboard().includes('مطعم تجريبي'),'operator can manage real venues');}
appIdentity=null;ownerCustomerId='';merchantTab='orders';liveWorkspace=freshWorkspace();
assert(forgotView().includes('data-go="reset-key"')&&resetKeyView().includes('id="reset-key-form"'),'one-use recovery route');
assert(passwordView(true).includes('data-go="forgot"')&&!passwordView(true).includes('id="password-form"'),'unverified reset gated');
appIdentity={id:'customer-a',role:'customer'};scopeUser='customer-a';state.favorites=['deal:first'];liveWorkspace.profiles=[{id:'customer-a'}];cart={restaurantId:'test'};switchScope('customer-b');
assert(!appIdentity&&!cart&&!state.favorites.length&&!liveWorkspace.profiles.length,'previous customer memory immediately cleared');
switchScope(null);
assert(!KOD_CONFIG.providers.phone&&!KOD_CONFIG.providers.google&&!KOD_CONFIG.providers.uaepass,'unconfigured external providers must remain disabled');
assert(new URL(KOD_CONFIG.publicAppUrl).hostname==='script.google.com'&&KOD_CONFIG.publicSiteUrl==='https://sites.google.com/view/tawfeer-uae/app','branded Google Sites home and Google deep links');
assert(!authView(true).includes('data-account-type="developer"'),'no public developer signup');
document.querySelector=()=>null;
render('discover');
assert(number(6434)==='6,434'&&number(25.5)==='25.5','Latin digits with grouping and decimal separators');
assert(latinDigits('١٢:٣٠ / ۴۵')==='12:30 / 45','times and both digit scripts in external text');
assert(norm('القطاع ٣٢')===norm('القطاع 32')&&norm('القطاع ۳۲')===norm('القطاع 32'),'branch search accepts all digit forms');
assert(!/[٠-٩۰-۹]/.test(new Date('2026-11-18T12:30:00Z').toLocaleTimeString(UI_LOCALE)+' '+new Date('2026-11-18T12:30:00Z').toLocaleDateString(UI_LOCALE)),'Latin digits in Arabic dates and times');
const testBranch={...officialPlaces[0],name:'فرع ٢٢',area:'القطاع ۳۲'};
const branchCard=placeRow(testBranch);
assert(branchCard.includes('فرع 22')&&branchCard.includes('القطاع 32')&&!/[٠-٩۰-۹]/.test(branchCard),'directory uses Latin digits in imported names and addresses');
const dealWithDigits={...PUBLIC_DEALS[0],priceLabel:'٢٥ د.إ',schedule:'١٢:٣٠',title:'قائمة ٢'};
assert([storyContent(dealWithDigits),dealCard(dealWithDigits)].every(html=>html.includes('25 د.إ')&&html.includes('12:30')&&!/[٠-٩۰-۹]/.test(html)),'featured and listed offers share numeral handling');
assert(CATEGORIES.length===3&&OFFERS.every(o=>['food','coffee','cafeteria'].includes(o.category)),'dining-only data');
assert(APP_ROUTES.has('directory')&&APP_ROUTES.has('deals'),'deep links');
assert(DINING_META.count===geoFixture.rows.length&&Object.keys(DINING_META.cities).length===7,'country coverage and count');
mapPlaces=indexMapData(geoFixture);mapByKey=new Map(mapPlaces.map(p=>[p.key,p]));mapStatus='ready';
assert(mapByKey.size===mapPlaces.length&&mapPlaces.every(p=>p.search&&p.lat&&p.lon),'unique and geocoded locations');
for(const city of CITIES.slice(1))for(const type of Object.keys(VENUE_TYPES)){
  state.city=city;directory.type=type;
  const list=matchingPlaces(mapPlaces);assert(list.length&&list.every(p=>p.emirate===city&&p.type===type),'emirate × type '+city+' '+type);
}
state.city='all';directory.type='all';
for(const cuisine of ['arabic','emirati','indian','western','chinese','italian','japanese','pakistani']){
  directory.cuisine=cuisine;
  assert(matchingPlaces(officialPlaces).length>0,'official cuisine '+cuisine);
  if(cuisine!=='emirati')assert(matchingPlaces(mapPlaces).length>0,'mapped cuisine '+cuisine);
}
directory.cuisine='all';query='الفنر';
assert(matchingPlaces(officialPlaces).every(p=>p.name.includes('الفنر'))&&matchingPlaces(officialPlaces).length>=2,'Arabic branch search');
query='Al Fanar';assert(matchingPlaces(officialPlaces).length>=2,'English name lookup');query='';
assert(state.favorites.length===0&&isDiningFavorite(mapPlaces[0].key)&&!isDiningFavorite('namshi'),'saved dining keys and old retail exclusions');
assert(PUBLIC_DEALS.length>=3&&activeDeals('2027-01-01').every(d=>d.id!=='refuel-creek-coffee-pastry'),'public offer expiry');
assert([...CUISINES.map(c=>c[2]),...Object.values(FEATURED_MENUS).map(s=>s.photo).filter(Boolean),...PUBLIC_DEALS.map(d=>d.photo)].every(p=>Boolean(PHOTOS[p])),'photographs resolve');
assert(officialPlaces.length===DINING_BRANCHES.length&&officialPlaces.length>=38&&new Set(officialPlaces.map(p=>p.emirate)).size===7,'primary-source branches');
assert(offerCard(OFFERS.find(o=>o.id==='shakeshack')).includes('data-menu='),'restaurant menu entry');
const featured=featuredDeals();
assert(featured[0].id==='grand-beirut-galleria-lunch','featured restaurant');
for(let i=1;i<=featured.length;i++){
  changeStory(1);
  assert(document.getElementById('lead-story').innerHTML.includes('data-public-deal="'+featured[i%featured.length].id+'"'),'next cover opens its own offer');
}
assert(storyIndex===0,'carousel loops');
state.city='عجمان';
assert(!featuredDeals().length&&campaignCover().includes('data-directory-open="all"')&&!campaignCover().includes('data-story-step'),'directory cover for an emirate with no active deals');
assert(Object.values(DINING_META.cityTypes[state.city]).reduce((a,b)=>a+b,0)===DINING_META.cities[state.city],'current emirate counts');
state.city='all';
const demoHome=discover();
assert(demoHome.includes('data-directory-open="cafeteria"')&&demoHome.includes('عروض المطاعم والمقاهي')&&!demoHome.includes('نمشي'),'dining homepage');
render('directory');render('deals');render('favorites');
console.log('PASS: nationwide directory, 21 emirate/type combinations, cuisines and bilingual search, published deals and saved keys');
for(const role of ['customer','merchant','developer']){previewRole=role;for(const route of [ROLE_ROUTES[role],'account','orders','food'])render(route);}
previewRole='customer';activeRestaurant='shakeshack';render('menu');addCartItem('shakeshack-item-0');addCartItem('shakeshack-item-0');
assert(cart.lines[0].quantity===2,'cart accumulates quantity');render('cart');assert(cartView().includes('تأكيد طلب تجريبي'),'demo checkout must be explicit');
previewRole='developer';assert(!developerDashboard().includes('@'),'the developer preview contains no contact address');
for(const tab of ['overview','orders','restaurants','users','offers','settings']){developerTab=tab;assert(developerDashboard().length>300,'developer tab '+tab);}
previewRole='merchant';for(const tab of ['orders','menu','settings']){merchantTab=tab;assert(merchantDashboard().length>300,'merchant tab '+tab);}
assert(ORDER_TRANSITIONS.preparing.includes('out_for_delivery')&&ORDER_TRANSITIONS.preparing.includes('ready_for_pickup'),'fulfillment routes');
console.log('PASS: pricing, delivery/pickup, invalid carts, role guards, provider state, all dashboards and cart rendering');
`,sandbox);
vm.runInContext(`(async()=>{
const originalRefresh=refreshAfterPassword;const authCalls=[];
refreshAfterPassword=async()=>{appIdentity={id:'pinned-owner',role:'developer'};};
kodClient={auth:{signInWithPassword:async input=>{authCalls.push(input.email);return {data:{session:{},user:{id:'pinned-owner'}}};},signInWithOtp:async()=>{throw Error('email link requested');}}};
for(let device=0;device<2;device++){
  appIdentity=null;previewRole=null;
  await submitAuth({dataset:{register:'false'},elements:{identifier:{value:'operator@example.test'},password:{value:'fixture-private-value'}},reset(){}});
  assert(location.hash==='developer'&&authCalls.length===device+1,'normal password login reaches owner console on each device');
}
assert(authCalls.every(email=>email==='operator@example.test'),'owner uses the ordinary email/password endpoint');
refreshAfterPassword=originalRefresh;kodClient=null;appIdentity=null;
previewRole='customer';state.membership=true;cart={restaurantId:'shakeshack',lines:[{itemId:'shakeshack-item-0',quantity:2}],method:'delivery',requestId:crypto.randomUUID()};
const before=previewOrders.length,form={elements:{notes:{value:'ملاحظة تجريبية'}},querySelector:()=>({disabled:false})};
await checkoutSubmit(form);assert(previewOrders.length===before+1,'order not created');const created=previewOrders.at(-1);assert(created.total_cents===5950,'checkout total');assert(cart===null,'cart not cleared');
await changeOrderStatus(created.id,'accepted');assert(created.status==='pending','customer could accept order');
previewRole='merchant';for(const next of ['accepted','preparing','out_for_delivery','delivered'])await changeOrderStatus(created.id,next);
assert(created.status==='delivered'&&created.events.length===5,'merchant fulfillment journey');
previewRole='customer';await changeOrderStatus(created.id,'cancelled',true);assert(created.status==='delivered','delivered order cancelled');
console.log('PASS: demo checkout, 59.50 AED total, customer/merchant separation, full delivery timeline, terminal-state protection');
previewRole=null;appIdentity=null;state.city='all';state.membership=false;liveWorkspace=freshWorkspace();
assert(navHtml(true).includes('data-go="food"')&&navHtml(true).includes('data-go="orders"'),'visible mobile order action and order history');
assert(discover().indexOf('class="order-primary"')<discover().indexOf('class="official-shelf"'),'primary ordering above directory');
assert(orderingBranches().length===9&&orderingBranches().every(r=>branchOrderAction(officialByKey.get('venue:'+r.entry.id)).includes('data-restaurant-info')),'branch-specific live ordering');
state.city='عجمان';assert(orderingBranches().length===2&&orderingBranches().every(r=>r.city==='عجمان'),'orders match selected emirate');state.city='all';
assert(!branchOrderAction({id:'no-order'}),'no fabricated checkout at another listing');
const allDirect=[...directVenues.values()];
for(const r of allDirect){
  showRestaurantOrder(r.id);
  const dialog=document.getElementById('modal').innerHTML;
  assert(dialog.includes('إضافة إلى السلة')&&dialog.includes('tel:'+r.contact.phone)&&dialog.includes(r.area),'every published ad and order card includes a branch, contact and basket action');
  assert(menuForOrder(r.id).every(i=>itemForOrder(i.id)===i),'stable catalog item identifiers');
  const selected=r.menu.at(-1);
  assert(dialog.includes('name="menu_item_id"')&&dialog.includes('value="'+selected.id+'"'),'restaurant dialog binds its menu control');
  await submitThroughDocument({id:'direct-add-form',dataset:{venue:r.id},elements:{namedItem:name=>name==='menu_item_id'?{value:selected.id}:null}});
  assert(location.hash==='cart'&&cart?.restaurantId===r.id&&cart.lines[0].itemId===selected.id,'submitting the displayed menu adds the selected item and opens the basket');
  cart=null;
}
const directKitchen=venueForOrder('branch:khafayef-yasmeen');
addCartItem(directKitchen.menu[0].id);addCartItem(directKitchen.menu[1].id);
let summary=directOrderSummary(directKitchen);
assert(summary.priced&&summary.amount===money(4200)&&summary.text.includes('مندي دجاج')&&summary.text.includes('كنافة')&&summary.text.includes('توصيل'),'priced basket carries exact items and fulfillment');
assert(cartView().includes('wa.me/971507990910?text=')&&cartView().includes('نسخ تفاصيل الطلب')&&!cartView().includes('checkout-form'),'real public WhatsApp stays between guest and restaurant');
assert(!['deliveroo.ae','talabat.com'].some(host=>foodView().includes(host)||discover().includes(host)),'no aggregator checkout');
const telVenue=venueForOrder('branch:dtf-emirates');
addCartItem(telVenue.menu[0].id);
assert(cart.restaurantId===directKitchen.id&&document.getElementById('modal').innerHTML.includes('data-replace-cart'),'switching branches requires basket replacement');
addCartItem(telVenue.menu[0].id,true);assert(directOrderSummary(telVenue).priced===false&&cartView().includes('tel:'+telVenue.contact.phone)&&!cartView().includes('wa.me/')&&!cartView().includes('0 د.إ'),'unpublished prices and telephone-only channels handled honestly');
const offer=venueForOrder('offer:pizzaexpress-jlt-wednesday');addCartItem(offer.menu[0].id,true);
assert(cart.method==='dinein'&&cartView().includes('اطلب الحجز عبر واتساب الفرع')&&!cartView().includes('data-fulfillment="delivery"'),'dine-in deal retains restrictions');
const ambiguous=venueForOrder('offer:sea-breeze-rak-indian-lunch');assert(ambiguous.menu[0].price_cents===null,'conflicting reservation prices require branch confirmation');
const expired={...offer,entry:{...offer.entry,endDate:'2000-01-01'}};assert(!availableDirect(expired),'expired offer not orderable after restoration');
assert(branchPhone('٠٤ ٢٦٥ ١٢٨٨')==='+97142651288'&&branchPhone('050 799 0910')==='+971507990910'&&!waLink('javascript:1'),'business contact formats');
cart=null;
activeRestaurant=PRACTICE_VENUE.id;addCartItem('sample-grill');addCartItem('sample-karak');
assert(cartQuote(PRACTICE_VENUE).total_cents===4700,'practice delivery total');cart.method='pickup';
await checkoutSubmit({dataset:{expected:'4000'},elements:{},querySelector:()=>({disabled:false})});
assert(location.hash==='receipt'&&lastReceipt.practice&&!cart&&!previewRole&&!appIdentity,'practice receipt stays out of customer and merchant data');
assert(receiptView().includes('DEMO-')&&!orders().some(o=>o.id===lastReceipt.id),'practice is clearly distinct');
const venue={id:'live-a',name:'QA',city:'دبي',approved:true,is_open:true,is_demo:false,minimum_order_cents:0,delivery_fee_cents:700,percent:10};
liveWorkspace.restaurants=[venue];liveWorkspace.menus=[{id:'meal-a',name:'Meal',restaurant_id:venue.id,is_available:true,price_cents:3000,category:'Meals'}];liveWorkspace.settings.ordering_enabled=true;
cart={restaurantId:venue.id,method:'delivery',requestId:crypto.randomUUID(),lines:[{itemId:'meal-a',quantity:1}]};
assert(cartView().includes('data-checkout-login')&&rememberGuestCheckout(),'guest may sign in from checkout');
assert(!JSON.stringify(guestCheckout).includes('contact_phone'),'handoff contains no contact details');
switchScope('buyer');appIdentity={id:'buyer',role:'customer',name:'QA'};liveWorkspace.restaurants=[venue];liveWorkspace.menus=[{id:'meal-a',name:'Meal',restaurant_id:venue.id,is_available:true,price_cents:3000}];liveWorkspace.settings.ordering_enabled=true;
assert(afterLogin()==='cart'&&cart.lines[0].quantity===1&&!guestCheckout,'guest checkout survives sign-in once');
liveWorkspace.memberships=[{user_id:'another-user',status:'active',expires_at:'2099-01-01'}];assert(cartQuote(venue).total_cents===3700,'discount scoped to purchaser');
let submitted;const row={id:'b1234567-b123',customer_id:'buyer',restaurant_id:venue.id,restaurant_name:'QA',status:'pending',items:[{name:'Meal',quantity:1}],fulfillment:'delivery',created_at:new Date().toISOString(),subtotal_cents:3000,delivery_fee_cents:700,discount_cents:0,total_cents:3700};
kodClient={rpc:async(name,parameters)=>{assert(name==='kod_checkout_order','server checkout');submitted=parameters;return {data:row,error:null};}};
const originalRefreshLive=refreshLiveWorkspace;refreshLiveWorkspace=async()=>{throw Error('offline after successful submission');};
await checkoutSubmit({dataset:{expected:'3700'},elements:{customer_name:{value:'QA'},contact_phone:{value:'٠٥٠١٢٣٤٥٦٧'},delivery_address:{value:'Test address'},notes:{value:''}},querySelector:()=>({disabled:false})});
assert(submitted.p_contact_phone==='+971501234567'&&submitted.p_expected_total===3700&&lastReceipt.id===row.id&&!cart,'normalized phone, confirmed price, successful response retained during outage');
appIdentity.role='developer';liveWorkspace.orders.push({...row,id:'a7654321',customer_id:'another-user',restaurant_name:'PRIVATE-OTHER-ORDER'});assert(!ordersView().includes('PRIVATE-OTHER-ORDER'),'my orders exclude another buyer even for operators');
refreshLiveWorkspace=originalRefreshLive;kodClient=null;switchScope(null);
console.log('PASS: primary order actions, verified direct branch contacts and offers, isolated local practice, guest checkout continuity, purchaser-specific discounts, scope isolation and confirmed live checkout response');

previewRole=null;appIdentity=null;liveWorkspace=freshWorkspace();
assert(memberPage().includes('تنزيل نموذج البطاقة')&&memberPage().includes('تسجيل الدخول لعرض بطاقتي'),'guest can inspect a clearly marked card');
assert(discover().includes('data-go="membership"')&&memberArtHtml(CARD_DEMO,'back').includes('shape-rendering="crispEdges"'),'visible card entry and local QR');
assert(cardCents('١٢٠٫٥٠')===12050&&cardCents('0.55')===55&&cardCents('12.345')===0&&cardCents('-1')===0,'cashier uses exact integer fils');
const exampleNumber='0123456789012345';
assert(cashCardNumber(KOD_CONFIG.publicAppUrl+'#cashier/'+exampleNumber)===exampleNumber&&cashCardNumber('0123 4567 8901 2345')===exampleNumber,'connected scanners and manual input resolve the same member');
assert(!cashCardNumber('https://other.invalid/#cashier/'+exampleNumber)&&!cashCardNumber(KOD_CONFIG.publicAppUrl+'#cashier/'+exampleNumber+'1'),'reject unrelated scanner content');
assert(memberPage().includes('data-card-face="back"')&&memberPage().includes('data-card-print="demo"'),'visitors can view the barcode and print a marked sample');

location.hash='#cashier/'+exampleNumber;assert(cardRoute()==='cashier'&&scannedCard===exampleNumber,'QR links prefill the cashier');
switchScope('cashier-session');assert(scannedCard===exampleNumber,'scanned card survives session restoration');
const cardBranch={id:'merchant-branch',name:'Test branch',approved:true,is_demo:false,owner_id:'merchant-1',instore_percent:20,city:'دبي'};
appIdentity={id:'member-1',role:'customer',name:'Member'};liveWorkspace.card={number:exampleNumber,name:'عضو اختباري',status:'active',expires_at:'2099-01-01'};
liveWorkspace.restaurants=[cardBranch,{...cardBranch,id:'demo',is_demo:true},{...cardBranch,id:'not-opted-in',instore_percent:0}];
const fixed=Date.parse('2028-06-15T08:00:00Z'),end='2029-02-01T00:00:00+04:00',nextEnd='2030-02-01T00:00:00+04:00';
const paidTerm={tier:'gold',starts:'2025-02-01T00:00:00+04:00',ends:end},later={tier:'silver',starts:end,ends:nextEnd};
const actualCard={...connectedCard(),periods:[later,paidTerm],expires_at:nextEnd};
for(const tier of ['bronze','silver','gold']){
  const details=cardEntitlement({...actualCard,periods:[{...paidTerm,tier},later]},fixed);
  assert(details.tier===tier&&details.until===Date.parse(tier==='silver'?nextEnd:end),'correct paid tier and uninterrupted period');
  const raw={...connectedCard(),tier,expires_at:'2099-01-01T00:00:00+04:00'};
  for(const side of ['front','back']){
    const scene=memberArtScene(raw,side),svg=memberArtHtml(raw,side);
    assert(scene.key===tier&&scene.mark===cardMetals[tier].mark&&scene.number==='0123 4567 8901 2345'&&scene.name==='عضو اختباري','actual member identity on artwork');
    assert(scene.paths[0].fill==='@metal'&&scene.gradients.metal.stops[1][1]===cardMetals[tier].face[1]&&svg.includes('data-card-metal="'+tier+'"'),'entire face uses the tier palette');
    assert(scene.labels.some(l=>l.text===cardMetals[tier].mark)&&!scene.labels.some(l=>l.text==='نموذج'),'member tier in upper corner');
    if(side==='front')assert(scene.labels.some(l=>l.text==='31/12/2098')&&scene.labels.some(l=>l.text==='عضو اختباري'),'name and expiry printed');
    else assert(scene.qr.runs.length>0,'personal cashier QR on reverse');
    const sample=memberArtScene(sampleMemberCard(tier),side);
    assert(sample.key===tier&&sample.labels.some(l=>l.text==='نموذج')&&sample.name==='عضو توفير'&&sample.number==='0000 0000 0000 0000','public samples contain only generic details');
  }
}
assert(cardEntitlement(actualCard,Date.parse(end)).tier==='silver'&&cardEntitlement(actualCard,Date.parse(nextEnd)).tier===null,'tier boundary and expiry');
assert(cardEntitlement({...actualCard,status:'cancelled'},fixed).tier===null&&memberArtScene({...actualCard,status:'cancelled'},'front').labels.some(l=>l.text==='موقوفة'),'inactive card does not advertise a tier');
assert(cardPrintedName('user@example.invalid')==='عضو توفير'&&cardPrintedName('+٩٧١ ٥٠ ١٢٣٤٥٦٧')==='عضو توفير','contact details are excluded');
assert(!planButtons().includes('عضو اختباري')&&!planButtons().includes('0123 4567 8901 2345'),'membership selector uses public specimens');
assert(cardIsActive(connectedCard())&&connectedCard().url.endsWith('#cashier/'+exampleNumber)&&memberPage().includes('حفظ البطاقة على الموبايل'),'member can open and save their own card');
assert(cardPartners().length===1&&!cashierPage().includes('card-bill-form'),'only explicitly participating branches and genuine cashiers');
appIdentity={id:'owner-card',role:'developer',name:'Owner'};
liveWorkspace.card={number:'1123456789012345',name:'عضو اختباري',status:'inactive'};
liveWorkspace.cardReceipts=[{customer_id:'member-1',invoice_ref:'PRIVATE-INVOICE'}];
render('membership');
assert(connectedCard().number==='1123456789012345'&&memberPage().includes('data-card-download="own"')&&memberPage().includes('غير مفعّلة')&&!memberPage().includes('PRIVATE-INVOICE'),'operator sees own real card, status and history');
assert(memberPage().includes('data-go="cashier"')&&memberPage().includes('data-member="owner-card"')&&ownerWorkspaceNav('developer').includes('بطاقتي'),'owner retains dashboard and cashier access');
assert(navHtml(true).includes('data-go="membership" class="active" aria-current="page"')&&navHtml(true).includes('بطاقتي'),'mobile shortcut opens and selects the card');
const ownCard=liveWorkspace.card;liveWorkspace.card=null;assert(memberPage().includes('data-card-reload')&&!memberPage().includes('data-card-download="demo"'),'failed load can retry without replacing the personal card with a sample');liveWorkspace.card=ownCard;
previewRole='customer';assert(connectedCard()===null&&memberPage().includes('نموذج بطاقة عضوية توفير')&&!memberPage().includes('data-card-download="own"'),'preview shows the current card artwork as a sample');previewRole=null;
appIdentity.role='developer_locked';assert(connectedCard()===null&&memberPage().includes('تسجيل الدخول لعرض بطاقتي'),'an unverified operator must sign in');
appIdentity={id:'merchant-1',role:'merchant',name:'Merchant'};assert(connectedCard()===null&&cashierPage().includes('card-bill-form'),'cashier does not receive a member card');
assert(memberPage().includes('فتح شاشة الكاشير')&&memberPage().includes('نموذج بطاقة عضوية توفير'),'merchant can see the sample and reach the cashier');
render('cashier');let calledQuote;
kodClient={rpc:async(name,args)=>{assert(name==='kod_instore_bill','server computes in-store bill');calledQuote=args;return {data:{restaurant_name:'Test branch',invoice_ref:'T-1',bill_cents:12000,percent:20,discount_cents:2400,net_cents:9600}};}};
const formBtn={disabled:false},formFeedback={textContent:''};
await submitThroughDocument({id:'card-bill-form',dataset:{},elements:{card:{value:exampleNumber},branch:{value:cardBranch.id},bill:{value:'120'},invoice:{value:'T-1'}},querySelector:s=>s==='button'?formBtn:formFeedback});
assert(calledQuote.p_bill_cents===12000&&!calledQuote.p_request_id&&cashierPage().includes('96 د.إ')&&cashierPage().includes('تأكيد خصم الفاتورة'),'cashier preview is separate from recording');
location.hash='#membership';switchScope('other-customer');assert(!cashierDraft&&!cashierReceipt&&!connectedCard()&&!scannedCard,'previous account card and cashier draft clear together');
appIdentity=null;previewRole=null;paymentAvailability={stripe:[],etisalat:[],du:[]};
const oldQuotes={'bronze/1':6900,'silver/3':18900,'gold/6':35900,'gold/12':59900};
const planRows=Object.keys(CLUB_TIERS).flatMap(tier=>SUBSCRIPTION_TERMS.map(({months})=>({tier,months,amount_fils:oldQuotes[tier+'/'+months]??null,carrier_allowed:!!oldQuotes[tier+'/'+months]})));
applyCatalog(planRows);
chosenTerm=0;chosenTier='bronze';
assert(subscriptionPage().includes('اختر مدة الاشتراك لعرض الإجمالي')&&!subscriptionPage().includes('class="sub-total"'),'initial view has no price until a duration is selected');
for(const row of planRows){
 chosenTier=row.tier;chosenTerm=row.months;
 const buttons=planButtons(),view=subscriptionPage();
 assert((buttons.match(/class="club-plan"/g)||[]).length===3&&(buttons.match(/data-sub-term=/g)||[]).length===4&&!buttons.includes('د.إ')&&!buttons.includes('club-tier-price'),'all tiers always offer four durations with prices off the cards');
 assert(selectedPlan().amount_fils===row.amount_fils&&selectedPlan().tier===row.tier,'pair determines quote');
 assert(view.includes(row.amount_fils===null?'بانتظار تحديد السعر':money(row.amount_fils)),'summary displays the saved price or pending status');
 if(row.amount_fils===null)assert(!view.includes('متابعة للدفع')&&!enabledForTerm('stripe'),'unset options cannot check out');
}
assert(parseMemberPrice('١٢٫٣٥')===1235&&parseMemberPrice('0.01')===1&&parseMemberPrice('')===null&&Number.isNaN(parseMemberPrice('1.234'))&&Number.isNaN(parseMemberPrice('0')),'Arabic entry and strict fractional AED');
sessionStorage.setItem('kod-selected-plan',JSON.stringify({months:3,rail:'stripe'}));restorePlan();assert(chosenTier==='silver'&&chosenTerm===3,'restore older silver selection');
chosenTier='gold';chosenTerm=1;rememberPlan();chosenTier='bronze';chosenTerm=12;restorePlan();assert(chosenTier==='gold'&&chosenTerm===1,'new tier and term survive navigation');
chosenTier='bronze';
assert(memberPage().includes('data-go="subscriptions"')&&discover().includes('data-go="subscriptions"'),'plans accessible from card and home');
assert(subscriptionPage().includes('Apple Pay')&&subscriptionPage().includes('Google Pay')&&subscriptionPage().includes('Mastercard')&&subscriptionPage().includes('فاتورة اتصالات')&&subscriptionPage().includes('فاتورة دو')&&!subscriptionPage().includes('متابعة للدفع'),'pending gateways are visible but not payable');
chosenTerm=1;paymentAvailability={stripe:[1],etisalat:[],du:[]};assert(subscriptionPage().includes('سجّل الدخول للدفع'),'available methods require member sign-in');appIdentity={id:'buyer',role:'customer',name:'عضو'};assert(subscriptionPage().includes('متابعة للدفع · 69'),'eligible live account checkout summary');
clearSubscriptionScope();assert(subscriptionReceipts.length===0&&!receiptEmail&&!returnedReceipt,'no previous payment receipt or email after switching accounts');
previewRole=null;appIdentity=null;rewardInfo=null;programDays=7;
assert(APP_ROUTES.has('marketing')&&APP_ROUTES.has('rewards')&&discover().includes('data-go="rewards"')&&memberPage().includes('data-go="rewards"'),'visible reward entry points');
assert(rewardsPage().includes('سجّل الدخول للحصول على رابطك')&&!rewardsPage().includes('?invite='),'guest has no personal referral link');
const myPromoCode='a06cb102-dc1a-4d6f-a5f0-a801f660bde1';
appIdentity={id:'member1',role:'customer',name:'عضو'};rewardInfo={code:myPromoCode,days:7,joined:3,paid:1,earned_days:7,applied_days:7};
assert(rewardPanel().includes('?invite='+myPromoCode+'#subscriptions')&&rewardPanel().includes('wa.me')&&rewardPanel().includes('facebook.com'),'member sharing controls');
assert(!marketingPage().includes('data-promo-form="rate"')&&!marketingPage().includes('إنشاء رابط الحملة'),'customer cannot see owner tools');
liveWorkspace.cardReceipts=[{id:'owned',customer_id:'member1',restaurant_name:'كافتيريا',bill_cents:8000,discount_cents:1600,net_cents:6400},{id:'private-other',customer_id:'member2',bill_cents:7000,discount_cents:700,net_cents:6300}];
savingsDraft={bill:'350',percent:'20',source:'example'};assert(shareAmounts().afterFils===28000&&shareAmountsView().includes('70 د.إ'),'350 AED before, 280 after');
savingsDraft.source='card-owned';assert(!shareAmounts().example&&shareAmounts().beforeFils===8000&&!savingsStudio().includes('private-other'),'only own confirmed receipts');
savingsDraft={bill:'',percent:'20',source:'example'};assert(shareAmounts()===null,'invalid bill');
location.search='?area=sharjah';captureMarketingEntry();assert(state.city==='الشارقة'&&marketingBanner().includes('في الشارقة'),'regional deep link');
location.search='?invite='+myPromoCode;captureMarketingEntry();promoEntry.inviteOffer={valid:true,days:7,ticket:'signed-invite'};
assert((await registrationMarketingData()).kod_invite_ticket==='signed-invite'&&subscriptionPage().includes('7 أيام عضوية'),'signed ticket used by registration');
assert(captureCompanyRoute('company/'+myPromoCode)&&companyToken===myPromoCode&&subscriptionPage().includes('تفعيل المقعد على حسابي'),'private seat requires confirmation');
cleanPromoEntry();companyToken='';location.search='';clearMarketingScope();assert(!rewardInfo&&!partnerDesk&&savingsDraft.source==='example','marketing account cleared');
appIdentity={id:'owner',role:'developer',name:'المالك'};partnerAdmin={days:7,paid:1,joined:2,earned_days:7};partnerDesk={requests:[],campaigns:[]};
assert(marketingPage().includes('data-promo-form="rate"')&&marketingPage().includes('data-promo-form="campaign"')&&ownerWorkspaceNav('marketing').includes('التسويق والشراكات'),'verified owner campaign tools');
assert(promoAreaLinks().includes('city-umm-al-quwain.html')&&localGuideShare('sharjah').includes('guide=sharjah'),'seven local guides');
assert(ownerWorkspaceNav('developer').includes('data-go="pricing"')&&(priceEditorBody().match(/data-price-months=/g)||[]).length===12,'developer navigation and twelve price fields');
for(const role of ['developer_locked','merchant','customer']){appIdentity.role=role;assert(!membershipPricingPage().includes('data-price-months'),'editing requires a verified operator');}
appIdentity.role='developer';previewRole='customer';assert(!priceEditorBody().includes('data-price-months'),'preview cannot edit prices');
appIdentity=null;previewRole=null;chosenTier='gold';chosenTerm=6;
assert(membershipPricingPage().includes('تسجيل دخول المطوّر')&&APP_ROUTES.has('pricing'),'direct owner link for signed-out visitors');
assert(memberInvoiceSection().includes('سجّل الدخول لطلب فاتورة')&&!memberInvoiceSection().includes('data-member-form'),'guest cannot request or view invoices');
const windowCard={status:'active',expires_at:'2027-03-01',periods:[{tier:'silver',starts:'2026-10-01',ends:'2027-01-01'},{tier:'gold',starts:'2027-01-01',ends:'2027-03-01'}]};
assert(activeClubTier(windowCard,Date.parse('2026-12-31'))==='silver'&&activeClubTier(windowCard,Date.parse('2027-01-01'))==='gold'&&!activeClubTier(windowCard,Date.parse('2027-03-01')),'valid tier boundaries');
assert(clubDiscount(15,{silver_extra:5},'silver')===20&&clubDiscount(0,{gold_extra:12},'gold')===0,'branch and channel opt-in');
state.city='دبي';featuredPublic={price_fils:14900,restaurants:[{id:'sponsored',booking:'bk',name:'Paid Branch',city:'دبي',ends:'2099-01-01'},{id:'other',name:'Other Emirate',city:'عجمان',ends:'2099-01-01'},{id:'expired',name:'Expired Branch',city:'دبي',ends:'2000-01-01'}]};
assert(featuredRail().includes('Paid Branch')&&!featuredRail().includes('Other Emirate')&&!featuredRail().includes('Expired Branch')&&featuredPage().includes('دخول صاحب المطعم'),'regional sponsored rail, expiry and merchant entry');
appIdentity={id:'buyer',role:'customer'};chosenTier='gold';chosenTerm=3;
assert(!memberInvoiceBody().includes('data-member-form="request"'),'customer cannot order an unpriced term');chosenTier='silver';
assert(memberInvoiceBody().includes('طلب فاتورة العضوية الفضية')&&!memberInvoiceBody().includes('data-member-form="settle"'),'customer can request the selected tier but cannot confirm payments');
const invoiceFixture={id:'abbccdfe-invoice',mine:true,club_tier:'silver',months:3,state:'invoiced',name:'عضو',amount_fils:18900,note:'private terms',url:'https://example.invalid/inv'};
memberBills={invoices:[invoiceFixture]};assert(memberInvoiceBody().includes('private terms')&&memberInvoiceBody().includes('https://example.invalid/inv')&&!memberInvoiceBody().includes('data-member-form="request"'),'own open bill details and duplicate prevention');
chosenTier='bronze';applyCatalog(planRows.map(r=>r.tier==='bronze'&&r.months===3?{...r,amount_fils:8450}:r));assert(memberInvoiceBody().includes('data-member-form="request"')&&memberInvoiceBody().includes('84.5'),'open silver invoice does not block bronze for the same duration');
appIdentity.role='developer';assert(memberInvoiceBody().includes('data-member-form="settle"')&&!memberInvoiceBody().includes('data-feature-form="settle"'),'member payment editor uses member settlement only');
clearSubscriptionScope();assert(!memberBills&&!memberInvoiceBody().includes('private terms'),'previous customer invoices clear with account');
console.log('PASS: named tiers, expiry boundaries, checkout benefits, sponsored rail filtering, separated private billing and owner settlement forms');
console.log('PASS: referral reward journey, signed registration, share links, privacy, real savings, corporate claim and operator campaigns');
console.log('PASS: subscription navigation, all four terms and advertised amounts, availability, payment rails and scoped UI');
console.log('PASS: member artwork and QR route, saved card, visible entry, scope reset, eligible branches and exact cashier quote');
})()`,sandbox).catch(e=>{console.error(e);process.exitCode=1;});
